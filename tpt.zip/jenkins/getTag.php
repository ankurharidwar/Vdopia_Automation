<?php 

header ('Content-type: text/plain');

$type = $_GET['type'];
$tag = $_GET['tag'];

$ch = curl_init ();
curl_setopt ($ch, CURLOPT_HEADER, 0);


if ($type == 'portal')
  {
    if ($tag == '' || $tag == 'master')
      {
		curl_setopt ($ch, CURLOPT_URL, 'http://portal.vdopia.com/version.txt?'.uniqid ());
		$tag = curl_exec ($ch);
		curl_close ($ch);
      }
      else
      {
       	print_r($tag);
      }
  }
else if ($type == 'vanilla')
  {
    if ($tag == '' || $tag == 'master')
      {
		curl_setopt ($ch, CURLOPT_URL, 'http://serve.vdopia.com/version.txt?'.uniqid ());
		$tag = curl_exec ($ch);
		curl_close ($ch);
      }
	else
      {
       	print_r($tag);
      }
	}
else if ($type == 'objectserver')
	{
      if ($tag == '' || $tag == 'master')
		{
	  		$tag = 'master';
		}
       	print_r($tag);
	}
else
    {
      curl_close ($ch);
    }
  exit ();
  
?>