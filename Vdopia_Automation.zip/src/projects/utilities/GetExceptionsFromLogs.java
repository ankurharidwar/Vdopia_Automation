/**
 * Last Changes Done on Jan 19, 2015 2:31:00 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Refactorying chocolate code into keyword driven framework 
 */

package projects.utilities;

import java.io.File;
import java.util.Date;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.jcraft.jsch.Session;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import projects.TestSuiteClass;
import vlib.ExecuteCommands;
import vlib.MobileTestClass_Methods;



public class GetExceptionsFromLogs 
{
	@Test
	public static void getChocolateExceptions()
	{
		//Get and parse the urls from the source page of the utility(hosted on dev server to fetch the urls from production)
		String chocolateIP = MobileTestClass_Methods.propertyConfigFile.getProperty("[chocolateIP]").toString().trim()+":8080";
		String automationPemFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/qa-automation.pem");
		String chocolateServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[chocolateIP]").toString().trim();
		Session sessionChocolateServer = ExecuteCommands.createSessionWithPrivateKey("ubuntu", automationPemFile, chocolateServer);
		WebDriver driver = MobileTestClass_Methods.WebDriverSetUp("chrome", null);
		String fileLocation = GetProductionCalls.parseURL(driver,chocolateIP, "100");
	
		//iterate excel sheet
		iterateExcel(driver, sessionChocolateServer, fileLocation, "/mnt/tmp/hudson/log/hudson.log");

		//close session
		sessionChocolateServer.disconnect();
		driver.quit();	
	}

	/**
	 * This method will get the exception from the chocolate log or page source if any
	 * @param driver
	 * @param session
	 * @param chocolateRequest
	 * @param hudsonLogFileLocation
	 * @return
	 */
	public static String chocolateTest(WebDriver driver, Session session, String chocolateRequest, String hudsonLogFileLocation)
	{
		String exceptionLog ="";

		try
		{
			String timeStamp = String.valueOf(new Date().getTime());
			String copiedHudsonLog = "/tmp/hudson_"+timeStamp+".log";

			// Copying hudson.log to temp file
			System.out.println(" : Copying "+hudsonLogFileLocation+" to temp file "+ copiedHudsonLog +"....");
			ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "cp " + hudsonLogFileLocation + " " + copiedHudsonLog);

			System.out.println(" : sending request ....."+ chocolateRequest);

			// Sending all request through http with custom headers, now browser will not be opened			
			driver.get(chocolateRequest);
			String response = driver.getPageSource();

			// Get the log for current execution using diff command and store output at tmpHudsonLogFile and use this for further processing
			String diffFile = "/tmp/diff_"+timeStamp;
			ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "diff " + hudsonLogFileLocation + " " + copiedHudsonLog + " | grep \"<\" | sed 's/^<//g' >  " + diffFile );
			System.out.println(" : hudson log for this iteration is stored at: "+diffFile);

			//get exception
			String exception = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "grep -i 'exception' "+diffFile);
			if(response.toLowerCase().contains("Exception"))
			{
				exceptionLog = response;
			}
			if(!exception.isEmpty())
			{
				exceptionLog = exceptionLog + "\n" +diffFile;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return exceptionLog;
	}

	/**
	 * This method will iterate the excel sheet in which prod url is written and call the chocolateTest method 
	 * @param driver
	 * @param session
	 * @param urlFile
	 * @param hudsonLogFileLocation
	 * @return
	 */
	public static boolean iterateExcel(WebDriver driver, Session session, String urlFile, String hudsonLogFileLocation)
	{
		boolean flag = false;

		try
		{
			Workbook book = Workbook.getWorkbook(new File(urlFile));
			WritableWorkbook copiedBook = Workbook.createWorkbook(new File(urlFile), book);
			WritableSheet sheet = copiedBook.getSheet(0);

			//add request column
			Label resultColumnName = new Label(1, 0, "Results");
			sheet.addCell(resultColumnName);

			for(int i=1; i<sheet.getRows(); i++)
			{
				String url = sheet.getCell(0, i).getContents();
				String output = chocolateTest(driver, session, url, hudsonLogFileLocation);

				/** add result in sheet */
				Label label = new Label(1, i, output);
				sheet.addCell(label);
			}

			copiedBook.write();
			copiedBook.close();
			book.close();

			flag = true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return flag;
	}

}