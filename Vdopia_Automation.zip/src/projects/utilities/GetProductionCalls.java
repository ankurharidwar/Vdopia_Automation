package projects.utilities;

import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import vlib.ExecuteCommands;
import vlib.FileLib;

public class GetProductionCalls 
{

	public static WebDriver getDriver()
	{
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);

		return driver;
	}

	/**
	 * This method will get and parse the urls from the source page of the utility(hosted on dev server to fetch the urls from production) 
	 * @param chocolateHost
	 * @param numberOfRequests
	 * @return
	 */
	public static String parseURL(WebDriver driver, String chocolateHost, String numberOfRequests)
	{
		String filelocation = "";

		try
		{
			driver.get("http://dev.vdopia.com/hudsonLogGrep/lookup_entry.py");
			driver.findElement(By.xpath("//input[@name='latest_num']")).sendKeys(numberOfRequests);
			driver.findElement(By.xpath("//input[@value='Submit']")).click();

			String response = driver.getPageSource().trim();

			//do not write of empty response is received
			if(!response.isEmpty())
			{
				String tmpFile = System.getProperty("java.io.tmpdir").concat("tmp");
				System.out.println("Writing Response in temp file: "+tmpFile);

				FileLib.WriteTextInFile(tmpFile, response);
				response = ExecuteCommands.ExecuteMacCommand_ReturnsOutput("grep -i 'adserver/html5/inwapads' "+ tmpFile +" | awk -F 'GET' '{print $2}'");

				List<String> list = Arrays.asList(response.split("\n"));

				String urls = "";
				for(int i=0; i<list.size(); i++)
				{
					String url = list.get(i);

					if(!url.isEmpty())
					{
						String tobeReplaced = url.substring(url.indexOf("HTTP/1.1"), url.length());
						url = url.replace(tobeReplaced, "").trim();
						url = "http://"+chocolateHost + url;

						urls = urls + url + "\n";
					}
				}

				//write url in file
				filelocation = "/tmp/url_file.xls";
				System.out.println("URL Written in file: "+filelocation);

				writeURLInExcel(filelocation, urls);
				//FileLib.WriteTextInFile(filelocation, urls);
			}
			else
			{
				System.out.println("Empty response received from production url, no requests will be written. ");
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}

		return filelocation;
	}

	/**
	 * This method will write the paserd urls in excel sheet
	 * @param driverFile
	 * @param urlString
	 * @return
	 */
	public static boolean writeURLInExcel(String driverFile, String urlString)
	{
		List<String> urls = Arrays.asList(urlString.split("\n"));
		boolean flag = false;

		try
		{
			FileOutputStream outputfile = new FileOutputStream(driverFile,true);
			WritableWorkbook book = Workbook.createWorkbook(outputfile);
			WritableSheet driverSheet = book.createSheet("Sheet1", 0);

			//add request column
			Label urlLblColumnName = new Label(0, 0, "Requests");
			driverSheet.addCell(urlLblColumnName);

			for(int i=0; i<urls.size(); i++)
			{
				String url = urls.get(i).replace("&amp;", "&");

				/** add result in sheet */
				Label label = new Label(0, i+1, url);
				driverSheet.addCell(label);
			}

			book.write();
			book.close();

			flag = true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return flag;
	}

}
