/**
 * Last Changes Done on Jan 19, 2015 3:46:15 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Added change to ignore those bidder who were timedout while responding, get biddercountry = geo if geo is supplied
 */

package projects.chocolate.lib.bidders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import projects.chocolate.lib.jsonHandler.JSONParserLib;
import projects.chocolate.lib.utils.ChocolateCommands;
import projects.chocolate.lib.utils.GetChocolateLogs;
import projects.chocolate.lib.utils.GetDeviceInformation;
import projects.chocolate.lib.utils.Maxmind;
import projects.chocolate.lib.utils.ReadChocolateConfig;

import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

public class BiddersLib 
{
	static Logger logger = Logger.getLogger(BiddersLib.class.getName());


	/** Get Picked Bidder Id From Chocolate from bq mx log json string, bq mx log json string contains bidderCount
	 * which will be the count of bidder picked up to make request.
	 * Actual Logic is ==>  Total Bidder Selected = bidderCount in BQMXLog + bidder filtered in white/blacklisting
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getSelectedBiddersFromBqLog(Session session, String tmpHudsonLogFile)
	{
		List<String> actualBiddersPickedup = new ArrayList<String>();		

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting bidder bidder list from Bq log and file is: "+tmpHudsonLogFile);

			/** Getting json string output of above command */
			String jsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);

			actualBiddersPickedup = JSONParserLib.getAllBidderIdFromBqLog(jsonString);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Bidder Ids Received From Bq Log: "+actualBiddersPickedup.toString());
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting bidder ids from bq mx log. " , e);
		}
		finally
		{
			return actualBiddersPickedup;
		}
	}


	/** Getting vdopia rtb bidders information map from selected bidder list from bq log, this method will return a map containing
	 * bidderurl, bidderid and request to be posted for all vdopia bidders.
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param connection
	 * @return
	 */
	public static HashMap<String, HashMap<String, String>> getSelectedVdopiaBiddersInfo(Session session, String tmpHudsonLogFile, Connection connection)
	{
		HashMap<String, HashMap<String, String>> selectedVdopiaBiddersInfo = new HashMap<>();		

		try
		{
			/** Get bidder and data to be post map */
			HashMap<String, String> bidderRequestMap = BiddersLib.getBidder_DataToBePostedMapFromLog(session, tmpHudsonLogFile);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting bidder bidder list from Bq log and file is: "+tmpHudsonLogFile);

			/** Getting json string output of above command */
			String jsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);

			List<String> actualBiddersPickedup = JSONParserLib.getAllBidderIdFromBqLog(jsonString);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Bidder Ids Received From Bq Log: "+actualBiddersPickedup.toString());

			/** Proceed only if there are some selected bidders */
			if(!actualBiddersPickedup.isEmpty())
			{
				/** getting vdopia bidders from the selected bidder list from bq log */
				for(int i=0; i<actualBiddersPickedup.size(); i++)
				{
					String bidder = actualBiddersPickedup.get(i).trim();
					HashMap<String, String> bidderInformation = DBLib.getBidderInformation(bidder, connection);

					if(bidderInformation.get("isvdopiabidder").equalsIgnoreCase("1") 
							&& bidderInformation.get("biddertype").contains("rtb"))
					{
						/** get bidder url */
						String bidderUrl = bidderInformation.get("bidderurl");

						/** get request to be posted from map: bidderRequestMap */
						String requestToBePosted = bidderRequestMap.get(bidder);

						/** putting vdopia bidder information: bidderid, bidderurl and datatobeposted in map */
						HashMap<String, String> vdopiaBiddersInfo = new HashMap<>();
						vdopiaBiddersInfo.put("bidderid", bidder);
						vdopiaBiddersInfo.put("bidderurl", bidderUrl);
						vdopiaBiddersInfo.put("request", requestToBePosted);

						/** put the information in final map with key = bidderid and value = vdopiaBiddersInfo */
						selectedVdopiaBiddersInfo.put(bidder, vdopiaBiddersInfo);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting vdopia bidder information. " , e);
		}

		return selectedVdopiaBiddersInfo;
	}


	/** This method will return the expected bidder ad format based on the supplied ad format in test url
	 *  
	 * @param fileNameWithLocation
	 * @param adformat
	 * @param outputType
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getExpectedAdFormatsForHudsonBidder(String fileNameWithLocation, HashMap<String, String> requiredExpectedParameters)
	{
		List<String> expectedAdFormats = new ArrayList<String>();

		try
		{
			String requestType = requiredExpectedParameters.get("requestType");

			/** handling get calls */
			if(requestType.equalsIgnoreCase("GET"))
			{
				/** Getting expected ad formats for bidder */
				String adformat = requiredExpectedParameters.get("adFormat");
				String outputType = requiredExpectedParameters.get("output");

				/** These are fixed values, can't be changed. */
				String sheetName = "BidderAdformats";
				String columnForKey = "Adformat/Output";	

				//This method will return a hash map having key from Column = Adformat/Output and value from Column = outputType
				HashMap<String, String> hashMap = XlsLib.getHashMapFromExcelsheet(fileNameWithLocation, sheetName, columnForKey, outputType);
				String value = hashMap.get(adformat);

				//Checking if there is no expected ad format for rtb object creation
				if(value.equalsIgnoreCase("NONE") || value.equalsIgnoreCase("NA") || value.isEmpty())
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no expected bidder ad format found for supplied ad format: "+adformat);
				}
				else
				{
					//Get expected ad formats in a list
					expectedAdFormats = Arrays.asList(value.split(","));
				}
			}
			/** handling post calls */
			else
			{
				expectedAdFormats = getBidderAdformatsForPostRequest(requiredExpectedParameters);

			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting expected supported bidder ad formats.", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Ad Formats For Hudson Bidder: "+expectedAdFormats.toString());
			return expectedAdFormats;
		}
	}


	/**
	 * This methord will
	 * @param requiredExpectedParameters
	 * @return
	 */

	public static List<String> getBidderAdformatsForPostRequest(HashMap<String, String> requiredExpectedParameters)
	{
		List<String> adFormats = new ArrayList<>();
		if(requiredExpectedParameters.get("adformatnode").equalsIgnoreCase("banner"))
		{
			if(requiredExpectedParameters.get("w").equalsIgnoreCase("300") && requiredExpectedParameters.get("h").equalsIgnoreCase("250"))
			{
				adFormats.add("video");
				adFormats.add("bannerNinterstitial");
			}
			else if (requiredExpectedParameters.get("w").equalsIgnoreCase("320") && requiredExpectedParameters.get("h").equalsIgnoreCase("480")) 
			{
				adFormats.add("video");
				adFormats.add("bannerNinterstitial");
			}
			else if (requiredExpectedParameters.get("w").equalsIgnoreCase("480") && requiredExpectedParameters.get("h").equalsIgnoreCase("320")) 
			{
				adFormats.add("video");
				adFormats.add("bannerNinterstitial");
			}
		}
		else
		{
			if(requiredExpectedParameters.get("w").equalsIgnoreCase("300") && requiredExpectedParameters.get("h").equalsIgnoreCase("250"))
			{
				adFormats.add("video");
			}
			else if (requiredExpectedParameters.get("w").equalsIgnoreCase("320") && requiredExpectedParameters.get("h").equalsIgnoreCase("480")) 
			{
				adFormats.add("video");
			}
			else if (requiredExpectedParameters.get("w").equalsIgnoreCase("480") && requiredExpectedParameters.get("h").equalsIgnoreCase("320")) 
			{
				adFormats.add("video");
			}
		}
		return adFormats;
	}

	/** Get expected eligible bidder list for chocolate from database.
	 * 
	 * @param fileNameWithExpectedData
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getExpectedBidderIdsFromDB(String fileNameWithExpectedData, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> expectedBidderList = new ArrayList<String>();

		try
		{
			String bidderPlatform = requiredExpectedParameters.get("type");
			String ipAddress = requiredExpectedParameters.get("ip");

			/** Getting bidder country code from maxmind based on supplied ip address, but in case there is any target_params are
			 * supplied with geo parameter then bidderCountryCode will be value of geo 
			 */
			String bidderCountryCode;
			if(requiredExpectedParameters.get("geo") != null)
			{
				bidderCountryCode = requiredExpectedParameters.get("geo"); 
			}
			else
			{
				bidderCountryCode = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "country");
			}

			/** Getting expected supported biddersAdformats */ 
			List<String> bidderAdformats = BiddersLib.getExpectedAdFormatsForHudsonBidder(fileNameWithExpectedData, requiredExpectedParameters );

			//			if(requestType.equalsIgnoreCase("GET"))
			//			{ 
			//				String output = requiredExpectedParameters.get("output");
			//				bidderAdformats = BiddersLib.getExpectedAdFormatsForHudsonBidder(fileNameWithExpectedData, adFormat, output, requestType);
			//			}
			//			else
			//			{
			//				/** in case of post request, adformat can be either of banner/video */
			//				bidderAdformats.add(adFormat);
			//			}

			/** Getting market place setting of given channel */
			String marketPlaceSetting = requiredExpectedParameters.get("market_place_setting");
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : market_place_setting is: "+marketPlaceSetting);

			/** In case market place setting is null, assigning default value */
			if(!(marketPlaceSetting != null))
			{
				marketPlaceSetting = "all_bidders_vdopia_optional";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Market Place Setting is null, re-asigning to = all_bidders_vdopia_optional");
			}

			/** Initializing bidderStatus,isVdopiaBidder as these will change depending upon market place setting */
			String bidderStatus = "Approved";
			String isVdopiaBidder = "";

			/** In case market_place_setting is test_bidders_only, pick only test bidders */
			if(marketPlaceSetting.equalsIgnoreCase("test_bidders_only"))
			{
				bidderStatus = "Test";
			}
			else
			{
				/** Get isVdopiaBidderValue based on market place setting */
				isVdopiaBidder = BiddersLib.getVdopiaBidderValueForGivenMarketPlaceSetting(marketPlaceSetting);
			}

			/** If market place setting is not test_bidders_only, 
			 * then get the expected bidders based on additional field IsVdopiaBidder */
			String subQuery = "";
			if(bidderStatus.equalsIgnoreCase("Test"))
			{
				subQuery = "";
			}
			else
			{
				subQuery = " AND IsVdopiaBidder IN ("+ isVdopiaBidder + ") " ;
			}

			/** Getting expected bidders from database using above information from test url */
			String query = 
					"SELECT BidderId FROM hudsonBidder WHERE BidderStatus = '" + bidderStatus + "' " +
							subQuery +
							" AND BidderPlatform LIKE '%"+ bidderPlatform +"%' " +
							" AND ( BidderCountryCode LIKE '%"+ bidderCountryCode +"%' OR BidderCountryCode = '' ) AND ";

			subQuery = "";

			/** Forming sub clause based on adformats provided for bidder */
			for(int i=0; i<bidderAdformats.size(); i++)
			{
				subQuery = subQuery + " BidderAdformat LIKE '%"+ bidderAdformats.get(i) +"%' " ;

				if(i != bidderAdformats.size()-1)
				{
					subQuery = subQuery + " OR ";
				}
			}

			/** Adding a condition enabledonTablet based on the supplied user agent, if ua is from tablet then 
			 * get those bidders which has enabledonTablet = 1 else get bidders with enabledonTablet = 0
			 */
			String userAgent = requiredExpectedParameters.get("ua");
			String isTablet = GetDeviceInformation.getDeviceInformation(userAgent).get("istablet").trim();

			String enabledOnTablet = "";
			//wurfl used to send isTablet = true/false, device atlas sends 1/0
			if(isTablet.equalsIgnoreCase("1"))
			{
				enabledOnTablet = " AND EnabledOnTablet in ('1', '0') ";
			}
			else
			{
				enabledOnTablet = " AND EnabledOnTablet = '0' ";
			}

			/** Making full query */
			query = query + "(" +subQuery + ")" + enabledOnTablet;


			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting expected bidder list by executing query: "+query);

			/** Getting bidder id into a list */
			expectedBidderList = MobileTestClass_Methods.ExecuteMySQLQueryReturnsList(connection, query);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting expected bidders from database. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected bidders found in database: "+expectedBidderList.toString());

			return expectedBidderList;
		}

	}


	/**
	 * This method will match the expected and actual picked up bidders. from
	 * expected bidder list - filtered bidder (Blacklisted / Whitelisted bidder)
	 * will be removed before matching.
	 * 
	 * @param fileNameWithExpectedData
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static String validateBidderSelection(String fileNameWithExpectedData, Session session, String tmpHudsonLogFile, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #################### Validating Bidder Selection ###################");

		String result = "";

		try
		{
			/** Getting expected bidder count and ids */
			List<String> expectedBidderList = getExpectedBidderIdsFromDB(fileNameWithExpectedData, requiredExpectedParameters, connection);			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Bidders From DB: "+expectedBidderList.toString() +" Count: "+expectedBidderList.size());

			/** 1. Get non white-black listed bidders */
			expectedBidderList = BidderWhiteBlackListingLib.getNonWhiteBlackListedBidders(expectedBidderList, requiredExpectedParameters, connection);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Bidders After Checking White/BlackListing: "+expectedBidderList.toString() +" Count: "+expectedBidderList.size());

			/** 2. Getting those bidders which have a match in bidder and channels filters */
			expectedBidderList = BidderFiltersLib.getNotFilteredBidders(expectedBidderList, requiredExpectedParameters, connection);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Bidders After Checking Filters: "+expectedBidderList.toString() +" Count: "+expectedBidderList.size());

			/** 3. Excluding cyclic bidders - if advertiser and publisher accounts are matched */
			expectedBidderList = BidderFiltersLib.getNonCyclicBidders(expectedBidderList, requiredExpectedParameters, connection);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Bidders After Excluding Cyclic Ones: "+expectedBidderList.toString() +" Count: "+expectedBidderList.size());

			/** 4. Excluding vast bidders having effective bidder price < channel floor price */
			expectedBidderList = BidderFiltersLib.getVastBidderAboveFloorPrice(expectedBidderList, requiredExpectedParameters, connection);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Bidders After Excluding Vast Bidder Having Lower Effective Bid Price: "+expectedBidderList.toString() +" Count: "+expectedBidderList.size());

			/** 5. Excluding moat enabled bidders for output = vast requests */
			expectedBidderList = requiredExpectedParameters.get("output").equalsIgnoreCase("vast") ? BidderFiltersLib.getNonMoatBidderForVastRequest(expectedBidderList, connection, requiredExpectedParameters) : expectedBidderList; 
			
			/** 6. Getting bluekai matched bidders */
			expectedBidderList = BidderFiltersLib.getBluekaiMatchedBidders(requiredExpectedParameters, expectedBidderList, connection);
			
			/** Getting actual picked up bidder count and ids from hudson temp log file */
			List<String> actualSelectedBidderList = BiddersLib.getSelectedBiddersFromBqLog(session, tmpHudsonLogFile);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Picked Bidders: "+ actualSelectedBidderList.toString() + " Count: "+actualSelectedBidderList.size());

			/** Getting unmatched value from expected list in actual one */
			List<String> unmatchedFromExpected = StringLib.getUnmatchedValuesFromTwoLists(expectedBidderList, actualSelectedBidderList);

			/** Getting extra value from actual list than the actual one */
			List<String> extraValuesInActual = StringLib.getUnmatchedValuesFromTwoLists(actualSelectedBidderList, expectedBidderList);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Unmatched Expected Bidders: "+unmatchedFromExpected + " Extra Actual Bidders: "+extraValuesInActual);

			/** collect bidder selection result */
			result = collectBidderSelectionResult(expectedBidderList, actualSelectedBidderList, unmatchedFromExpected, extraValuesInActual);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while validation bidder selection. ",e);
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result Of Bidder Selection Test: ");
		logger.info(result);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #################################################################");

		return result;
	}


	/** get collective result of comparing actual and expected selected bidders.
	 * 
	 * @param expectedBidderList
	 * @param actualSelectedBidderList
	 * @param unmatchedFromExpected
	 * @param extraValuesInActual
	 * @return
	 */
	public static String collectBidderSelectionResult(List<String> expectedBidderList, List<String> actualSelectedBidderList, 
			List<String> unmatchedFromExpected, List<String> extraValuesInActual) 
	{
		String result = "";

		/** Collecting results 
		 *
		 * IN Case there is no expected bidder found in db
		 */
		if(expectedBidderList.size()<1 && actualSelectedBidderList.size()<1)	
		{
			result = "PASS: There was no expected bidders therefore none was picked up for bidding for this request. ";
		}
		else
		{
			if(unmatchedFromExpected.size()<1 && extraValuesInActual.size()<1)
			{
				result = "PASS: Expected: "+ expectedBidderList.size() +" bidders were picked up for bidding. ";
			}
			else if(unmatchedFromExpected.size()<1 && extraValuesInActual.size()>0)
			{
				result = "FAIL: Extra Bidders: "+extraValuesInActual.toString() +" were picked up for bidding. ";
			}
			else if(unmatchedFromExpected.size()>0 && extraValuesInActual.size()<1)
			{
				result = "FAIL: Expected Bidders: "+unmatchedFromExpected.toString() +" were not picked up for bidding. ";
			}
			else if(unmatchedFromExpected.size()>0 && extraValuesInActual.size()>0)
			{
				result = result + "\n" + "FAIL: Expected Bidders: "+unmatchedFromExpected.toString() +" were not picked up for bidding. ";
				result = result + "\n" + "Extra Bidders: "+extraValuesInActual.toString() + " were picked up for bidding. ";
			}
		}

		return result;
	}


	/** This method will return the public variable actualSelectedVdopiaRTBBidderCount set by method validateHudsonBidderSelection
	 * @return
	 */
	public static int getActualSelectedVdopiaRTBBidderCount(Session session, String tmpHudsonLogFile, Connection connection)
	{
		List<String> actualSelectedBidderList = BiddersLib.getSelectedBiddersFromBqLog(session, tmpHudsonLogFile);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Picked Bidders: "+actualSelectedBidderList.toString());

		int actualSelectedVdopiaRTBBidderCount = DBLib.getVdopiaRTBBidderCount(actualSelectedBidderList, connection);
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Selected RTB Vdopia Bidder Count: "+actualSelectedVdopiaRTBBidderCount);

		return actualSelectedVdopiaRTBBidderCount;
	}


	/** This method will return a hashmap containing campaign id, channel id and ad id from winning rtb bidder's response. 
	 * This method will be utilized while checking the trackers at the time of serving the winning bidder's response.
	 *  
	 * @param session
	 * @param tmpHudsonLogFile
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> getAdInformationOfWinningBidder(Session session, String tmpHudsonLogFile, Connection connection)
	{
		HashMap<String, String> adInformation = new HashMap<String, String>();
		try
		{
			/** Get all bidders information from bq mx log
			 */
			String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
			TreeMap<String, HashMap<String, String>> bidderInformation = JSONParserLib.getAllBiddersInfoFromBqLog(bqmxJsonString);

			/** Getting expected number of rtb_bp trackers by checking the number of rtb vdopia bidders and putting into final map */
			int expectedrtb_bpTracker =  getExpectedrtb_bpTrackerCount(bidderInformation, connection);
			adInformation.put("rtb_bp", String.valueOf(expectedrtb_bpTracker));

			/** Get seat bid node of winning bidder from bq mx json string received above
			 */
			bqmxJsonString = JSONParserLib.getWinningBidderSeatBidFromBqLog(bqmxJsonString);

			/** Getting the cid, adid and crid from winning bidder's seatbid node
			 */
			//<Input json of winning bidder>
			HashMap<String, String> information = JSONParserLib.parseAdInfoFromSeatBidNode(bqmxJsonString);
			adInformation.putAll(information);

			//			adInformation.put("adid", JSONParserLib.parseAdInfoFromSeatBidNode(bqmxJsonString).get("adid"));
			//			adInformation.put("cid", JSONParserLib.parseAdInfoFromSeatBidNode(bqmxJsonString).get("cid"));
			//			adInformation.put("crid", JSONParserLib.parseAdInfoFromSeatBidNode(bqmxJsonString).get("crid"));
		}
		catch(Exception e)
		{	
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while creating the hashmap containing the adid information of the winning rtb bidder. ", e);
		}
		finally
		{
			return adInformation;
		}

	}


	/** This method will get the count of Vdopia RTB Bidders who has responded with correct values,
	 * This count will be equal to the expected rtb_bp tracker count.
	 * For this get all the bidder and their response status from bq mx log and then find out vdopia rtb bidders out of them 
	 * who has correct response status. 
	 * 
	 * @param bidderResponse
	 * @return
	 */
	@SuppressWarnings("finally")
	public static int getExpectedrtb_bpTrackerCount(TreeMap<String, HashMap<String, String>> bidderInformation, Connection connection)
	{
		int count = 0;
		try
		{
			for(Entry<String, HashMap<String, String>> map : bidderInformation.entrySet())
			{
				String bidderId = map.getKey();

				/** Get bidder information from db, if no information received from db then don't proceed
				 */
				HashMap<String, String> bidderInformationFromDB = DBLib.getBidderInformation(bidderId, connection);

				if(!bidderInformationFromDB.isEmpty())
				{
					String bidderType = bidderInformationFromDB.get("biddertype");
					String isvdopiabidder = bidderInformationFromDB.get("isvdopiabidder");

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : bidderType: "+bidderType + ", isvdopiabidder: "+isvdopiabidder);

					/** Checking the vdopia rtb bidder from the supplied whole bidder list
					 */
					if(bidderType.contains("rtb") && isvdopiabidder.equalsIgnoreCase("1"))
					{
						count = count + 1;
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting the count of rtb vdopia bidders. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : RTB Bidders: "+count + " Therefore Expected RTB_BP Trackers = "+count);
			return count;
		}
	}


	/** This method will return the standard adformats with respect to bidder adformats = 'video','bannerNinterstitial' 
	 * to be used later on.
	 */
	public static String getBidderRespectiveAdFormat(String bidderAdFormat)
	{		
		if(bidderAdFormat.equalsIgnoreCase("bannerNinterstitial") || bidderAdFormat.equalsIgnoreCase("banner"))
		{
			bidderAdFormat = "banner";
		}
		else if(bidderAdFormat.equalsIgnoreCase("video"))
		{
			bidderAdFormat = "video";
		}

		return bidderAdFormat;
	}


	/** This method will return the all rtb bidder and data to be posted map
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> getBidder_DataToBePostedMapFromLog(Session session, String tmpHudsonLogFile)
	{			
		HashMap<String, String> bidderRequestMap = new HashMap<>();
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting request to be posted json and corresponding bidders from hudson.log...");

			/** command to get bidder and respective request to be posted 
			 */
			String command = new ChocolateCommands().formCommandToReadLog(tmpHudsonLogFile, "dataToBePosted");
			String commandOutput = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, command);

			/** Trim un-desired characters */
			commandOutput = commandOutput.replace(">", "\n").trim().replace("<", "\n").trim();

			List<String> list = Arrays.asList(commandOutput.split("\n"));

			for(int i=0; i<list.size(); i++)
			{
				if(!list.get(i).isEmpty())
				{
					String bidderID = list.get(i).split("####")[0].trim();
					String requestToBePosted = list.get(i).split("####")[1].trim();
					bidderRequestMap.put(bidderID, requestToBePosted);
				}
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Data to be posted:");
			logger.info(commandOutput);			
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting rtb object string from hudson log. ", e);
		}
		finally
		{
			return bidderRequestMap;
		}

	}


	/** This method will return the expected isVdopiaBidder value based on supplied market place setting
	 * 
	 * @param marketPlaceSetting
	 * @return
	 */
	public static String getVdopiaBidderValueForGivenMarketPlaceSetting(String marketPlaceSetting)
	{
		//Given Market Place Setting Values: ('all_bidders_vdopia_optional','vdopia_bidders_only','all_bidders_vdopia_mandatory','no_bidders')

		String isVdopiaBidder = "DO_NOT_PICK_ANY_BIDDER";

		if(marketPlaceSetting.equalsIgnoreCase("all_bidders_vdopia_optional"))
		{
			isVdopiaBidder = " '1', '0' ";
		}
		else if(marketPlaceSetting.equalsIgnoreCase("vdopia_bidders_only"))
		{
			isVdopiaBidder = " '1' ";
		}
		else if(marketPlaceSetting.equalsIgnoreCase("all_bidders_vdopia_mandatory"))
		{
			isVdopiaBidder = " '1', '0' ";
		}
		else if(marketPlaceSetting.equalsIgnoreCase("no_bidders"))
		{
			isVdopiaBidder = " 'DO_NOT_PICK_ANY_BIDDER' ";
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : isVdopiaBidder value: "+isVdopiaBidder);
		return isVdopiaBidder;
	}


	/** This method creates a hash map containing bidder and their bidding price from the bidder response written in bq mx log from the log file.
	 * First the bq mx json string will be parsed and bidder with valid status will be considered and these bidders' price will be written in
	 * the final tree map and this map will be used further to check pricing validation.
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static TreeMap<String, String> getBidderPricingMap(Session session, String tmpHudsonLogFile, String hudsonMappings, HashMap<String, String> requiredExpectedParameters, Connection con)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting expected bidder id and their bidding price from mq mx log from file: "+tmpHudsonLogFile);

		TreeMap<String, String> bidderPricingMap = new TreeMap<String, String>();

		try
		{
			/** Get the bq mx json string
			 */
			String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);

			if(!bqmxJsonString.isEmpty())
			{
				/** Get all the blocked bidder status from configuration file.
				 */
				List<String> excludedBidderStatus = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("bidderResponseStatus");

				/** Get tree map containing all bidders' information from bq mx log.
				 */
				TreeMap<String, HashMap<String, String>> bidderInformation = JSONParserLib.getAllBiddersInfoFromBqLog(bqmxJsonString);

				/** Iterate the received the bidder information tree map and omit those bidders whose response status is one of blockedBidderStatus   
				 */
				for(Entry<String, HashMap<String, String>> bidderMap : bidderInformation.entrySet())
				{
					/** Get key from bidderInformation map
					 */
					String bidderID = bidderMap.getKey();

					/** Get value  from bidderInformation map
					 */
					String responseStatus = bidderMap.getValue().get("responseStatus");
					String bidPrice = bidderMap.getValue().get("bidPrice");

					/** Keep only those bidders whose status is not excluded.
					 */
					if(!excludedBidderStatus.contains(responseStatus))
					{
						bidderPricingMap.put(bidderID, bidPrice);
					}
				}				
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No bqmx json string was received in log file: "+tmpHudsonLogFile);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while preparing bidder pricing map from "+tmpHudsonLogFile, e);
		}
		finally
		{
			return bidderPricingMap;
		}
	}


}
