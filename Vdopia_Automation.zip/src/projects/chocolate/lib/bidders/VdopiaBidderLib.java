/**
 * Last Changes Done on 14 Jul, 2015 1:18:01 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.bidders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.mysql.jdbc.Connection;

import projects.chocolate.lib.jsonHandler.JSONParserLib;

import vlib.DBLib;
import vlib.httpClientWrap;

public class VdopiaBidderLib 
{

	static Logger logger = Logger.getLogger(VdopiaBidderLib.class.getName());


	/** Getting expected keys in no ad vdopia bidder response 
	 * @return
	 */
	public static List<String> getExpectedNoAdVdopiaResponseFields()
	{
		/** Getting expected keys in a list */

		List<String> expectedNoAdResponseKeys = new ArrayList<>();
		expectedNoAdResponseKeys.add("id");
		expectedNoAdResponseKeys.add("bidid");
		expectedNoAdResponseKeys.add("nbr");

		return expectedNoAdResponseKeys;
	}


	/** Getting expected keys in ad vdopia bidder response
	 * @return
	 */
	public static List<String> getExpectedAdVdopiaResponseFields(String keyType)
	{
		/** Getting expected keys in a list */
		List<String> expectedAdResponseKeys = new ArrayList<>();

		if(keyType.equalsIgnoreCase("main"))
		{
			expectedAdResponseKeys.add("id");
			expectedAdResponseKeys.add("bidid");
			expectedAdResponseKeys.add("seatbid");
		}
		else if(keyType.equalsIgnoreCase("seatbid"))
		{
			expectedAdResponseKeys.add("seat");
			expectedAdResponseKeys.add("bid");
		}
		else if(keyType.equalsIgnoreCase("bid"))
		{
			expectedAdResponseKeys.add("iurl");
			expectedAdResponseKeys.add("adomain");
			expectedAdResponseKeys.add("crid");
			expectedAdResponseKeys.add("impid");
			expectedAdResponseKeys.add("price");
			expectedAdResponseKeys.add("adid");
			expectedAdResponseKeys.add("nurl");
			expectedAdResponseKeys.add("adm");
			expectedAdResponseKeys.add("id");
			expectedAdResponseKeys.add("cid");
		}

		return expectedAdResponseKeys;
	}

	/** This method will validate the vdopia bidder response(structure, vast type)*/
	public static String validateVdopiaBidderResponse(String bidder,String requestURL, String postRequest)
	{
		String result = "";
		try {

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received bidder is : " +bidder);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received requested url is : " +requestURL);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received postRequest is : " +postRequest);

			/** Get the response after hit the post request to vdopia*/
			String response = httpClientWrap.sendPostRequest(requestURL, postRequest);

			/** Validate the structure of the json vdopia response*/
			result = validateVdopiaBidderResponseStructure(bidder, response);

			/** Validate the vast type(InLine/Wrraper) from the vdopia response */
			result  = result + validateVastTypeOfVdopiaBidder(response);

		} catch (Exception e) {

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting exception when validating the vdopia bidder response: "+e);

		}
		return result;
	}



	/** Validate vdopia bidder response - check if expected fields are present in response.
	 * 
	 * @param requestURL
	 * @param postRequest
	 * @return
	 */
	public static String validateVdopiaBidderResponseStructure(String bidder, String response)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Validating vdopia bidder response of bidder: "+bidder);
		String result = "";
		try
		{

			boolean proceed = true;
			JSONObject jsonObj = null;

			try {
				jsonObj = new JSONObject(response);
			}catch (JSONException e) {
				proceed = false;
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received vdopia bidder response is not a valid json. ");
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Response From Vdopia Bidder: "+response);
			}

			/** Proceed to further test only if a valid json is received */
			if(proceed)
			{
				try
				{
					/** get json array from response of key = seatbid, if no json array found
					 *  then check ad response and macros in nurl else check no ad response */

					jsonObj.getJSONArray("seatbid");
					result = JSONParserLib.parseVdopiaBidderAdResponse(response);

					String nurl = JSONParserLib.getVdopiaBidderNURL(response);
					result = result + "\n" + validateVdopiaNURL(nurl);
				}
				catch(JSONException j)
				{
					result = JSONParserLib.parseVdopiaBidderNoAdResponse(response);
				}
			}
			else
			{
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : FAIL: Response received from vdopia bidder, is not a valid json. Response received: "+response+".");
				result = "FAIL: Response received from vdopia bidder, is not a valid json.";
			}
		}
		catch(Exception e)
		{
			result = result + " Error occurred while checking vdopia bidder response. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking vdopia bidder response. ", e);
		}

		return result;
	}


	/** Validating macros in received nurl from vdopia bidder response. 
	 * 
	 * @param nurl
	 * @return
	 */
	public static String validateVdopiaNURL(String nurl)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Validating macros present in nurl responded by vdopia bidder. ");

		List<String> notPresentMacro = new ArrayList<String>();

		try
		{
			/** splitting received nurl and converting into a list */
			List<String> params = Arrays.asList(nurl.split("/"));

			/** get expected macros */
			List<String> expectedMacro = getExpectedVdopiaBidderNURLMacros();

			/** Checking each expected macro in nurl */ 
			for(int i=0; i<expectedMacro.size(); i++)
			{
				if(!params.contains(expectedMacro.get(i)))
				{
					notPresentMacro.add(expectedMacro.get(i));
				}
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking nurl in vdopia bidder's response.", t);
		}

		if(notPresentMacro.isEmpty())
		{
			return "PASS: nurl has expected macros: AUCTION_BID_ID, AUCTION_IMP_ID, AUCTION_AD_ID and AUCTION_PRICE. ";
		}
		else
		{
			return "FAIL: nurl doesn't have macro(s): "+notPresentMacro.toString();
		}

	}


	/** This method will return the expected list of macros in nurl present in 
	 * vdopia bidder's response.
	 * 
	 * @return
	 */
	public static List<String> getExpectedVdopiaBidderNURLMacros()
	{
		List<String> expectedMacro = new ArrayList<String>();

		expectedMacro.add("${AUCTION_BID_ID}");
		expectedMacro.add("${AUCTION_IMP_ID}");
		expectedMacro.add("${AUCTION_AD_ID}");
		expectedMacro.add("${AUCTION_PRICE}");

		return expectedMacro;
	}

	/**
	 * This method will verify the vast type (inline/wrraper) from vdopia bidder response
	 * 
	 * @param response
	 * @return
	 */
	public static String validateVastTypeOfVdopiaBidder(String response)
	{
		String result = "";
		try {

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received response is:" + response);
			JSONObject jsonResponse = new JSONObject(response);
			JSONArray seatbid = jsonResponse.getJSONArray("seatbid");
			String adm = seatbid.getJSONObject(0).getJSONArray("bid").getJSONObject(0).getString("adm");

			if(adm.toLowerCase().contains("inline"))
			{
				result = "PASS: Vdopia bidder responded with vast inline."; 
			}
			else if(adm.toLowerCase().contains("wrapper"))
			{
				result = "FAIL: Vdopia bidder responded with vast wrapper.";
			}

		} catch (JSONException e) {

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : FAIL : Getting exception when validating vast type from vdopia bidder response :" + e );
		}

		return result;
	}


	/** This method will check the vdopia winning bidder information like winurl, nurl, iurl etc...
	 * 
	 * @return
	 */
	public static String validateWinningVdopiaBidderInformation(String bqmxJsonString, Connection NewCon)
	{
		String result = "";

		// 1. find winning bidder
		String winningBidderId =  JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);

		// 2. proceed only if there is a winning bidder
		if(!winningBidderId.isEmpty())
		{
			HashMap<String, String> bidderInformation  = DBLib.getBidderInformation(winningBidderId, NewCon);

			// 3. check winning bidder is vdopia
			if(bidderInformation.get("biddertype").equalsIgnoreCase("rtb21") && bidderInformation.get("isvdopiabidder").equalsIgnoreCase("1"))
			{
				// 4. Getting iurl, nurl and winurl of winning bidder from bq log
				HashMap<String, String> map = JSONParserLib.parseWinningInformationsFromBqLog(bqmxJsonString);
				String iurl = null ;
				try {
					iurl = map.get("iurl").trim();
				}catch(NullPointerException e){
					result = result + "\n Fail : iurl node is not available for winning bidder in log";
				}
				// 5. Getting campaign id of winning vdopia bidder from bq log
				String winningBidderSeatBidJson = JSONParserLib.getWinningBidderSeatBidFromBqLog(bqmxJsonString);
				HashMap<String, String> AdInfoMap = JSONParserLib.parseAdInfoFromSeatBidNode(winningBidderSeatBidJson);

				//6. Getting the infomation of campaign
				String cid  = AdInfoMap.get("cid");
				HashMap<String, String> campaignInfoMap = DBLib.getCampaignInformation(cid, NewCon);
				String screenshot_url = campaignInfoMap.get("screenshot_url").trim();

				// 7. Matching screen shot url getting from database with iurl getting from bq log

				if (iurl != null)
				{
					if (screenshot_url.equalsIgnoreCase(iurl))
					{
						result = result + "\nPass : Expeacted and Actual iurl matched ";
					}
					else{
						result = result + "\nFail : Expected iurl : " + screenshot_url + " and Actual iurl : " + iurl + " not matched.";
					}
				}

				String bidderUrl = bidderInformation.get("bidderurl");
				String partialSplitUrl = bidderUrl.replaceAll("adrequest", "").replaceAll("/hudson", "").trim();
				//				String[] SplitBiddewrUrl = bidderUrl.split("/");
				//				String partialSplitUrl = null;
				//				for (int i =1; i <=5 ; i++)
				//				{
				//					partialSplitUrl += SplitBiddewrUrl[i] + '/';
				//				}
				// 8. Verifying the nurl value getting in bq log
				String nurl = null ;
				try {
					nurl = map.get("nurl").trim();
				}catch(NullPointerException e){
					result = result + "\n Fail : nurl node is not available for winning bidder in log";
				}

				//Getting the publisher info
				HashMap<String, String> publisherInfo = DBLib.getPublisherInformation(NewCon);
				String publisherId = publisherInfo.get("id");
				String expectednurl = partialSplitUrl+"win/hudson_rtb/"+publisherId+"/general/${AUCTION_BID_ID}/${AUCTION_IMP_ID}/${AUCTION_AD_ID}/${AUCTION_PRICE}".trim();

				if (nurl != null)
				{
					if(nurl.equalsIgnoreCase(expectednurl))
					{
						result = result + "\nPass : Expeacted nurl matches with Actual nurl.";
					}
					else{
						result = result + "\nFail : Expected nurl " + expectednurl +" not matched with actual " + nurl;
					}
				}

				// 9. Verifying the winurl value getting in bq log
				String winurl = null ;
				try {
					winurl = map.get("winurl").trim();
				}catch(NullPointerException e){
					result = result + "\n Fail : winurl node is not available for winning bidder in log";
				}
				String expectedWinurl = partialSplitUrl+"win/hudson_rtb/"+publisherId+"/general/${AUCTION_BID_ID}/${AUCTION_IMP_ID}/${AUCTION_AD_ID}/${AUCTION_PRICE}".trim();
				if(winurl != null)
				{
					if(winurl.equalsIgnoreCase(expectedWinurl))
					{
						result = result + "\nPass : Expected winurl matches with Actual winurl.";
					}
					else{
						result = result + "\nFailed : Expected winurl "+ expectedWinurl + " not matched with actual winurl " + winurl;
					}
				}
			}
			else
			{
				result = "SKIP: Vdopia bidder wasn't the winner therefore bidder information (iurl, winurl, nurl) wasn't validated.";
			}
		}
		else 
		{
			result = "SKIP: There was no winning bidder found therefore skipping vdopia bidder information (iurl, winurl, nurl) validation.";
		}
		return result;
	}
}

