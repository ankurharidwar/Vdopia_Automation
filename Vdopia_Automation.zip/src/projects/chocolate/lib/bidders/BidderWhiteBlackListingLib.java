/**
 * Last Changes Done on 15 May, 2015 10:45:44 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains methods to find out bidders filtered with whitelisting and blacklisting
 * 
 *  Blacklist, WhiteList Concept:
 *  based on supplied type parameter = site/app or kind of apikey: site/app in url:
 *  Domain is considered in case of site and Bundle is considered in case of App.
 *  BlackListing: Bidder Domain should not contain specific parameter only.
 *  WhiteListing: Bidder Domain should contain specific parameters only.
 */

package projects.chocolate.lib.bidders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;


import vlib.DBLib;


public class BidderWhiteBlackListingLib 
{

	static Logger logger = Logger.getLogger(BidderWhiteBlackListingLib.class.getName());


	/** This method will check if the supplied bidders' domain is blacklisted or whitelisted 
	 * 
	 * @param requiredExpectedParameters
	 * @param bidderId
	 * @param connection
	 */
	public static boolean isBidderNotFiltered(String bidderId, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		boolean bidderNotFiltered = false;

		try
		{
			String requestPlatform = requiredExpectedParameters.get("type").toLowerCase().trim();
			//String requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();
			
			String requestDomain;
			if(requiredExpectedParameters.get("type").equalsIgnoreCase("app"))
			{
				requestDomain = requiredExpectedParameters.get("bundle").toLowerCase().trim();
			}
			else
			{
				requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();
			}

			if(requestPlatform != null)
			{
				List<String> blackListedDomain = DBLib.getFilteredBidderDomain(bidderId, "blacklist", requestPlatform, connection);
				List<String> whiteListedDomain = DBLib.getFilteredBidderDomain(bidderId, "whitelist", requestPlatform, connection);

				boolean blackListCheck = false;
				boolean whiteListCheck = false;

				/** Check condition only when there is any list received from db; */
				if(!blackListedDomain.isEmpty())
				{
					if(!blackListedDomain.contains(requestDomain)){
						blackListCheck = true;
					}
				}
				else
				{
					blackListCheck = true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no black list received from db for bidder: "+bidderId +" considering it not filtered. ");
				}

				if(!whiteListedDomain.isEmpty())
				{
					if(whiteListedDomain.contains(requestDomain)){
						whiteListCheck = true;
					}
				}
				else
				{
					whiteListCheck = true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no white list received from db for bidder: "+bidderId +" considering it not filtered. ");
				}

				bidderNotFiltered = blackListCheck && whiteListCheck;
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : platform wasn't supplied. ");
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking if bidder is filtered: "+bidderId, t);
		}
		return bidderNotFiltered;
	}


	/** Get filtered bidder domain list.
	 * 
	 * @param bidderId
	 * @param filter
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static List<String> getFilteredBidderDomainList(String bidderId, String filter, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> filteredDomain = new ArrayList<String>();

		try
		{
			String requestPlatform = requiredExpectedParameters.get("type").toLowerCase().trim();

			if(requestPlatform != null)
			{
				if(filter.contains("whitelist"))
				{
					filteredDomain = DBLib.getFilteredBidderDomain(bidderId, "whitelist", requestPlatform, connection);
				}
				else
				{
					filteredDomain = DBLib.getFilteredBidderDomain(bidderId, "blacklist", requestPlatform, connection);
				}
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : platform wasn't supplied. ");
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting filtered domain: "+bidderId, t);
		}
		return filteredDomain;
	}


	/** This method will check if the supplied bidders' domain is whitelisted 
	 * 
	 * @param requiredExpectedParameters
	 * @param bidderId
	 * @param connection
	 */
	public static boolean ifBidderHasWhiteListedDomain(String bidderId, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		boolean whiteListCheck = false;

		try
		{
			String requestPlatform = requiredExpectedParameters.get("type").toLowerCase().trim();
			String requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();

			if(requestPlatform != null)
			{
				List<String> whiteListedDomain = DBLib.getFilteredBidderDomain(bidderId, "whitelist", requestPlatform, connection);

				if(!whiteListedDomain.isEmpty())
				{
					if(whiteListedDomain.contains(requestDomain)){
						whiteListCheck = true;
					}
					else{
						whiteListCheck = false;
					}
				}
				else
				{
					whiteListCheck = false;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no white list domain received from db for bidder: "+bidderId);
				}
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : platform wasn't supplied. ");
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking if bidder is whitelisted: "+bidderId, t);
		}
		return whiteListCheck;
	}


	/** This method will check if the supplied bidders' domain is blacklisted in db 
	 * 
	 * @param requiredExpectedParameters
	 * @param bidderId
	 * @param connection
	 */
	public static boolean ifBidderHasBlackListedDomain(String bidderId, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		boolean blackListCheck = false;

		try
		{
			String requestPlatform = requiredExpectedParameters.get("type").toLowerCase().trim();
			String requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();

			if(requestPlatform != null)
			{
				List<String> blackListedDomain = DBLib.getFilteredBidderDomain(bidderId, "blacklist", requestPlatform, connection);

				/** Check condition only when there is any list received from db; */
				if(!blackListedDomain.isEmpty())
				{
					if(blackListedDomain.contains(requestDomain)){
						blackListCheck = true;
					}
				}
				else
				{
					blackListCheck = false;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no black list received from db for bidder: "+bidderId );
				}
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : platform wasn't supplied. ");
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking if bidder is filtered: "+bidderId, t);
		}
		return blackListCheck;
	}


	/** Mapping: 
	 * WHITELIST | BLACKLIST | 	FINAL CHECK
	 * 1		|	0	|		WHITELIST
	 * 0		|	1	|		BLACKLIST
	 * 1		|	2	|		WHITELIST
	 * 1		|	1	|		BLACKLIST
	 * 
	 * @param requiredExpectedParameters
	 * @param connection
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param fileNameWithExpectedData
	 */
	public static String validateWhiteBlackListing(HashMap<String, String> requiredExpectedParameters, Connection connection, 
			Session session, String tmpHudsonLogFile, String fileNameWithExpectedData)
	{
		String result = "";

		try
		{
			/**1. Get all expected bidders based on supplied parameters in url and iterate the list to check if any bidder is filtered.
			 */
			List<String> allExpectedBidders = BiddersLib.getExpectedBidderIdsFromDB(fileNameWithExpectedData, requiredExpectedParameters, connection);

			/**1a. If there is no expected bidder, then skip test
			 */
			if(!allExpectedBidders.isEmpty())
			{
				/**2. Get all bidders for whom data to posted request was created, 
				 * Converting the bidders from map into a list
				 */
				HashMap<String, String> dataToBePostedbidderMap = BiddersLib.getBidder_DataToBePostedMapFromLog(session, tmpHudsonLogFile);
				List<String> dataToBePostedbidderList = new ArrayList<>(dataToBePostedbidderMap.keySet());

				/**3. Get all bidders whom connections were made from bq mx logs */
				List<String> allBidderFromBqMXLog = BiddersLib.getSelectedBiddersFromBqLog(session, tmpHudsonLogFile);

				for(int i=0; i<allExpectedBidders.size(); i++)
				{
					String bidderId = allExpectedBidders.get(i);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking filtered bidder: "+bidderId);

					/** Checking if the bidder has a domain which is black listed, if yes, then data to be posted 
					 * should NOT be created */
					//					boolean bidderWhiteListed = ifBidderHasWhiteListedDomain(bidderId, requiredExpectedParameters, connection);
					//					boolean bidderBlackListed = ifBidderHasBlackListedDomain(bidderId, requiredExpectedParameters, connection);

					List<String> whiteListedDomain = getFilteredBidderDomainList(bidderId, "whitelist", requiredExpectedParameters, connection);
					List<String> blackListedDomain = getFilteredBidderDomainList(bidderId, "blacklist", requiredExpectedParameters, connection);

					/** Getting results */
					if(!whiteListedDomain.isEmpty())
					{
						result = result + getWhiteListingResult(connection, dataToBePostedbidderList, allBidderFromBqMXLog, whiteListedDomain, requiredExpectedParameters, bidderId);
					}
					else
					{
						result = result + getBlackListingResult(connection, dataToBePostedbidderList, allBidderFromBqMXLog, blackListedDomain, requiredExpectedParameters, bidderId);
						result = result + "\nWhitelisted domain not found for bidder: "+bidderId; 
					}
				}
			}
			else
			{
				result = "SKIP: No expected bidders found for this request therefore skipping white/black listing validation. ";
			}
		}
		catch(Exception e)
		{
			result = "SKIP: Exception occurred while checking black and white listing. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking black and white listing. ", e);
		}

		return result;
	}


	/** This method will return the result after checking white and black listing bidders.
	 * 
	 * @param dataToBePostedbidderList
	 * @param allBidderFromBqMXLog
	 * @param bidderBlackListed
	 * @param bidderWhiteListed
	 * @param bidderId
	 * @return
	 */
	public static String getWhiteListingResult(Connection connection, List<String> dataToBePostedbidderList, List<String> allBidderFromBqMXLog,
			List<String> whiteListedDomain, HashMap<String, String> requiredExpectedParameters, String bidderId)
	{
		String result = "";

		if(!whiteListedDomain.isEmpty())
		{
			String requestDomain;
			if(requiredExpectedParameters.get("type").equalsIgnoreCase("app"))
			{
				requestDomain = requiredExpectedParameters.get("bundle").toLowerCase().trim();
			}
			else
			{
				requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();
			}

			/** white listed bidder should be in bq mx log and there should be data to be posted for that bidder */
			if(whiteListedDomain.contains(requestDomain))
			{
				if(!dataToBePostedbidderList.contains(bidderId))
				{
					/** FOR VAST BIDDER, DATA TO BE POSTED WILL NOT BE CREATED */
					if(!DBLib.getBidderType(bidderId, connection).toLowerCase().contains("vast"))
					{
						result = result + "  " + "FAIL: Data to be posted wasn't created for whitelisted bidder: "+bidderId;
					}
				}
				else
				{
					result = result + "  " + "PASS: Data to be posted was created for whitelisted bidder: "+bidderId;
				}

				if(!allBidderFromBqMXLog.contains(bidderId))
				{
					result = result + "  " + "FAIL: Whitelisted bidder: "+ bidderId +" is not present in BQ MX log.";
				}	
				else
				{
					result = result + "  " + "PASS: Whitelisted bidder: "+ bidderId +" is present in BQ MX log.";
				}
			}
			/** if request doesn't contain the whitelisted domain then data to be posted should not be created */
			else
			{
				if(dataToBePostedbidderList.contains(bidderId))
				{
					/** FOR VAST BIDDER, DATA TO BE POSTED WILL NOT BE CREATED */
					if(!DBLib.getBidderType(bidderId, connection).toLowerCase().contains("vast"))
					{
						result = result + "  " + "FAIL: Data to be posted was created for bidder: "+bidderId + " which has \n" +
								" a different whitelisted domain than supplied in request. ";
					}
				}
				else
				{
					result = result + "  " + "PASS: Data to be posted was created for bidder: "+bidderId;
				}

				if(allBidderFromBqMXLog.contains(bidderId))
				{
					result = result + "  " + "FAIL: bidder: "+ bidderId +" which has \n" +
							" a different whitelisted domain than supplied in request, is present in BQ MX log whereas it shouldn't be. ";
				}
				else
				{
					result = result + "  " + "PASS: Whitelisted bidder: "+ bidderId +" is present in BQ MX log.";
				}
			}
		}
		else
		{
			result = "SKIP: There is no whitelisted domain found for bidder: "+bidderId;
		}

		logger.debug(result);

		return result.trim();
	}


	/** This method will generate result for black listed bidder domain 
	 * 
	 * @param connection
	 * @param dataToBePostedbidderList
	 * @param allBidderFromBqMXLog
	 * @param bidderBlackListed
	 * @param bidderId
	 * @return
	 */
	public static String getBlackListingResult(Connection connection, List<String> dataToBePostedbidderList, List<String> allBidderFromBqMXLog,
			List<String> blackListedDomain, HashMap<String, String> requiredExpectedParameters, String bidderId)
	{
		String result = "";

		if(!blackListedDomain.isEmpty())
		{
			String requestDomain;
			if(requiredExpectedParameters.get("type").equalsIgnoreCase("app"))
			{
				requestDomain = requiredExpectedParameters.get("bundle").toLowerCase().trim();
			}
			else
			{
				requestDomain = requiredExpectedParameters.get("domain").toLowerCase().trim();
			}

			if(blackListedDomain.contains(requestDomain))
			{
				/** black listed bidder should not be in bq mx log and there should not be any data to be posted for that bidder */
				if(dataToBePostedbidderList.contains(bidderId))
				{
					if(!DBLib.getBidderType(bidderId, connection).toLowerCase().contains("vast"))
					{
						result = result + "  " + "FAIL: Data to be posted was created for blacklisted bidder: "+bidderId ;
					}
				}
				else
				{
					result = result + "  " + "PASS: Data to be posted was not created for blacklisted bidder: "+bidderId ;
				}

				if(allBidderFromBqMXLog.contains(bidderId))
				{
					result = result + "  " + "FAIL: Blacklisted bidder: "+ bidderId +" is present in BQ MX log.";
				}	
				else
				{
					result = result + "  " + "PASS: Blacklisted bidder: "+ bidderId +" is not present in BQ MX log.";
				}
			}
			else
			{
				result = result + "  " + "SKIP: Bidder: "+bidderId + " has blacklisted domain: "+blackListedDomain.toString() +
						" whereas request has domain: "+requestDomain + " therefore skipping validation.";
			}
		}
		else
		{
			result = "SKIP: There is no blacklisted domain found for bidder: "+bidderId;
		}

		logger.debug(result);

		return result.trim();
	}


	/** This method will return the non filtered bidders (non white/blacklisted) from the supplied bidder list.
	 * 
	 * @param bidderList
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static List<String> getNonWhiteBlackListedBidders(List<String> bidderList, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> finalBidderList = new ArrayList<>();
	
		try
		{
			for(int i=0; i<bidderList.size(); i++)
			{
				String bidderId = bidderList.get(i);
	
				/** Checking each bidder from the supplied list and adding that into finalBidderList if bidder
				 * is not filtered.
				 */
				boolean flag = BidderWhiteBlackListingLib.isBidderNotFiltered(bidderId, requiredExpectedParameters, connection);
	
				if(flag)
				{
					finalBidderList.add(bidderId);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting non filtered bidders. ", e);
		}
		return finalBidderList;
	}

}
