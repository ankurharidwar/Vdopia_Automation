/**
 * Last Changes Done on 26 Aug, 2015 4:45:58 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.bidders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.mysql.jdbc.Connection;

import projects.chocolate.lib.utils.AerospikeHandler;
import projects.chocolate.lib.utils.ReadChocolateConfig;

import vlib.DBLib;

public class BidderFiltersLib 
{

	static Logger logger = Logger.getLogger(BidderFiltersLib.class.getName());


	/** This method matches all the filters of bidder with channels and returns true only if all matches else false;
	 * 
	 * @param bidderInformation
	 * @param requiredExpectedParameters
	 * @return
	 */
	public static boolean isChannelBidderFilterMatched(HashMap<String, String> bidderInformation, HashMap<String, String> requiredExpectedParameters)
	{
		boolean flag = false;

		String bidderid = bidderInformation.get("bidderid");

		/** getting a list of supported bidder filters */
		List<String> supportedFilters = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("bidderFilters");

		/** iterating the supported filters received from config file */
		for(int i=0; i<supportedFilters.size(); i++)
		{
			String filter = supportedFilters.get(i);

			/** checking the above filter at bidder side */
			if(bidderInformation.containsKey(filter))
			{
				/** checking if channel side parameter has the filter */
				if(requiredExpectedParameters.containsKey(filter))
				{
					String strBidderFilter = bidderInformation.get(filter);
					String strChannelFilter = requiredExpectedParameters.get(filter);

					if(strBidderFilter.equalsIgnoreCase(strChannelFilter))
					{
						flag = true;
						continue;
					}
					else
					{
						flag = false;
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : filter: "+filter + ", channel side value: "+strChannelFilter + ", bidder side value: "+strBidderFilter );

						break;
					}
				}
				else
				{
					flag = false;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : filter: "+filter + " is not present at bidder side, exiting after setting final flag: "+flag);

					break;
				}
			}
			else
			{
				continue;
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Final filters match flag for bidder: "+bidderid + " is: "+flag);
		return flag;
	}


	/** This method will return the bidder list which have matching filters with respect to channel setting.
	 * 
	 * @param expectedBidderList
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static List<String> getNotFilteredBidders(List<String> expectedBidderList, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> bidderOkay = new ArrayList<>();

		for(int i=0; i<expectedBidderList.size(); i++)
		{
			String bidderId = expectedBidderList.get(i);
			HashMap<String, String> bidderInformation = DBLib.getBidderInformation(bidderId, connection);

			/** if there is no bidder additional setting the its not filtered one */
			if(bidderInformation.get("bidderadditionalsettings").trim().isEmpty())
			{
				bidderOkay.add(bidderId);
			}
			/** if bidder additional setting has blank filter json then also its open to all channel, not filtered */
			else if(Integer.parseInt(bidderInformation.get("bidderfiltercount")) < 1)
			{
				bidderOkay.add(bidderId);
			}
			/** check if there is any filter defined. */
			else
			{
				boolean isBidderOk = BidderFiltersLib.isChannelBidderFilterMatched(bidderInformation, requiredExpectedParameters);

				if(isBidderOk)
				{
					bidderOkay.add(bidderId);
				}
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Returning non filtered bidders: "+bidderOkay.toString());
		return bidderOkay;
	}


	/** Get those bidder whose advertiser and publisher accounts are not matching.
	 * 
	 * @param expectedBidderList
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static List<String> getNonCyclicBidders(List<String> expectedBidderList, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> bidderOkay = new ArrayList<>();
		String publisherEmail = requiredExpectedParameters.get("publisher_email");

		for(int i=0; i<expectedBidderList.size(); i++)
		{
			String bidderId = expectedBidderList.get(i);

			/** if bidder's advertiser account and publisher account is same then exclude this bidder */
			if(!publisherEmail.equalsIgnoreCase(DBLib.getBidderInformation(bidderId, connection).get("advertiser_email")))
			{
				bidderOkay.add(bidderId);
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Cyclic Bidder: "+bidderId + " Excluding this bidder... ");
			}
		}

		return bidderOkay;
	}


	/**
	 * Get vast bidders - having higher effective price than channel floor price
	 * @param expectedBidderList
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	public static List<String> getVastBidderAboveFloorPrice(List<String> expectedBidderList, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		List<String> lowPriceVastBidder = new ArrayList<>();
		float channelFloorPrice = Float.parseFloat(requiredExpectedParameters.get("channel_floor_price"));

		for(int i=0; i<expectedBidderList.size(); i++)
		{
			String bidderId = expectedBidderList.get(i);

			String bidderType = DBLib.getBidderInformation(bidderId, connection).get("biddertype");

			/** considering only vast case as rtb bidder respond price on each request whereas vast is fixed */
			if(bidderType.toLowerCase().contains("vast"))
			{
				String bidderPrice = DBLib.getBidderInformation(bidderId, connection).get("bidderprice");
				String vdopiaMargin = DBLib.getBidderInformation(bidderId, connection).get("vdopiamargin");

				/** effective bidder price is = bidderPrice*(1-vdopiaMargin/100) 
				 */
				float margin = Float.parseFloat(vdopiaMargin)/100;
				float effectiveBidderPrice = (Float.parseFloat(bidderPrice))*(1-margin);

				/** checking if effective bid is lower than channel price */
				if(effectiveBidderPrice < channelFloorPrice)
				{
					lowPriceVastBidder.add(bidderId);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : vast bidder: "+bidderId +" is discarded due to lower effective bid price = "+effectiveBidderPrice +" than channel floor price = "+channelFloorPrice);
				}
			}
		}

		/** remove low price vast bidder from expected bidder list */
		expectedBidderList.removeAll(lowPriceVastBidder);
		return expectedBidderList;
	}


	/** exclude moat enabled bidders.
	 * 
	 * @param expectedBidderList
	 * @return
	 */
	public static List<String> getNonMoatBidderForVastRequest(List<String> expectedBidderList, Connection connection, HashMap<String, String> requiredExpectedParameters)
	{
		List<String> bidderOkay = new ArrayList<>();

		for(int i=0; i<expectedBidderList.size(); i++)
		{
			String bidderId = expectedBidderList.get(i);
			HashMap<String, String> bidderInformation = DBLib.getBidderInformation(bidderId, connection);

			/** if there is no bidder additional setting the its not filtered one */
			if(bidderInformation.get("bidderadditionalsettings").trim().isEmpty())
			{
				bidderOkay.add(bidderId);
			}
			/** if bidder additional setting has blank filter json then also its open to all channel, not filtered */
			else if(Integer.parseInt(bidderInformation.get("bidderfiltercount")) < 1)
			{
				bidderOkay.add(bidderId);
			}
			/** check if there is any filter defined then exclude moat enabled bidders */
			else
			{
				if(!bidderInformation.get("moatview").equalsIgnoreCase("true"))
				{
					bidderOkay.add(bidderId);
				}
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Returning excluded moat enabled bidders: "+bidderOkay.toString());
		return bidderOkay;
	}


	/** Get filtered bidders after matching bidder and bluekai category
	 * 
	 * @param requiredExpectedParameters
	 * @param bidderList
	 * @param connection
	 * @return
	 */
	public static List<String> getBluekaiMatchedBidders(HashMap<String, String> requiredExpectedParameters, List<String> bidderList, Connection connection)
	{
		try
		{
			if(requiredExpectedParameters.containsKey("di") && !requiredExpectedParameters.get("di").isEmpty())
			{
				String ifa = requiredExpectedParameters.get("di");
				List<String> bkMatchedBidders = new ArrayList<>();

				for(int i=0; i<bidderList.size(); i++)
				{
					/** get bidder expression from database, if there is bidder expression then only look for blue kai data */
					String bidder = bidderList.get(i);
					String bidderExpression = DBLib.getBidderInformation(bidder, connection).get("expression");

					if(!bidderExpression.isEmpty())
					{
						/** get bluekai expression from aerospike */
						String bluekaiExpression = AerospikeHandler.getBlueKaiCategory(ifa);

						/** if bidder and bluekai matched, then add to bkMatchedBidders list */
						boolean isMatch = AerospikeHandler.isBidderBlueKaiCategoriesMatched(bidderExpression, bluekaiExpression);
						if(isMatch)
						{
							bkMatchedBidders.add(bidder);
						}
					}
					else
					{
						bkMatchedBidders.add(bidder);
					}
				}
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Filtered bidder list after applying bluekai targeting: "+bkMatchedBidders);
				return bkMatchedBidders;
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Not applying bluekai targeting as request has no di parameter: "+bidderList);
				return bidderList;
			}
		}catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred, Returning the original list without applying bk filter: "+bidderList);
			logger.error(e.getMessage(), e);
			return bidderList;
		}
	}


}


