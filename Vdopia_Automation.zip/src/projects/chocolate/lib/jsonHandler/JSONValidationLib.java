/**
 * Last Changes Done on Jan 19, 2015 5:27:38 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Commented results containing mismatch in geo and device node values
 */

package projects.chocolate.lib.jsonHandler;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import projects.chocolate.lib.ValidateValuesLib;
import projects.chocolate.lib.utils.MapFromThreeLetterToTwoLetter;
import projects.chocolate.lib.utils.Maxmind;
import projects.chocolate.lib.utils.ReadChocolateConfig;
import projects.chocolate.lib.utils.GetDeviceInformation;



import com.mysql.jdbc.Connection;


import vlib.DBLib;
import vlib.StringLib;


// TODO: Auto-generated Javadoc
public class JSONValidationLib 
{

	static Logger logger = Logger.getLogger(JSONValidationLib.class.getName());

	static String bidderType;
	static String isVdopiaBidder;
	static String winningBidder;


	/** This method will check the mandatory nodes in rtb object string
	 * 
	 * 
	 * @param adformatForJson
	 * @param hudsonRTBObjectJSONString
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings({ "finally", "unchecked" })
	public static String checkNodesInRTBObject(String bidderID, String adformatForJson, String hudsonRTBObjectJSONString,  HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		String result = "";

		try
		{
			/** Get expected node --> app or site based on parameter = type supplied in url,
			 * if not in url then get apikey type from db, this is already checked and put in supplied hashmap requiredExpectedParameters
			 */

			String expectedappORsiteNode = requiredExpectedParameters.get("type");		//HudsonMethodsLib.getExpectedAppSiteNode(testURL); 

			//getting required and recommended values from config
			List<String> requiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Bid_Request_Object_Required");
			List<String> recommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Bid_Request_Object_Recommended");

			//Adding app or site node in recommended values based on api key supplied in url
			recommendedFields.add(expectedappORsiteNode);

			//String expectedTotalNodes = "imp,device,user,at,tmax,allimps,cur,"+expectedappORsiteNode;

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ####### Checking Required Node: "+requiredFields + "," + recommendedFields + " in supplied JSON String. ##########");

			List<String> actualKeys = new ArrayList<String>();

			//Getting all nodes from hudson rtb object
			JSONObject js = new JSONObject(hudsonRTBObjectJSONString);
			Iterator<String> it = js.keys();

			//Iterating each node and checking if it is one of expectedAppSiteNode
			while(it.hasNext())
			{
				String str = it.next();

				//Collect imp node validation result
				if(str.equalsIgnoreCase("imp"))
				{
					result = result + checkimpNodeValuesInRTBObject(bidderID, adformatForJson, hudsonRTBObjectJSONString, requiredExpectedParameters, connection);
				}

				//Collect app node validation result
				else if(str.equalsIgnoreCase("app") || str.equalsIgnoreCase("site"))
				{
					result = result + checkappORsiteNodeValuesInRTBObject(hudsonRTBObjectJSONString, requiredExpectedParameters);
				}

				/** Collect device node validation result
				 */
				else if(str.equalsIgnoreCase("device"))
				{
					result = result + checkdeviceNodeValuesInRTBObject(hudsonRTBObjectJSONString, requiredExpectedParameters);
				}

				//Add all those nodes in a list which are present in rtb object 
				actualKeys.add(str);
			}

			//Generating result based on comparison of required fields and actual fields 
			result = result + generateRTBObjectValidationResult(requiredFields, recommendedFields, actualKeys, "bid request");


		}
		catch(JSONException e)
		{
			result = "FAIL: "+e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Exception occurred while checking keys in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking keys. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking keys in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}


	/** This method will check the app nodes in rtb object string
	 * 
	 * 
	 * @param hudsonRTBObjectJSONString
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings({ "finally", "unchecked" })
	public static String checkappORsiteNodeValuesInRTBObject(String hudsonRTBObjectJSONString,  HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";
		String expectedsiteORappNode = "";
		try
		{
			expectedsiteORappNode = requiredExpectedParameters.get("type");

			//getting required and recommended values from config
			List<String> requiredFields = new ArrayList<String>();
			List<String> recommendedFields = new ArrayList<String>();

			List<String> actualKeys = new ArrayList<String>();

			if(expectedsiteORappNode.equalsIgnoreCase("site"))
			{
				//getting required and recommended values from config for site object
				requiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Site_Object_Required_Fields");
				recommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Site_Object_Recommended_Fields");
			}
			else
			{
				//getting required and recommended values from config for app object
				requiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("App_Object_Required_Fields");
				recommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("App_Object_Recommended_Fields");
			}

			/** app or type node is created based on supplied parameter = type, it is supplied with url, if not check type of channel in db based on apikey,
			 * in addition to this, other values are already collected at the start of test and passed in form of hash map.
			 * Checking which one of app or site node will be received, if site is received then adding site specific expected node 
			 */

			String channelAPIKey = requiredExpectedParameters.get("ak");
			String publisherID = requiredExpectedParameters.get("publisher_id");

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ####### Checking values: "+ requiredFields + "," + recommendedFields + " of Node: "+ expectedsiteORappNode  +" in supplied JSON String. ##########");			

			//Getting all nodes from hudson rtb object
			JSONObject js = new JSONObject(hudsonRTBObjectJSONString);

			//Creating JSON object again for node app or site depending on above parameter expectedsiteORappNode
			JSONObject appNode = (JSONObject)(js.get(expectedsiteORappNode));

			//Getting all keys of node app
			Iterator<String> it = appNode.keys();

			while(it.hasNext())
			{
				String key = it.next();
				String value = appNode.get(key).toString();

				if(key.equalsIgnoreCase("id"))
				{
					if(!value.equalsIgnoreCase(channelAPIKey))
					{
						result = result + "FAIL: Expected value of id is: " + channelAPIKey + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("name"))
				{
					if(!value.equalsIgnoreCase(requiredExpectedParameters.get("name")))
					{
						result = result + "FAIL: Expected value of name is: " + requiredExpectedParameters.get("name") + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("domain"))
				{
					if(!value.equalsIgnoreCase(requiredExpectedParameters.get("domain")))
					{
						result = result + "FAIL: Expected value of domain is: " + requiredExpectedParameters.get("domain") + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("bundle"))
				{
					if(!value.equalsIgnoreCase(requiredExpectedParameters.get("bundle")))
					{
						result = result + "FAIL: Expected value of bundle is: " + requiredExpectedParameters.get("bundle") + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("page"))
				{
					if(!value.equalsIgnoreCase(requiredExpectedParameters.get("page")))
					{
						result = result + "FAIL: Expected value of page is: " + requiredExpectedParameters.get("page") + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("ref"))
				{
					if(!value.equalsIgnoreCase(requiredExpectedParameters.get("ref")))
					{
						result = result + "FAIL: Expected value of ref is: " + requiredExpectedParameters.get("ref") + " and actual is: " +value + "\n";
					}
				}
				else if(key.equalsIgnoreCase("publisher"))
				{
					//Getting JSON Object for publisher node
					JSONObject publisher = (JSONObject)(appNode.get("publisher"));

					try
					{
						String actualPublisherId = publisher.get("id").toString();
						if(!publisherID.equalsIgnoreCase(actualPublisherId))
						{
							result = result + "FAIL: Expected value of publisher id is: " + publisherID + " and actual is: " +actualPublisherId + "\n";
						}

						//Blocked intentionally as per Maynak's input
						//							if(!publisherCompany.equalsIgnoreCase(publisher.get("name").toString()))
						//							{
						//								result = result + "FAIL: Expected value of publisher name is: " + publisherCompany + " and actual is: " +value + "\n";
						//							}
					}catch(JSONException e)
					{
						result = result + "FAIL: Error occurred while checking publisher node: "+e.getMessage();
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :  Exception occurred while checking publisher node inside "+ expectedsiteORappNode +" node. " +e.getMessage());
					}
				}

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : key: "+ key + ", value: " + value);

				//Adding found keys in a list 
				actualKeys.add(key);
			}


			//Generate result after comparison of expected and actual fields present in imp node
			result = result + "\n" + generateRTBObjectValidationResult(requiredFields, recommendedFields, actualKeys, expectedsiteORappNode);
		}
		catch(JSONException e)
		{
			result = "FAIL: "+e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Exception occurred while checking "+expectedsiteORappNode +" node in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking "+expectedsiteORappNode +" node. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking "+ expectedsiteORappNode +" node in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(expectedsiteORappNode +" node JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}


	/**This method will check the imp nodes in rtb object string
	 * 
	 * 
	 * @param adformatForJson
	 * @param hudsonRTBObjectJSONString
	 * @return
	 */
	@SuppressWarnings({ "finally", "unchecked" })
	public static String checkimpNodeValuesInRTBObject(String bidderID, String adformatForJson, String hudsonRTBObjectJSONString, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		String result = "";

		try
		{
			List<String> imprequiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Imp_Object_Required_Fields");

			//Adding banner / video node in the required list based on mapping of output and adformat received in url
			imprequiredFields.add(adformatForJson);

			List<String> imprecommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Imp_Object_Recommended_Fields");

			List<String> actualKeys = new ArrayList<String>();

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ####### Checking imp Node: "+ imprequiredFields + "," + imprecommendedFields + " in supplied JSON String. ##########");

			/** Create JSON Object and then get JSONArray of imp node.
			 */
			JSONObject jsonObj = new JSONObject(hudsonRTBObjectJSONString);
			JSONArray impArray = jsonObj.getJSONArray("imp");

			/** Getting JSON Object of imp json array{0} element
			 */
			JSONObject impJSONObj = impArray.getJSONObject(0);

			/** Checking bidfloor price in data to be posted request
			 */
			float bidFloorPrice = Float.parseFloat(impJSONObj.getString("bidfloor"));

			result = ValidateValuesLib.validateBidFloorPrice(requiredExpectedParameters, bidderID, bidFloorPrice, connection);

			/** Checking the iurl value of ext object
			 */
			String requestType = requiredExpectedParameters.get("requestType");
			if (requestType.equalsIgnoreCase("POST"))
			{
				JSONObject extJsonOnj = (JSONObject)impJSONObj.get("ext");
				Iterator<String> ite = extJsonOnj.keys();

				while(ite.hasNext())
				{
					String iurlkey = ite.next();
					if (iurlkey.equalsIgnoreCase("iurl"))
					{

						result = result + "\nPASS : iurl node are present in Json onject ";
					}

					else 
					{
						result = result + "\nFAIL :  iurl node are not present json object ";
					}
				}
			}
			/** Checking each key present on json request
			 */
			Iterator<String> it = impJSONObj.keys();

			while(it.hasNext())
			{
				String key = it.next();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found Key in imp node: "+key);

				//Checking video and banner node
				if(key.equalsIgnoreCase("video"))
				{						
					//Getting JSON Value of video node 	
					String videoJSON = impJSONObj.getString("video");

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VIDEO JSON VALUE: "+videoJSON);

					//getting expected fields for video node
					List<String> videorequiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Video_Object_Required_Fields");
					List<String> videorecommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Video_Object_Recommended_Fields");

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Required Fields: "+videorequiredFields);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Recommended Fields: "+videorecommendedFields);

					result = result + genericMethodToCheckNodes(videorequiredFields, videorecommendedFields, videoJSON, "video");
				}
				else if(key.equalsIgnoreCase("banner"))
				{
					//Getting JSON Value of banner node 	
					String bannerJSON = impJSONObj.getString("banner");

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : BANNER JSON VALUE: "+bannerJSON);

					//getting expected fields for video node
					List<String> bannerrequiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Banner_Object_Required_Fields");
					List<String> bannerrecommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Banner_Object_Recommended_Fields");

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Banner Required Fields: "+bannerrequiredFields);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Banner Recommended Fields: "+bannerrecommendedFields);

					result = result + genericMethodToCheckNodes(bannerrequiredFields, bannerrecommendedFields, bannerJSON, "banner");
				}

				//Adding found keys in a list
				actualKeys.add(key);
			}	


			//Generate result after comparison of expected and actual fields present in imp node
			result = result + "\n" + generateRTBObjectValidationResult(imprequiredFields, imprecommendedFields, actualKeys, "imp");
		}
		catch(JSONException e)
		{
			result = "FAIL: "+e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Exception occurred while checking imp node in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking imp node. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking imp node in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : imp node JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}


	/** This method will check the imp nodes in rtb object string
	 * 
	 * 
	 * @param hudsonRTBObjectJSONString
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings({ "finally", "unchecked" })
	public static String checkgeoNodeValuesInRTBObject(String hudsonRTBObjectJSONString, HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";

		//Expected node to present in geo node of device node
		//String expectedgeoNodes = "lat,lon,country,region,metro,city,zip,type";

		List<String> requiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Geo_Object_Required_Fields");
		List<String> recommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Geo_Object_Recommended_Fields");

		List<String> actualKeys = new ArrayList<String>();

		try
		{
			//Getting ip address used in url
			String ipAddress = 	requiredExpectedParameters.get("ip");	

			//Get JSON Object of device node 
			JSONObject rtbObj = new JSONObject(hudsonRTBObjectJSONString);

			//Creating JSON Object of device node 
			JSONObject deviceObj = (JSONObject)(rtbObj.get("device"));

			//Creating JSON Object of geo node
			JSONObject geoObject = (JSONObject)(deviceObj.get("geo"));

			//Getting all keys of geo node
			Iterator<String> geoKeys = geoObject.keys();

			//Iterating each each found in geo node and checking its value
			while(geoKeys.hasNext())
			{
				//This flag is set to true only in case of mismatch
				boolean flag = false;

				String key = geoKeys.next();
				String value = geoObject.getString(key);

				try
				{

					//Expected value of keys present in geo node
					String expectedValue = "";

					if(key.equalsIgnoreCase("lat"))
					{
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "latitude");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					else if(key.equalsIgnoreCase("lon"))
					{
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "longitude");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					else if(key.equalsIgnoreCase("country"))
					{
						expectedValue = Maxmind.getThreeLetterCountryCodeUsingMaxmind(ipAddress);

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Country Code: "+expectedValue);

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					else if(key.equalsIgnoreCase("region"))
					{
						//Getting region from max mind
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "region");

						//Getting a Map which contains three letter and two letter values, Getting two letters of supplied country
						Map<String, String> map = MapFromThreeLetterToTwoLetter.setThreeLetterToTwoLetter();

						String actualCountryCodeFromJson = geoObject.getString("country");
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Country Code Received in JSON String To Check Region Node: "+actualCountryCodeFromJson);

						//get the value (two letter country code) from map for the supplied key - actualCountryCodeFromJson
						for(Entry<String, String> actualMap : map.entrySet())
						{
							if(actualMap.getKey().equalsIgnoreCase(actualCountryCodeFromJson))
							{
								//Actual region will be region from max mind - Two letter of Country Code
								expectedValue = actualMap.getValue()+"-"+expectedValue;
								logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Region: "+expectedValue);
								break;
							}
						}

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}


					else if(key.equalsIgnoreCase("metro"))
					{
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "metro");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					else if(key.equalsIgnoreCase("city"))
					{
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "city");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					else if(key.equalsIgnoreCase("zip"))
					{
						expectedValue = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "zip");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}


					/**
					 * Commenting the result of mismatch in values of geo node, as values in geo node come from 
					 * maxmind, which gets updated regularly. It will be in log file though. 
					 * 
					 */

					//In case of mismatch collect results.
					if(flag)
					{
						//result = result + "\n" + "WARNING: Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " in geo node.";

						logger.warn("WARNING: Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " in geo node.");
					}

					//Adding all found keys in a actualKeys list
					actualKeys.add(key);
				}

				catch (NullPointerException e) 
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ############# Maxmind couldn't provide value for key: "+key + " ##################");
				}
			}


			//checking if actual device node fields in device object contains all required and recommended fields, getting comparision result
			result = result + "\n" + generateRTBObjectValidationResult(requiredFields, recommendedFields, actualKeys, "geo");	

		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking geo node. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking geo node in received JSON String: ", e);

			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : geo node JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}


	/** This method will check the device nodes in rtb object string
	 * 
	 * 
	 * @param hudsonRTBObjectJSONString
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings({ "finally", "unchecked" })
	public static String checkdeviceNodeValuesInRTBObject(String hudsonRTBObjectJSONString, HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";
		String geoResult = "";
		String extResult = "";
		String requestType = requiredExpectedParameters.get("requestType");

		//1. Checking expected keys in device node
		List<String> requiredFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Device_Object_Required_Fields");
		List<String> recommendedFields = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("Device_Object_Recommended_Fields");

		List<String> actualKeys = new ArrayList<String>();

		try
		{
			//get user agent
			String userAgent = requiredExpectedParameters.get("ua");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received User Agent: ");
			logger.info(userAgent);

			//get device details from wurfl based on received user agent
			HashMap<String, String> deviceInfo = GetDeviceInformation.getDeviceInformation(userAgent);

			//Create the JSON Object of supplied JSON String 
			JSONObject rtbObj = new JSONObject(hudsonRTBObjectJSONString);

			//Get the device node and its content
			String deviceJSONString = rtbObj.getString("device");

			//Creating JSON Object of device node
			JSONObject deviceObject = new JSONObject(deviceJSONString);

			//Getting all keys of device node
			Iterator<String> deviceKeys = deviceObject.keys();

			//Iterating each each found in geo node and checking its value
			while(deviceKeys.hasNext())
			{
				//This flag is set to true only in case of mismatch
				boolean flag = false;

				String key = deviceKeys.next();
				String value = deviceObject.getString(key);

				try
				{
					//Checking Actual value of keys present in device node

					String expectedValue = "";

					if(key.equalsIgnoreCase("ua"))
					{
						expectedValue = userAgent;

						//Decoding user agent
						expectedValue = URLDecoder.decode(expectedValue, "UTF-8");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("ip"))
					{
						expectedValue = requiredExpectedParameters.get("ip");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("language"))
					{
						expectedValue = requiredExpectedParameters.get("language");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("make"))
					{
						expectedValue = deviceInfo.get("make");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("model"))
					{
						expectedValue = deviceInfo.get("model");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("os"))
					{
						expectedValue = deviceInfo.get("os");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("osv"))
					{
						expectedValue = deviceInfo.get("osv");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("js"))
					{
						expectedValue = deviceInfo.get("js");

						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}

					else if(key.equalsIgnoreCase("geo"))
					{
						geoResult = checkgeoNodeValuesInRTBObject(hudsonRTBObjectJSONString, requiredExpectedParameters);
					}

					/**
					 *  This ext node validation is validating for post request only 
					 */

					else if (requestType.equalsIgnoreCase("POST") && key.equalsIgnoreCase("ext"))
					{
						extResult = checkextNodeValueInDeviceObjOfRTBobject(hudsonRTBObjectJSONString, requiredExpectedParameters);
					}

					//In case of mismatch collect results.
					if(flag)
					{
						/**
						 * Commenting the result of mismatch in values of device node, as values in device node come from 
						 * wurfl, which gets updated regularly. It will be in log though. 
						 * only in case of ip mismatch result will be displayed else not.
						 */

						if(key.equalsIgnoreCase("ip"))
						{
							result = result + "\n" + "WARNING: Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " in device node.";
						}

						logger.warn("Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " in device node. ");
					}


					//Adding all found keys in a actualKeys list
					actualKeys.add(key);
				}

				catch (Exception e) 
				{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred While Checking Device Node: ", e);
				}
			}

			//checking if actual device node fields in device object contains all required and recommended fields, getting comparison result
			result = extResult+ geoResult + result + generateRTBObjectValidationResult(requiredFields, recommendedFields, actualKeys, "device");
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking device node. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking device node in received JSON String: ", e);

			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : device node JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}


	/** This method will generate result after comparing required and recommended fields from actual fields in json
	 * 
	 * 
	 * @param requiredFields
	 * @param recommendedFields
	 * @param actualKeys
	 * @param jsonNode
	 * @return
	 */
	public static String generateRTBObjectValidationResult(List<String> requiredFields, List<String> recommendedFields, List<String> actualKeys, String jsonNode)
	{

		String result = "";

		//checking if actual device node fields in device object contains all required and recommended fields
		String requiredFieldString = requiredFields.toString().replace("[", "").replace("]", "").trim();
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Required Field String: "+requiredFieldString + " For Node: "+jsonNode);

		if(!requiredFieldString.isEmpty())
		{
			if(actualKeys.containsAll(requiredFields))
			{
				result = result + "PASS: All required fields are present in "+ jsonNode +" node of Hudson RTB Object. ";
			}
			else
			{
				String missingRequiredFields = StringLib.getUnmatchedValuesFromTwoLists(requiredFields, actualKeys).toString();
				missingRequiredFields =  missingRequiredFields.replace("[", "").replace("]", "").trim();
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Missing Required Fields: "+missingRequiredFields + " For Node: "+jsonNode);

				if(!missingRequiredFields.isEmpty())
				{
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Missing Required Fields From "+ jsonNode +" Object: "+missingRequiredFields);
					result = result + "FAIL: Required Fields: "+ missingRequiredFields + " are not present in " + jsonNode +" node of Hudson RTB Object. ";
				}
			}
		}


		String recommendedFieldString = recommendedFields.toString().replace("[", "").replace("]", "").trim();
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Recommended Field String: "+recommendedFieldString + " For Node: "+jsonNode);

		if(!recommendedFieldString.isEmpty())
		{
			if(!actualKeys.containsAll(recommendedFields))
			{
				String missingRecommendedFields = StringLib.getUnmatchedValuesFromTwoLists(recommendedFields, actualKeys).toString();
				missingRecommendedFields = missingRecommendedFields.replace("[", "").replace("]", "").trim(); 
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Missing Recommended Fields: "+missingRecommendedFields + " For Node: "+jsonNode);

				if(!missingRecommendedFields.isEmpty())
				{
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Missing Recommended Fields From " + jsonNode + " Object: "+missingRecommendedFields);
					result = result + "\nWarning: Recommended Fields: "+ missingRecommendedFields + " are not present in " + jsonNode +" node of Hudson RTB Object. ";
				}
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result Of Node "+jsonNode +":\n "+result);
		return result;
	}


	/** This is a generic method to check if the given keys are present in the supplied JSON object or not
	 * 
	 * 
	 * @param requiredFields
	 * @param recommendedFields
	 * @param hudsonRTBObjectJSONString
	 * @param jsonNode
	 * @return
	 */
	@SuppressWarnings({"finally", "unchecked"})
	public static String genericMethodToCheckNodes(List<String> requiredFields, List<String> recommendedFields, String hudsonRTBObjectJSONString, String jsonNode)
	{	
		String result = "";

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ####### Checking Fields: "+requiredFields + "," + recommendedFields + " in "+ jsonNode +" in supplied JSON String. ##########");

			List<String> actualKeys = new ArrayList<String>();

			//Getting all nodes from hudson rtb object
			JSONObject js = new JSONObject(hudsonRTBObjectJSONString);
			Iterator<String> it = js.keys();

			//Iterating each node 
			while(it.hasNext())
			{
				//Add all those nodes in a list which are present in rtb object
				String str = it.next();
				actualKeys.add(str);
			}

			result = result + "\n" + generateRTBObjectValidationResult(requiredFields, recommendedFields, actualKeys, jsonNode);

		}
		catch(JSONException e)
		{
			result = "FAIL: "+e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Exception occurred while checking keys in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking keys. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking keys in received JSON String: ", e);
			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #####################");
			return result;
		}
	}


	/** This method will parse the JSON response of rtb bidder and get the Pricing Info from response.
	 * 
	 * 
	 * @param winningBidderJsonString
	 * @param expectedWinningBidder
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String compareWinningBidderWithExpectedOne(String winningBidderJsonString, String expectedWinningBidder, Connection connection)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Winning Hudson Bidder Id is being compared with expected one in bq mx JSON String ......... ");

		String result = "SKIP: There was no winning bidder found in bq log. ";
		List<String> responseStatus = new ArrayList<String>();

		try
		{
			//Creating JSON Object
			JSONObject jsonObject = new JSONObject(winningBidderJsonString);

			//Get JSON Array of node bidResponses
			JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bidResponses");

			//Iterating bidResponsesJSONArray JSON Array
			for(int i=0; i<bidResponsesJSONArray.length(); i++)
			{
				//Moving to the node where winning bidder information is stored

				//Getting bidder winning status
				String bidderStatus = bidResponsesJSONArray.getJSONObject(i).getString("responseStatus").trim();

				//Getting JSON Object of node containing winning bidder information and getting bidder id
				String winningBidderIDFromJSON = bidResponsesJSONArray.getJSONObject(i).getString("bidderId").trim();

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received Bidder: " + winningBidderIDFromJSON + " & Bidder Status: "+bidderStatus + " From Winning Json String: ");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Its status is being compared to expected status: WON ");

				/** collecting all response status */
				responseStatus.add(bidderStatus);

				//First find the winning bidder 
				if(bidderStatus.equalsIgnoreCase("WON"))
				{	
					//And then compare expected and actual winning bidder
					if(winningBidderIDFromJSON.equalsIgnoreCase(expectedWinningBidder))
					{
						result = "PASS: Expected bidder "+ expectedWinningBidder +" won the auction. ";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : PASS: Expected bidder "+ expectedWinningBidder +" won the auction. ");
					}
					else
					{
						result = "FAIL: Actual Winning Bidder: "+winningBidderIDFromJSON +", Expected Winning bidder: "+expectedWinningBidder;
						logger.info(result);
					}

					//Getting winningBidder
					winningBidder = winningBidderIDFromJSON;
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : winningBidder is: "+winningBidder);

					//Getting winning bidder information from database
					HashMap<String, String> map = DBLib.getBidderInformation(expectedWinningBidder, connection);
					if(!map.isEmpty() && map != null)
					{
						isVdopiaBidder = map.get("isvdopiabidder");
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : isVdopiaBidder value: "+isVdopiaBidder +" for bidder: "+winningBidderIDFromJSON);

						bidderType = map.get("biddertype");
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : biddertype value: "+bidderType +" for bidder: "+winningBidderIDFromJSON);
					}
					else
					{
						logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No information received from database for winning bidder = "+ winningBidderIDFromJSON);
					}

					break;
				}
				else
				{
					continue;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting winning bidder id from supplied winning json string. ", e);
			logger.debug(winningBidderJsonString);
		}
		finally
		{
			/** in case of no winning bidder, print all the received bidder status */
			if(!responseStatus.contains("WON")){
				result = result + " \n Received Bidder Status' are: "+responseStatus.toString();
			}

			return result;
		}

	}


	/** This method will check the imp nodes of the data to be posted to the bidder.
	 * These Validations will be performed: 
	 * ## bidder ad format = video then instl == 1
	 * & check video node exists in imp {0}
	 * h = 480 && w = 320
	 * #bidder ad format = banner then instl = 0
	 * & check banner node exists in imp {0}
	 * h = 50 && w = 320
	 * 
	 * @param bidderID
	 * @param bidderAdformat
	 * @param bidderRequestToBePosted
	 * @return
	 */
	@SuppressWarnings({ "finally" })
	public static String validate_BidderRequest(String bidderAdformat, String bidderRequestToBePosted, HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";

		try
		{
			/** Create JSON Object and then get JSONArray of imp node. */
			JSONObject jsonObj = new JSONObject(bidderRequestToBePosted);
			JSONArray impArray = jsonObj.getJSONArray("imp");

			/** Normally request json string contains only one element in imp JSON Array, therefore
			 * considering impArray.getJSONObject(0) element  
			 * 
			 * Getting JSON Object of imp node
			 */
			JSONObject impNodeJsonObj = impArray.getJSONObject(0);

			/** Getting instl node value */
			String instl = impNodeJsonObj.getString("instl").trim();

			/** Getting JSON Value of video/banner node depending on supplied bidder ad format */
			String videoBannerJSONString = impNodeJsonObj.getString(bidderAdformat);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VIDEO JSON VALUE: "+videoBannerJSONString);

			/** Getting json object of video / banner string node */
			JSONObject videoBannerJsonObj = new JSONObject(videoBannerJSONString);

			String w = videoBannerJsonObj.getString("w");
			String h = videoBannerJsonObj.getString("h");

			/** Validating ad dimension in request to be posted
			 */
			result = result + "  " + ValidateValuesLib.validateAdDimension(instl, bidderAdformat, w, h, requiredExpectedParameters);
		}
		catch(JSONException j)
		{
			result = result + ",  " + "FAIL: "+j.getMessage();
		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking imp node. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking imp node in received JSON String: ", e);
			logger.info(bidderRequestToBePosted);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : imp node JSON Validation Result: ");
			logger.info(result);
			return result;
		}

	}


	/** This method will check the ext node in case of post request
	 * 
	 * @param hudsonRTBObjectJSONString
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String checkextNodeValueInDeviceObjOfRTBobject(String hudsonRTBObjectJSONString, HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";

		//List<String> actualKeys = new ArrayList<String>();

		try
		{
			//Getting ifa used in post call
			String ifa = requiredExpectedParameters.get("ifa");	

			//Get JSON Object of device node 
			JSONObject rtbObj = new JSONObject(hudsonRTBObjectJSONString);

			//Creating JSON Object of device node 
			JSONObject deviceObj = (JSONObject)(rtbObj.get("device"));

			//Creating JSON Object of ext node
			JSONObject extObject = (JSONObject)(deviceObj.get("ext"));

			//Getting all keys of ext node
			@SuppressWarnings("unchecked")
			Iterator<String> extKeys = extObject.keys();

			//Iterating each each found in ext node and checking its value
			while(extKeys.hasNext())
			{
				//This flag is set to true only in case of mismatch
				boolean flag = false;

				String key = extKeys.next();
				String value = extObject.getString(key);

				try
				{
					//Expected value of keys present in ifa node
					String expectedValue = ifa;
					if(key.equalsIgnoreCase("ifa"))
					{
						if(!expectedValue.equalsIgnoreCase(value))
						{
							flag = true;
						}
					}
					if(flag)
					{
						result = result + "\n" + "Failed : Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " of ifa.";

						logger.warn("WARNING: Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " in ext node.");
					}

					else
					{
						result = result + "\n" + "Pass : Expected value of "+key +" is: " + expectedValue + " and actual is: " +value + " of ifa.";	
					}

				}

				catch (NullPointerException e) 
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ############# Post Request couldn't provided key: "+key + " ##################");
				}
			}


			//checking if actual device node fields in device object contains all required and recommended fields, getting comparision result


		}
		catch(Exception e)
		{
			result = "FAIL: Exception occurred while checking ifo value in ext node. ";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking ext node in received JSON String: ", e);

			logger.info(hudsonRTBObjectJSONString);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ext node JSON Validation Result: ");
			logger.info(result);
			return result;
		}
	}
}

