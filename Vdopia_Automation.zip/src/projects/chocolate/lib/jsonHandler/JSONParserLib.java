/**
 * Last Changes Done on 13 May, 2015 5:00:39 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains methods to parse the supplied json 
 */
package projects.chocolate.lib.jsonHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import projects.chocolate.lib.bidders.VdopiaBidderLib;


public class JSONParserLib 
{
	static Logger logger = Logger.getLogger(JSONParserLib.class.getName());


	/** This method will parse the supplied bq mx json string and return the map containing 
	 * adid and campaign id and other ad information from seatbid node of supplied bq json string.
	 * 
	 * @param bidderResponse
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> parseAdInfoFromSeatBidNode(String winningBidderSeatBidJson)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : AD information is being retrieved from bq mx log: "+winningBidderSeatBidJson);

		HashMap<String, String> map = new HashMap<>();

		try
		{	
			/** Proceed only if there is any winning bidder json node is received 
			 */
			if(!winningBidderSeatBidJson.isEmpty())
			{
				/** Create JSON Object
				 */
				JSONObject obj = new JSONObject(winningBidderSeatBidJson);

				/** Get JSON Array of bid node
				 */
				JSONArray bidJSONArray = obj.getJSONArray("bid");

				/** Iterating JSON Array
				 */
				for(int i=0; i<bidJSONArray.length(); i++)
				{
					/** converting each bid JSON Array element into json object
					 */
					JSONObject bidJSONObj = bidJSONArray.getJSONObject(i);

					/** Getting ad information from BID Json Object
					 */
					String adid = bidJSONObj.getString("adid");
					String cid = bidJSONObj.getString("cid");
					String crid = bidJSONObj.getString("crid");

					map.put("adid", adid);
					map.put("cid", cid);
					map.put("crid", crid);

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding adid = "+adid + " and cid = "+cid);
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No winning bidder json node was received.");
			}
		}
		catch(JSONException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Exception occurred: " +e.getMessage());
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting the adid information from bidder response. ", e);
		}
		finally
		{
			return map;
		}
	}


	/** This method will split the adid string and convert into a hashmap.
	 * 
	 * @param adIDInformation
	 * @return
	 */
	public static HashMap<String, String> createMapFromAdId(String adIDInformation)
	{
		//Change this method to parse string: "VDO_inapp_156517" to get ad format

		HashMap<String, String> hashmap = new HashMap<String, String>();
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Splitting the received adid string: "+adIDInformation);

			String [] array = adIDInformation.split("::");

			//in case preinter
			if(array[0].equalsIgnoreCase("preinter"))
			{
				hashmap.put("ad_format", "appinterstitial");
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ad_format: "+"appinterstitial" + " corresponding to received ad format: "+array[0]);
			}
			else if(array[0].equalsIgnoreCase("banner"))
			{
				hashmap.put("ad_format", "banner");
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ad_format: "+"banner" + " corresponding to received ad format: "+array[0]);
			}
			else
			{
				hashmap.put("ad_format", "video");
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ad_format: "+ "video" + " corresponding to received ad format: "+array[0]);
			}

			hashmap.put("campaign_id", array[1]);
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : campaign_id: "+array[1]);

			hashmap.put("ad_id", array[2]);
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ad_id: "+array[2]);

			hashmap.put("channel_id", array[3]);
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : channel_id: "+array[3]);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while splitting the received string: "+adIDInformation, e);
		}
		return hashmap;
	}


	/** This method will return the all bidder ids as a list after parsing the supplied bq json string
	 * excluding bidders: hudson and GOOGLE_ADX_FALLBACK
	 * 
	 * @param jsonString
	 * @return
	 */
	public static List<String> getAllBidderIdFromBqLog(String jsonString)
	{
		List<String> bidderList = new ArrayList<>();

		try
		{
			if(!jsonString.isEmpty())
			{
				JSONObject obj = new JSONObject(jsonString);

				JSONArray bid_responses = obj.getJSONArray("bidResponses");

				for(int i=0; i<= bid_responses.length(); i++)
				{
					JSONObject json = bid_responses.getJSONObject(i);

					String bidder = "";
					try{
						bidder = json.getString("bidderId").toLowerCase().trim();
					}catch(JSONException j){
						logger.error(j.getMessage());
					}

					/** add bidders to list if bidder is not empty and not equal to hudson
					 * also excluding bidder: GOOGLE_ADX_FALLBACK in case of fall back behavior */
					if(!bidder.isEmpty() && !bidder.equalsIgnoreCase("hudson") && !bidder.equalsIgnoreCase("GOOGLE_ADX_FALLBACK"))
					{
						bidderList.add(bidder);
					}
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No JSON String received. ");
			}
		}
		catch(JSONException j)
		{
			logger.error(j.getMessage());
		}		
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting bidder list from bq mx log:", e);
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Bidder List From BqMx Log: "+bidderList);

		return bidderList;
	}


	/** This method will parse the bq mx log and find out bidder with response status = WON
	 * 
	 * @param winningBidderJsonString
	 * @param expectedWinningBidder
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getWinningBidderIDFromBqLog(String bqmxJsonString)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Winning Hudson Bidder Id From BQ MX Log JSON String ......... ");

		String winningBidderID = "";

		try
		{
			if(!bqmxJsonString.isEmpty())
			{
				JSONObject jsonObject = new JSONObject(bqmxJsonString);

				/** Get JSON Array of node bidResponses */
				JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bidResponses");

				/** Iterating bidResponsesJSONArray JSON Array */
				for(int i=0; i<bidResponsesJSONArray.length(); i++)
				{
					/** Moving to the node where winning bidder information is stored, Getting bidder winning status
					 */
					String bidderStatus = bidResponsesJSONArray.getJSONObject(i).getString("responseStatus").trim();

					/** Check if this bidder is the winner
					 */
					if(bidderStatus.equalsIgnoreCase("WON"))
					{
						/** Getting JSON Object of node containing winning bidder information and getting bidder id 
						 */
						winningBidderID = bidResponsesJSONArray.getJSONObject(i).getString("bidderId").trim();
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Winning bidder found from bq mx log: "+winningBidderID);

						break;
					}
					else
					{
						continue;
					}
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No bq mx json string was received. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting winning bidder id from supplied json string. ", e);
			logger.debug(bqmxJsonString);
		}
		finally
		{
			return winningBidderID;
		}

	}


	@SuppressWarnings("finally")
	public static String getWinPriceSupplyFromBqLog(String bqmxJsonString)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting WinPriceSupply For Winning Bidder Id From BQ MX JSON String ......... ");

		String winPriceSupply = "";

		try
		{
			if(!bqmxJsonString.isEmpty())
			{
				JSONObject jsonObject = new JSONObject(bqmxJsonString);

				/** Get JSON Array of node bidResponses */
				JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bidResponses");

				/** Iterating bidResponsesJSONArray JSON Array */
				for(int i=0; i<bidResponsesJSONArray.length(); i++)
				{
					/** Moving to the node where winning bidder information is stored, Getting bidder winning status
					 */
					String bidderStatus = bidResponsesJSONArray.getJSONObject(i).getString("responseStatus").trim();

					/** Check if this bidder is the winner
					 */
					if(bidderStatus.equalsIgnoreCase("WON"))
					{
						/** Getting JSON Object of node containing winning bidder information and getting bidder id 
						 */
						try{
							winPriceSupply = bidResponsesJSONArray.getJSONObject(i).getString("winPriceSupply").trim();
						}catch(JSONException e){
							logger.debug(e.getMessage());
						}
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WinPriceSupply For Winning Bidder From bq mx log: "+winPriceSupply);

						break;
					}
					else
					{
						continue;
					}
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No bq mx json string was received. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting winPriceSupply from supplied json string. ", e);
			logger.debug(bqmxJsonString);
		}
		finally
		{
			return winPriceSupply;
		}

	}


	/** This method will return a list containing all the response status from bq mmx json string
	 * 
	 * @param bqmxJsonString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getAllResponseStatusFromBqMMxLog(String bqmxJsonString)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Response Status From BQ MX Log JSON String ......... ");

		List<String> responseStatus = new ArrayList<>();

		try
		{
			if(!bqmxJsonString.isEmpty())
			{
				JSONObject jsonObject = new JSONObject(bqmxJsonString);

				/** Get JSON Array of node bidResponses */
				JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bid_responses");

				/** Iterating bidResponsesJSONArray JSON Array */
				for(int i=0; i<bidResponsesJSONArray.length(); i++)
				{
					/** Moving to the node where winning bidder information is stored, Getting bidder winning status
					 */
					String response = bidResponsesJSONArray.getJSONObject(i).getString("responseStatus").trim();
					responseStatus.add(response);
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No bq mx json string was received. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting response status from supplied json string. ", e);
			logger.debug(bqmxJsonString);
		}
		finally
		{
			return responseStatus;
		}

	}


	/** This method will parse the bq mx log and find out seatbid node
	 * corresponding to winning bidder.
	 * 
	 * @param bqmxJsonString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getWinningBidderSeatBidFromBqLog(String bqmxJsonString)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Winning Hudson Bidder Id From BQ Log JSON String ......... ");

		String seatbid = "";

		try
		{
			JSONObject jsonObject = new JSONObject(bqmxJsonString);

			/** Get JSON Array of node bidResponses 
			 */
			JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bidResponses");

			/** Iterating bidResponsesJSONArray JSON Array
			 */
			for(int i=0; i<bidResponsesJSONArray.length(); i++)
			{
				JSONObject json = bidResponsesJSONArray.getJSONObject(i);

				/** Moving to the node where winning bidder information is stored, Getting bidder winning status
				 */
				String responseStatus = json.getString("responseStatus").trim();

				/** Check if this bidder is the winner 
				 */
				if(responseStatus.equalsIgnoreCase("WON"))
				{
					/** Getting seatbid, seat bid is json array, storing the first element of seatbid json array
					 */
					seatbid = json.getJSONArray("seatbid").getString(0);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Winnig bidder's seat bid found from bq mx log: "+seatbid);

					break;
				}
				else
				{
					continue;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting winning bidder seat bid from supplied json string. ", e);
			logger.debug(bqmxJsonString);
		}
		finally
		{
			return seatbid;
		}

	}


	/** This method will parse the bq mx log and find out all the bidder and corresponding information
	 * like response status, bid price etc... and return this information in a hashmap. This method can be extended further
	 * depending on what all information is needed.
	 * 
	 * @param bqmxJsonString
	 * @return
	 */
	public static TreeMap<String, HashMap<String, String>> getAllBiddersInfoFromBqLog(String bqmxJsonString)
	{
		TreeMap<String, HashMap<String, String>> bidderInformation = new TreeMap<>();

		/** This list contains the desired fields to be retrieved from supplied json string for each bidder
		 */
		List<String> desiredFieldList = new ArrayList<>(Arrays.asList("responseStatus,bidPrice,seatbid".split(",")));

		try{
			/** Create a json object then get the json array of bid_responses
			 */
			JSONObject bqmxJsonObj = new JSONObject(bqmxJsonString);
			JSONArray bid_responses = bqmxJsonObj.getJSONArray("bidResponses");

			/** Iterate json array
			 */
			for(int i=0; i<bid_responses.length(); i++)
			{
				/** Converting each json array element into a json object and using every string in lower case
				 */
				JSONObject jsonObj = bid_responses.getJSONObject(i);

				String bidder_id = "";

				try{
					bidder_id = jsonObj.getString("bidderId").toLowerCase().trim();
				}catch(JSONException j){
					logger.error(j.getMessage());
				}

				/** Put all the bidder information into a hash map.
				 */
				HashMap<String, String> info = getDesiredBidderInformation(jsonObj, desiredFieldList);

				/** Finally put the hashmap info into above created map bidderInformation if bidder_id 
				 * is not hudson
				 */
				if(!bidder_id.isEmpty() && !bidder_id.equalsIgnoreCase("hudson"))
				{
					bidderInformation.put(bidder_id, info);
				}
			}
		}
		catch(JSONException e){
			logger.error(e.getMessage());
		}
		catch(Exception e){
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : exception occurred while parsing bq mx log.", e);
		}

		return bidderInformation;
	}


	/** This method is being used by method getAllBiddersInfoFromBqMxLog to get all required fields from supplied json object.
	 * 
	 * @param jsonObj
	 * @param info
	 * @param desiredFieldList
	 */
	public static HashMap<String, String> getDesiredBidderInformation(JSONObject jsonObj, List<String> desiredFieldList)
	{
		HashMap<String, String> info = new HashMap<>();

		for(int i=0; i<desiredFieldList.size(); i++)
		{
			String desiredField = desiredFieldList.get(i).trim();
			String desiredFieldValue;

			try{
				desiredFieldValue = jsonObj.getString(desiredField).toLowerCase().trim();
			}catch(JSONException j)
			{
				desiredFieldValue = "";
				logger.error(j.getMessage());
			}

			info.put(desiredField, desiredFieldValue);
		}

		return info;
	}


	/** This method will check the vdopia bidder's no ad response 
	 * 
	 * @param response
	 * @return
	 */
	public static String parseVdopiaBidderNoAdResponse(String response)
	{
		List<String> keysNotPresent = new ArrayList<>();
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking vdopia bidder no ad response, received response: "+response);
		try
		{
			/** Getting expected keys in a list */
			List<String> expectedNoAdResponseKeys = VdopiaBidderLib.getExpectedNoAdVdopiaResponseFields();

			JSONObject object = new JSONObject(response);

			@SuppressWarnings("unchecked")
			Iterator<String> it = object.keys();

			while(it.hasNext())
			{
				String key = it.next();
				if(!expectedNoAdResponseKeys.contains(key.trim()))
				{
					keysNotPresent.add(key);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking no ad response from vdopia bidder. ", e);
		}

		if(keysNotPresent.isEmpty())
		{
			return "PASS: Vdopia bidder responded without an ad with a valid json format containing all expected fields."; 
		}
		else
		{
			return "FAIL: Vdopia bidder (no ad) response is not correct. Expected fields: "+keysNotPresent.toString() + " are not present in response. ";
		}
	}


	/** This method will check the vdopia bidder's ad response
	 * 
	 * @param response
	 * @return
	 */
	public static String parseVdopiaBidderAdResponse(String response)
	{
		List<String> keysNotPresent = new ArrayList<>();
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking vdopia bidder ad response... ");

		try
		{
			JSONObject object = new JSONObject(response);			
			List<String> expectedAdResponseKeys = VdopiaBidderLib.getExpectedAdVdopiaResponseFields("main");

			/** checking main keys present in response */
			keysNotPresent.addAll(matchKeys(object, expectedAdResponseKeys));

			/** checking other fields present in response */ 
			keysNotPresent.addAll(parseVdopiaBidderSeatBidNode(response));
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking ad response from vdopia bidder. ", e);
		}

		if(keysNotPresent.isEmpty())
		{
			return "PASS: Vdopia bidder responded with an ad in a valid json format containing all expected fields."; 
		}
		else
		{
			return "FAIL: Vdopia bidder response is not correct. Fields not present: "+keysNotPresent.toString();
		}
	}


	/** This method will match the expected keys and actual keys in json and return the unmatched keys.
	 * 
	 * @param object
	 * @param expectedAdResponseKeys
	 * @return
	 */
	public static List<String> matchKeys(JSONObject object, List<String> expectedAdResponseKeys)
	{
		List<String> keysNotPresent = new ArrayList<>();

		@SuppressWarnings("unchecked")
		Iterator<String> it = object.keys();

		while(it.hasNext())
		{
			String key = it.next();
			if(!expectedAdResponseKeys.contains(key.trim()))
			{
				keysNotPresent.add(key);
			}
		}

		return keysNotPresent;
	}


	/** This method will check the seatbid node in supplied vdopia bidder's response and returned 
	 * a list containing expected keys which are not present.  
	 * 
	 * @param response
	 * @return
	 */
	public static List<String> parseVdopiaBidderSeatBidNode(String response)
	{
		List<String> keysNotPresent = new ArrayList<>();

		try
		{
			JSONObject object = new JSONObject(response);

			/** Get seatbid json array */
			JSONArray seatbidArray = object.getJSONArray("seatbid");

			/** Get json object of seatbidArray[0] as there will be only one element in this array */
			JSONObject seatbidObj = seatbidArray.getJSONObject(0);

			/**1. check keys present in seatbidObj json object */
			List<String> expectedseatbidKeys = VdopiaBidderLib.getExpectedAdVdopiaResponseFields("seatbid");
			keysNotPresent.addAll(matchKeys(seatbidObj, expectedseatbidKeys));

			/** get json array of bid node from seatbidObj */
			JSONArray bidArray = seatbidObj.getJSONArray("bid");

			/** Get json object of bidArray[0] as there will be only one element in this array */
			JSONObject bidObject = bidArray.getJSONObject(0);

			/**2. check keys present in bidObject json object */
			List<String> expectedbidKeys = VdopiaBidderLib.getExpectedAdVdopiaResponseFields("bid");
			keysNotPresent.addAll(matchKeys(bidObject, expectedbidKeys));

			/**3. get adomain json array from bidObject */
			JSONArray adomain = bidObject.getJSONArray("adomain");

			if(adomain.length()<1)
			{
				keysNotPresent.add("adomain json array is blank. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking seat bid node of vdopia bidder response .", e);
		}

		return keysNotPresent;
	}


	/** Get nurl from vdopia bidder's response.
	 * 
	 * @param response
	 * @return
	 */
	public static String getVdopiaBidderNURL(String response)
	{
		String nurl="";
		try
		{
			JSONObject object = new JSONObject(response);

			/** Get seatbid json array */
			JSONArray seatbidArray = object.getJSONArray("seatbid");

			/** Get json object of seatbidArray[0] as there will be only one element in this array */
			JSONObject seatbidObj = seatbidArray.getJSONObject(0);

			/** get json array of bid node from seatbidObj */
			JSONArray bidArray = seatbidObj.getJSONArray("bid");

			/** Get json object of bidArray[0] as there will be only one element in this array */
			JSONObject bidObject = bidArray.getJSONObject(0);

			nurl = (String) bidObject.get("nurl");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting nurl from vdopia bidder response .", e);
		}

		return nurl;
	}


	/** Check if the supplied string is a valid json object. 
	 * 
	 * @param json
	 * @return
	 */
	public static boolean isJsonObject(String json)
	{
		try{
			new JSONObject(json);
			return true;
		}catch(JSONException j)
		{
			return false;
		}		
	}


	/** Check if the supplied string is a valid json array. 
	 * 
	 * @param json
	 * @return
	 */
	public static boolean isJsonArray(String json, String key)
	{
		try{
			new JSONObject(json).getJSONArray(key);
			return true;
		}catch(JSONException j)
		{
			return false;
		}		
	}


	/** Check if the supplied string is a valid json array. 
	 * 
	 * @param json
	 * @return
	 */
	public static boolean isJsonArray(JSONObject jsonObj, String key)
	{
		try{
			jsonObj.getJSONArray(key);
			return true;
		}catch(JSONException j)
		{
			return false;
		}		
	}

	/**
	 * This method will return the values of the winning parameters(nurl, iurl and winurl)
	 * @param bqmxJsonString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> parseWinningInformationsFromBqLog(String bqmxJsonString)
	{
		HashMap<String, String> map = new HashMap<>();
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Response Json information is being retrieved from bq log: "+bqmxJsonString);
			String winningBidderSeatbidobj = getWinningBidderSeatBidFromBqLog(bqmxJsonString);

			/** Proceed only if there is any winningBidderSeat json node is received 
			 */
			if(!winningBidderSeatbidobj.isEmpty())
			{
				/** Create JSON Object
				 */
				JSONObject obj = new JSONObject(winningBidderSeatbidobj);

				/** Get JSON Array of bid node
				 */
				JSONArray bidJSONArray = obj.getJSONArray("bid");

				/** converting each bid JSON Array element into json object
				 */
				JSONObject bidJSONObj = bidJSONArray.getJSONObject(0);

				/** Getting ad information from BID Json Object
				 */	
				String nurl = "";
				String iurl = "";
				String winurl = "";
				try{
					nurl = bidJSONObj.getString("nurl");
					map.put("nurl", nurl);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding nurl in map = " +winurl);
				}catch(JSONException j){
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : nurl node are not available in winning Bidder Seatbid obj ");
				}
				try{
					iurl = bidJSONObj.getString("iurl");
					map.put("iurl", iurl);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding iurl in map = " +winurl);
				}catch(JSONException j){
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iurl node are not available in winning Bidder Seatbid obj ");
				}	

				/** Getting win url
				 */
				winurl = getWinUrlOfWinningBidderFromBqLog(bqmxJsonString);

				if(!winurl.equalsIgnoreCase("")){
					map.put("winurl", winurl);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding winurl in map = " +winurl);
				}
				else{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : winUrl node are not available for winning Bidder");
				}

			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No winning bidder json node was received.");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting the seadBid information from bidder response. ", e);
		}
		finally
		{
			return map;
		}
	}


	/** This method will parse the bq log and find out win url
	 * corresponding to winning bidder.
	 * 
	 * @param bqmxJsonString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getWinUrlOfWinningBidderFromBqLog(String bqmxJsonString)
	{
		String winUrl = "";

		try
		{
			JSONObject jsonObject = new JSONObject(bqmxJsonString);

			/** Get JSON Array of node bidResponses 
			 */
			JSONArray bidResponsesJSONArray = jsonObject.getJSONArray("bidResponses");

			/** Iterating bidResponsesJSONArray JSON Array
			 */
			for(int i=0; i<bidResponsesJSONArray.length(); i++)
			{
				JSONObject json = bidResponsesJSONArray.getJSONObject(i);

				/** Moving to the node where winning bidder information is stored, Getting bidder winning status
				 */
				String responseStatus = json.getString("responseStatus").trim();

				/** Check if this bidder is the winner 
				 */
				if(responseStatus.equalsIgnoreCase("WON"))
				{
					/** Getting win url
					 */
					winUrl = json.getString("winUrl").trim();
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Winnig bidder's win url found from bq mx log: "+winUrl);

					break;
				}
				else
				{
					continue;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting winning bidder win url from supplied json string. ", e);
			logger.debug(bqmxJsonString);
		}
		finally
		{
			return winUrl;
		}

	}


	/** This method will parse the bidder advanced settings, which are filters, 
	 * received filters will be parsed and put into a map.
	 * 
	 * @param bidderFilters
	 * @return
	 */
	public static HashMap<String, String> parseBidderFilters(String bidderFilters) 
	{
		HashMap<String, String> filters = new HashMap<>();
		try
		{
			if(!bidderFilters.trim().isEmpty())
			{
				JSONObject jsonObject = new JSONObject(bidderFilters);
				JSONObject filterObj = jsonObject.getJSONObject("filters");

				@SuppressWarnings("unchecked")
				Iterator<String>it = filterObj.keys();

				while(it.hasNext())
				{
					String key = it.next();
					filters.put(key, filterObj.getString(key));
				}

				/** in case received bidder additional setting is like: 
				 * {"filters":{},"companionResourceType":{"static":"1"}}
				 * then adding a key filtercount and value = 0, bacause in this case bidder will be
				 * open to all channel calls and this filtercount will be used later on .. */
				filters.put("bidderfiltercount", String.valueOf(filterObj.length()));
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while parsing bidder filters. ", e);
		}

		return filters;
	}

}
