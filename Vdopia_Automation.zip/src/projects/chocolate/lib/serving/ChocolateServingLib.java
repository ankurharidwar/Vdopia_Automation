/**
 * Last Changes Done on Jan 23, 2015 12:23:59 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Code to handle serving behavior, added code to verify vdpia trackers
 */

package projects.chocolate.lib.serving;

import java.util.HashMap;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;

import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;



import projects.bq.BQHandler;
import projects.bq.BQQueriesLib;
import projects.chocolate.lib.serving.TrackersLib;
import projects.chocolate.lib.bidders.BiddersLib;
import projects.chocolate.lib.jsonHandler.JSONParserLib;
import projects.chocolate.lib.utils.GetChocolateLogs;
import vlib.DBLib;
import vlib.MobileTestClass_Methods;
import vlib.FileLib;
/*
import org.testng.annotations.Test;
import vlib.httpClientWrap;
import vlib.FileServerLib;
 */


public class ChocolateServingLib 
{

	static Logger logger = Logger.getLogger(ChocolateServingLib.class.getName());


	/*
	//This Code is for debugging only
	@Test
	public static void TestClass() 
	{
		try{

			int port = 9184;

			FileServerLib fileserver = new FileServerLib();
			fileserver.FTPStart(port);

			System.out.println("Debug started: ");

			String url = "http://ec2-54-90-16-143.compute-1.amazonaws.com:8058/adserver/html5/inwapads/?slide=1&sleepAfter=0&adFormat=preappvideo&ak=2679f11f6ac85ae86a8d179f9db7b148&version=1.0&vdo=1&DIMSIZE&PUBCLK&channelType=[app/site]&pageURL=[WEB_PAGE_URL]&siteName=[SITE_NAME]&appBundle=[BUNDLE_NAME/PACKAGE_NAME]&appName=[APP_NAME]&category=[CATEGORY]&refURL=[REFERER_URL]&di=[DEVICE_ID]&dif=[DEVICE_ID_FORMAT]&latlong=[LATITUDE/LONGITUDE]&cb=ABAjH0i1xWgc8Pwq4LwaG39pdiBH;ipAddress=139.82.255.255;output=js";
			//String url = "http://ec2-54-90-16-143.compute-1.amazonaws.com:8068/adserver/html5/inwapads/?slide=1&sleepAfter=0&adFormat=preappvideo&ak=2679f11f6ac85ae86a8d179f9db7b148&version=1.0&vdo=1&DIMSIZE&PUBCLK&channelType=[app/site]&pageURL=[WEB_PAGE_URL]&siteName=[SITE_NAME]&appBundle=[BUNDLE_NAME/PACKAGE_NAME]&appName=[APP_NAME]&category=[CATEGORY]&refURL=[REFERER_URL]&di=[DEVICE_ID]&dif=[DEVICE_ID_FORMAT]&latlong=[LATITUDE/LONGITUDE]&cb=ABAjH0i1xWgc8Pwq4LwaG39pdiBH;ipAddress=139.82.255.255;output=js";

			String response = httpClientWrap.sendGetRequest(url);

			writeHtmlFile(url, response, "js");

			HashMap<String, String> requiredExpectedParameters = GetExpectedParamValues.getExpectedRequiredParamValues(url);

			WebDriver driver = MobileTestClass_Methods.WebDriverSetUp("chrome", null);

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : serving Response: "+serveHudsonResponse(driver, port, url, response, requiredExpectedParameters));
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception: ", e);
		}
	}
	 */


	/** This method will create a html file containing response and browse it to check all vdopia 
	 * trackers. 
	 * 
	 * @param driver
	 * @param port
	 * @param hudsonRequestUrl
	 * @param response
	 * @param outputType
	 */
	@SuppressWarnings("finally")
	public static String verifyTrackers(Session session, String tmpHudsonLogFile, WebDriver driver, String hudsonRequestUrl, String response, HashMap<String, String> requiredExpectedParameters, Bigquery bqConnection, String bqProjectID, String bidderType,Connection connection)
	{
		String result = "";

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************* Serving bidder response to check vdopia trackers **************** ");

			String outputType = requiredExpectedParameters.get("output");

			String url;

			/** 
			 * in case of html output type request, no need to create html file containing response, just browse the request
			 * else get the response and write in html file and browse it.   
			 */
			if(outputType.equalsIgnoreCase("html"))
			{
				url = hudsonRequestUrl;
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Browsing URL: "+url + " for output: "+outputType);
			}
			else
			{
				/** Writing html file depending on output type */
				String fileLocation = writeHtmlFile(hudsonRequestUrl, response, outputType);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : File created at location: "+fileLocation);

				int fileServerPort = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("fileServerPort").toString());

				url = "http://localhost:" + fileServerPort + fileLocation;
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Browsing URL: "+url + " for output: "+outputType);
			}


			/** Getting the required values to check vdopia trackers while serving the winning vdopia rtb bidder's response,
			 * in case vast bidder wins the auction, then vdopia tracker will not fired, only those trackers will be fired 
			 * which are in vast bidder's response, therefore in case vast bidder vdopia trackers will not be checked 
			 * and adINformation hashmap will be empty.
			 */
			HashMap<String, String> adInformation = BiddersLib.getAdInformationOfWinningBidder(session, tmpHudsonLogFile, connection);

			/** in case adInformation map is empty then atleast check if either of vi or ui tracker is fired
			 * to make sure hudson response is correct, if not empty then verify all vdopia trackers
			 */
			if(adInformation.get("cid") == null)
			{
				result = verifyResponse(driver, url, response, requiredExpectedParameters);
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Response Serving Result: "+result);
			}
			else
			{
				/** adid received in case of banner is in format: html::29352::153747::113857 , else only id received 
				 * therefore in case of banner, parse string to receive ad format */

				String adid = "";
				if(requiredExpectedParameters.get("adFormat").equalsIgnoreCase("banner"))
				{
					adid = adInformation.get("adid");

					/** splitting string and getting first string as ad format */
					adid = adid.split("::")[2];
				}
				else
				{
					adid = adInformation.get("adid");
				}

				String adFormat = DBLib.getAdFormat(adid, connection);
				String campaignID = adInformation.get("cid");
				String channelID = requiredExpectedParameters.get("channel_id");
				String adsDuration = "30";

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For Serving Response, Received ad_format: "+adFormat + ", campaignID: "+campaignID + ", channelID: "+channelID + ", adsDuration: "+adsDuration);

				/** Setting up hudsonFlag = hudson by calling constructor MobileTestClass_Methods(String configFlag, String isVast2vdo, String hudsonFlag),
				 * so that si tracker need not be validated and extra tracker rtb_win and rtb_bp needs to be checked.
				 * 
				 * in case of hudson serving, count of ai tracker = number of Vdopia RTB Bidders picked up for auction,
				 * count of rtb_bp tracker = number of valid response sent by selected Vdopia RTB Bidders
				 */

				int expectedaiTracker = BiddersLib.getActualSelectedVdopiaRTBBidderCount(session, tmpHudsonLogFile, connection);
				int expecetdrtb_bpTracker = Integer.parseInt(adInformation.get("rtb_bp"));

				/** this is the mysql conection, commenting now to move to BQ */
				//new MobileTestClass_Methods("hudson", expectedaiTracker, expecetdrtb_bpTracker);
				//result = MobileAdServingLegacy.mobileAdServe(driver, adFormat, url, campaignID, channelID, adsDuration, "", false, false, "", "","");

				/** This is for BQ connection 
				 * 1. calling BQQueriesLib("hudson", expectedaiTracker, expecetdrtb_bpTracker); constructor 
				 * "huson" flag --> will notify to check any chocolate specific tracker */
				new BQQueriesLib("hudson", expectedaiTracker, expecetdrtb_bpTracker);

				/** 2. get result from bq */
				result = TrackersLib.getTrackersFromBQ(driver,adFormat,url,campaignID,channelID,adsDuration, 
						"", "", "","", "", "", bqConnection, bqProjectID, connection);

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Response Serving and Tracker Result: "+result);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking trackers from hudson response. ", e);
		}
		finally
		{
			return result;
		}

	}


	/**
	 * This method will just serve the hudson response and check for either of vi and ui tracker to make sure response is correct.
	 * This is not applicable to vast winning bidder at present because on vast winning bidder, vdopia trackers will not be fired.
	 * all vast xml specified trackers will be fired.
	 * 
	 * @param driver
	 * @param url
	 * @param response
	 * @param requiredExpectedParameters
	 */
	@SuppressWarnings("finally")
	public static String verifyResponse(WebDriver driver, String url, String response, HashMap<String, String> requiredExpectedParameters)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Serving response .... ");

		boolean flag;
		String result = "";

		try
		{
			String channelID = requiredExpectedParameters.get("channel_id");
			String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker start time: "+trackerStartTime + " for channelID: "+channelID);

			driver.get(url);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sleeping for 2 seconds .... ");
			Thread.sleep(2000);

			flag = MobileTestClass_Methods.GetCampaignTracker("vi", null, channelID, trackerStartTime);

			//Check campaign side tracker first, if found then response is okay, if not then check ui tracker to validate response. 

			if(flag)
			{
				result = "PASS: vi tracker found, hudson response is correct. ";
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : vi tracker found, hudson response is correct. ");
			}
			else
			{
				flag = MobileTestClass_Methods.GetChannelTracker("ui", channelID, trackerStartTime);

				if(flag)
				{
					result = "PASS: ui tracker was found, hudson response is correct. ";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ui tracker was found, hudson response is correct. ");

					//In case ui tracker is fired then check the hudson response message
					//result = result + VerifyResponseMessages.verifyNoAdFoundMessage(response, outputType);
				}
				else
				{
					result = "FAIL: neither of ui and vi tracker was fired, hudson response is not correct. ";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : neither of ui and vi tracker was fired, hudson response is not correct. ");
				}
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while serving the response. ", e);
		}
		finally
		{
			return result;
		}

	}


	/** This method will create a html file with the content corresponding to output type and return the
	 *  file location like /tempfiles/xyz.html to be browsed on driver
	 * @param hudsonRequestUrl
	 * @param response
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String writeHtmlFile(String hudsonRequestUrl, String response, String outputType)
	{
		String pageSource = "";
		String fileLocation = TestSuiteClass.AUTOMATION_HOME.toString();
		String fileName = "/tempfiles/";

		try
		{
			if(outputType.equalsIgnoreCase("js"))
			{
				fileName = fileName + "js_"+MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss")+".html";
				fileLocation = fileLocation + fileName;

				pageSource = jspageSource(hudsonRequestUrl);

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : File is being created at: "+fileLocation + " for output = js " );
			}
			else if(outputType.equalsIgnoreCase("javascript") || outputType.equalsIgnoreCase("xhtml"))
			{
				fileName = fileName + "javascript_"+MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss")+".html";
				fileLocation = fileLocation + fileName;

				pageSource = xhtmlJavaScriptpageSource(response);

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : File is being created at: "+fileLocation + " for output = javascript/xhtml" );
			}
			else
			{
				fileLocation = "<Not_Supported_OutputType="+outputType+">";
				logger.warn("This type of output = "+outputType + " is not supported. ");
			}

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : File will be created at: "+fileLocation);

			//Writing file content
			if(FileLib.WriteTextInFile(fileLocation, pageSource))
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : file at: "+fileLocation + " was written successfully. ");
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : file at: "+fileLocation + " was not written successfully. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while writing html file to analyze hudson request response. ", e);
		}
		finally
		{
			return fileName;
		}
	}


	/** This method will return the page source for js requests, to be written in html file later on
	 *   
	 * @param hudsonRequestUrl
	 * @return
	 */
	public static String jspageSource(String hudsonRequestUrl)
	{
		String pageSource = "<html><body><div align=\"center\" width=300px height=250px >\n" +
				"<script src = '" + hudsonRequestUrl +"'>\n" +
				"</script></div></body></html>";

		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Page Source for output type = javascript is being returned as: ");
		logger.debug(pageSource);

		return pageSource;
	}


	/** This method will return the page source for xhtml/javascript requests, to be written in html file later on
	 * 
	 * @param response
	 * @return
	 */
	public static String xhtmlJavaScriptpageSource(String response)
	{
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Page Source for output type = javascript/xhtml is being returned as: ");
		logger.debug(response);

		return response;
	}


	/** This method will get the response of chocolate get requests, write in a file and serve it, 
	 * Tracker validation will be done based on winning bidder type, if winning bidder is a vdopia bidder then all trackers will be validated.
	 *  
	 * @return
	 */
	public static String validateChocolateResponse(Session session, String tmpHudsonLogFile, WebDriver driver, String chocolateRequestUrl, String response, 
			HashMap<String, String> requiredExpectedParameters, Bigquery bqConnection, String bqProjectID, Connection connection)
	{
		String result = "";

		/** 1. Get bq mx json string from server log 
		 * 2. Get winning bidder from this json string 
		 * 3. Check if the winning bidder is rtb type then get ad information detail
		 * 4. serve the response and check trackers
		 */
		String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
		String winningBidderFromBqMxLog = JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);
		String outputType = requiredExpectedParameters.get("output");

		if(!bqmxJsonString.isEmpty())
		{
			if(!winningBidderFromBqMxLog.isEmpty())
			{
				/** do not serve in case of Goolgle adx is winning bidder - thats a fall back feature */
				if(!winningBidderFromBqMxLog.equalsIgnoreCase("GOOGLE_ADX_FALLBACK"))
				{
					/** If there is any winning bidder, then get bidder information from db
					 */
					HashMap<String, String> bidderInfo = DBLib.getBidderInformation(winningBidderFromBqMxLog, connection);
					String isVdopiaBidder = bidderInfo.get("isvdopiabidder");
					String bidderType = bidderInfo.get("biddertype");

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : value received about winning bidder: "+winningBidderFromBqMxLog+ ", isVdopiaBidder: "+isVdopiaBidder + ", bidderType: "+bidderType);

					/** Verify trackers only for winning vdopia rtb bidders 
					 */
					if(isVdopiaBidder.equalsIgnoreCase("1"))
					{
						if(bidderType.startsWith("rtb"))
						{
							if(outputType.equalsIgnoreCase("vast"))
							{
								result =  "SKIP: Curently Serving trackers are not verified for vast request,\n but vast response can be checked using" +
										" module: validate_vast_response";
								logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected winning bidder is a vdopia bidder, chocolate response for vast output will not be checked .... ");
							}
							else
							{
								logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected winning bidder is a vdopia bidder, checking serving of chocolate response .... ");
								result = ChocolateServingLib.verifyTrackers(session, tmpHudsonLogFile, driver, chocolateRequestUrl, response, requiredExpectedParameters, bqConnection, bqProjectID, bidderType, connection);

							}
						}
						else
						{
							result =  "SKIP: Curently Serving trackers are not verified for "+ bidderType +" winning bidders.";
						}
					}
					else
					{
						result = "SKIP: Curently Serving trackers are not verified for non vdopia winning bidders.";
					}
				}
				else
				{
					result = "SKIP: In case of winning bidder = GOOGLE_ADX_FALLBACK, ad serving is not verified. ";
				}
			}
			else
			{
				result = "SKIP: No winning bidder found therefore response will not be served. ";
			}
		}
		else
		{
			result = "SKIP: No BQ MX Json String received from log, check log file location.";
		}

		logger.info(result);
		return result;
	}

	
	/**
	 * This method will verify the source(marketplace/direct) from BQ for serving through chocolate
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param channelID
	 * @param campaignID
	 * @return
	 */
	public static String verifySource(String trackerStartTime, String trackerEndTime, String channelID, String campaignID, Bigquery bigQueryConnection, 
			String projectID)
	{
		String result = "";

		/** Getting the query of BQ to get the value of source */
		String query = BQQueriesLib.queryToGetSource(trackerStartTime, trackerEndTime, channelID, campaignID);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : executing query to check source from ad log: "+ query);

		/** Geting Query Results in json format*/
		GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection, projectID, query);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Result in json format is :" + queryResult);

		/** Get Query Results */
		String [] resultArr = new BQHandler().get1DArrayFromBQResults(queryResult);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Result in 1D array format is :" + resultArr);

		if(resultArr.length > 0)
		{
			if(resultArr[0].equalsIgnoreCase("marketplace"))
			{
				result = "PASS: Source = marketplace, as exepected.";
			}
			else{
				result = "FAIL: Expected source = marketplace but actual = " + resultArr[0];
			}
		}
		else
		{
			result = "SKIP: No Data received from BQ to check field source.";
		}

		return result;
	}

	
	/** Get container size while serving ads
	 * 
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param channelID
	 * @param campaignID
	 * @param bigQueryConnection
	 * @param projectID
	 * @return
	 */
	public static String verifyContainerSize(String trackerStartTime, String trackerEndTime, String channelID, String campaignID, Bigquery bigQueryConnection, 
			String projectID)
	{
		String result = "";


		/** Getting the query of BQ to get the value of container size */
		String query = BQQueriesLib.queryToGetContainer_size(trackerStartTime, trackerEndTime, channelID, campaignID);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : executing query to check source from ad log: "+ query);

		/** Geting Query Results in json format*/
		GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection, projectID, query);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Result in json format is :" + queryResult);

		/** Get Query Results */
		String [] resultArr = new BQHandler().get1DArrayFromBQResults(queryResult);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Result in 1D array format is :" + resultArr);

		if(resultArr.length > 0)
		{
			if(!(resultArr[0].equalsIgnoreCase("null") || resultArr[0].equalsIgnoreCase("")))
			{
				result = "PASS: Container size is nither balnk nor null";
			}
			else{
				result = "FAIL: Container size is either balnk or null";
			}
		}
		else
		{
			result = "SKIP: No Data received from BQ to check container size.";
		}

		return result; 

	}

}
