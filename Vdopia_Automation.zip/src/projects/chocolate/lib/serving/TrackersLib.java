package projects.chocolate.lib.serving;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;

import com.google.api.services.bigquery.Bigquery;
import com.mysql.jdbc.Connection;

import projects.adserve.mobileAdServe.lib.MobileAdServingLib;
import projects.adserve.mobileAdServe.lib.MobileAdServingUtilsLib;
import projects.bq.BQQueriesLib;


public class TrackersLib 
{

	static Logger logger = Logger.getLogger(TrackersLib.class.getName());

	
	/**
	 * This method will get the vdopia trackers fired by chocolate from bq.
	 *  
	 * @param driver
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adsDuration
	 * @param custom_details
	 * @param expectedImpressionTrackerURLs
	 * @param actionType
	 * @param destinationURL
	 * @param companionBanner
	 * @param channelSettings
	 * @param bqConnection
	 * @param bqProjectID
	 * @param mySqlConnection
	 * @return
	 */
	public static String getTrackersFromBQ(WebDriver driver, String adFormat, String adURL, String campaignID, String channelID, String adsDuration, 
			String expectedImpressionTrackerURLs, String actionType, String custom_details,String destinationURL, String companionBanner, String channelSettings,
			Bigquery bqConnection, String bqProjectID, Connection mySqlConnection)
	{
		String result = "";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting vdopia trackers fired by chocolate from bq ..... ");
		try
		{
			/** getting current db time from bq - startTime*/
			String trackerStartTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);

			/** first parameter "marketplace" in the below method - will be used to decide the value of boolean parameter proccedTest  */
			TreeMap<String, TreeMap<String, TreeMap<String, String>>> mobileServingData = MobileAdServingLib.mobileAdServe("marketplace", driver, adFormat, adURL, campaignID, 
					channelID, adsDuration, expectedImpressionTrackerURLs,  actionType, false, false, custom_details , destinationURL, companionBanner, 
					channelSettings, bqConnection, bqProjectID, mySqlConnection);

			/** getting current db time from bq - endTime*/
			String trackerEndTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);

			/** creating a list to contain the above created map as desired by the below mwthod */
			List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> trackerData = new ArrayList<>();
			trackerData.add(mobileServingData);

			/** results -- getting trackers from adlog table in bq */
			List<String> resultList= MobileAdServingUtilsLib.getMobileAdServingTrackersFromBQ(trackerData, bqConnection, bqProjectID);
			result = resultList.get(0);

			/** checking source value from adlog table in bq */
			result =  result + "\n" + ChocolateServingLib.verifySource(trackerStartTime, trackerEndTime, channelID, campaignID, bqConnection, bqProjectID);

			/** Checking container size from adlog table in bq */
			result = result + "\n" + ChocolateServingLib.verifyContainerSize(trackerStartTime, trackerEndTime, channelID, campaignID, bqConnection, bqProjectID);


		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting vdopia trackers fired by chocolate. ", e);
		}

		return result;
	}


}
