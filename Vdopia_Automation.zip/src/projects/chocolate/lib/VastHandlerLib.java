/**
 * 
 */
package projects.chocolate.lib;



import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.httpClientWrap;



/**
 * This class having method to control the vast related things
 *
 */
public class VastHandlerLib 
{

	static Logger logger = Logger.getLogger(VastHandlerLib.class.getName());


	/**
	 * This method will copy the vast player code from tpt folder to tempfiles folder then replace the
	 * vast xml url into vast player code then return the vast player url.
	 * @param vastXmlFileurl
	 * @return
	 */
	public static String copyVastPlayerCodeToResult(String chocolateUrl, String taskID)
	{
		String url = "";
		try{

			String sourceDir = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/vast_player/");
			//String destinationDir = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tempfiles/");
			String destinationDir = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/")+taskID;

			/** Copy all files from tpt folder to tempfiles folder*/
			FileLib.CopyAllFilesToDirectory(sourceDir, destinationDir);

			/** Replace the vast xml url into vast player code*/
			String vastPlayerFileLocation = destinationDir + "vastplayer.html";
			String content = FileLib.ReadContentOfFile(vastPlayerFileLocation);
			String newContent = content.replace("url_to_be_replace", chocolateUrl);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Content of vast player after replace the vast xml url: "+newContent);
			FileLib.WriteTextInFile(vastPlayerFileLocation, newContent);
			String ip = ExecuteCommands.ExecuteCommand_ReturnsOutput("ipconfig getifaddr en1");
			url = "http://"+ip+"/tempfiles/vastplayer.html";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vast player url is : "+url);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occured when copy player code to tmp file", e);
		}

		return url;

	}


	/**
	 * This method will serve the vast xml into vast player and verified that ad is played or not by verifying alert text
	 * TO DO - LATER ON - CURRENTLY ONLY VI IS BEING VALIDATED LATER ON OTHER TRACKERS WILL ALSO BE VERIFIED  
	 * 
	 * @param vastPlayerUrl
	 * @return
	 */
	public static String playVastXMLbyVastPlayer(String vastPlayerUrl, WebDriver driver)
	{
		String result ="";

		try
		{
			if(new VastHandlerLib().checkVastAdImpression(driver, vastPlayerUrl))
			{
				result = "PASS: Impression served from received vast response, url used: "+vastPlayerUrl;
			}
			else
			{
				result = "FAIL: Impression wasn't served from received vast response, url used: "+vastPlayerUrl;
			}

		}catch (Exception e) 
		{
			result = "FAIL: THERE was error while playing vast resposne with url: "+vastPlayerUrl;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was ad error while playing vast resposne with url: "+vastPlayerUrl, e);
		}

		return result;
	}



	/**
	 * this will check the vast ad impression only  
	 * 
	 * @param driver
	 * @param vastPlayerUrl
	 * @return
	 */
	public boolean checkVastAdImpression(WebDriver driver, String vastPlayerUrl)
	{
		boolean flag = false;

		if(driver != null)
		{
			try{
				/** Launch vast player url */ 
				driver.get(vastPlayerUrl);

				/** Clicked on vast player to play the ad*/
				By by = By.id("AdContainer");
				driver.findElement(by).click();

				/** Wait until ad is not playing(Alert is not displaying) */
				WebDriverWait wait = new WebDriverWait(driver, 8);
				wait.until(ExpectedConditions.alertIsPresent());

				/** Move focus on alert and get its text*/
				String text = driver.switchTo().alert().getText().toString();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : The text of the alert is: "+ text);

				/** Applying the condition to verify the text of alert for validating that ad is available or not*/ 
				if(text.equalsIgnoreCase("AD.IMPRESSION"))
				{
					flag = true ;
				}

				/** Accept the alert*/
				driver.switchTo().alert().accept();
			}
			catch (Exception e) {
				flag = false;
			}
		}
		else
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Error occurred while creating driver. ");
		}

		return flag;
	}



	/**
	 * This method will determine expected winning bidder, in case none - then
	 * analyze if GOOGLE_ADX_FALLBACK can be a winning bidder
	 * 
	 * 1. NO FALL BACK OPTION: when there is winning bidder - chocolate returned
	 * a vast response ==> Serve vast response in mobile vast player 2. FALL
	 * BACK OPTION: means channel has a fall back url and chocolate request has
	 * both parameters like: player=mobilevastplayer & output=vast in this case,
	 * if there is no winning bidder, then chocolate returns the fall back url
	 * in tags: <VASTAdTagURI> passBackURL </VASTAdTagURI> in vast response so
	 * automation doesn't serve this response as fall back url may or may not
	 * have the ad, just check the presence of VASTAdTagURI in response.
	 * 
	 * sample request:
	 * http://ec2-54-163-18-219.compute-1.amazonaws.com:8058/adserver
	 * /html5/inwapads
	 * /?ipAddress=37.143.191.255;slide=1&sleepAfter=0&adFormat=preappvideo
	 * &ak=bf0e6460a27fcf73930f28cc9e1c76ce
	 * &version=1.0&vdo=1&DIMSIZE&PUBCLK&channelType
	 * =%5Bapp/site%5D&pageURL=%5BWEB_PAGE_URL
	 * %5D&siteName=%5BSITE_NAME%5D&appBundle
	 * =%5BBUNDLE_NAME/PACKAGE_NAME%5D&appName
	 * =%5BAPP_NAME%5D&category=%5BCATEGORY
	 * %5D&refURL=%5BREFERER_URL%5D&di=%5BDEVICE_ID
	 * %5D&dif=%5BDEVICE_ID_FORMAT%5D
	 * &latlong=%5BLATITUDE/LONGITUDE%5D&cb=ABAjH0i1xWgc8Pwq4LwaG39pdiBH
	 * ;player=mobilevastplayer&output=vast
	 * 
	 * @param requiredExpectedParameters
	 * @param expectedWinningBidder
	 * @return
	 */
	public static String ifFallBackBidder(HashMap<String, String> requiredExpectedParameters, String expectedWinningBidder)
	{
		String vastTag = requiredExpectedParameters.get("vast_tag");

		if(expectedWinningBidder.isEmpty())
		{
			/** checking if requested channel has fall back url support -> request has params: output=vast, player=mobilevastplayer
			 * and vast_tag=<valid url> in db */

			if(requiredExpectedParameters.get("output").equalsIgnoreCase("vast")
					&& requiredExpectedParameters.get("player").equalsIgnoreCase("mobilevastplayer")
					&& !vastTag.isEmpty())
			{

				/** checking if vast_tag is returning 200 ok status */
				int statusCode = httpClientWrap.getStatusCodeOfGetRequest(vastTag, null);

				if(statusCode == 200)
				{
					expectedWinningBidder = "GOOGLE_ADX_FALLBACK";
				}
			}
		}

		return expectedWinningBidder;
	}


	/**
	 * This method will check the vast response in case of fall back behavior or if there is a winning bidder the serve vast response else skip. 
	 * 
	 * @param driver
	 * @param chocolateRequest
	 * @param winningBidderFromBqMxLog
	 * @param response
	 * @param expectedVastTag
	 * @return
	 */
	/*public static String validateVastResponse(WebDriver driver, String chocolateRequest, String winningBidderFromBqMxLog, String response, String expectedVastTag)
	{
		String result;

	 *//** serve vast response through a mobile player if there is valid winning bidder *//*
		if(!winningBidderFromBqMxLog.isEmpty())
		{
			if(!winningBidderFromBqMxLog.equalsIgnoreCase("GOOGLE_ADX_FALLBACK"))
			{
	  *//** Copy the vast player and its js from tpt folder to tempfile *//*
				String vastPlayerUrl = VastHandlerLib.copyPlayerCodeToTemp(chocolateRequest, "");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vast player url to be browsed: " + vastPlayerUrl);

	   *//** Serve the vast xml into vast player and verified that ad is played by verifying the alert text *//*
				result = VastHandlerLib.playVastXMLbyVastPlayer(vastPlayerUrl, driver);
			}
			else
			{
	    *//** add code to check string in vast response <VASTAdTagURI> passBackURL </VASTAdTagURI> in case of fall back behavior *//*
				result = parseVastResponse(response, expectedVastTag);
			}
		}
		else
		{
			result = "SKIP: There was no winning bidder, therefore vast response will not be served. ";
		}

		return result;
	}*/


	/** This method will parse the vast response in case of fall back behavior and return the validation result if 
	 * vast tag is present in response or not.
	 * 
	 * @param response
	 * @param expectedVastTag
	 * @return
	 */
	public static String parseVastResponse(String response, String expectedVastTag)
	{
		String result;

		/**
		 * (?s) --> ignore new lines in match, \\]\\] --> escaping unclosed ], ?<=VASTAdTagURI --> don't include VASTAdTagURI in match.
		 */
		Pattern pattern = Pattern.compile("(?s)(?<=VASTAdTagURI><!\\[CDATA\\[)(.*)(?=\\]\\]><\\/VASTAdTagURI>)");
		Matcher match = pattern.matcher(response);

		if(match.find())
		{
			String vastTagFromResponse = match.group();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : vastTagFromResponse: "+vastTagFromResponse);

			// need to remove extra new line from above received url from response
			if(vastTagFromResponse.equalsIgnoreCase(expectedVastTag))
			{
				result = "PASS: Its a fallback scenario, expected vast tag: "+expectedVastTag+ " is present in received vast response. ";
			}
			else
			{
				result = "FAIL: Its a fallback scenario, expected vast tag: "+expectedVastTag +" is not present in received vast response. ";
			}
		}
		else
		{
			result = "FAIL: Its a fallback scenario, couldn't find vast tag in received chocolate response. ";
		}

		return result;
	}

}
