/**
 * Last Changes Done on Jan 19, 2015 3:55:40 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;

import projects.chocolate.lib.bidders.BiddersLib;
import projects.chocolate.lib.jsonHandler.JSONValidationLib;
import projects.chocolate.lib.utils.GetChocolateLogs;
import projects.chocolate.lib.utils.Maxmind;



import vlib.MobileTestClass_Methods;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;


public class PricingLib 
{

	static Logger logger = Logger.getLogger(PricingLib.class.getName());


	/** This method will check the bidding floor price which will be used in post request (Data to be posted requests)
	 * 
	 * @param testUrl
	 * @param bidder
	 * @param requiredExpectedParameters
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static String validateFloorPrice(String testUrl, String bidder, HashMap<String, String> requiredExpectedParameters) throws SQLException, ClassNotFoundException 
	{
		float floorPriceDemand = 1.0f;

		//2. get ip address from url
		String ipAddress = requiredExpectedParameters.get("ip");

		//3. get channel_id through apikey from database
		String channel_Id = requiredExpectedParameters.get("channel_id");

		//4. get country code through ipaddress by maxmind
		String country_Code = Maxmind.getGeoDetailsUsingMaxmind(ipAddress, "countrycode");

		//5. get floor price usd from channel_floor_price database table
		String query = "SELECT IFNULL(floor_price_usd,0) AS floor_price_usd FROM channel_floor_price WHERE channel_id = '" + channel_Id + "' AND country_code = '" + country_Code + "'";

		//Creating SQL Connection
		Connection con = MobileTestClass_Methods.CreateSQLConnection();

		//Getting bidder Vdopia Margin
		String[] arr_floor_price = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(con, query);

		//Closing Connection
		con.close();
		float floorPriceSupply = 1.0f;
		if(arr_floor_price[0] == null)
		{
			floorPriceSupply = 1.0f; 
		}
		else
		{
			floorPriceSupply = Float.parseFloat(arr_floor_price[0]);
		}
		if(Float.compare(floorPriceSupply, 0f)==0)
		{
			floorPriceSupply = 1.0f;
		}

		//6. get bidder margin through bidder from database
		// Get Vdopia Margin from database
		query = "SELECT IFNULL(BidderVdopiaMargin,0) AS Margin FROM hudsonBidder WHERE BidderId = '" + bidder + "'";

		//Creating SQL Connection
		con = MobileTestClass_Methods.CreateSQLConnection();

		//Getting bidder Vdopia Margin
		String[] vdopiaMargin = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(con, query);
		//Closing Connection
		con.close();

		float margin = Float.parseFloat(vdopiaMargin[0]) / 100.0f;

		//7. return floor price demand side
		floorPriceDemand = floorPriceSupply / (1.0f - margin);
		String returnFloorpriceDemand = Float.toString(floorPriceDemand);
		return returnFloorpriceDemand;
	}


	/** This method will validate the winning bidder.
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param hudsonMappings
	 * @param requiredExpectedParameters
	 * @param connection
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String validateWinningBidder(Session session, String tmpHudsonLogFile, String hudsonMappings, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		String result = "";
		try
		{
			/** Get bidder and their response map from bq log */
			TreeMap<String, String> bidderPricingMap = BiddersLib.getBidderPricingMap(session, tmpHudsonLogFile, hudsonMappings, requiredExpectedParameters, connection);

			/** Get the expected winning bidder */
			String expectedWinningBidder = PricingLib.getExpectedWinningBidder(bidderPricingMap, connection);

			/** in case channel has fallback url and request has params: player=mobileplayer,output=vast
			 * then if there is no expected winning bidder --> GOOGLE_ADX_FALLBACK */
			expectedWinningBidder = VastHandlerLib.ifFallBackBidder(requiredExpectedParameters, expectedWinningBidder);
			
			/** Getting JSON string containing winning bidder information */
			String winningBidderJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);

			/** Get number of bidResponses from BQ Log */
			int bidResponses = 0;

			try{
				bidResponses = new JSONObject(winningBidderJsonString).getJSONArray("bidResponses").length();
			}catch(JSONException j){
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting bidResponse array from bq json string, considering bidResponses = 0");
				logger.error(j.getMessage());
			}

			/** if no expected bidder found then check bid response array also, both should be empty */
			if(expectedWinningBidder.isEmpty() && bidResponses == 0)
			{
				result = "SKIP: There was no expected bidder found as well as" +
						" there was no bidder response found in bq json string in chocolate log. ";

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : validateHudsonWinningBidder Result: " +result);
			}
			else
			{
				/** Get the actual winning bidder */
				result = JSONValidationLib.compareWinningBidderWithExpectedOne(winningBidderJsonString, expectedWinningBidder, connection);
			}
		}
		catch(Exception e)
		{
			result = "SKIP: Exception occurred while validating expected and actual winning bidder. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while validating expected and actual winning bidder. ", e);
		}
		finally
		{
			return result;
		}
	}


	/** This method will get the expected winning bidder
	 * 
	 * @param bidderPricingMap
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getExpectedWinningBidder(TreeMap<String, String> bidderPricingMap, Connection con)
	{
		float price = 0f;
		float winPrice = 0f;
		float secondPrice = 0f;
		float winPriceSupply = 0f;
		float winPriceDemand = 0f;
		String winningBidderId= "";

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : .... Getting expected hudson winning bidder ......");

			//Check if provided hash map 
			if(bidderPricingMap.isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* No bidder response received, No pricing calculation will be performed. ******** ");
			}
			else
			{
				for (Map.Entry<String,String> entry : bidderPricingMap.entrySet())
				{
					String bidderId = entry.getKey();

					try{
						price = Float.parseFloat(entry.getValue());
					}catch(NumberFormatException n)
					{
						price = 0f;
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Reassigning price of bidder: "+bidderId + " to: "+price);
						logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Correct Price is not received for bidder: "+bidderId + " actual price received: "+entry.getValue());
					}

					//Get Vdopia Margin from database
					String query = "SELECT IFNULL(BidderVdopiaMargin,0) AS Margin FROM hudsonBidder WHERE BidderId = '" + bidderId + "'";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Vdopia Margin by query: "+query);

					//Getting bidder Vdopia Margin
					String[] vdopiaMargin = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(con, query);

					if(vdopiaMargin.length < 1 || vdopiaMargin[0] == null)
					{
						vdopiaMargin[0] = "0";
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting vdopia margin for bidder: "+bidderId + " reassigning margin to 0.0");
					}

					float margin = Float.parseFloat(vdopiaMargin[0]) / 100.0f;
					float bidderPriceForAuction = price * (1.0f - margin);

					if (Float.compare(bidderPriceForAuction, winPrice) > 0) 
					{
						secondPrice = winPrice;
						winPrice = bidderPriceForAuction;
						winningBidderId = bidderId;
					}
					else if (Float.compare(bidderPriceForAuction, secondPrice) > 0)
					{
						secondPrice = bidderPriceForAuction;
					}
				}

				//Get Bidder Auction Type from database
				String query = "SELECT IFNULL(BidderAuctionType,0) AS Margin FROM hudsonBidder WHERE BidderId = '" + winningBidderId + "'";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Auction Type by executing query: "+query);

				//Getting bidder Vdopia Margin
				String[] vdopiaAuctionType = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(con, query);

				if(vdopiaAuctionType.length < 1 || vdopiaAuctionType[0] == null)
				{
					vdopiaAuctionType[0] = "Test";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vdopia Auction is not received from db for winning bidder id: "+winningBidderId + " reassigning to: Test");
				}


				if (Float.compare(secondPrice, 0f) == 0)
				{
					secondPrice = winPrice;
				}

				if (vdopiaAuctionType[0].equals("first_price_auction"))
				{
					winPriceSupply = winPrice;
				}
				else
				{
					if (secondPrice + 0.01f > winPrice)
						winPriceSupply = secondPrice;
					else
						winPriceSupply = secondPrice + 0.01f;
				}

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : winPriceSupply== " + winPriceSupply); 

				//Get Vdopia Margin from database
				String query1 = "SELECT IFNULL(BidderVdopiaMargin,0) AS Margin FROM hudsonBidder WHERE BidderId = '" + winningBidderId + "'";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting vdopia margin by query: "+query1);

				//Getting bidder Vdopia Margin
				String[] vdopiaMargin = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(con, query1);

				if(vdopiaMargin.length < 1 || vdopiaMargin[0] == null)
				{
					vdopiaMargin[0] = "0";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting vdopia margin for bidder: "+winningBidderId + " reassigning margin to 0.0");
				}

				winPriceDemand = winPriceSupply / (1.0f - Float.parseFloat(vdopiaMargin[0]) / 100.0f);

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : winPriceDemand == " + winPriceDemand);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting expected winning bidder. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Winning Bidder is: " + winningBidderId);
			return winningBidderId.trim();
		}
	}


}

