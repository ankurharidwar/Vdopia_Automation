/**
 * Last Changes Done on Jan 23, 2015 4:20:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib;


import java.net.URLDecoder;
import java.util.HashMap;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 


import projects.chocolate.lib.jsonHandler.JSONParserLib;
import projects.chocolate.lib.requestHandler.GetRequestLib;
import projects.chocolate.lib.utils.ChocolateUtils;
import projects.chocolate.lib.utils.GetChocolateLogs;



import com.jcraft.jsch.Session;


public class ChocolateResponseErrorLib 
{

	static Logger logger = Logger.getLogger(ChocolateResponseErrorLib.class.getName());


	/** This method will verify the request rejection error messages
	 * 
	 * @param urlParam
	 * @param adFormatValidate
	 * @param outputTypeValidate
	 * @param url
	 * @param actualResponse
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String verifyRequestRejectionErrorMessage(HashMap<String, String> urlParam, boolean adFormatValidate, boolean outputTypeValidate, String url, String actualResponse)
	{
		String result = "";
		String expectedResponse = "";
		boolean verifyerrorMessage = true;

		try
		{
			String hudsonmapping = TestSuiteClass.AUTOMATION_HOME.concat("/conf/hudsonMappings.xls");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hudson Response Mapping File is located at: "+hudsonmapping);

			String output = GetRequestLib.getQueryParamsFromGetRequest(url).get("output");

			if(!outputTypeValidate)
			{
				result = " output type in supplied url, is not supported. ";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : supplied output type is not supported. ");

				//invalid output type error message
				expectedResponse = "/* Error Code: 201, Error Message: Output type not support*/var evt = document.createEvent( \"Event\" ); evt.initEvent( \"ivdoAdsUnavailable\", true, true ); window.dispatchEvent( evt ); var img=new Image(1,1); img.src=\"http://serve.vdopia.com/adserver/html5/evttrk?e=ref&referrer=\"+escape(document.referrer);";
			}
			else if(!adFormatValidate)
			{
				result = " adformat in supplied url, is not supported. ";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : supplied adformat is not supported. ");

				//Get invalid adformat error message
				expectedResponse = ChocolateUtils.getExpectedRequestRejectionMessage(hudsonmapping, output, "Invalid_Ad_Format").trim();

				/** Remove callid string from expected and actual messages before comparing response for requests
				 * having output = json, aplicable for invalid api key and adformat only  
				 */
				if(output.equalsIgnoreCase("json"))
				{
					expectedResponse = getEffectiveErrorMessageForJS(expectedResponse);
					actualResponse = getEffectiveErrorMessageForJS(actualResponse);

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expecetd Error Message After Removing CallId: "+expectedResponse);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Error Message After Removing CallId: "+actualResponse);
				}
			}
			else if(urlParam.isEmpty())
			{
				result = " apikey in supplied url, is not valid. ";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : apikey in url is not valid. ");

				//Get invalid apikey error message
				expectedResponse = ChocolateUtils.getExpectedRequestRejectionMessage(hudsonmapping, output, "Invalid_API_Key");

				/** Remove callid string from expected and actual messages before comparing response for requests
				 * having output = json, aplicable for invalid api key and adformat only  
				 */
				if(output.equalsIgnoreCase("json"))
				{
					expectedResponse = getEffectiveErrorMessageForJS(expectedResponse);
					actualResponse = getEffectiveErrorMessageForJS(actualResponse);

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expecetd Error Message After Removing CallId: "+expectedResponse);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Error Message After Removing CallId: "+actualResponse);
				}
			}
			else
			{
				/** in case request is not rejected at all then do not verify error message.
				 */
				result = "SKIP: Request rejection message need not to be checked as there was an ad response found for this request. ";
				verifyerrorMessage = false;
			}

			if(verifyerrorMessage)
			{
				/** Verify error messages */
				if(expectedResponse.trim().equalsIgnoreCase(actualResponse.trim()))
				{
					result = result + "\nPASS: Request rejection error message is as expected. ";
				}
				else
				{
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Error Message: ");
					logger.debug(expectedResponse);

					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual Error Message: ");
					logger.debug(actualResponse);
					result = result + "\nFAIL: Request rejection error message is not as expected. ";
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while checking request rejection error message: "+e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error Message Verification Result: "+result);
			return result;
		}
	}


	/** This method will check the hudson response message for No_Ad_Found case.
	 * 
	 * @param actualResponse
	 * @param output
	 * @return
	 */
	public static String verifyNoAdFoundMessage(String actualResponse, HashMap<String, String> requiredExpectedParameters, Session session, String tmpHudsonLogFile)
	{
		String result = "";

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No Ad Found Message will be checked now .... ");

			String output = requiredExpectedParameters.get("output");
			
			/** Get json string from bq mx log and find out any winning bidder, if there is no winning bidder then 
			 * only verify no ad found message.
			 */
			String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
			String winningBidderFromBqMxLog = JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);

			/** Check no ad found in case of no winning bidder */
			if(winningBidderFromBqMxLog.isEmpty())
			{
				if(output.equalsIgnoreCase("html") || output.equalsIgnoreCase("js"))
				{
					result = "SKIP: Error message is not being checked for output = "+output;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No_Ad_Found message will not be checked for output = "+output);
					actualResponse = URLDecoder.decode(actualResponse, "UTF-8").trim();
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No_Ad_Found message is being checked for output = "+output);

					String hudsonmapping = TestSuiteClass.AUTOMATION_HOME.concat("/conf/hudsonMappings.xls");
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hudson Response Mapping File is located at: "+hudsonmapping);

					//Get No_Ad_Found message
					String expectedResponse = ChocolateUtils.getExpectedRequestRejectionMessage(hudsonmapping, output, "No_Ad_Found");
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected response message for No_Ad_Found: "+expectedResponse);

					//Verify messages
					if(expectedResponse.equalsIgnoreCase(actualResponse))
					{
						result = "PASS: No_Ad_Found message is as expected. ";
					}
					else
					{
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected No_Ad_Found Message: ");
						logger.debug(expectedResponse);

						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Actual No_Ad_Found Message: ");
						logger.debug(actualResponse);
						result = "FAIL: No_Ad_Found message is not as expected. ";
					}
				}
			}
			else
			{
				result = "Skip: Error message need not to be checked as there was an ad response found for this request. ";
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occured while validation response message for No_Ad_Found case.", e);
		}

		return result;
	}


	/** This method will remove the dynamic string callid from request rejection error message for request containing output =json.
	 * This callid will be removed from both expected and output values ad compared. */
	public static String getEffectiveErrorMessageForJS(String message)
	{		
		String dynamicID = message.substring(message.indexOf("callid\":\"")+8, message.indexOf(",", message.indexOf("callid\":\"")));
		message = message.replaceFirst(dynamicID, "");
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Effective error message after removing callid string: "+message);
		return message;
	}

}
