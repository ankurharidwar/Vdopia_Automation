package projects.chocolate.lib.utils;


import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.Key;
import com.aerospike.client.policy.Policy;





public class AerospikeHandler 
{

	static Logger logger = Logger.getLogger(AerospikeHandler.class.getName());

	public static void main(String[] args) throws FileNotFoundException  {
		// TODO Auto-generated method stub

		//System.setOut(new PrintStream(new File("/Users/poojaaggarwal/Desktop/Device_Performance")));
		//getAllRecords();

		//		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : List: "+getBlueKaiCategory("b3e42dd5-63d6-4b32-9d04-cb67b81234_bk").toString());
		//
		//		//String bkExpressionStringFromDB = "(BK_2090|BK_5915|BK_36386|BK_75320|BK_142416|BK_196106|BK_219726|BK_219727|BK_219728|BK_219730|BK_416561|BK_416562|BK_416563|BK_416564|BK_416565|BK_416566|BK_416567|BK_416568|BK_416569|BK_416570|BK_416571|BK_416573|BK_416574|BK_416575|BK_416579|BK_416580|BK_416581|BK_416582|BK_416583|BK_416584|BK_416585|BK_416586|BK_416587|BK_416588|BK_416589|BK_416590|BK_416591|BK_416592|BK_416593|BK_416594|BK_416595|BK_416596|BK_416597|BK_416598|BK_416599|BK_416600|BK_416601|BK_416602|BK_417120|BK_417140)&(BK_416560)&(BK_416572)&(BK_43878)&(BK_44152)&(BK_416578)&(BK_75578)&(BK_49558)&(BK_416882)&(BK_44082)&(BK_44141)&(BK_417927)&(BK_75310)&(BK_417931)&(BK_417932)&(BK_417933|BK_417934)&(BK_417936)&(BK_417442)&(BK_43887)&(BK_43889)";		
		//		//String bluekaiExpression = "BK_2090,BK_5915,BK_36386,BK_75320,BK_142416,BK_196106,BK_219726,BK_219727,BK_219728,BK_219730,BK_416561,BK_416562,BK_416563,BK_416564,BK_416565,BK_416566,BK_416567,BK_416568,BK_416569,BK_416570,BK_416571,BK_416573,BK_416574,BK_416575,BK_416579,BK_416580,BK_416581,BK_416582,BK_416583,BK_416584,BK_416585,BK_416586,BK_416587,BK_416588,BK_416589,BK_416590,BK_416591,BK_416592,BK_416593,BK_416594,BK_416595,BK_416596,BK_416597,BK_416598,BK_416599,BK_416600,BK_416601,BK_416602,BK_417120,BK_417140,BK_416560,BK_416572,BK_43878,BK_44152,BK_416578,BK_75578,BK_49558,BK_416882,BK_44082,BK_44141,BK_417927,BK_75310,BK_417931,BK_417932,BK_417933,BK_417934,BK_417936,BK_417442,BK_43887,BK_43889,BK_14,BK_25305,BK_25320,BK_30732,BK_30943,BK_30957,BK_30961,BK_31020,BK_31089,BK_34077,BK_5955,BK_6211,BK_12276,BK_25222,BK_25321,BK_25325,BK_25326,BK_25328,BK_30739,BK_30741,BK_31039,BK_31092,BK_36228,BK_36234,BK_36479,BK_36483,BK_36484,BK_36485,BK_36486,BK_36487";
		//
		//		String bkExpressionStringFromDB = "(BK_438891)&(BK_43889)";
		//		String bluekaiExpression = "BK_43889,BK_36486,BK_36487";
		//
		//		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ExpressionMatched: "+isBidderBlueKaiCategoriesMatched(bkExpressionStringFromDB, bluekaiExpression));
	}


	/** Get all the category corresponding to supplied ifa.
	 * 
	 * @return
	 * @throws JSONException
	 */
	public static String getBlueKaiCategory(String ifa)
	{
		String bluekaiExpression = "";
		try
		{
			String host = "serve.qa.vdopia.com";
			AerospikeClient client = new AerospikeClient(host, 3000);

			if(client.isConnected())
			{
				Policy policy = new Policy();
				policy.timeout = 60000;

				Key key = new Key("profiles", "UserProfilesStore", ifa);
				Map<String, Object> cat = client.get(policy, key).bins;

				client.close();

				JSONObject json = new JSONObject((String)cat.get("data"));
				bluekaiExpression = json.getString("categories");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Category Found So Far: "+bluekaiExpression);
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Couldn't connect to server. ");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return bluekaiExpression;
	}


	/** This method checks if the supplied bidder category matches with the bluedata data received from aerospike. 
	 * 
	 * @param bkExpressionStringFromDB
	 * @param bluekaiExpression
	 */
	public static boolean isBidderBlueKaiCategoriesMatched(String bk_BidderExpression, String bluekaiExpression)
	{
		boolean expressionMatched = true; 

		/** split received expression of bidder from db by & after this expressionArr contains string separated by | */
		String [] expressionArr = bk_BidderExpression.split("&");

		/** split received expression from aerospike by , */
		String [] bluekaiCategories = bluekaiExpression.split(",");

		/** iterating expression array containing lot of bidder categories */
		for(int i=0; i<expressionArr.length; i++)
		{
			/** get | separated category string */
			String expression = expressionArr[i].replace("(", "").replace(")", "").trim();
			String [] bidderCategories = expression.split("\\|");

			int bidderCategoryNumTemp = 0;
			boolean bidderCategoryFlag = false;

			/** iterating bidderCategories array and match if any of bidderCategories objects, is found in bluekaiCategories array */
			for(int j=0; j<bidderCategories.length; j++)
			{
				String bidderCategory = bidderCategories[j].trim();

				/** removing BK_ from the received bidder category and parse it as integer */
				int bidderCategoryNum = Integer.parseInt(bidderCategory.toLowerCase().replace("bk_", "").trim());

				/** if any element of bidder category is found in bluekai and then don't match further */
				if(!bidderCategoryFlag && bidderCategoryNum > bidderCategoryNumTemp)
				{
					/** iterating bluekaiCategories array and matching bluekai category with bidder category */
					for(int k=0; k<bluekaiCategories.length; k++)
					{
						/** matching bluekai and bidder category */
						if(bluekaiCategories[k].trim().equalsIgnoreCase(bidderCategory))
						{
							/** exiting from matching of bidder category with bluekai category if any match found */
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Bidder category match: "+bidderCategory);
							bidderCategoryFlag = true;
							break;
						}
						else
						{
							continue;
						}
					}

					//break;
				}

				/** storing each bidder category */
				bidderCategoryNumTemp = Integer.parseInt(bidderCategory.toLowerCase().replace("bk_", "").trim());
			}

			/** set a flag when no category of bidder was found in bluekai categories */
			if(expressionArr.length > 1 && !bidderCategoryFlag)
			{
				expressionMatched = false;
				break;
			}
		}

		return expressionMatched;
	}


	/** This method writes the key - value in aerospike, supply the categories - this code will insert the supplied  
	 * categories in aerospike with device id suffix by _bk and _lr.
	 * 
	 * @param host
	 * @param category
	 * @return
	 */
	public static String setAerospikeCategories(String host, String category, String taskID)
	{
		String ifa = null;

		try
		{
			AerospikeClient client = new AerospikeClient(host, 3000);

			if(client.isConnected())
			{
				com.aerospike.client.policy.WritePolicy policy = new com.aerospike.client.policy.WritePolicy();
				policy.timeout = 60000;

				/** parsing category -- supplied in test data: 
				 * How to:  replace all the | and & sign with comma and then separate this string */
				category = category.replace("|", ",").replace("&", ",");
				List<String> categoryList = Arrays.asList(category.split(","));

				List<Integer> bluekaiCategoryList = new ArrayList<Integer>();
				List<Integer> liverampCategoryList  = new ArrayList<Integer>();

				/** store all the liveramp and bluekai categories in sorted order */
				for(int i=0; i<categoryList.size(); i++)
				{
					String strCategory = categoryList.get(i).toLowerCase().trim();
					if(strCategory.contains("lr"))
					{	
						strCategory = strCategory.replace("_", "").replace("lr", "").trim();
						liverampCategoryList.add(Integer.parseInt(strCategory));
					}
					else if(strCategory.contains("bk"))
					{
						strCategory = strCategory.replace("_", "").replace("bk", "").trim();
						bluekaiCategoryList.add(Integer.parseInt(strCategory));
					}
				}

				/** sort category lists */
				Collections.sort(bluekaiCategoryList);;
				Collections.sort(liverampCategoryList);

				String bkSegment = "{\"categories\": \""+ bluekaiCategoryList.toString().replace("[", "").replace("]","").trim() +"\",\"status\": \"\",\"last_updated\":" +new Date().getTime()+"}";;
				String lrSegment = "{\"categories\": \""+ liverampCategoryList.toString().replace("[", "").replace("]","").trim() +"\",\"status\": \"\",\"last_updated\":" +new Date().getTime()+"}";;

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " BK Segment to be inserted: "+bkSegment);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " LR Segment to be inserted: "+lrSegment);

				/** generate a device id */
				Key key = null;
				ifa = taskID+"_"+UUID.randomUUID().toString();

				//lr
				String  liveRamp =  ifa +"_lr";
				key = new Key("profiles", "UserProfilesStore", liveRamp);
				com.aerospike.client.Bin binLR = new com.aerospike.client.Bin("data", lrSegment);;
				client.put(policy, key, binLR);

				//bk
				String bluekai = ifa +"_bk";
				key = new Key("profiles", "UserProfilesStore", bluekai);
				com.aerospike.client.Bin binBK = new com.aerospike.client.Bin("data", bkSegment);;
				client.put(policy, key, binBK);

				client.close();

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " Segments are inserted for device id: "+ifa);
			}
			else
			{
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Couldn't connect to server: "+host);
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occured while inserting data in aerospike : ", e);
		}

		return ifa;
	}

}
