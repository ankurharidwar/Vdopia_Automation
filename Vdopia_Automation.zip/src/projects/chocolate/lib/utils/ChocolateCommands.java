/**
 * Last Changes Done on 4 May, 2015 6:20:53 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 



public class ChocolateCommands 
{
	
	/** Command used in earlier version:
	 * 
	 * Command used in bidder selection:
	 * "sed -n '/Number of bidders picked/, /Preprocessing done and now waiting for futures to complete/p' "+ tmpHudsonLogFile +" | grep -i \"BidderID:[0-9,a-z,A-Z]\" | awk -F \":\" '{print $3}'| sed -e \"s/ //g\"  | sort | uniq";
	 * 
	 * Command used to find bidder and bidder response from log
	 * " sed -e \"s/^<//g\" " + tmpHudsonLogFile  +  " | " + " sed -e ':a;N;$!ba;s/\\n/ /g' -e 's/CallID: /\\nCallID: /g' " + " -e \"s/\\[TRACE\\]/\\n\\[TRACE\\]/g\" " +
					" -e \"s/\\[DEBUG\\]/\\n\\[DEBUG\\]/g\" " + " -e \"s/\\[ INFO\\]/\\n\\[ INFO\\]/g\" " + "  | grep -i \"Response is\" " +
					" |grep  -i \"Bidder id:\" | grep -i \"Url:\" " +
					" | awk -F \"Bidder id: |Response is:|, Url:\" '{print $2,\"@@@@@\"$4}' " ;
	 
	 *
	 * Command used in finding number of bidder picked up
	 * command = "sed -n '/Number of bidders picked/, /com.vdopia.extRequestProcessor.Servers.ExternalRequestProcessor:retrieve/p' "+ tmpHudsonLogFile +" | grep -i \"Number of bidders\" | awk -F \":\" '{print $3}' | sort | uniq";
	 * changing sting "com.vdopia.bigQuery.bigQueryInput.BqMmxAuctionLog" to string "com.vdopia.fluentData.fluentLogs.AuctionLog" in regular expression as it is changed in chocolate log
	 */
	
	
	Logger logger = Logger.getLogger(ChocolateCommands.class.getName());
	
	
	public String formCommandToReadLog (String fileLocation, String whichCommand)
	{
		String command = "";

		if(whichCommand.equalsIgnoreCase("dataToBePosted"))
		{
			command = "cat "+fileLocation +" | grep -i 'Data to be posted' | awk -F \"BidderID:\" '{print $2}' | awk -F \". Data to be posted:\" '{print $1 , \"####\" $2}'";
		}
		else if(whichCommand.equalsIgnoreCase("BqMXLog"))
		{
			command = " sed -e \"s/^<//g \" "+ fileLocation 
					+ " | sed  -e ':a;N;$!ba;s/\\n/ /g' -e 's/CallID: /\\nCallID: /g' "
					+ " -e \"s/\\[TRACE\\]/\\n\\[TRACE\\]/g\" "  
					+ " -e \"s/\\[DEBUG\\]/\\n\\[DEBUG\\]/g\" " 
					+ " -e \"s/\\[INFO\\]/\\n\\[ INFO\\]/g\" "
					+ " | grep -n 'com.vdopia.fluentData.fluentLogs.AuctionLog:write:[0-9][0-9])  {' " 
					+ " | tail -n1 | awk -F \"  \" '{print $2}' " ;
		}
		else if(whichCommand.equalsIgnoreCase("BqLog"))
		{
			command = " sed -e \"s/^<//g \" "+ fileLocation 
					+ " | sed  -e ':a;N;$!ba;s/\\n/ /g' -e 's/CallID: /\\nCallID: /g' "
					+ " -e \"s/\\[TRACE\\]/\\n\\[TRACE\\]/g\" " 
					+ " -e \"s/\\[DEBUG\\]/\\n\\[DEBUG\\]/g\" " 
					+ " -e \"s/\\[INFO\\]/\\n\\[ INFO\\]/g\" "
					+ " | grep -n 'com.vdopia.fluentData.fluentLogs.AuctionLog:write:[0-9][0-9])  {' "
					+ " | head -n1 | awk -F \"(com.vdopia.fluentData.fluentLogs.AuctionLog:write:([0-9]+)))\" '{print $2}' ";
		}
		
		
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For: "+whichCommand + " Returning command: "+command);
		return command;
	}


}
