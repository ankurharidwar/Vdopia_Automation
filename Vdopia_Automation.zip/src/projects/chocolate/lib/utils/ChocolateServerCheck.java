/**
 * Last Changes Done on 26 Aug, 2015 10:57:21 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.MobileTestClass_Methods;



public class ChocolateServerCheck 
{

	static Logger logger = Logger.getLogger(ChocolateServerCheck.class.getName());


	/** This method will be used to start the chocolate server if its not started.
	 * 
	 * @return
	 */
	public static boolean chocolateServerStatus(Session session, Connection connection)
	{
		boolean flag = false;
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			String chocolateHomeDir= MobileTestClass_Methods.propertyConfigFile.getProperty("chocolateHomeDir").toString();
			String statusCommand = "sudo "+chocolateHomeDir+"/netty/target/jsw/hudson/bin/hudson status";
			String startCommand = "sudo "+chocolateHomeDir+"/netty/target/jsw/hudson/bin/hudson start";
			String statusoutput = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, statusCommand);

			if(statusoutput.toLowerCase().contains("netty is running"))
			{
				flag = true;
			}	
			else
			{
				int i =0;

				while(!statusoutput.toLowerCase().contains("netty is running"))
				{	
					/** starting server */
					ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, startCommand);

					Thread.sleep(2500);

					statusoutput = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, statusCommand);
					
					Thread.sleep(2500);
					
					if(statusoutput.contains("netty is running"))
					{
						flag = true;
					}

					/** limiting attempt of starting service to 10 */
					if(i == 10)
					{
						flag = false;
						break;
					}

					i++;
				}

				/** putting a delay of 10 sec in case server is being started ... */
				Thread.sleep(5000);
			}

			/** Checking serving status from rt_checkpoints table */
			checkServingStatus(connection);

			return flag;
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while starting chocolate server.", e);
			return flag;
		}		
	}		


	/** This method executes below query to check if serving is started the server, if not, then start it by updating table.
	 * 
	 * Query:
	 * select TIMESTAMPDIFF(SECOND,last_aggregation_update_time,now() ) as aggregation_update_delay, TIMESTAMPDIFF(SECOND,last_memcamp_update_time,now()) as memcamp_update_delay, 
	 * if(TIMESTAMPDIFF(SECOND,last_aggregation_update_time,now() ) > aggregation_update_delay_limit, 'AGGREGATION_DELAY_LIMIT_EXCEEDED', 
	 * if(TIMESTAMPDIFF(SECOND,last_memcamp_update_time,now()) > memcamp_update_delay_limit, 'MEMCAMP_DELAY_LIMIT_EXCEEDED', 'OK' )   ) as status,last_aggregation_update_time,
	 * aggregation_update_delay_limit,last_memcamp_update_time,memcamp_update_delay_limit from rt_checkpoints;
	 * 
	 * @param connection
	 * @return
	 */
	public static boolean checkServingStatus(Connection connection)
	{
		boolean flag = false;

		try
		{
			String sqlQuery = " SELECT IF(TIMESTAMPDIFF(SECOND,last_aggregation_update_time,now() ) > aggregation_update_delay_limit, 'AGGREGATION_DELAY_LIMIT_EXCEEDED', " +
					" IF(TIMESTAMPDIFF(SECOND,last_memcamp_update_time,now()) > memcamp_update_delay_limit, 'MEMCAMP_DELAY_LIMIT_EXCEEDED', 'OK' )   ) AS STATUS " +
					" FROM rt_checkpoints; ";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking serving status from rt_checkpoints table using query: "+sqlQuery);

			String status = MobileTestClass_Methods.ExecuteMySQLQueryReturns1DArray(connection, sqlQuery)[0];
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received status: "+status);

			if(!status.equalsIgnoreCase("OK"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received serving status from server: "+status + " updating table rt_checkpoints ... ");

				String updateQuery = "UPDATE rt_checkpoints SET last_aggregation_update_time = now();";
				flag = new DBLib().executeUpdateInsertQuery(connection, updateQuery);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Update query execution status: "+flag + " after executing query: "+updateQuery);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking serving status from db. ", e);
		}
		return flag;

	}


}