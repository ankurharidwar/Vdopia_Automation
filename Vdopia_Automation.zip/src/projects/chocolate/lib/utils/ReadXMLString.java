package projects.chocolate.lib.utils;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import java.io.ByteArrayInputStream;





public class ReadXMLString
{

	static Logger logger = Logger.getLogger(ReadXMLString.class.getName());

	/** This method will parse the supplied xml.
	 * 
	 * @param xmlString
	 * @param nodeName
	 * @param elementName
	 * @return
	 */
	public static String parseXMLString(String xmlString, String nodeName, String elementName) 
	{
		String elementValue = null;
		try 
		{			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new ByteArrayInputStream(xmlString.getBytes()));

			doc.getDocumentElement().normalize();

			//NodeList nList = doc.getElementsByTagName("Moat");
			NodeList nList = doc.getElementsByTagName(nodeName);

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					try{
					elementValue = eElement.getElementsByTagName(elementName).item(0).getTextContent();
					}catch(NullPointerException n){}
				}
			}
		} catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received XMl: "+xmlString);
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while parsing supplied xml.", e);
		}

		return elementValue;
	}

}