/**
 * Last Changes Done on Jan 19, 2015 2:29:57 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */

package projects.chocolate.lib.utils;


import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.testng.annotations.Test;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import mobi.mtld.da.Properties;
import mobi.mtld.da.device.DeviceApi;
import net.sourceforge.wurfl.core.Device;
import net.sourceforge.wurfl.core.GeneralWURFLEngine;
import net.sourceforge.wurfl.core.WURFLEngine;




public class GetDeviceInformation 
{

	static Logger logger = Logger.getLogger(GetDeviceInformation.class.getName());


	/** This test is for debugging purpose.
	 * 
	 */
	@Test
	public static void test()
	{
		new GetDeviceInformation().writeSpreadsheetWithDeviceInfo("/Users/ankur/Desktop/Automation/qascripting/Vdopia_Automation/tpt/DA_UA2.xls");

		//		HashMap<String, String> map = getDeviceInformation("Mozilla/5.0 (Linux; U; Android 4.0.3; fr-fr; MIDC410 Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30");
		//
		//		for(Entry<String, String> e : map.entrySet())
		//		{
		//			System.out.println(e.getKey() + "  ,  " + e.getValue());
		//		}
	}


	/** Get device information using wurfl.
	 * 
	 * @param userAgent
	 * @return
	 */
	public static HashMap<String, String> getDeviceInfoUsingWurfl(String userAgent) 
	{
		/** Extend the new capability/parameter by just adding them in chocolate config file
		 * Format:  <NameToBeUsedLater>:<ActualCapability> 
		 */
		List<String> parameterList = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("deviceParameters_Wurfl");

		/* Commenting this code as string deviceParameters is placed in chocolateConfig
		String deviceParameters = "model:model_name, os:device_os, osv:device_os_version, js:ajax_support_javascript, make:brand_name, istablet:is_tablet";
		List<String> parameterList = new ArrayList<String>(Arrays.asList(deviceParameters.split(",")));
		 */

		//Load wurfl xml
		String wurflLocation = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/wurfl/wurfl.xml");
		WURFLEngine engine = new GeneralWURFLEngine(wurflLocation);		

		Device device = engine.getDeviceForRequest(userAgent);

		HashMap<String, String> deviceInfo = new HashMap<String, String>();

		for(int i=0; i<parameterList.size(); i++)
		{
			String key = parameterList.get(i).split(":")[0].trim();

			String capability = parameterList.get(i).split(":")[1].trim();

			String value = "";

			try
			{
				value = device.getCapability(capability);

				//In case of capability=ajax_support_javascript, if value is true then put = 1, else = 0
				if(capability.equalsIgnoreCase("ajax_support_javascript"))
				{
					if(value.equalsIgnoreCase("true"))
					{
						value = "1";
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ajax_support_javascript is enabled. ");
					}
					else
					{
						value = "0";
						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ajax_support_javascript is not enabled. ");
					}
				}
			}
			catch(Exception e)
			{
				value = "";
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while device info from wurfl: ", e);
			}

			deviceInfo.put(key, value);
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Wurfl Information.  Key: " +key + " Value: "+value);
		}

		return deviceInfo;
	}


	/** This method will replace the wurfl code and get the device information from deviceAtlas.
	 * 
	 * @param userAgent
	 * @return
	 */
	public static HashMap<String, String> getDeviceInfoUsingDA(String userAgent)
	{
		HashMap<String, String> deviceInfo = new HashMap<String, String>();

		/** Extend the new capability/parameter by just adding them in chocolate config file
		 * Format:  <NameToBeUsedLater>:<ActualCapability> 
		 */
		List<String> parameterList = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("deviceParameters_DA");

		/** get device properties based on supplied ua */
		Properties propeties = new GetDeviceInformation().getDeviceProperties(userAgent);

		/** iterating the received the parameter list from config  */
		for(int i=0; i<parameterList.size(); i++)
		{
			String key = "";
			String propertyValue;
			String property = "";

			try{
				key = parameterList.get(i).split(":")[0].trim();
				property = parameterList.get(i).split(":")[1].trim();
				propertyValue = propeties.get(property).asString();
			}catch(Exception e){
				propertyValue = "";
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* Error occurred while getting "+property +" from device atlas: " + "\n" + e.getMessage() + " for ua: "+userAgent +  " *********");
			}

			deviceInfo.put(key, propertyValue);
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Device Atlas Information.  Key: " +key + " Value: "+propertyValue);

			/* //for wurfl - In case of capability=ajax_support_javascript, if value is true then put = 1, else = 0
			if(property.equalsIgnoreCase("ajax_support_javascript"))
			{
				if(propertyValue.equalsIgnoreCase("true")){
					propertyValue = "1";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ajax_support_javascript is enabled. ");
				}
				else{
					propertyValue = "0";
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ajax_support_javascript is not enabled. ");
				}
			}
			 */
		}

		return deviceInfo;
	}


	/** Get the Properties instance containing all values corresponding to supplied user agent.
	 * 
	 * @param userAgent
	 * @return
	 */
	public Properties getDeviceProperties(String userAgent)
	{		
		Properties property = null;
		try
		{
			try {
				userAgent = URLDecoder.decode(userAgent, "UTF-8");
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : User Agent After Decoding: "+userAgent);
			} catch (UnsupportedEncodingException e1) {
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while decoding user agent to be used in device atlas. ", e1);
			}

			String jsonfile = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/deviceAtlas/deviceAtlas.json");
			DeviceApi device = new DeviceApi();
			device.loadDataFromFile(jsonfile);
			property = device.getProperties(userAgent);

		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}

		return property;
	}


	/** Get device information using wurfl / device atlas
	 * 
	 * @param userAgent
	 * @return
	 */
	public static HashMap<String, String> getDeviceInformation(String userAgent) 
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received User Agent: "+userAgent);

		try {
			userAgent = URLDecoder.decode(userAgent, "UTF-8");
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : User Agent After Decoding: "+userAgent);
		} catch (UnsupportedEncodingException e1) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred wile decoding user agent to be used in wurfl. ", e1);
		}

		/** get device information using wurfl / device atlas -- which ever is required keep that one */
		//HashMap<String, String> deviceInformation = getDeviceInfoUsingWurfl(userAgent);
		HashMap<String, String> deviceInformation = getDeviceInfoUsingDA(userAgent);

		return deviceInformation;
	}	


	/** This method receives a spreadsheet containing the user agents in a column named - user-agent and fills other columns 
	 * from device atlas.
	 * 
	 * @param fileName
	 */
	public void writeSpreadsheetWithDeviceInfo(String fileName)
	{
		try
		{
			Workbook book = Workbook.getWorkbook(new File(fileName));
			WritableWorkbook copiedbook = Workbook.createWorkbook(new File(fileName), book);
			WritableSheet sheet = copiedbook.getSheet(0);

			int userAgentColumn = 0;
			boolean flag;
			try{
				userAgentColumn = sheet.findCell("user_agent", 0, 0, sheet.getColumns(), 0, false).getColumn();
				flag = true;
			}catch(NullPointerException n){
				flag = false;
			}

			/** proceed further only if user-agent column is found.*/
			if(flag)
			{
				/** add columns in sheet */
				sheet.addCell(new Label(sheet.getColumns(), 0, "os_name"));
				int osNameColumn = sheet.getColumns()-1;

				sheet.addCell(new Label(sheet.getColumns(), 0, "os_version"));
				int osVersionColumn = sheet.getColumns()-1;

				sheet.addCell(new Label(sheet.getColumns(), 0, "device_type"));
				int deviceTypeColumn = sheet.getColumns()-1;		

				sheet.addCell(new Label(sheet.getColumns(), 0, "device_vendor"));
				int deviceVendorColumn = sheet.getColumns()-1;
				
				for(int i=1; i<sheet.getRows(); i++)
				{
					try
					{
						logger.info("getting UA of row: "+i);
						
						/** get user agent from sheet and find all the required details from device atlas */
						String userAgent = sheet.getCell(userAgentColumn, i).getContents().trim();

						Properties property = new GetDeviceInformation().getDeviceProperties(userAgent);
						String osVersion = property.get("osVersion").asString();
						String osName = property.get("osName").asString();
						String deviceVendorName = property.get("vendor").asString();

						/** add os name and os version and device type */
						Label labelOSName = new Label(osNameColumn, i, osName);
						sheet.addCell(labelOSName);

						Label labelOSVersion = new Label(osVersionColumn, i, osVersion);
						sheet.addCell(labelOSVersion);

						String deviceType;
						if(property.get("isTablet").asBoolean()){
							deviceType = "Tablet";
						}else{
							deviceType = "Phone";
						}
						Label labelDeviceType = new Label(deviceTypeColumn, i, deviceType);
						sheet.addCell(labelDeviceType);
						
						Label labelDeviceVendor = new Label(deviceVendorColumn, i, deviceVendorName);
						sheet.addCell(labelDeviceVendor);
						
					}catch(Exception e)
					{
						logger.error(e.getMessage(), e);
					}
				}
			}
			else
			{
				logger.info("user_agent coumn wasn't found in supplied spreadsheet. ");
			}
			
			copiedbook.write();
			copiedbook.close();
			book.close();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

	}

}
