/**
 * Last Changes Done on 19 May, 2015 12:58:33 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.configuration.PropertiesConfiguration;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 




public class ReadChocolateConfig 
{

	static Logger logger = Logger.getLogger(ReadChocolateConfig.class.getName());
	
	
	/** This method will convert the comma separated values from config into a list.
	 * 
	 * @param configParam
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getCommaSeparatedValuesFromConfig(String configParam)
	{
		List<String> validAdFomatsList = new ArrayList<String>();
	
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *********** Getting required paramter values of: "+ configParam +" *********** ");
	
			/** Get all the valid ad formats from config file 
			 */
			PropertiesConfiguration conf = loadChocolateConfiguration();
	
			String values = conf.getProperty(configParam).toString().replace("[", "").replace("]", "").trim();
	
			logger.debug(configParam +" values from chocolateParam config: "+values);
	
			String [] validAdFormatsArray = values.split(",");
	
			for(int i=0; i<validAdFormatsArray.length; i++)
			{
				/** Adding parameters into a list */
				validAdFomatsList.add(validAdFormatsArray[i].trim());
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding config values in a list: "+validAdFormatsArray[i].trim());
			}
	
			logger.info(configParam+" list from config: " +validAdFomatsList.toString());
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting values of "+configParam+" list from config. ",e);
		}
		finally
		{
			return validAdFomatsList;
		}
	
	}

	
	/**
	 * This method will have the parameter name (keys) equivalent to parameter name used in rtb object json 
	 * @param hashmap
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> getKeysFromConfig(HashMap<String, String> hashmap)
	{
		HashMap<String, String> finalMap = new HashMap<String, String>();
	
		try 
		{
			PropertiesConfiguration conf = loadChocolateConfiguration();
			
			for(Entry<String, String> map : hashmap.entrySet())
			{
				String key = map.getKey();
				String value = map.getValue();
	
				try
				{
					String keyFromConfig = conf.getProperty(key).toString().trim();
					finalMap.put(keyFromConfig, value);
				}
				catch(NullPointerException e)
				{
					finalMap.put(key, value);
				}
			}
	
		} 
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while preparing the final map containing expected values. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************");
	
			for(Entry<String, String> map : hashmap.entrySet())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Final Map has key: "+map.getKey() + " Value: "+map.getValue());
			}
	
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************");
	
			return finalMap;
		}
	
	}

	
	
	/** This method loads the chocolate configuration file. 
	 */
	public static PropertiesConfiguration loadChocolateConfiguration()  
	{	
		PropertiesConfiguration propertyConfigFile = new PropertiesConfiguration();
	
		try
		{			
			String config = TestSuiteClass.AUTOMATION_HOME.concat("/conf/chocolateParam.properties");
			propertyConfigFile.load(config);
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Error occurred While Reading Config File, Ensure that Config file is at the mentioned path. ", e);
		}
		return propertyConfigFile;
	}

}
