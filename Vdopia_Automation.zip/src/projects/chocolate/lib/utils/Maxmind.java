/**
 * Last Changes Done on 5 Mar, 2015 12:07:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import java.util.Map;
import java.util.Map.Entry;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 



import com.maxmind.geoip.Location;
import com.maxmind.geoip.LookupService;


public class Maxmind 
{

	static Logger logger = Logger.getLogger(Maxmind.class.getName());
	
	
	//Get two letter country code using max mind
	@SuppressWarnings("finally")
	public static String getThreeLetterCountryCodeUsingMaxmind(String ipAddress)
	{
		String expectedValue = "";
		try
		{
			expectedValue = getGeoDetailsUsingMaxmind(ipAddress, "country");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Country Code From Maxmind: "+expectedValue);

			//Getting a Map which contains three letter key and two letter values, Getting two letter of supplied country
			Map<String, String> map = MapFromThreeLetterToTwoLetter.setThreeLetterToTwoLetter();

			//get the value (two letter country code) from map
			for(Entry<String, String> actualMap : map.entrySet())
			{
				//Getting value from map whose key is above expected value
				if(actualMap.getValue().equalsIgnoreCase(expectedValue))
				{
					expectedValue = actualMap.getKey();
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Three Letter Country Code: "+expectedValue);
					break;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while getting two letter country code from max mind. ", e);
		}
		finally
		{
			return expectedValue;
		}
	}

	//Get user information based on provided ip address using max mind
	@SuppressWarnings("finally")
	public static String getGeoDetailsUsingMaxmind(String ipAddress, String desiredValue) 
	{
		//Region getRegion = isp.getRegion(ipAddress);

		Location getLocation;
		String returnString = "";
		try
		{
			/*
			//If ip address is not supplied in url, then get it
			if(ipAddress.isEmpty() || (ipAddress == null))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ip address wasn't supplied in url, checking by site: http://wgetip.com ...");
				ipAddress = httpClientWrap.sendGetRequest("http://wgetip.com");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received ipAddress: "+ipAddress);
			}
			 */		

			String geoIPCity_datFile = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/GeoIP/GeoIPCity.dat");
			LookupService isp = new LookupService(geoIPCity_datFile);
			getLocation = isp.getLocation(ipAddress);
			isp.close();

			//Getting all location details 
			if(desiredValue.equalsIgnoreCase("latitude") || desiredValue.equalsIgnoreCase("lat"))
			{
				returnString = String.valueOf(getLocation.latitude);
			}
			else if(desiredValue.equalsIgnoreCase("longitude") || desiredValue.equalsIgnoreCase("lon"))
			{
				returnString = String.valueOf(getLocation.longitude);
			}
			else if(desiredValue.equalsIgnoreCase("countrycode") || desiredValue.equalsIgnoreCase("country"))
			{
				returnString = getLocation.countryCode;
			}
			else if(desiredValue.equalsIgnoreCase("countryname"))
			{
				returnString = getLocation.countryName;
			}
			else if(desiredValue.equalsIgnoreCase("region"))
			{
				returnString = getLocation.region;
			}
			else if(desiredValue.equalsIgnoreCase("metro"))
			{
				returnString = String.valueOf(getLocation.metro_code);
			}
			else if(desiredValue.equalsIgnoreCase("city"))
			{
				returnString = getLocation.city;
			}
			else if(desiredValue.equalsIgnoreCase("zip") || desiredValue.equalsIgnoreCase("postalcode"))
			{
				returnString = getLocation.postalCode;
			}
			else
			{
				returnString = "";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no value found for parameter: "+desiredValue);
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Value of: "+desiredValue + " is: "+returnString + " for ip address: "+ipAddress);
		}
		catch(NullPointerException n)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied ip is null.");
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while getting "+ desiredValue + " from max mind. ", e);
		}
		finally
		{
			return returnString;
		}
	}

}
