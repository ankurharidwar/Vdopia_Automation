package projects.chocolate.lib.utils;

import com.jcraft.jsch.Session;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;

public class EnvironmentSetup {

	public static void Test(Session session) 
	{
		// TODO Auto-generated method stub
		try{
			/** Copy setup files at chocolate,serve and QA server */
			String copyFrom = "/Users/navneetsharma/Desktop/qaAutomation/qascripting/Vdopia_Automation/setup/chocolate_code_release.sh";
			String copyTo = "/tmp";
			//String script_location = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt");
			//String parameter = TestSuiteClass.AUTOMATION_HOME.toString();
			//String command = "sh script_location/transferSetUpFile.sh parameter";
			//ProcessBuilder pb = new ProcessBuilder("script_location", "AUTOMATION_HOME");
			//Process p = pb.start();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel; 

			sftpChannel.put(copyFrom, copyTo);
			sftpChannel.exit();
			session.disconnect();
			//ExecuteCommands.ExecuteCommandUsingJsch(session, "scp /Users/navneetsharma/Desktop/Test.txt ec2-user@qa.vdopia.com:/tmp");

			System.out.println("Done");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
