/**
 * Last Changes Done on Jan 27, 2015 5:22:20 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import projects.chocolate.lib.bidders.BiddersLib;
import projects.chocolate.lib.jsonHandler.JSONValidationLib;



import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import jxl.Workbook;
import jxl.biff.CellFinder;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import vlib.DBLib;
import vlib.MobileTestClass_Methods;
import vlib.XlsLib;


public class ChocolateUtils 
{

	static Logger logger = Logger.getLogger(ChocolateUtils.class.getName());


	@SuppressWarnings("finally")
	public static boolean writingHudsonTestURLInExcelSheet(String fileNameWithLocation) throws IOException, RowsExceededException, WriteException, BiffException
	{	
		String HudsonBaseUrl = "";
		String FinalUrl = "";

		//This flag will decide if URLs needs to write or not.
		boolean flag = false;
		boolean urlWritten = false;

		try
		{
			Workbook book = Workbook.getWorkbook(new File(fileNameWithLocation));
			WritableWorkbook copiedBook = Workbook.createWorkbook(new File(fileNameWithLocation), book);	
			WritableSheet sheet = copiedBook.getSheet(0);	//.getSheet(sheetName);

			CellFinder cellFind = new CellFinder(sheet);	//Finding the Cell with a particular text and later on get the corresponding Row or Column;

			int column = sheet.getColumns();

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test URLs are being written in file...");

			Label lblColumnName = new Label(column, 0, "Test_URLs");	//Adding Column Name = Test_URLs at last 
			sheet.addCell(lblColumnName);

			for(int row=1;row<sheet.getRows();row++)
			{
				FinalUrl = "";

				String strRequestType = sheet.getCell(cellFind.findLabelCell("requestType").getColumn(), row).getContents().toString();
				if(strRequestType.equalsIgnoreCase("adfetch"))
				{
					//reading Test URL information - Hudson Base Url from configuration.
					HudsonBaseUrl = MobileTestClass_Methods.propertyConfigFile.getProperty("getRequest_ChocolateAdFetchBaseUrl").toString();
					flag = true;
				}
				else if(strRequestType.equalsIgnoreCase("inwapads"))
				{
					HudsonBaseUrl = MobileTestClass_Methods.propertyConfigFile.getProperty("getRequest_ChocolateInwapadsBaseUrl").toString();
					flag = true;
				}
				else if(strRequestType.equalsIgnoreCase("adrequest"))
				{
					flag = false;
				}
				else
				{
					flag = false;
				}

				if(flag)
				{
					//get all param for forming url
					String adFormat = sheet.getCell(cellFind.findLabelCell("adFormat").getColumn(), row).getContents().toString();
					String ak = sheet.getCell(cellFind.findLabelCell("ak").getColumn(), row).getContents().toString();
					String ipAddress = sheet.getCell(cellFind.findLabelCell("ipAddress").getColumn(), row).getContents().toString();
					String version = sheet.getCell(cellFind.findLabelCell("version").getColumn(), row).getContents().toString();
					String optionalParameters = sheet.getCell(cellFind.findLabelCell("optionalParameters").getColumn(), row).getContents().toString();
					String output = sheet.getCell(cellFind.findLabelCell("output").getColumn(), row).getContents().toString();

					//Create Final URL
					FinalUrl = HudsonBaseUrl + "adFormat=" + adFormat + ";" + "ak=" + ak + ";" + "ipAddress=" + ipAddress + ";" + "version=" + version  + ";" 
							+ optionalParameters + ";" + "output=" + output; 


					/*

					String HudsonReqParameter = MobileTestClass_Methods.propertyConfigFile.getProperty("HudsonReqParameter").toString();
					HudsonReqParameter = HudsonReqParameter.replace("[", "");
					HudsonReqParameter = HudsonReqParameter.replace("]", "");

					// Get required Parameter type from config file for ex:- adFormat,ak,ipAddress,version
					String[] arrHudsonRequiredParam = HudsonReqParameter.split(",");

					// Get Parameter from excel file to be write in url for ex:- adFormat
					HashMap<String, String> arrHudsonParamForUrlMap = GetHudsonparamForUrl(requestParameterToCheck);

					// Base url
					FinalUrl = FinalUrl + HudsonBaseUrl;

					// Writing mandatory parameters in url from config
					for (String hudsonRequiredParam : arrHudsonRequiredParam) 
					{
						if(arrHudsonParamForUrlMap.containsKey(hudsonRequiredParam.trim()))
						{
							if(includeExcludeFlag.equalsIgnoreCase("Yes"))
							{
								String strValue = arrHudsonParamForUrlMap.get(hudsonRequiredParam.trim());
								FinalUrl = FinalUrl + hudsonRequiredParam.trim() + "=" + strValue + ";";
							}
							arrHudsonParamForUrlMap.remove(hudsonRequiredParam.trim());
						}
						else
						{
							if(hudsonRequiredParam.trim().equalsIgnoreCase("adFormat"))
							{
								FinalUrl = FinalUrl + "adFormat=" + strAdFormatType + ";";
							}
							else
							{
								String strValue = GetHudsonReqParamFromConfig(hudsonRequiredParam.trim());
								FinalUrl = FinalUrl + hudsonRequiredParam.trim() + "=" + strValue + ";";
							}
						}
					}

					// Writing Parameters from excel file
					for (Entry<String, String> entry : arrHudsonParamForUrlMap.entrySet()) 
					{
						String strKey = entry.getKey();
						String strvalue = entry.getValue(); 
						FinalUrl = FinalUrl + strKey + "=" + strvalue + ";";
					}

					FinalUrl = FinalUrl + "output=" + desiredOutputType + ";";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Final Url: row no: " + row + "   " + FinalUrl);

					 */

					//Writing The Test URL In Excel Sheet
					Label lblTestURL = new Label(column, row, FinalUrl);
					sheet.addCell(lblTestURL);	
				}
				else
				{
					Label lblTestURL = new Label(column, row, "UnDefined_Case");
					sheet.addCell(lblTestURL);
				}
			}
			copiedBook.write();
			copiedBook.close();
			book.close();

			urlWritten = true;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test URLs are written in file.");
		}
		catch(Exception e)
		{
			urlWritten = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled while writing test urls in excel sheet by method: WritingTestURLInExcelSheet. ", e);
		}
		finally
		{
			return urlWritten;
		}
	}


	public static String getHudsonReqParamFromConfig(String hudsonRequiredParam)
	{
		String returnParameter = "";
		if(hudsonRequiredParam.equalsIgnoreCase("ak"))
		{
			returnParameter = MobileTestClass_Methods.propertyConfigFile.getProperty("Hudsonak").toString();
		}
		if(hudsonRequiredParam.equalsIgnoreCase("ipAddress"))
		{
			returnParameter = MobileTestClass_Methods.propertyConfigFile.getProperty("HudsonipAddress").toString();
		}
		if(hudsonRequiredParam.equalsIgnoreCase("version"))
		{
			returnParameter = MobileTestClass_Methods.propertyConfigFile.getProperty("Hudsonversion").toString();
		}
		return returnParameter;
	}


	/** This method checks if server is running
	 * 
	 * @param pageSource
	 * @param browser
	 * @return
	 */
	public static boolean checkServerRunning(String pageSource, String browser)
	{
		boolean flag = false;

		if(browser.equalsIgnoreCase("chrome"))
		{
			if(pageSource.contains("Google Chrome could not connect to") || pageSource.contains("This webpage is not available") || pageSource.isEmpty())
			{
				flag = false;
			}
			else
			{
				flag = true;
			}
		}
		else if(browser.equalsIgnoreCase("firefox") || (browser.equalsIgnoreCase("ff")))
		{
			if(pageSource.contains("Firefox can't establish a connection to the server at"))
			{
				flag = false;
			}
			else
			{
				flag = true;
			}
		}
		else if(pageSource == null)
		{
			flag = false;
		}
		else if(pageSource.isEmpty())
		{
			flag = false;
		}
		return flag;
	}


	/** This method will check rtb objects in hudson log
	 * 
	 * @param rtbObjectStringFromHudsonLog
	 * @param expectedAdFormatsForRTBObject
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String checkCreatedRTBObjectsInHudsonLog(String rtbObjectStringFromHudsonLog, List<String> expectedAdFormatsForRTBObject)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ############# Checking RTB Object Creation For Expected Ad Formats ################ ");
		String result = "";

		try
		{
			//Check if there is any expected ad format
			if(expectedAdFormatsForRTBObject.isEmpty())
			{
				/**This FALSE flag will be used when there is no rtb object created and which is expected, actual result will be splited upon use
				 */
				result = "FALSE # RTB Object will not be created for this scenario, please check the output type of request. ";

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :  RTB Object will not be created for this scenario, please check the output type of request. ");
			}
			else
			{
				if(rtbObjectStringFromHudsonLog.isEmpty())
				{
					/** This FALSE flag will be used when there is no rtb object created and which may be unexpected, actual result will be splited upon use
					 */
					result = "FALSE # FAIL: There was no rtb object created for this request. ";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no rtb object created for this request. ");
				}
				else
				{
					//Converting the rtb object string into a list
					List<String> rtbObjectList = Arrays.asList(rtbObjectStringFromHudsonLog.split("\n"));

					//Checking rtb object for each expected ad format in the captured hudson log
					for(int i=0; i<expectedAdFormatsForRTBObject.size(); i++)
					{
						String expectedAdFormatString = expectedAdFormatsForRTBObject.get(i).toLowerCase();
						String searchText = "";

						if(expectedAdFormatString.equalsIgnoreCase("banner"))
						{
							searchText = "banner json string";
						}
						else if(expectedAdFormatString.equalsIgnoreCase("video"))
						{
							searchText = "video json string";
						}

						logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Searching string: "+searchText + " for ad format: "+expectedAdFormatString +" in given rtb object string. ");

						int count = 0;
						for(int j=0; j<rtbObjectList.size(); j++)
						{
							String rtbObjectString = rtbObjectList.get(j).toLowerCase();

							if(rtbObjectString.contains(searchText))
							{
								count ++;

								logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : RTB Object is created for ad format: "+expectedAdFormatString);
								logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : RTB Object String: ");
								logger.info(rtbObjectString.trim());
							}
						}


						/** Creating result string based on validation of number of rtb objects created for each expected ad format
						 */
						if(count < 1)
						{
							result = result + "FAIL: RTB Object was not created for ad format: "+expectedAdFormatString + "\n";
						}
						else if(count == 1 )
						{
							result = result + "PASS: "+ count +" RTB Object was created for ad format: "+expectedAdFormatString + "\n";
						}
						else
						{
							result = result + "FAIL: "+ count +" RTB Object were created for ad format: "+expectedAdFormatString + "\n";
						}
					}
				}

			}
		}
		catch(Exception e)
		{
			result = result + "\n Exception occured while checking rtb objects in hudson log.";

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while checking rtb objects in hudson log. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ######################################################");
			return result;
		}
	}


	/** This method will return the expected ad format for which rtb objects should be created from test data file
	 *   
	 * @param fileNameWithLocation
	 * @param adformat
	 * @param outputType
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getExpectedAdFormatsForHudsonRTBObject(String fileNameWithLocation, String adformat, String outputType)
	{
		List<String> expectedAdFormats = new ArrayList<String>();
		try
		{
			//These are fixed values, can't be changed.
			String sheetName = "RTBObjectsForAdformats";
			String columnForKey = "Adformat/Output";	

			//This method will return a hash map having key from Column = Adformat/Output and value from Column = outputType
			HashMap<String, String> hashMap = XlsLib.getHashMapFromExcelsheet(fileNameWithLocation, sheetName, columnForKey, outputType.toLowerCase());
			String value = hashMap.get(adformat.toLowerCase());

			//Checking if there is no expected ad format for rtb object creation
			if(value.equalsIgnoreCase("NONE") || value.equalsIgnoreCase("NA") || value.isEmpty() || value == null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no expected ad format for output: "+outputType);
			}
			else
			{
				//Get expected ad formats in a list
				expectedAdFormats = Arrays.asList(value.split(","));
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Ad Formats For Which RTB Object is Supposed To Be Created Are: "+expectedAdFormats.toString());
			}
		}
		catch(NullPointerException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No expected adformat found for RTB Object creation for given ad format: "+adformat + " and output type: " +outputType +"\n", e);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while getting expected RTB Object for ad format: "+adformat + " and output type: " +outputType+"\n", e);
		}
		finally
		{
			return expectedAdFormats;
		}
	}


	/** This method will return the expected request rejection error message for given output type
	 * 
	 * @param fileNameWithLocation
	 * @param outputType
	 * @param requestRejectionCase
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getExpectedRequestRejectionMessage(String fileNameWithLocation, String outputType, String requestRejectionCase)
	{
		String requestRejectionMessage = "";
		try
		{
			//These are fixed values, can't be changed.
			String sheetName = "RequestRejectionMessage";
			String columnForKey = "Output/RequestRejectionCase";	

			//This method will return a hash map having key from Column = Adformat/Output and value from Column = outputType
			HashMap<String, String> hashMap = XlsLib.getHashMapFromExcelsheet(fileNameWithLocation, sheetName, columnForKey, requestRejectionCase);
			requestRejectionMessage = hashMap.get(outputType);

			//Checking if there is no expected ad format for rtb object creation
			if(requestRejectionMessage.equalsIgnoreCase("NONE") || requestRejectionMessage.equalsIgnoreCase("NA") || requestRejectionMessage.isEmpty() || requestRejectionCase == null)
			{
				requestRejectionMessage = "";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no expected request rejection error message for output: "+outputType);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while getting expected request rejection error message for output: " +outputType+"\n", e);
		}
		finally
		{
			return requestRejectionMessage.trim();
		}
	}


	/** This method will return the JSON List from RTB Objects
	 * 
	 * @param rtbObjectString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getJSONRequestListFromHudsonRTBObject(String rtbObjectString)
	{
		List<String> receivedJSON = new ArrayList<String>();

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ###### Converting JSON String Into A List From Hudson RTB Object ########");

			//Splitting the received RTB Object String and getting it into a list
			List<String> rtbObjectList = Arrays.asList(rtbObjectString.split("\n"));

			//Iterating the above list and getting JSON string in a list
			for(int i=0; i<rtbObjectList.size(); i++)
			{
				rtbObjectString = rtbObjectList.get(i).trim();

				if(!rtbObjectString.isEmpty())
				{
					//Getting JSON string from rtb object string
					rtbObjectString = rtbObjectString.substring(rtbObjectString.indexOf("{"), rtbObjectString.lastIndexOf("}") + 1).trim();

					//Adding the received json in a list
					receivedJSON.add(rtbObjectString);

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON String:  ");
					logger.info(rtbObjectString);
				}
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while splitting rtb object string into a list. " , e);
		}
		finally
		{
			return receivedJSON;
		}
	}


	/** This method will return the JSON Hash Map (ad format, json) from RTB Objects
	 * 
	 * @param rtbObjectString
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> getAdFormat_RTBObjectStringMapFromHudsonLog(String rtbObjectString)
	{
		HashMap<String, String> json = new HashMap<String, String>();

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ###### Converting JSON String Into A HashMap From Hudson RTB Object ########");

			//Splitting the received RTB Object String and getting it into a list
			List<String> rtbObjectList = Arrays.asList(rtbObjectString.split("\n"));

			//Iterating the above list and getting JSON string in a list
			for(int i=0; i<rtbObjectList.size(); i++)
			{
				String rtbString = rtbObjectList.get(i).trim();

				if(!rtbString.isEmpty())
				{
					try
					{
						//Getting JSON string from rtb object string
						String jsonString = rtbString.substring(rtbString.indexOf("{"), rtbString.lastIndexOf("}") + 1).trim();

						//Getting ad format for the above json string
						String adformat = rtbString.replace(jsonString, "");

						if(adformat.toLowerCase().contains("banner"))
						{
							adformat = "banner";
						}
						else if(adformat.toLowerCase().contains("video"))
						{
							adformat = "video";
						}

						//Adding the above value in hashmap
						json.put(adformat, jsonString);

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Ad Format: " + adformat + ", JSON String:  ");
						logger.info(json.get(adformat));
					}
					catch(StringIndexOutOfBoundsException e)
					{
						logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while splitting JSON string from rtb object string ==> ", e);
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received RTB String ==> "+rtbString);
					}
				}
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while validating rtb object string. ", e);
		}
		finally
		{
			return json;
		}
	}


	/**
	 * This method will verify each json request to be posted with respect to
	 * each selected bidder, also the type of request will be verified with
	 * respect to selected bidder.
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param requiredExpectedParameters
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String validate_bidderDataToBePosted(Session session, String tmpHudsonLogFile, HashMap<String, String> requiredExpectedParameters, Connection connection)
	{
		String result = "";
		HashMap<String, String> bidderInformation = new HashMap<>();

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #################################### JSON REQUEST TO BE POSTED VALIDATION STARTED ####################################");

			/** Get a map containing bidder and respective data to be posted 
			 */
			HashMap<String, String> bidderRequestMap = BiddersLib.getBidder_DataToBePostedMapFromLog(session, tmpHudsonLogFile);			

			if(!bidderRequestMap.isEmpty())
			{
				for(Entry<String, String> entry : bidderRequestMap.entrySet())
				{
					/** Getting bidder id and respective json request to be posted 
					 */
					String bidderID = entry.getKey().trim();
					String jsonrequestToBePosted = entry.getValue(); 

					/** Get bidder (if rtb bidder) adformat from database  
					 */
					bidderInformation = DBLib.getBidderInformation(bidderID, connection);

					String bidderAdFormat = bidderInformation.get("bidderadformat");
					String bidderType = bidderInformation.get("biddertype");

					/** Converting bidder adformats 'video','bannerNinterstitial' to standard adformats to be used later on.
					 */
					bidderAdFormat = BiddersLib.getBidderRespectiveAdFormat(bidderAdFormat);

					/** If selected bidder is rtb type then only validate json request to be posted and
					 * check if the posted request is according to selected bidder ad format.
					 */
					if(bidderType.toLowerCase().startsWith("rtb"))
					{
						/** 1. checkNodesInRTBObject method requires adformat parameter which internally interpreted like if video is passed
						 * then video object should be present else if banner is passed then banner should be present in supplied json string.  
						 */
						result = result + "Bidder_ID: " + bidderID +": " + JSONValidationLib.checkNodesInRTBObject(bidderID, bidderAdFormat, jsonrequestToBePosted, requiredExpectedParameters, connection);

						/** ****** Add validation of json with respect to bidder ad format ********
						 * validation like: video supported bidder should be have video node in request to be posted video versa.
						 * instl, height and width values should be according to ad format present in request.
						 */
						result = result + "  " + JSONValidationLib.validate_BidderRequest(bidderAdFormat, jsonrequestToBePosted, requiredExpectedParameters) + "\n";
					}
					else if(bidderType.toLowerCase().contains("vast"))
					{
						/** putting a check: there should not be any data to be posted created for vast bidders */
						if(!jsonrequestToBePosted.isEmpty())
						{
							result = result + "   " +  "FAIL: Data to be posted was created for VAST Bidder: "+bidderID;
							logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Data to be posted was created for VAST Bidder: "+bidderID);
							logger.debug(jsonrequestToBePosted);
						}
					}
				}
			}
			else
			{
				result = "SKIP: No data to be posted found in chocolate log. ";
			}
		}
		catch(Exception e)
		{
			result = "SKIP: Exception occurred while performing request to be posted validation. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while performing request to be posted validation. ", e);
		}	
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #################################### JSON REQUEST TO BE POSTED VALIDATION ENDED ####################################");
			return result;
		}
	}

}

