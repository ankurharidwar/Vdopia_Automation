/**
 * Last Changes Done on 5 Mar, 2015 12:07:45 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * class to get two letter country code from three letter country code.
 * 
 */
public class MapFromThreeLetterToTwoLetter {

  private static Map<String, String> threeLetterToTwoLetter = setThreeLetterToTwoLetter();
  private static MapFromThreeLetterToTwoLetter instanceOfMapFromThreeLetterToTwoLetter = null;

  public static Map<String, String> setThreeLetterToTwoLetter() {
    Map<String, String> threeLetterToTwoLetter = new ConcurrentHashMap<String, String>();
    threeLetterToTwoLetter.put("USA", "US");
    threeLetterToTwoLetter.put("AFG", "AF");
    threeLetterToTwoLetter.put("ALB", "AL");
    threeLetterToTwoLetter.put("DZA", "DZ");
    threeLetterToTwoLetter.put("ASM", "AS");
    threeLetterToTwoLetter.put("AND", "AD");
    threeLetterToTwoLetter.put("AGO", "AO");
    threeLetterToTwoLetter.put("AIA", "AI");
    threeLetterToTwoLetter.put("ATA", "AQ");
    threeLetterToTwoLetter.put("ATG", "AG");
    threeLetterToTwoLetter.put("ARG", "AR");
    threeLetterToTwoLetter.put("ARM", "AM");
    threeLetterToTwoLetter.put("ABW", "AW");
    threeLetterToTwoLetter.put("AUS", "AU");
    threeLetterToTwoLetter.put("AUT", "AT");
    threeLetterToTwoLetter.put("AZE", "AZ");
    threeLetterToTwoLetter.put("BHS", "BS");
    threeLetterToTwoLetter.put("BHR", "BH");
    threeLetterToTwoLetter.put("BGD", "BD");
    threeLetterToTwoLetter.put("BRB", "BB");
    threeLetterToTwoLetter.put("BLR", "BY");
    threeLetterToTwoLetter.put("BEL", "BE");
    threeLetterToTwoLetter.put("BLZ", "BZ");
    threeLetterToTwoLetter.put("BEN", "BJ");
    threeLetterToTwoLetter.put("BMU", "BM");
    threeLetterToTwoLetter.put("BTN", "BT");
    threeLetterToTwoLetter.put("BOL", "BO");
    threeLetterToTwoLetter.put("BIH", "BA");
    threeLetterToTwoLetter.put("BWA", "BW");
    threeLetterToTwoLetter.put("BVT", "BV");
    threeLetterToTwoLetter.put("BRA", "BR");
    threeLetterToTwoLetter.put("IOT", "IO");
    threeLetterToTwoLetter.put("VGB", "VG");
    threeLetterToTwoLetter.put("BRN", "BN");
    threeLetterToTwoLetter.put("BGR", "BG");
    threeLetterToTwoLetter.put("BFA", "BF");
    threeLetterToTwoLetter.put("BDI", "BI");
    threeLetterToTwoLetter.put("KHM", "KH");
    threeLetterToTwoLetter.put("CMR", "CM");
    threeLetterToTwoLetter.put("CAN", "CA");
    threeLetterToTwoLetter.put("CPV", "CV");
    threeLetterToTwoLetter.put("CYM", "KY");
    threeLetterToTwoLetter.put("CAF", "CF");
    threeLetterToTwoLetter.put("TCD", "TD");
    threeLetterToTwoLetter.put("CHL", "CL");
    threeLetterToTwoLetter.put("CHN", "CN");
    threeLetterToTwoLetter.put("CXR", "CX");
    threeLetterToTwoLetter.put("CCK", "CC");
    threeLetterToTwoLetter.put("COL", "CO");
    threeLetterToTwoLetter.put("COM", "KM");
    threeLetterToTwoLetter.put("COD", "CD");
    threeLetterToTwoLetter.put("COG", "CG");
    threeLetterToTwoLetter.put("COK", "CK");
    threeLetterToTwoLetter.put("CRI", "CR");
    threeLetterToTwoLetter.put("CIV", "CI");
    threeLetterToTwoLetter.put("CUB", "CU");
    threeLetterToTwoLetter.put("CYP", "CY");
    threeLetterToTwoLetter.put("CZE", "CZ");
    threeLetterToTwoLetter.put("DNK", "DK");
    threeLetterToTwoLetter.put("DJI", "DJ");
    threeLetterToTwoLetter.put("DMA", "DM");
    threeLetterToTwoLetter.put("DOM", "DO");
    threeLetterToTwoLetter.put("TLS", "TL");
    threeLetterToTwoLetter.put("ECU", "EC");
    threeLetterToTwoLetter.put("EGY", "EG");
    threeLetterToTwoLetter.put("SLV", "SV");
    threeLetterToTwoLetter.put("GNQ", "GQ");
    threeLetterToTwoLetter.put("ERI", "ER");
    threeLetterToTwoLetter.put("EST", "EE");
    threeLetterToTwoLetter.put("ETH", "ET");
    threeLetterToTwoLetter.put("FRO", "FO");
    threeLetterToTwoLetter.put("FLK", "FK");
    threeLetterToTwoLetter.put("FJI", "FJ");
    threeLetterToTwoLetter.put("FIN", "FI");
    threeLetterToTwoLetter.put("FRA", "FR");
    threeLetterToTwoLetter.put("GUF", "GF");
    threeLetterToTwoLetter.put("PYF", "PF");
    threeLetterToTwoLetter.put("ATF", "TF");
    threeLetterToTwoLetter.put("GAB", "GA");
    threeLetterToTwoLetter.put("GMB", "GM");
    threeLetterToTwoLetter.put("GEO", "GE");
    threeLetterToTwoLetter.put("DEU", "DE");
    threeLetterToTwoLetter.put("GHA", "GH");
    threeLetterToTwoLetter.put("GIB", "GI");
    threeLetterToTwoLetter.put("GRC", "GR");
    threeLetterToTwoLetter.put("GRL", "GL");
    threeLetterToTwoLetter.put("GRD", "GD");
    threeLetterToTwoLetter.put("GLP", "GP");
    threeLetterToTwoLetter.put("GUM", "GU");
    threeLetterToTwoLetter.put("GTM", "GT");
    threeLetterToTwoLetter.put("GIN", "GN");
    threeLetterToTwoLetter.put("GNB", "GW");
    threeLetterToTwoLetter.put("GUY", "GY");
    threeLetterToTwoLetter.put("HTI", "HT");
    threeLetterToTwoLetter.put("HMD", "HM");
    threeLetterToTwoLetter.put("VAT", "VA");
    threeLetterToTwoLetter.put("HND", "HN");
    threeLetterToTwoLetter.put("HKG", "HK");
    threeLetterToTwoLetter.put("HRV", "HR");
    threeLetterToTwoLetter.put("HUN", "HU");
    threeLetterToTwoLetter.put("IND", "IN");
    threeLetterToTwoLetter.put("ISL", "IS");
    threeLetterToTwoLetter.put("IDN", "ID");
    threeLetterToTwoLetter.put("IRN", "IR");
    threeLetterToTwoLetter.put("IRQ", "IQ");
    threeLetterToTwoLetter.put("IRL", "IE");
    threeLetterToTwoLetter.put("ISR", "IL");
    threeLetterToTwoLetter.put("ITA", "IT");
    threeLetterToTwoLetter.put("JAM", "JM");
    threeLetterToTwoLetter.put("JPN", "JP");
    threeLetterToTwoLetter.put("JOR", "JO");
    threeLetterToTwoLetter.put("KAZ", "KZ");
    threeLetterToTwoLetter.put("KEN", "KE");
    threeLetterToTwoLetter.put("KIR", "KI");
    threeLetterToTwoLetter.put("PRK", "KP");
    threeLetterToTwoLetter.put("KOR", "KR");
    threeLetterToTwoLetter.put("KWT", "KW");
    threeLetterToTwoLetter.put("KGZ", "KG");
    threeLetterToTwoLetter.put("LAO", "LA");
    threeLetterToTwoLetter.put("LVA", "LV");
    threeLetterToTwoLetter.put("LBN", "LB");
    threeLetterToTwoLetter.put("LSO", "LS");
    threeLetterToTwoLetter.put("LBR", "LR");
    threeLetterToTwoLetter.put("LBY", "LY");
    threeLetterToTwoLetter.put("LIE", "LI");
    threeLetterToTwoLetter.put("LTU", "LT");
    threeLetterToTwoLetter.put("LUX", "LU");
    threeLetterToTwoLetter.put("MAC", "MO");
    threeLetterToTwoLetter.put("MKD", "MK");
    threeLetterToTwoLetter.put("MDG", "MG");
    threeLetterToTwoLetter.put("MWI", "MW");
    threeLetterToTwoLetter.put("MYS", "MY");
    threeLetterToTwoLetter.put("MDV", "MV");
    threeLetterToTwoLetter.put("MLI", "ML");
    threeLetterToTwoLetter.put("MLT", "MT");
    threeLetterToTwoLetter.put("MHL", "MH");
    threeLetterToTwoLetter.put("MTQ", "MQ");
    threeLetterToTwoLetter.put("MRT", "MR");
    threeLetterToTwoLetter.put("MUS", "MU");
    threeLetterToTwoLetter.put("MYT", "YT");
    threeLetterToTwoLetter.put("MEX", "MX");
    threeLetterToTwoLetter.put("FSM", "FM");
    threeLetterToTwoLetter.put("MDA", "MD");
    threeLetterToTwoLetter.put("MCO", "MC");
    threeLetterToTwoLetter.put("MNG", "MN");
    threeLetterToTwoLetter.put("MSR", "MS");
    threeLetterToTwoLetter.put("MAR", "MA");
    threeLetterToTwoLetter.put("MOZ", "MZ");
    threeLetterToTwoLetter.put("MMR", "MM");
    threeLetterToTwoLetter.put("NAM", "NA");
    threeLetterToTwoLetter.put("NRU", "NR");
    threeLetterToTwoLetter.put("NPL", "NP");
    threeLetterToTwoLetter.put("ANT", "AN");
    threeLetterToTwoLetter.put("NLD", "NL");
    threeLetterToTwoLetter.put("NCL", "NC");
    threeLetterToTwoLetter.put("NZL", "NZ");
    threeLetterToTwoLetter.put("NIC", "NI");
    threeLetterToTwoLetter.put("NER", "NE");
    threeLetterToTwoLetter.put("NGA", "NG");
    threeLetterToTwoLetter.put("NIU", "NU");
    threeLetterToTwoLetter.put("NFK", "NF");
    threeLetterToTwoLetter.put("MNP", "MP");
    threeLetterToTwoLetter.put("NOR", "NO");
    threeLetterToTwoLetter.put("OMN", "OM");
    threeLetterToTwoLetter.put("PAK", "PK");
    threeLetterToTwoLetter.put("PLW", "PW");
    threeLetterToTwoLetter.put("PSE", "PS");
    threeLetterToTwoLetter.put("PAN", "PA");
    threeLetterToTwoLetter.put("PNG", "PG");
    threeLetterToTwoLetter.put("PRY", "PY");
    threeLetterToTwoLetter.put("PER", "PE");
    threeLetterToTwoLetter.put("PHL", "PH");
    threeLetterToTwoLetter.put("PCN", "PN");
    threeLetterToTwoLetter.put("POL", "PL");
    threeLetterToTwoLetter.put("PRT", "PT");
    threeLetterToTwoLetter.put("PRI", "PR");
    threeLetterToTwoLetter.put("QAT", "QA");
    threeLetterToTwoLetter.put("REU", "RE");
    threeLetterToTwoLetter.put("ROU", "RO");
    threeLetterToTwoLetter.put("RUS", "RU");
    threeLetterToTwoLetter.put("RWA", "RW");
    threeLetterToTwoLetter.put("SHN", "SH");
    threeLetterToTwoLetter.put("KNA", "KN");
    threeLetterToTwoLetter.put("LCA", "LC");
    threeLetterToTwoLetter.put("SPM", "PM");
    threeLetterToTwoLetter.put("VCT", "VC");
    threeLetterToTwoLetter.put("WSM", "WS");
    threeLetterToTwoLetter.put("SMR", "SM");
    threeLetterToTwoLetter.put("STP", "ST");
    threeLetterToTwoLetter.put("SAU", "SA");
    threeLetterToTwoLetter.put("SEN", "SN");
    threeLetterToTwoLetter.put("SYC", "SC");
    threeLetterToTwoLetter.put("SLE", "SL");
    threeLetterToTwoLetter.put("SGP", "SG");
    threeLetterToTwoLetter.put("SVK", "SK");
    threeLetterToTwoLetter.put("SVN", "SI");
    threeLetterToTwoLetter.put("SLB", "SB");
    threeLetterToTwoLetter.put("SOM", "SO");
    threeLetterToTwoLetter.put("ZAF", "ZA");
    threeLetterToTwoLetter.put("SGS", "GS");
    threeLetterToTwoLetter.put("ESP", "ES");
    threeLetterToTwoLetter.put("LKA", "LK");
    threeLetterToTwoLetter.put("SDN", "SD");
    threeLetterToTwoLetter.put("SUR", "SR");
    threeLetterToTwoLetter.put("SJM", "SJ");
    threeLetterToTwoLetter.put("SWZ", "SZ");
    threeLetterToTwoLetter.put("SWE", "SE");
    threeLetterToTwoLetter.put("CHE", "CH");
    threeLetterToTwoLetter.put("SYR", "SY");
    threeLetterToTwoLetter.put("TWN", "TW");
    threeLetterToTwoLetter.put("TJK", "TJ");
    threeLetterToTwoLetter.put("TZA", "TZ");
    threeLetterToTwoLetter.put("THA", "TH");
    threeLetterToTwoLetter.put("TGO", "TG");
    threeLetterToTwoLetter.put("TKL", "TK");
    threeLetterToTwoLetter.put("TON", "TO");
    threeLetterToTwoLetter.put("TTO", "TT");
    threeLetterToTwoLetter.put("TUN", "TN");
    threeLetterToTwoLetter.put("TUR", "TR");
    threeLetterToTwoLetter.put("TKM", "TM");
    threeLetterToTwoLetter.put("TCA", "TC");
    threeLetterToTwoLetter.put("TUV", "TV");
    threeLetterToTwoLetter.put("VIR", "VI");
    threeLetterToTwoLetter.put("UGA", "UG");
    threeLetterToTwoLetter.put("UKR", "UA");
    threeLetterToTwoLetter.put("ARE", "AE");
    threeLetterToTwoLetter.put("GBR", "GB");
    threeLetterToTwoLetter.put("UMI", "UM");
    threeLetterToTwoLetter.put("URY", "UY");
    threeLetterToTwoLetter.put("UZB", "UZ");
    threeLetterToTwoLetter.put("VUT", "VU");
    threeLetterToTwoLetter.put("VEN", "VE");
    threeLetterToTwoLetter.put("VNM", "VN");
    threeLetterToTwoLetter.put("WLF", "WF");
    threeLetterToTwoLetter.put("ESH", "EH");
    threeLetterToTwoLetter.put("YEM", "YE");
    threeLetterToTwoLetter.put("YUG", "YU");
    threeLetterToTwoLetter.put("ZMB", "ZM");
    threeLetterToTwoLetter.put("ZWE", "ZW");
    return threeLetterToTwoLetter;
  }

  public static MapFromThreeLetterToTwoLetter mapFromThreeLetterToTwoLetter() {
    if (instanceOfMapFromThreeLetterToTwoLetter == null) {
      instanceOfMapFromThreeLetterToTwoLetter = new MapFromThreeLetterToTwoLetter();
    }
    return instanceOfMapFromThreeLetterToTwoLetter;
  }

  /**
   * @param threeLetterCode three letter country code
   * @return the two letter country code
   */
  public String getTwoLetterFromThreeLetter(String threeLetterCode) {
    return threeLetterToTwoLetter.get(threeLetterCode);
  }

}
