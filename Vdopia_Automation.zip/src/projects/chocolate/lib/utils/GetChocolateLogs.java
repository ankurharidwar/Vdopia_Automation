/**
 * Last Changes Done on 13 May, 2015 5:38:23 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib.utils;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 


import vlib.ExecuteCommands;

import com.jcraft.jsch.Session;



public class GetChocolateLogs {

	static Logger logger = Logger.getLogger(GetChocolateLogs.class.getName());


	/** This method will get the bq json string from hudson log
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getBQJsonString(Session session, String tmpHudsonLogFile)
	{
		String bqJson = "";
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting BQ Log: "+tmpHudsonLogFile);

			String command = new ChocolateCommands().formCommandToReadLog(tmpHudsonLogFile, "BqLog");

			/** Getting output of grep command */
			bqJson = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, command).trim();

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : BQ Json String: ");
			logger.debug(bqJson);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting bq string. ", e);
		}
		finally
		{
			return bqJson.trim();
		}
	}


	/** This method will get the bq mmx json string from hudson log
	 * 
	 * @param session
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String getBQMMXJsonString(Session session, String tmpHudsonLogFile)
	{
		String bqMMXJson = "";
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting BQ MX Log: "+tmpHudsonLogFile);

			String command = new ChocolateCommands().formCommandToReadLog(tmpHudsonLogFile, "BqMXLog");

			/** Getting output of grep command */
			bqMMXJson = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, command).trim();

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : BQ MMX Json String: ");
			logger.debug(bqMMXJson);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting bq mx string. ", e);
		}
		finally
		{
			return bqMMXJson.trim();
		}
	}


	/** This method will execute the diff command to get the hudson log of the current request
	 * 
	 * @param session
	 * @param originalHudsonLogFile
	 * @param copiedHudsonLogFile
	 * @param tmpHudsonLogFile
	 * @return
	 */
	@SuppressWarnings("finally")
	public static boolean getCurrentChocolateLog(Session session, String originalHudsonLogFile, String copiedHudsonLogFile, String tmpHudsonLogFile)
	{
		boolean flag = true;
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing diff command to get the log of current request, storing log at: "+tmpHudsonLogFile);

			/** Get the difference between hudson.log and hudson_bak.log after sending request */
			ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "diff " + originalHudsonLogFile + " " + copiedHudsonLogFile + " | tee "+tmpHudsonLogFile);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting the hudson log of current request. ",e);
		}
		finally
		{
			return flag;
		}
	}

}
