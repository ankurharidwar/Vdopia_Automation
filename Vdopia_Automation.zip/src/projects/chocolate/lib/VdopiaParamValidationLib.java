/**
 * Last Changes Done on 21 Aug, 2015 3:42:13 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.chocolate.lib;

import java.util.HashMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import projects.chocolate.lib.jsonHandler.JSONParserLib;
import projects.chocolate.lib.utils.GetChocolateLogs;



import vlib.DBLib;

public class VdopiaParamValidationLib 
{
	static Logger logger = Logger.getLogger(VdopiaParamValidationLib.class.getName());


	/** This method will return the result after validate the value of the fullscreen parameter send by vdopia bidder in it's response
	 * 
	 * @param map
	 * @param response
	 * @return
	 */
	public static String validateVdopiaParams(HashMap<String, String> requiredExpectedParameters, String response) {

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Responce :"+ response);
		String fullScreen = null;
		//String size = null;
		String status = "Fail";
		if(requiredExpectedParameters.containsKey("fullscreen"))
		{
			fullScreen = requiredExpectedParameters.get("fullscreen");

			if(response.contains("\"fullscreen\":"+fullScreen))
			{
				status = "PASS: Expected fullscreen value is present in response.";
			}

			else
			{
				status = "FAIL: Expected fullscreen value is" + fullScreen + " which is not matching with actual fullscreen value present in response.";

			}
		}	

		return status;

	}

	/**
	 * This method will return the result after validate the value of the addition parameters send by vdopia bidder in it's response.
	 * @param requiredExpectedParameters
	 * @param response
	 * @return
	 */
	public static String validateAdditionalSettingPram(HashMap<String, String> requiredExpectedParameters, String response)
	{	
		String status = null;
		String closeAfter = null;
		String closeTimeout = null;
		String vdo_adsby_text = null;
		String topBarHeight = null;
		System.out.println("Required expected Parameter"+ requiredExpectedParameters);
		if(requiredExpectedParameters.containsKey("closeAfter"))
		{
			closeAfter = requiredExpectedParameters.get("closeAfter");

			if(response.contains("\"closeAfter\":"+closeAfter))
			{
				status = "Pass: Expected closeAfter value is present in response.";
			}

			else
			{
				status = "Fail: Expected closeAfter value is = " + closeAfter + " which is not matching with actual closeAfter value present in response.";

			}
		}

		if(requiredExpectedParameters.containsKey("closeTimeout"))
		{
			closeTimeout = requiredExpectedParameters.get("closeTimeout");

			if(response.contains("\"closeTimeout\":"+closeTimeout))
			{
				status += "\n Pass: Expected closeTimeout value is present in response.";
			}

			else
			{
				status += "\n Fail: Expected closeTimeout value is = " + closeTimeout + " which is not matching with actual closeTimeout value present in response.";

			}
		}	

		if(requiredExpectedParameters.containsKey("ads_by_text"))
		{
			vdo_adsby_text = requiredExpectedParameters.get("ads_by_text");

			if(response.contains("\"vdo_adsby_text\":\""+vdo_adsby_text+"\""))
			{
				status +=  "\n Pass: Expected vdo_adsby_text value is present in response.";
			}

			else
			{
				status += "\n Fail: Expected vdo_adsby_text value is = " + vdo_adsby_text + " which is not matching with actual vdo_adsby_text value present in response.";

			}
		}	

		if(requiredExpectedParameters.containsKey("top_bar_height"))
		{
			topBarHeight = requiredExpectedParameters.get("top_bar_height");

			if(response.contains("\"topBarHeight\":"+topBarHeight))
			{
				status += "\n Pass: Expected topBarHeight value is present in response.";
			}

			else
			{
				status += "\n Fail: Expected topBarHeight value is = " + topBarHeight + " which is not matching with actual topBarHeight value present in response.";

			}
		}	
		return status;
	}


	/**
	 * This method will return the result after validating the vdopia parameters in finally returned response by chocolate  
	 * @param session
	 * @param tmpHudsonLogFile
	 * @param requiredExpectedParameters
	 * @param response
	 * @return
	 */
	public static String Verify_vdopia_parameter(Session session, String tmpHudsonLogFile, HashMap<String, String> requiredExpectedParameters, String response, Connection connection)
	{
		String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
		String winningBidderId = JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);
		
		if(!winningBidderId.equals(""))
		{	
			/** vdopia parameters will not be checked if GOOGLE_ADX_FALLBACK is winning bidder */
			if(!winningBidderId.equalsIgnoreCase("GOOGLE_ADX_FALLBACK"))
			{
				HashMap<String, String> bidderInfo = DBLib.getBidderInformation(winningBidderId, connection);
				String isvdopiaBidder = bidderInfo.get("isvdopiabidder");
				System.out.println("isvdopiaBidder value is :" + isvdopiaBidder);

				/** Validate these only in case of winning vdopia bidder */
				if(bidderInfo.get("isvdopiabidder").equalsIgnoreCase("1"))
				{
					if(requiredExpectedParameters.get("adFormat").equalsIgnoreCase("video"))
					{
						String result = "\nVdopia Bidder Parameter Validation Result In Final Response:\n" + VdopiaParamValidationLib.validateVdopiaParams(requiredExpectedParameters, response);
						result = result + "\n" + VdopiaParamValidationLib.validateAdditionalSettingPram(requiredExpectedParameters, response);
						return result;
					}
					else
					{
						return "SKIP: Channel Advanced Setting Parameters are validated only for Video ad format, received ad format is Banner in request."; 
					}
				}
				else
				{
					return "SKIP: Channel Advanced Setting Parameters were not checked in chocolate response because vdopia wasn't the winning bidder.";
				}
			}
			else
			{
				return "SKIP: Winning bidder is = GOOGLE_ADX_FALLBACK therefore Channel Advanced Setting Parameters were not checked, applicable only when vdopia is winning bidder.";
			}
		}
		else 
		{
			return "SKIP: Channel Advanced Setting Parameters were not checked in chocolate response because there was no winning bidder.";
		}
	}
}

