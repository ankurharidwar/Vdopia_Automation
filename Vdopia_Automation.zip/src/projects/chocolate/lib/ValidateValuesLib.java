/**
 * Last Changes Done on 12 May, 2015 4:29:48 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the logic of validation of values/parameter 
 */

package projects.chocolate.lib;

import java.util.HashMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import projects.chocolate.lib.utils.GetDeviceInformation;



import com.mysql.jdbc.Connection;
import vlib.DBLib;


public class ValidateValuesLib 
{

	static Logger logger = Logger.getLogger(ValidateValuesLib.class.getName());


	/** This method will validate the dimension of banner and video in request to be 
	 * posted json request string.
	 * 
	 *  These Validations will be performed: 
	 * for both: w x h
	 * fullscreen =1 && tablet: 492x517
	 * fullscreen =1 && non tablet: 320x480
	 * nofullscreen && notablet: 320x480
	 * fullscreen =0 && tablet: 300x250
	 * fullscreen =0 && non tablet: 300x250
	 * 
	 * @return
	 */
	public static String validateAdDimension(String instl, String bidderAdformat, String w, String h, HashMap<String, String> requiredExpectedParameters)
	{
		String result = "";

		String expectedinstl; 
		String expectedHeight; 
		String expectedWidth;

		/** In case of get request */
		if(requiredExpectedParameters.get("requestType").equalsIgnoreCase("GET"))
		{
			if(requiredExpectedParameters.get("adFormat").equalsIgnoreCase("banner"))
			{
				expectedHeight = "48";
				expectedWidth = "320";
				expectedinstl = "0";
			}
			else
			{
				String userAgent = requiredExpectedParameters.get("ua");		
				String isTablet = GetDeviceInformation.getDeviceInformation(userAgent).get("istablet").trim();
				String fullscreen = requiredExpectedParameters.get("fullscreen");

				if(fullscreen.equalsIgnoreCase("1"))
				{
					if(isTablet.equalsIgnoreCase("true"))
					{
						expectedHeight = "517";
						expectedWidth = "492";
					}
					else
					{
						expectedHeight = "480";
						expectedWidth = "320";
					}
					expectedinstl = "1";
				}
				else
				{
					expectedHeight = "250";
					expectedWidth = "300";
					expectedinstl = "0";
				}
			}
		}
		/** In case of post request */
		else
		{
			expectedinstl = requiredExpectedParameters.get("instl");
			expectedHeight = requiredExpectedParameters.get("h");
			expectedWidth = requiredExpectedParameters.get("w");
		}

		if(!instl.equalsIgnoreCase(expectedinstl))
		{
			result = result + "Fail: Expected instl = "+expectedinstl + " and Actual = "+ instl +" for adformat = "+bidderAdformat;
		}
		if(!h.equalsIgnoreCase(expectedHeight))
		{
			result = result + "  " + "Fail: Expected h = "+expectedHeight + " and Actual = "+ h +" for adformat = "+bidderAdformat;
		}
		if(!w.equalsIgnoreCase(expectedWidth))
		{
			result = result + "  " + "Fail: Expected w = "+expectedWidth + " and Actual = "+ w +" for adformat = "+bidderAdformat;
		}

		return result;
	}


	/** This method will compare the expected and actual bid floor price which is posted in data to posted request
	 * 
	 * @param requiredExpectedParameters
	 * @param bidderID
	 * @param actualBidFloorPrice
	 * @param connection
	 * @return
	 */
	public static String validateBidFloorPrice(HashMap<String, String> requiredExpectedParameters, String bidderID, float actualBidFloorPrice, Connection connection)
	{
		String result = "";

		try
		{
			float channelFloorPrice;
			try
			{
				channelFloorPrice = Float.parseFloat(requiredExpectedParameters.get("floor_price_usd"));
			}catch(NumberFormatException n){
				channelFloorPrice = 0.00f;
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred, Reassigning channelFloorPrice = 0.00 ");
			}

			float bidderVdopiaMargin = Float.parseFloat(DBLib.getBidderVdopiaMargin(bidderID, connection));		

			float expectedBidFloorPrice = channelFloorPrice / ( 1 - bidderVdopiaMargin/100);

			/** Converting the expected bid floor price in to string to get only 2 decimal places after calculation
			 */
			String expectedValue = String.format("%.2f", expectedBidFloorPrice);
			String actualValue = String.format("%.2f", actualBidFloorPrice);

			if(!expectedValue.equals(actualValue))
			{	
				result = "Fail: Expected bid floor price = "+expectedBidFloorPrice + " whereas actual is = "+actualBidFloorPrice;
			}

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected bid price = "+expectedBidFloorPrice + " Actual bid price = "+actualBidFloorPrice);			
		}
		catch(Exception e)
		{
			result = " Error occurred while checking bidfloor price. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while comparing the expected and actual bid floor price. ", e);
		}

		return result;
	}

}
