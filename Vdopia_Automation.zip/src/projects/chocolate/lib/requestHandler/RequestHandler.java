/**
 * Last Changes Done on 17 Jul, 2015 11:20:47 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the generic handling of supplied requests.
 */
package projects.chocolate.lib.requestHandler;

import java.util.HashMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;


import vlib.httpClientWrap;

// TODO: Auto-generated Javadoc
public class RequestHandler 
{

	static Logger logger = Logger.getLogger(RequestHandler.class.getName());


	/** This method will check the supplied request and returns boolean. 
	 * 
	 * @param chocolateRequest
	 * @return
	 */
	public static boolean isRequestValid(String chocolateRequest)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking if supplied request is valid or not: "+chocolateRequest);
		boolean isRequestValid;

		isRequestValid = isGetRequest(chocolateRequest);

		if(!isRequestValid)
		{
			isRequestValid = isPostRequest(chocolateRequest);
			
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied request is valid ? "+String.valueOf(isRequestValid));
		return isRequestValid;
	}


	/**
	 * This method will send get / post request to chocolate server and return
	 * the response.
	 * 
	 * @param postRequestChocolateURL
	 * @param chocolateRequest
	 * @param headers
	 * @return
	 */
	public static String requestChocolateURL(String postRequestChocolateURL, String chocolateRequest, HashMap<String, String> headers)
	{
		String response;

		if(chocolateRequest.trim().startsWith("http"))
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sending GET request ... ");
			response = httpClientWrap.sendGetRequest(chocolateRequest, headers);
		}
		else
		{
			/** If the supplied request is not a valid json request then return response = null*/
			try{
				new JSONObject(chocolateRequest);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sending POST request ... ");
				response = httpClientWrap.sendPostRequest(postRequestChocolateURL, chocolateRequest, headers);
			}catch(JSONException j){

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied POST request is not a valid JSON: "+chocolateRequest);
				response = null;
			}
		}

		return response;
	}


	/** This method will determine if the supplied request is GET .
	 * 
	 * @param chocolateRequest
	 * @return
	 */
	public static boolean isGetRequest(String chocolateRequest)
	{
		boolean requestType = false;

		if(chocolateRequest.trim().startsWith("http"))
		{
			requestType = true;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied Request is a GET request ... ");
		}

		return requestType;
	}


	/** This method will determine if the supplied request is POST .
	 * 
	 * @param chocolateRequest
	 * @return
	 */
	public static boolean isPostRequest(String chocolateRequest)
	{
		boolean requestType;

		/** If the supplied request is a valid json request */
		try{
			new JSONObject(chocolateRequest);

			requestType = true;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied Request is a valid POST request ... ");
		}catch(JSONException j){

			requestType = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied Request is an invalid request ... ");
		}

		return requestType;
	}

}
