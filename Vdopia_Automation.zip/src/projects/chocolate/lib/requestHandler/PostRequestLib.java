/**
 * Last Changes Done on 17 Jul, 2015 12:32:02 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class will contain the handling of post requests.
 */

package projects.chocolate.lib.requestHandler;

import java.util.HashMap;
import java.util.Iterator;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;

import projects.chocolate.lib.jsonHandler.JSONParserLib;




public class PostRequestLib 
{
	static Logger logger = Logger.getLogger(PostRequestLib.class.getName());


	/** Get final map containing keys and values of supplied json request and other required fields like ak. 
	 * 
	 * @param postRequest
	 * @return
	 */
	public static HashMap<String, String> parsePostRequest(String postRequest)
	{
		HashMap<String, String> map = new HashMap<>();

		/** Get all json object keys and values in a map */
		map.putAll(parsePostRequest(postRequest, map));

		/** get imp values into map */
		map.putAll(getImpValuesFromPostRequest(postRequest));

		/** Get site values into map */
		map.putAll(getSiteValuesFromPostRequest(postRequest));

		/** Get type of post request into map */
		map.putAll(getTypeOfPostRequest(postRequest));

		/** In case of post request, rename keys ip and ref to ipAddress and refURL. */
		map = ApplyRulesLib.renameKeysForPostRequest(map);

		return map;
	}


	public static HashMap<String, String> getTypeOfPostRequest(String postRequest)
	{
		HashMap<String, String> map = new HashMap<>();

		String type = "";
		try
		{
			try{
				new JSONObject(postRequest).getJSONObject("site");
				type = "site";
			}catch(JSONException e){
				new JSONObject(postRequest).getJSONObject("app");
				type = "app";
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Couldn't get type of supplied post request.", e);
		}

		map.put("type", type);

		return map;
	}


	/** This is a generic method to return the key and values from the supplied json post request.
	 * 
	 * @param postRequest
	 * @param deviceValues
	 * @return
	 */
	public static HashMap<String, String> parsePostRequest(String postRequest, HashMap<String, String> map)
	{
		try
		{
			JSONObject jsonObject = new JSONObject(postRequest);

			@SuppressWarnings("unchecked")
			Iterator<String> keyIterator = jsonObject.keys();

			while(keyIterator.hasNext())
			{
				String fieldName = keyIterator.next();
				String fieldValue = jsonObject.getString(fieldName);

				if(JSONParserLib.isJsonObject(fieldValue))
				{
					parsePostRequest(fieldValue, map);
				}
				else
				{
					map.put(fieldName, fieldValue);
				}
			}
		}catch(JSONException j)
		{
			logger.error(j.getMessage(), j);
		}

		return map;
	}


	/** Get required values from imp node of supplied post request.
	 * 
	 * @param postRequest
	 * @return
	 */
	public static HashMap<String, String> getImpValuesFromPostRequest(String postRequest)
	{
		HashMap<String, String> map = new HashMap<>();
		try
		{
			JSONObject jsonObject = new JSONObject(postRequest);
			JSONObject imp = jsonObject.getJSONArray("imp").getJSONObject(0);

			String instl = imp.getString("instl");

			String floor_price_usd;
			try{floor_price_usd = imp.getString("bidfloor");}catch(JSONException j){
				floor_price_usd = "0.00";}

			String w;
			String h;
			String adformatnode;
			
			try{
				JSONObject bannerVideoObj = imp.getJSONObject("banner");				
				w = bannerVideoObj.getString("w");
				h = bannerVideoObj.getString("h");
				adformatnode = "banner";
			
			}catch(JSONException j){

				JSONObject bannerVideoObj = imp.getJSONObject("video");				
				w = bannerVideoObj.getString("w");
				h = bannerVideoObj.getString("h");
				adformatnode = "video";
				
			}

			map.put("instl", instl);
			map.put("w", w);
			map.put("h", h);
			map.put("floor_price_usd", floor_price_usd);
			map.put("adformatnode", adformatnode);
		

		}catch(JSONException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no instl found in site object in supplied request. ", e);
		}

		return map;
	}


	/** Get site node values into a map, this map will be put in the final map.
	 * 
	 * @param postRequest
	 * @return
	 */
	public static HashMap<String, String> getSiteValuesFromPostRequest(String postRequest)
	{
		HashMap<String, String> map = new HashMap<>();

		try
		{
			String ak = new JSONObject(postRequest).getJSONObject("site").getString("id");
			String publisher_id = new JSONObject(postRequest).getJSONObject("site").getJSONObject("publisher").getString("id");
			String publisher_name = new JSONObject(postRequest).getJSONObject("site").getJSONObject("publisher").getString("name");
			String name = new JSONObject(postRequest).getJSONObject("site").getString("name");

			map.put("ak", ak);
			map.put("publisher_id", publisher_id);
			map.put("publisher_name", publisher_name);
			map.put("name", name);

		}catch(JSONException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was no site or publisher node found in supplied request. ", e);
		}

		return map;
	}



	/** This method will check if supplied chocolate post request is valid by checking supplied values: 
	 * w: 	h: 		instl:
	 * 300 x 250	0
	 * 320 x 480	1
	 * 300 x 250	1
	 * 
	 * @param hudsonRequestUrl
	 * @param requiredExpectedParameters
	 * @return
	 */
	public static boolean isPostRequestValid(HashMap<String, String> requiredExpectedParameters)
	{
		try
		{
			/** Getting values from supplied map to check validity of supplied request */
			String instl = requiredExpectedParameters.get("instl");
			String w = requiredExpectedParameters.get("w");
			String h = requiredExpectedParameters.get("h");

			if(w.equalsIgnoreCase("300") && h.equalsIgnoreCase("250") && (instl.equalsIgnoreCase("0") || instl.equalsIgnoreCase("1")) )
			{
				return true;
			}
			if(w.equalsIgnoreCase("250") && h.equalsIgnoreCase("300") && (instl.equalsIgnoreCase("0") || instl.equalsIgnoreCase("1")) )
			{
				return true;
			}
			else if(w.equalsIgnoreCase("480") && h.equalsIgnoreCase("320") && (instl.equalsIgnoreCase("0") || instl.equalsIgnoreCase("1")))
			{
				return true;
			}
			else if(w.equalsIgnoreCase("320") && h.equalsIgnoreCase("480") && (instl.equalsIgnoreCase("0") || instl.equalsIgnoreCase("1")))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking supplied post request. ", e);
			return false;
		}

	}

}
