/**
 * Last Changes Done on Jan 30, 2015 11:02:56 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: in case of multiple occurrence, last one will be considered in supplied url for get call
 */
package projects.chocolate.lib.requestHandler;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.testng.annotations.Test;

import projects.chocolate.lib.utils.ReadChocolateConfig;



/**
 * This class will get all the query parameters from the supplied url.
 * Logic of splitting: 
 * 1. replace all ; with &
 * 2. split url beginning with ?
 * 3. after splitting, each splitted string will have a format like: value&parametereName 
 * 4. Now each string will have value of previous of parameterName and parameterName for subsequent value.
 * 5. In case any value os repeated then first occurrence will be taken.
 */

public class GetRequestLib 
{

	static Logger logger = Logger.getLogger(GetRequestLib.class.getName());


	/**
	 * This test is for debugging only.
	 */
	@Test
	public static void test()
	{
		String request = "http://chocolate.da.vdopia.com:86//adserver/html5/inwapads/?adFormat=preappvideo&version=1.0&ak=4466f43e7cf8fcbf5f1ded94ef2b9a10&cb=1131511051&DIMSIZE&INVTRACKER&PUBCLK&PUBENDTRK&type=site&pageURL=http%3A%2F%2Fwww.theblaze.com%2Fstories%2F2015%2F10%2F14%2Falready-suspended-for-muslim-tweet-legendary-pitcher-curt-schilling-sends-brutal-four-letter-response-to-donald-trumps-dem-debate-question%2F%3Futm_source%3Dsailthru%26utm_medium%3Demail%26utm_campaign%3Dfirewire%2520morning%2520edition%2520recurring%2520v2%25202015-10-15%26utm_term%3Dfirewire_morning_test&siteName=theblaze.com&category=IAB1&refURL=&di=&dif=&ua=Mozilla%2F5.0%20%28Linux%3B%20Android%205.1%3B%20XT1034%20Build%2FLPB23.13-58%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F45.0.2454.94%20Mobile%20Safari%2F537.36&ipAddress=23.29.223.255&latlong=&output=vast%20HTTP/1.1%22%20200%20130%20%22http://nym1.ib.adnxs.com/if?e=wqT_3QLuC_BC5QUAAAIA1gAFCLKa_rAFENjw-KXl3q1CGPD8q-CJjLT_VSABKi0JrkfhehSuFEARrkfhehSuFEAZ2c73U-OlDEAhrg0SACkRJKgw64P-ATjNFEDNFEgCUKORvg9Y8OYtYABo22FwAHiFEoABAYoBA1VTRJIBAQbwPJgBrAKgAfoBqAEAsAEAuAECwAEEyAEA0AEA2AEA4AEA6gGnBWh0dHBzOi8vYWRjbGljay5nLmRvdWJsZWMFDvDIbmV0L2FjbGslM0ZzYSUzREwlMjZhaSUzREJES2dVTUkwZlZwaVJINDZ5ZlBLQ3FyQUtsYmpKNFFZQUFBQVFBU0FBT0FCWTVkR0R4T1VCWU1tR3A0ZmNvNVFSZ2dFWFkyRXRjSFZpTFRjNU5ESTRNakl5TVRrNU5EazNNekN5QVJCM2QzY3VkR2hsWW14aGVtVXVZMjl0dWdFSloyWndYMmx0WVdkbHlBRUoyZ0cyQVdoMGRIQTZMeTkzZDNjdWRHaGxZbXhoZW1VBTjwhEwzTjBiM0pwWlhNdk1qQXhOUzh4TUM4eE5DOWhiSEpsWVdSNUxYTjFjM0JsYm1SbFpDMW1iM0l0YlhWemJHbHRMWFIzWldWMExXeGxaMlZ1WkdGeWVTMXdhWFJqYUdWeUxXTjFjblF0YzJOb2FXeHNhVzVuTFhObGJtUnpMV0p5ZFhSaGIFVPRjAVZ5TFd4bGRIUmxjaTF5WlhOd2IyNXpaUzEwYnkxa2IyNWhiR1F0ZEhKMWJYQnpMV1JsYlMxa1pXSmhkR1V0Y1hWbGMzUnBiMjR2bUFMUUQ4QUNBdUFDQU9vQ0hpODNOVFE0TkRBMk1TOVVhR1ZDYkdGNlpTNWpiMjB2VTNSdmNtbGxjX2dDX05FZWtBUGdBNWdEckFLb0F3SGdCQUdRQmdHZ0JoYllCZ0xZQndBJTI2bnVtJTNEMCUyNmNpZCUzRDVHaXl4U1BYVGlKXzFVbDlOT0RJRVpFNSUyNnNpZyUzREFPRDY0XzBuQS1uSXdTU1pJNDRiQ18xWDNRQVNqVWJ1MXclMjZjbGllbnQlM0RjYS1wdWItNzk0MjgyMjIxOTk0OTczMCUyNmFkdXJsJTNE8AEAigI6dWYoJ2EnLCA1NjU1MTEsIDE0NDQ5MDgzMzgpO3VmKCdyJywgMzI0NzUyOTksMh4A8IeSAp0BIWlTYlhoZ2o4b2N3RUVLT1J2ZzhZQUNEdzVpMHdBRGdBUUFOSXpSUlE2NFAtQVZnQVlNZ0JhQUJ3QUhnQWdBRUFpQUVBa0FFQm1BRUJvQUVCcUFFRHNBRUF1UUd1Ui1GNkZLNFVRTUVCcmtmaGVoU3VGRURKQWZYcW9XVzB6ZndfMlFFYRg8QUFBRHdQLUFCc09BTjlRRQERJEGaAh0heFFiUVA6oAD0OAE4T1l0SUFNLtgCpgrgAsTVH-oCwgJodHRwOi8vd3d3LnRoZWJsYXplLmNvbS9zdG9yaWVzLzIwMTUvMTAvMTQvYWxyZWFkeS1zdXNwZW5kZWQtZm9yLW11c2xpbS10d2VldC1sZWdlbmRhcnktcGl0Y2hlci1jdXJ0LXNjaGlsbGluZy1zZW5kcy1icnV0YWwtZm91ci1sZXR0ZXItcmVzcG9uc2UtdG8tZG9uYWxkLXRydW1wcy1kZW0tZGViYXRlLXF1ZXN0aW9uLz91dG1fc291cmNlPVNhaWx0aHJ1JnV0bV9tZWRpdW09ZW1haWwmdXRtX2NhbXBhaWduPUZpcmV3aXJlJTIwTW9ybmluZyUyMEVkaXRpb24lMjBSZWN1cnJpbmclMjB2MiUyMDIwMTUtMTAtMTUmAUgMdGVybRVEAF8NQvBVX1Rlc3TyAhEKBkNQR19JRBIHMjE1OTI1OIADAIgDAZADAJgDAKADAaoDALADALgDAMADrALIAwDYA8q4DuADAOgDAPADAPgDAYAEAJIEBC90dGqYBAA.&s=0994d3f947dc5f014403699372d7ddd76d21d2a8&dlo=1&referrer=http%3A%2F%2Fwww.theblaze.com%2Fstories%2F2015%2F10%2F14%2Falready-suspended-for-muslim-tweet-legendary-pitcher-curt-schilling-sends-brutal-four-letter-response-to-donald-trumps-dem-debate-question%2F%3Futm_source%3DSailthru%26utm_medium%3Demail%26utm_campaign%3DFirewire%2520Morning%2520Edition%2520Recurring%2520v2%25202015-10-15%26utm_term%3DFirewire_Morning_Test%22%20%22Mozilla/5.0%20(Linux;%20Android%205.1;%20XT1034%20Build/LPB23.13-58)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Chrome/45.0.2454.94%20Mobile%20Safari/537.36%22%200.101%203607%20746%20127.0.0.1;pAddress=129.90.255.255;output=js";
		HashMap<String, String> map = getQueryParamsFromGetRequest(request);

		for(Entry<String, String> e : map.entrySet())
		{
			System.out.println(e.getKey() + " , " +e.getValue());
		}
	}


	/** This method will split all query parameter from url and store in hash map, also if there is no output supplied in url
	 * then consider default output = js
	 * 
	 * @param url
	 * @return
	 */
	public static HashMap<String, String> getQueryParamsFromGetRequest(String getRequest)
	{
		HashMap<String, String> map = new HashMap<String, String>();

		/** If url contains % then decode it.
		 */
		String url = "";
		try{
			url = URLDecoder.decode(getRequest, "UTF-8");
			url = URLDecoder.decode(url, "UTF-8");
		}catch(UnsupportedEncodingException u)
		{
			url = getRequest;
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting query parameter of received decoded URL: "+url);

		/** 1. get query parameter */
		url = url.substring(url.indexOf("?")+1, url.length());

		/** 2. replace ; with & */
		url = url.replace(";", "&");


		/**2a. Apply rule to handle specific parameters like target_params which has specific format in url and can;t be 
		 * handled using the below mechanism, in this case these specific parameters will be removed from url and 
		 * parse them, convert them into a hashmap and put into final map.
		 */
		HashMap<String, String>specificParams = applyRule(url);


		/** 3. Split query string by = */
		List<String> list = new ArrayList<String>(Arrays.asList(url.split("=")));

		/** 4. Regular expression to find out string ending with & */
		String regexString = "^.*&";
		Pattern pattern = Pattern.compile(regexString);

		String key_old = list.get(0);

		String key;
		String value;
		for(int i=1; i<list.size()-1; i++)
		{ 
			String xyz = list.get(i);

			Matcher m = pattern.matcher(xyz);
			while (m.find()) 
			{
				String match = m.group();

				value  = match.substring(0, match.lastIndexOf("&"));

				/** in case ends with &, then remove it */
				if(value.endsWith("&"))
				{
					value = value.replace("&", "").trim();
				}

				key = xyz.replace(match, "").trim();

				/** In case value of any parameter is passed as [xyz], then ignore it. */
				if(value.startsWith("[") || value.endsWith("]"))
				{
					value = "";
				}

				map.put(key_old, value);
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Paremeter Name: "+key_old + " Value: "+value);

				/* Commenting this code as only last occurrence will be considered in case of multiple occurrences of parameters in get call
				//In case map doesn't have this key then only add it 
				if(map.get(key_old) == null || map.get(key_old).isEmpty())
				{
					map.put(key_old, value);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Paremeter Name: "+key_old + " Value: "+value);
				}
				 */

				key_old = key;
			}
		}

		/** get the last value splited by = */
		String finalValue = list.get(list.size() -1);

		/** in case ends with &, then remove it */
		if(finalValue.endsWith("&"))
		{
			finalValue = finalValue.replace("&", "").trim();
		}

		/** In case value of any parameter, is passed as [xyz], then ignore it get it from db. */
		if(finalValue.startsWith("[") || finalValue.endsWith("]"))
		{
			value = "";
		}

		map.put(key_old, finalValue);
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Paremeter Name: "+key_old + " Value: "+finalValue);

		/** In case there is no output parameter in url then default value is js */
		if(map.get("output") == null )
		{
			map.put("output", "js");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : output is not supplied in given url, reassigning to js: "+url);
		}

		/** Put all the specific params also in the final map
		 */
		map.putAll(specificParams);

		/** Put all manipulation of user agent also
		 */
		map.putAll(applyRule(map));

		return map;
	}


	/** This method will check if supplied chocolate get request is valid by checking supplied adformat, api key and output type
	 * 
	 * @param hudsonRequestUrl
	 * @param requiredExpectedParameters
	 * @return
	 */
	public static boolean isGetRequestValid(String hudsonRequestUrl, HashMap<String, String> requiredExpectedParameters)
	{
		try
		{
			String adFormat = GetRequestLib.getQueryParamsFromGetRequest(hudsonRequestUrl).get("adFormat");
			String outputType = GetRequestLib.getQueryParamsFromGetRequest(hudsonRequestUrl).get("output");

			boolean adFormatValidate = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("validAdFormats").contains(adFormat);
			boolean outputTypeValidate = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("validOutputType").contains(outputType);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : adFormat received in request: "+adFormat + " output Type received in request: "+outputType);

			if(!requiredExpectedParameters.isEmpty() && adFormatValidate && outputTypeValidate)
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied request is valid.");
				return true;
			}
			else
			{
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied request is not valid. "+adFormat + ": "+ adFormatValidate + ", " + outputType + ": "+outputTypeValidate + ", "+ "api key: "+requiredExpectedParameters.isEmpty());
				return false;
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking supplied get request. ", e);
			return false;
		}

	}


	/** This method will check if supplied chocolate get request has valid ad format
	 * 
	 * @param hudsonRequestUrl
	 * @param requiredExpectedParameters
	 * @return
	 */
	public static boolean isAdFormatValid(String hudsonRequestUrl)
	{
		try
		{
			String adFormat = GetRequestLib.getQueryParamsFromGetRequest(hudsonRequestUrl).get("adFormat");
			boolean adFormatValidate = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("validAdFormats").contains(adFormat);

			return adFormatValidate;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking supplied adformat in request:  "+hudsonRequestUrl, e);
			return false;
		}

	}


	/** This method will check if supplied chocolate get request has valid output type
	 * 
	 * @param hudsonRequestUrl
	 * @param requiredExpectedParameters
	 * @return
	 */
	public static boolean isOutputTypeValid(String hudsonRequestUrl)
	{
		try
		{
			String outputType = GetRequestLib.getQueryParamsFromGetRequest(hudsonRequestUrl).get("output");
			boolean outputTypeValidate = ReadChocolateConfig.getCommaSeparatedValuesFromConfig("validOutputType").contains(outputType);

			return outputTypeValidate;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking supplied output type in request: "+hudsonRequestUrl, e);
			return false;
		}

	}


	/** This method will be used to handle specific parameters while parsing the sub query parameters received in get request.
	 */
	public static HashMap<String, String> applyRule(String getRequestUrl)
	{
		HashMap<String, String> hashmap = new HashMap<>();

		try
		{
			/** split the parameter target_params with its values which are | separated.
			 * How: get the substring starting index of target_params until the first index of &
			 */
			if(getRequestUrl.contains("target_params"))
			{
				String targetingString = getRequestUrl.substring(getRequestUrl.indexOf("target_params")+14, getRequestUrl.indexOf("&", getRequestUrl.indexOf("target_params")));

				List<String> targetingParams = new ArrayList<>(Arrays.asList(targetingString.split("\\|")));

				hashmap.put("target_params", targetingString);

				for(int i=0; i<targetingParams.size(); i++)
				{
					String parameter = targetingParams.get(i);
					String name = parameter.split("=")[0].trim();
					String value = "";

					/** geo parameter has values like US:MA: currently considering the first one = US may be changed later on
					 */
					if(name.equalsIgnoreCase("geo"))
					{
						value = parameter.split("=")[1].split(":")[0].trim();
					}
					else
					{
						value = parameter.split("=")[1].trim();
					}

					hashmap.put(name, value);
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Parameter Name: "+name + " Parameter Value: "+value);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : error occurred while applying rule. ");
		}
		return hashmap;
	}


	/** This method will be used to manipulate user agent string like:
	 * if ua contains & replace it with ; 
	 */
	public static HashMap<String, String> applyRule(HashMap<String, String> hashmap)
	{
		try
		{
			if(hashmap.containsKey("ua"))
			{
				String userAgent = hashmap.get("ua").replace("&", ";");
				hashmap.put("ua", userAgent);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : error occurred while applying rule. ", e);
		}
		return hashmap;
	}


}
