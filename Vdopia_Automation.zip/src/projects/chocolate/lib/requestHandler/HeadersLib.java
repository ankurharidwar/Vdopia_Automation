/**
 * Last Changes Done on Jan 30, 2015 11:03:02 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: this class conatins all the desired headers to set with requests.
 */
package projects.chocolate.lib.requestHandler;

import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.commons.configuration.PropertiesConfiguration;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import projects.chocolate.lib.utils.ReadChocolateConfig;




/** This class basically sets header parameters and get all the expected required values to be used later on in rtbObject JSONs.
 * method setRequestHeader which sets parameter: type, pageURL, siteName, domain, appBundle, appName, category, refURL
 * and their default value to be added in request header. In case, any new parameter is added in header, just add
 * that parameter in below hash map set by setRequetHeader.
 */

public class HeadersLib 
{

	static Logger logger = Logger.getLogger(HeadersLib.class.getName());


	/** Setting up all standard and custom parameters in headers */ 
	public static HashMap<String, String> setHeaders()
	{
		HashMap<String, String> header = new HashMap<String, String>();

		/** Getting headers from chocolate config */
		PropertiesConfiguration config = ReadChocolateConfig.loadChocolateConfiguration();

		String referrer = config.getProperty("referrer").toString().trim();
		String accept_language = config.getProperty("accept-language").toString().trim();
		String user_agent = config.getProperty("user-agent").toString().trim();
		String X_FORWARDED_FOR = config.getProperty("X-FORWARDED-FOR").toString().trim();

		/** Remove [ ] at the starting and end of the received user agent from config file
		 */
		user_agent = user_agent.substring(user_agent.indexOf("[")+1, user_agent.lastIndexOf("]"));

		/**Mandatory fields for further processing */
		header.put("referrer", referrer);
		header.put("accept-language", accept_language);
		header.put("user-agent", user_agent);
		header.put("X-FORWARDED-FOR", X_FORWARDED_FOR);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : **************** Setting up header with values **************");

		for(Entry<String, String> map : header.entrySet())
		{
			logger.debug(map.getKey() + ":  "+ map.getValue());
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *************************************************************");

		return header;
	}


	/** Getting header Hashmap and changing standard parameter name to those name which can be passed in url
	 *  Standard Parameter: referrer, accept-language, user-agent, X-FORWARDED-FOR
	 * @return
	 */
	public static HashMap<String, String> getHeaders()
	{
		HashMap<String, String> header = new HashMap<String, String>();
		header = setHeaders();

		String key = "";
		String value = "";

		key = "referrer";
		value = header.get(key);
		header.remove(key);
		header.put("refURL", value);

		key = "accept-language";
		value = header.get(key).split("-")[0];
		header.remove(key);
		header.put("language", value);

		key = "user-agent";
		value = header.get(key);
		header.remove(key);
		header.put("ua", value);

		key = "X-FORWARDED-FOR";
		value = header.get(key);
		header.remove(key);
		header.put("ipAddress", value);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* Getting header values ***********");

		for(Entry<String, String> map : header.entrySet())
		{
			logger.debug(map.getKey() + ":  "+ map.getValue());
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *****************************************");

		return header;
	}

}