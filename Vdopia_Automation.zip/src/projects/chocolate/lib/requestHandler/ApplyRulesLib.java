/**
 * Last Changes Done on Feb 2, 2015 5:29:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: handling domain and pageURL for site
 */

package projects.chocolate.lib.requestHandler;

import java.util.HashMap;

import org.apache.log4j.Logger; 

import com.vdopia.utils.TopLevelDomain.PopulateTldTree;


public class ApplyRulesLib 
{

	static Logger logger = Logger.getLogger(ApplyRulesLib.class.getName());


	/** This method will apply rule to the query parameter and return the final map
	 * 
	 * @param hashmap
	 * @param paramValuesFromURL
	 * @return
	 */
	public static HashMap<String, String> applyRules(HashMap<String, String> finalHashMap, HashMap<String, String> paramValuesFromURL, HashMap<String, String> requiredValuesFromDB, String request) 
	{

		/** 1. In case type = site then remove appName as this will not relevant same with type = app
		 */
		if(finalHashMap.get("type").equalsIgnoreCase("app"))
		{
			/** appBundle should be get from url if not then get from db if not in db then default: app_hudson
			 * and domain: first from url, if not then get from db */
			if(!finalHashMap.containsKey("appBundle") || finalHashMap.get("appBundle").isEmpty())
			{
				/** get bundle from db */
				if(!requiredValuesFromDB.containsKey("appBundle") || requiredValuesFromDB.get("appBundle").isEmpty())
				{
					finalHashMap.put("appBundle", requiredValuesFromDB.get("appBundle"));
				}
				else
				{
					finalHashMap.put("domain", "app_hudson");
					finalHashMap.put("appBundle", "app_hudson");
				}
				finalHashMap.remove("siteName");
			}

			if(!finalHashMap.containsKey("domain") || finalHashMap.get("domain").isEmpty())
			{
				finalHashMap.put("domain", requiredValuesFromDB.get("domain"));
			}
		}

		/** 2. Handling domain and pageURL for site
		 */
		else if(finalHashMap.get("type").equalsIgnoreCase("site"))
		{
			/** 1. Getting domain from query parameters, 
			 *  2. if not provided then get domain from supplied pageURL in query parameter,
			 *  3. if pageURL is not supplied in url then pageURL = channel.url then get domain, 
			 * 	4. still no domain, get domain from pageURL (pageURL = refURL)
			 * 	5. still no domain, get channels.domain
			 */
			//2.
			if(!paramValuesFromURL.containsKey("domain") || paramValuesFromURL.get("domain").isEmpty())
			{				
				//3.
				if(!paramValuesFromURL.containsKey("pageURL") || paramValuesFromURL.get("pageURL").isEmpty())
				{
					String pageURL = "";

					/** in case of inwapads call, if pageURL is not supplied in request, then it will be same as referrer */
					if(request.toLowerCase().contains("inwapads"))
					{
						pageURL = finalHashMap.get("refURL");
					}
					else
					{
						pageURL = requiredValuesFromDB.get("pageURL");
					}

					//4.
					if(pageURL == null || pageURL.isEmpty())
					{
						String domain = PopulateTldTree.getTopLevelDomain(finalHashMap.get("refURL"));

						/** remove any www or http:// from the final domain */
						domain.replace("http://", "").replace("www.", "").trim();

						finalHashMap.put("domain", domain);
						finalHashMap.put("pageURL", finalHashMap.get("refURL"));
					}
					else
					{
						String domain = PopulateTldTree.getTopLevelDomain(pageURL);

						if(domain != null)
						{
							/** remove any www or http:// from the final domain */
							domain = domain.replace("http://", "").replace("www.", "").trim();

							finalHashMap.put("domain", domain);
							finalHashMap.put("pageURL", pageURL);
						}
					}
				}
				else
				{
					/** Getting top level domain (equivalent to domain) using utils.jar coded by development if no domain supplied in url */
					String pageURL = paramValuesFromURL.get("pageURL");
					String domain = PopulateTldTree.getTopLevelDomain(pageURL);

					/** remove any www or http:// from the final domain */
					if(domain !=null)
					{
						domain.replace("http://", "").replace("www.", "").trim();
					}

					finalHashMap.put("domain", domain);	
				}
			}

			finalHashMap.remove("appName");
		}

		/** 3. in case ip is supplied in url then rename ip to ipAddress in the final map
		 */
		if(finalHashMap.get("ip") != null)
		{
			String value = finalHashMap.get("ip");
			finalHashMap.remove("ip");
			finalHashMap.put("ipAddress", value);
		}

		/** 
		 * 4. This will update the fullscreen/size value in finalHashMap 
		 */
		finalHashMap = updateVdopiaParamValues(finalHashMap,paramValuesFromURL,requiredValuesFromDB);

		/**
		 * 5. updating viewability value in the final map, viewability will be true for non-vast adformat requests
		 */
		if(finalHashMap.get("adFormat").equalsIgnoreCase("vast"))
		{
			finalHashMap.put("viewability", "false");
		}
		else
		{
			finalHashMap.put("viewability", "true");
		}

		return finalHashMap;
	}


	/**
	 * This method will update fullscreen/size values in final expected map
	 * @param finalHashMap
	 * @param paramValuesFromURL
	 * @param requiredValuesFromDB
	 * @return
	 */
	public static HashMap<String, String> updateVdopiaParamValues(HashMap<String, String> finalHashMap, HashMap<String, String> paramValuesFromURL, HashMap<String, String> requiredValuesFromDB)
	{

		String size = null;
		size = requiredValuesFromDB.get("size");
		if(!paramValuesFromURL.containsKey("fullscreen"))
		{
			if(!paramValuesFromURL.containsKey("size") || (!paramValuesFromURL.get("size").equalsIgnoreCase("320x480") && !paramValuesFromURL.get("size").equalsIgnoreCase("300x250")))
			{
				//size = requiredValuesFromDB.get("size");

				if (size == null || (!size.equalsIgnoreCase("320x480") && !size.equalsIgnoreCase("300x250")))
				{
					finalHashMap.put("fullscreen", "1");
				}
				else if (size.equalsIgnoreCase("320x480"))
				{
					//finalHashMap.put("size", size);
					finalHashMap.put("fullscreen", "1");
				}
				else if (size.equalsIgnoreCase("300x250"))
				{
					//finalHashMap.put("size", size);
					finalHashMap.put("fullscreen", "0");
				}

			}
			else if (paramValuesFromURL.get("size").equalsIgnoreCase("320x480"))
			{
				//finalHashMap.put("size", size);
				finalHashMap.put("fullscreen", "1");
			}
			else if (paramValuesFromURL.get("size").equalsIgnoreCase("300x250"))
			{
				//finalHashMap.put("size", size);
				finalHashMap.put("fullscreen", "0");
			}
			else
			{
				finalHashMap.put("fullscreen", "1");
			}

		}
		else if (!paramValuesFromURL.get("fullscreen").equalsIgnoreCase("1") && !paramValuesFromURL.get("fullscreen").equalsIgnoreCase("0"))
		{
			if (size.equalsIgnoreCase("320x480"))
			{
				//finalHashMap.put("size", size);
				finalHashMap.put("fullscreen", "1");
			}
			else if (size.equalsIgnoreCase("300x250"))
			{
				//finalHashMap.put("size", size);
				finalHashMap.put("fullscreen", "0");
			}
		}

		return finalHashMap;
	}



	/** This method will rename keys ipAddress and refURL to ip and ref for post requests and remove appName and siteName as 
	 * post request has this param.
	 * 
	 * @param header
	 * @return
	 */
	public static HashMap<String, String> renameKeysForPostRequest(HashMap<String, String> map)
	{
		if(map.containsKey("ip"))
		{
			String ip = map.get("ip");
			map.remove("ip");
			map.put("ipAddress", ip);
		}

		if(map.containsKey("ref"))
		{
			String ref = map.get("ref");
			map.remove("ref");
			map.put("refURL", ref);
		}

		if(map.containsKey("appName"))
		{
			map.remove("appName");
		}

		if(map.containsKey("siteName"))
		{
			map.remove("siteName");
		}

		return map;
	}

}
