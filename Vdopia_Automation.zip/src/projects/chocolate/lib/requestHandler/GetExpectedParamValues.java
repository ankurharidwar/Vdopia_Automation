/**
 * Last Changes Done on Feb 2, 2015 11:25:48 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the logic to create a map containing 
 * the expected values -- to be used all over chocolate modules. 
 */

package projects.chocolate.lib.requestHandler;

import java.util.HashMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.mysql.jdbc.Connection;

import projects.chocolate.lib.utils.ReadChocolateConfig;

import vlib.DBLib;
import vlib.StringLib;


public class GetExpectedParamValues 
{

	static Logger logger = Logger.getLogger(GetExpectedParamValues.class.getName());	


	/** This method return the final map containing all expected parameter and their values, 
	 * **** Note For Developer: final map should be empty in case request doesn't have correct api key. ****  
	 * 
	 * @param url
	 * @return
	 */
	@SuppressWarnings("finally")
	public static HashMap<String, String> getExpectedRequiredParamValues(String chocolateRequest, Connection connection)
	{
		HashMap<String, String> hashmap = new HashMap<String, String>();

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *********** Getting required paramter values *********** ");

			/** Get all the expected headers into a hashmap */
			HashMap<String, String> getExpectedRequestHeader = HeadersLib.getHeaders();

			/** Get all the parameters and their values from supplied get or post request, getting 
			 * paramValuesFromRequest into another hashmap queryParameters to be used later on, 
			 * adding requestType = GET/POST also in map to be used later on. 
			 * */ 
			HashMap<String, String> paramValuesFromRequest = new HashMap<>();

			if(RequestHandler.isGetRequest(chocolateRequest))
			{
				paramValuesFromRequest = GetRequestLib.getQueryParamsFromGetRequest(chocolateRequest);
				paramValuesFromRequest.put("requestType", "GET");

				/** adding chocolate GET/POST request also in the final map to used later on while peforming validation...  */
				paramValuesFromRequest.put("request", chocolateRequest);
			}
			else if(RequestHandler.isPostRequest(chocolateRequest))
			{
				paramValuesFromRequest = PostRequestLib.parsePostRequest(chocolateRequest);
				paramValuesFromRequest.put("requestType", "POST");

				/** adding chocolate GET/POST request also in the final map to used later on while peforming validation...  */
				paramValuesFromRequest.put("request", chocolateRequest);
			}

			String apikey = paramValuesFromRequest.get("ak");
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : api key from url: " +apikey);

			/** Get the values of all required parameters from db - to be used later, in case the parameter is not supplied in url */ 
			HashMap<String, String> requiredValuesFromDB = DBLib.getRequiredHudsonParamsFromDB(apikey, connection);

			/** only in case of post request, supplied api key wasn't found in db then request is not rejected, 
			 * therefore sending paramValuesFromRequest as final map for post request. */
			if(RequestHandler.isPostRequest(chocolateRequest))
			{
				hashmap = paramValuesFromRequest;
				hashmap = StringLib.copyOneDistinctHashmapToAnother(getExpectedRequestHeader, hashmap);
			}
			else
			{
				if(requiredValuesFromDB.isEmpty())
				{
					logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied api key wasn't found in database. ");
				}
				else
				{
					/** 1. Get all query params into hashmap, 2. copy distinct values from getExpectedRequestHeader map to hashmap, 
					 * 3. then copy distinct values from requiredValuesFromDB to hashmap  
					 * this is being done to maintain the priority of values: First from url and then from header and then from db. */
					hashmap.putAll(paramValuesFromRequest);

					hashmap = StringLib.copyOneDistinctHashmapToAnother(getExpectedRequestHeader, hashmap);
					hashmap = StringLib.copyOneDistinctHashmapToAnother(requiredValuesFromDB, hashmap);

					/** in final map, there will be either siteName or appName depending on type parameter, if type =app then retain appName else siteName
					 * if domain = '' or null finally then reassign it to value of siteName or appName
					 * apply rule, so far applicable to get request, need to see for post request */

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Rule Applied in Case of Get Request ..... ");
					hashmap = ApplyRulesLib.applyRules(hashmap, paramValuesFromRequest, requiredValuesFromDB, chocolateRequest);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while creating a map containing all expected required parameter and their values. ", e);
		}
		finally
		{
			/**
			 * Finally updating the map keys (parameter name) with values defined in config because same parameter names 
			 * are used in rtb object jsons  
			 */

			HashMap<String, String> finalMap = ReadChocolateConfig.getKeysFromConfig(hashmap);
			return finalMap;
		}
	}

}
