/**
 * Last Changes Done on 4 May, 2015 3:30:30 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */

package projects.chocolate.lib.moduleHandler;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;

import projects.chocolate.lib.ChocolateResponseLib;
import projects.chocolate.lib.PricingLib;
import projects.chocolate.lib.VdopiaParamValidationLib;
import projects.chocolate.lib.ChocolateResponseErrorLib;
import projects.chocolate.lib.bidders.BiddersLib;
import projects.chocolate.lib.bidders.VdopiaBidderLib;
import projects.chocolate.lib.jsonHandler.JSONParserLib;
import projects.chocolate.lib.requestHandler.GetRequestLib;
import projects.chocolate.lib.requestHandler.RequestHandler;
import projects.chocolate.lib.serving.ChocolateServingLib;

import projects.chocolate.lib.utils.ChocolateUtils;
import projects.chocolate.lib.utils.GetChocolateLogs;



import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;


public class ModulesLib 
{
	Logger logger = Logger.getLogger(ModulesLib.class.getName()); 

	HashMap<String, String> requiredExpectedParameters = new HashMap<>();
	String chocolateRequest;
	Session session;
	File hudsonMappings;
	String tmpHudsonLogFile;
	Connection connection;
	WebDriver driver;
	String response;
	boolean isRequestValid;
	Bigquery bqConnection;
	String bqProjectID;


	/** This constructor will set all the values required in below methods.
	 * 
	 * @param session
	 * @param chocolateRequest
	 * @param hudsonMappings
	 * @param requiredExpectedParameters
	 * @param tmpHudsonLogFile
	 * @param connection
	 * @param driver
	 * @param response
	 * @param isRequestValid
	 */
	public ModulesLib(Session session, String chocolateRequest, File hudsonMappings, HashMap<String, String> requiredExpectedParameters, String tmpHudsonLogFile
			, Connection connection, WebDriver driver, String response, boolean isRequestValid, Bigquery bqConnection, String bqProjectID)
	{
		this.requiredExpectedParameters = requiredExpectedParameters;
		this.chocolateRequest = chocolateRequest;
		this.session = session;
		this.hudsonMappings = hudsonMappings;
		this.tmpHudsonLogFile = tmpHudsonLogFile;
		this.connection = connection;
		this.driver = driver;
		this.response = response;
		this.isRequestValid = isRequestValid;
		this.bqConnection = bqConnection;
		this.bqProjectID = bqProjectID;
	}


	/** This module will validate the data to be posted to bidders.
	 * 
	 * @return
	 */
	public String validate_data_to_be_posted()
	{
		if(isRequestValid)
		{
			String result = ChocolateUtils.validate_bidderDataToBePosted(session,tmpHudsonLogFile, requiredExpectedParameters, connection);
			return result;
		}
		else
		{
			return "SKIP: Supplied request is not valid.";
		}
	}


	/** This module will validate the bidder selection, it will compare the expected bidders from db and actual selected 
	 * and mentioned in bq mx log.
	 * Features covered in this module: 
	 * 1. bidder selection based on request param: ip, adformat
	 * 2. white/blacklisting 
	 * 3. bidder filtering based on channel and bidder filters
	 * 4. cyclic bidders
	 * 5. exclusion below floor vast bidder
	 * 
	 * @return
	 */
	public String validate_bidder_selection()
	{
		if(isRequestValid)
		{
			/** Need to add validation of white/blacklisting coz
			 * Total Number of Bidders Selected = bidders in BqMx log + Bidders filtered in whitelist/blacklist
			 */
			String result = BiddersLib.validateBidderSelection(hudsonMappings.toString(), session, tmpHudsonLogFile, requiredExpectedParameters, connection);
			return result;
		}
		else
		{
			return "SKIP: Supplied request is not valid.";
		}
	}


	/** This module will validate the pricing and compare the expected and actual winning bidder.
	 * 
	 * @return
	 */
	public String validate_pricing()
	{
		if(isRequestValid)
		{
			String result = PricingLib.validateWinningBidder(session, tmpHudsonLogFile, hudsonMappings.toString(), requiredExpectedParameters, connection);
			return result;
		}
		else
		{
			return "SKIP: Supplied request is not valid.";
		}
	}



	/** This module will serve the chocolate response and validate the trackers.
	 * Tracker will be checked upon serving chocolate response only for Vdopia RTB Bidder, third party checks not yet implemented.
	 * 
	 * Hudson response message will be checked based on winningBidderResult, if there is no winning bidder
	 * ui tracker should be fired else create html file containing response, serve ad and check vi tracker.  
	 * Serving will not be done in two cases: 1. There is no winning bidder 2. Bidding didn't take place
	 *  
	 * @return
	 */
	public String validate_serving()
	{
		if(driver != null)
		{
			if(isRequestValid)
			{
				String result = ChocolateServingLib.validateChocolateResponse(session, tmpHudsonLogFile, driver, chocolateRequest, 
						response, requiredExpectedParameters, bqConnection, bqProjectID,connection);

				return result;
			}
			else
			{
				return "SKIP: Supplied request is not valid.";
			}
		}
		else
		{
			return "SKIP: Webdriver wasn't setup, therefore skipping test.";
		}
	}


	/** This module will be used to check the final response string given by chocolate: 
	 * if, request is invalid, then - check request rejection / no ad found string in response
	 * else if, there is any winning bidder then check price node in response.
	 *  
	 * @return
	 */
	public String validate_response_text()
	{
		String result= "";
		if(RequestHandler.isGetRequest(chocolateRequest))
		{
			/** Check if supplied ad format and output are valid, in case of invalid apikey in request requiredExpectedParameters map will be empty,
			 */
			boolean isAdFormatValid = GetRequestLib.isAdFormatValid(chocolateRequest);
			boolean isOutputTypeValid = GetRequestLib.isOutputTypeValid(chocolateRequest);

			/** supplied request can either be rejected or can have a no ad found message, therefore first check request rejection
			 * because of invalid apikey, adformat or output and then no ad found message
			 */
			if((!isAdFormatValid || !isOutputTypeValid) || requiredExpectedParameters.isEmpty())
			{
				result = ChocolateResponseErrorLib.verifyRequestRejectionErrorMessage(requiredExpectedParameters, isAdFormatValid, isOutputTypeValid, chocolateRequest, response);
			}
			else
			{
				/** if request is valid and if there is a winning bidder then check price information in response */
				String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
				String winningBidderFromBqMxLog = JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);

				if(!winningBidderFromBqMxLog.isEmpty())
				{
					/** validate price information in chocolate response */
					result = ChocolateResponseLib.validatePriceInformation(winningBidderFromBqMxLog, bqmxJsonString, response, requiredExpectedParameters);
				}
				else
				{
					result = ChocolateResponseErrorLib.verifyNoAdFoundMessage(response, requiredExpectedParameters, session, tmpHudsonLogFile);
				}
			}
			return result;
		}
		else
		{
			return "SKIP: This module is valid for GET request only, supplied one is not a GET request.";
		}

	}


	/** This module will check the filtering of specific status in bq mmx log.
	 * 
	 * @return
	 */
	public String validate_mmxresponsestatus()
	{
		try
		{
			if(isRequestValid)
			{
				/** Get command to retrieve the bq mmx json
				 */
				String mmxJsonString = GetChocolateLogs.getBQMMXJsonString(session, tmpHudsonLogFile); 

				/** Get all response status from bq mmx json
				 */
				List<String> listStatus = JSONParserLib.getAllResponseStatusFromBqMMxLog(mmxJsonString);

				if(listStatus.contains("NO CONTENT") || listStatus.contains("EMPTY VAST") || listStatus.contains("JSON_ERROR"))
				{
					return "FAIL: Received Response Status From MMX JSON: \n" + listStatus.toString() 
					+ "\nExpected: mmx json string should not have bidder status: NO CONTENT, EMPTY VAST and JSON_ERROR";
				}
				else
				{
					return "PASS: Received Response Status From MMX JSON: \n" + listStatus.toString() 
					+ "\nExpected: mmx json string should not have bidder status: NO CONTENT, EMPTY VAST and JSON_ERROR";
				}
			}
			else
			{
				return "SKIP: Supplied request is not valid.";
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking bq mmx log. ", e);
			return "Exception occurred while getting response status from mmx json. ";
		}

	}

	
	/** This module will validate the structure of vdopia bidder's response returned to chocolate,
	 * validation will be of: response json format, expected josn fields,  
	 * how to do: automation code will find out the vdopia bidder's url and request to be posted to vdopia
	 * and automation suite will send the post request and validate the received response.  
	 * 
	 * @return
	 */
	public String validate_vdopia_bidder_response()
	{
		String result = "";

		/** Get selected vdopia bidders information from the bq log */
		HashMap<String, HashMap<String, String>> vdopiaBiddersInfo = BiddersLib.getSelectedVdopiaBiddersInfo(session, tmpHudsonLogFile, connection);
		if(RequestHandler.isGetRequest(chocolateRequest))
		{
			if(!vdopiaBiddersInfo.isEmpty())
			{
				/** Validate bidder response */
				for(Entry<String, HashMap<String, String>> entry : vdopiaBiddersInfo.entrySet())
				{
					String bidder = entry.getKey();
					String requestURL = entry.getValue().get("bidderurl");

					/** Getting request to be posted to vdopia bidder */
					String postRequest = entry.getValue().get("request");

					result = "Response validation result of vdopia bidder: "+bidder +": " +  VdopiaBidderLib.validateVdopiaBidderResponse(bidder, requestURL, postRequest);

					/** Validate these only in case of winning vdopia bidder */
					result = result + "\n" + VdopiaParamValidationLib.Verify_vdopia_parameter(session, tmpHudsonLogFile, requiredExpectedParameters, response, connection);
				}
			}
			else
			{
				result = "SKIP: There was no vdopia bidder picked up for this iteration. ";
			}
		}
		else
		{
			result = result + "\n SKIP: This module is valid for GET request only, supplied one is a POST request.";
		}
		if(!vdopiaBiddersInfo.isEmpty())
		{
			result = result + "\n" + VdopiaBidderLib.validateWinningVdopiaBidderInformation(response, connection);
		}

		return result;
	}



	/**
	 * This method will validate the vast response for output=vast request, in case there is any winning bidder, 
	 * then vast response will be served else if request has params for fall back, then vast response will be verified 
	 * whether it contains the vastAdTag for fall back url 
	 * 
	 * @return
	 */
	public String validate_vast_response()
	{
		String result = "";

		try
		{
			/** Getting winning bidder from the bq log */
			String bqmxJsonString = GetChocolateLogs.getBQJsonString(session, tmpHudsonLogFile);
			String winningBidderFromBqMxLog = JSONParserLib.getWinningBidderIDFromBqLog(bqmxJsonString);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Winning bidder id is: "+ winningBidderFromBqMxLog);

			/** Applying condition for skipping this module if request have other than output = vast */
			if(!requiredExpectedParameters.get("output").equalsIgnoreCase("vast"))
			{
				result = "SKIP: This module is for output = vast only, but supplied output is: "+requiredExpectedParameters.get("output"); 
			}
			else if(winningBidderFromBqMxLog.isEmpty())
			{
				result = "SKIP: There was no winning bidder found, vast response will be validated only in case of a winning bidder.";
			}
			else
			{
				/** Checking vast response */
				//String expectedVastTag = requiredExpectedParameters.get("vast_tag");
				//result = VastHandlerLib.validateVastResponse(driver, chocolateRequest, winningBidderFromBqMxLog, response, expectedVastTag);
			}
		}
		catch(Exception e)
		{
			result = "SKIP: Error occurred while executing this module. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception while validating the vast response", e);
		}
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result of validating vast response is: "+result );
		return result;
	}

}
