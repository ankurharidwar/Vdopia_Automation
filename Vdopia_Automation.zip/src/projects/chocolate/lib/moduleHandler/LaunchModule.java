/**
 * Last Changes Done on 14 May, 2015 11:15:18 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class will call the methods defined in modulesLb dynamically. 
 */
package projects.chocolate.lib.moduleHandler;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;

import projects.chocolate.lib.requestHandler.GetRequestLib;
import projects.chocolate.lib.requestHandler.PostRequestLib;
import projects.chocolate.lib.requestHandler.RequestHandler;


import vlib.ExecuteCommands;
import vlib.StringLib;

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

public class LaunchModule 
{

	Logger logger = Logger.getLogger(LaunchModule.class.getName());


	/** This method will launch the chocolate test, basically it will call the methods dynamically corresponding to supplied modules.
	 * 
	 * @param module
	 * @param session
	 * @param chocolateRequestUrl
	 * @param hudsonMappings
	 * @param requiredExpectedParameters
	 * @param tmpHudsonLogFile
	 * @param connection
	 * @return
	 */
	public String launchModules(String module, Session session, String chocolateRequest, File hudsonMappings, 
			HashMap<String, String> requiredExpectedParameters, String tmpHudsonLogFile, Connection connection, WebDriver driver, String response,
			Bigquery bqConnection, String bqProjectID)
	{
		String result = "";
		module = module.toLowerCase().trim();

		try
		{
			/** Proceed to test only if module name is not empty
			 */
			if(!module.isEmpty())
			{
				/** proceed for bidder selection only if received log file is not empty. 
				 */
				String tmpLogFileContent = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "cat "+tmpHudsonLogFile);

				if(!tmpLogFileContent.trim().isEmpty())
				{
					/** check if the supplied get or post request is valid
					 */
					boolean isRequestValid = false;
					if(RequestHandler.isGetRequest(chocolateRequest))
					{
						isRequestValid = GetRequestLib.isGetRequestValid(chocolateRequest, requiredExpectedParameters);
					}
					else if(RequestHandler.isPostRequest(chocolateRequest))
					{
						isRequestValid = PostRequestLib.isPostRequestValid(requiredExpectedParameters);
					}

					/** executing modules
					 */
					result = executeModules(module, session, chocolateRequest, hudsonMappings, requiredExpectedParameters, 
							tmpHudsonLogFile, connection, driver, response, isRequestValid, bqConnection, bqProjectID);
				}
				else
				{
					return "SKIP: Received empty log file: "+tmpHudsonLogFile + ", skipping this module.";
				}
			}
			else
			{
				result = "SKIP: Module name should be supplied.";
			}
		}
		catch(Exception e)
		{
			result = "Fail: Error occurred while performing tests.";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while executing test for module: "+module, e);
		}

		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Module Result: "+result);
		return result;
	}


	/** This method will launch the chocolate test, basically it will call the methods dynamically corresponding to the supplied  modules.
	 * 
	 * @param module
	 * @param session
	 * @param chocolateRequestUrl
	 * @param hudsonMappings
	 * @param requiredExpectedParameters
	 * @param tmpHudsonLogFile
	 * @param connection
	 * @param driver
	 * @param response
	 * @return
	 */
	public String executeModules(String module, Session session, String chocolateRequestUrl, File hudsonMappings, 
			HashMap<String, String> requiredExpectedParameters, String tmpHudsonLogFile, Connection connection, 
			WebDriver driver, String response, boolean isRequestValid, Bigquery bqConnection, String bqProjectID)
	{

		String result = "";

		/** getting supplied module list */
		List<String> moduleList = StringLib.getListFromCommaSeparatedString(module);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received module list: "+moduleList);

		/** executing each module */
		for(int i=0; i<moduleList.size(); i++)
		{
			String moduleResult = "";
			module = moduleList.get(i).toLowerCase().trim();

			if(!module.trim().isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ################### Executing module: "+module +" ################### ################### ");

				try{

					Class<?> moduleClass = Class.forName(ModulesLib.class.getName());			
					Method moduleMethod = moduleClass.getMethod(module);

					ModulesLib keywordObj = new ModulesLib(session, chocolateRequestUrl, hudsonMappings, requiredExpectedParameters, 
							tmpHudsonLogFile, connection, driver, response, isRequestValid, bqConnection, bqProjectID);

					moduleResult = (String) moduleMethod.invoke(keywordObj);
				}catch(NoSuchMethodException m)
				{
					moduleResult = "  SKIP: supplied module: "+module +" is not supported yet. ";
				}
				catch (Exception e) 
				{
					moduleResult = "  FAIL: Error occurred while performing tests for supplied module: "+module;
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while executing test for module: "+module, e);
				}

				/** collecting result */
				result = result + "\n" + "Result of " + module + ":\n" + moduleResult;
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ################### Module: "+module +" Ended ################### ################### ");
		return result;
	}

}
