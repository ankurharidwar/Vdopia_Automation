
package projects.chocolate.lib;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import projects.chocolate.lib.jsonHandler.JSONParserLib;




public class ChocolateResponseLib {


	static Logger logger = Logger.getLogger(ChocolateResponseLib.class.getName());

	public static void main(String[] args) 
	{

		String fl = "5";
		System.out.println("Float: "+Float.parseFloat(fl));

		String response = "</SkipAfterSeconds>"+
				"\n<Extension type=\"value\">" +
				"\n<Price model=\"CPM\" source=\"Vdopia\">5.0</Price>"+
				"\n<Currency>USD</Currency>";

		String regular = "(?s)(<Extension type=\"value\">\n<Price model=\"CPM\" source=\"Vdopia\">)5.0(<\\/Price)";
		Pattern pattern = Pattern.compile(regular);
		Matcher match = pattern.matcher(response);

		boolean foundMatch = match.find();

		System.out.println("Match Found: "+foundMatch);
	}


	/** This method will check the expected price information in the received response string. 
	 * 
	 * @param response
	 * @param requiredExpectedParameters
	 * @param winSupplyPrice
	 * @return
	 */
	public static String validatePriceInformation(String winningBidderFromBqMxLog, String bqmxJsonString, String response, HashMap<String, String> requiredExpectedParameters)
	{
		String result;
		String output = requiredExpectedParameters.get("output");
		String adformat = requiredExpectedParameters.get("adFormat");

		if(winningBidderFromBqMxLog.equalsIgnoreCase("GOOGLE_ADX_FALLBACK"))
		{
			result = "SKIP: GOOGLE_ADX_FALLBACK is winning bidder (a fall back scenario), therefore price information was not checked. ";
		}
		else
		{
			/** get win supply price price */
			String winSupplyPrice = JSONParserLib.getWinPriceSupplyFromBqLog(bqmxJsonString);

			if(adformat.equalsIgnoreCase("banner") || adformat.equalsIgnoreCase("preinter"))
			{
				result = "SKIP: Price information is not being checked for adformat = "+adformat ;
			}
			else
			{
				String regularExpression = "";

				if(output.equalsIgnoreCase("vast"))
				{
					regularExpression = "(?s)(?<=<Extension type=\"value\"><Price model=\"CPM\" source=\"Vdopia\">)(.*)(?=<\\/Price)";
					result = parseResponseWithRegularExpression(output, regularExpression, response, winSupplyPrice);
				}
				else if(output.equalsIgnoreCase("js") || output.equalsIgnoreCase("xhtml") || output.equalsIgnoreCase("javascript"))
				{
					regularExpression = "(?<=\"price\":\"{\\\\\"model\\\\\":\\\\\"CPM\\\\\",\\\\\"currency\\\\\":\\\\\"USD\\\\\",\\\\\"source\\\\\":\\\\\"vdopia\\\\\",\\\\\"value\\\\\":)(.*)(?=}\",\"stick)";
					result = parseResponseWithRegularExpression(output, regularExpression, response, winSupplyPrice);
				}
				else
				{
					result = "SKIP: Price information is not checked for output = "+output;
				}
			}
		}

		return result;
	}


	/** This method will parse the supplied response with the supplied regular expression and return boolean based on finding. 
	 * 
	 * @param regularExpression
	 * @param response
	 * @return
	 */
	public static String parseResponseWithRegularExpression(String output, String regularExpression, String response, String winSupplyPrice)
	{
		String result;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received Regular Expression: "+regularExpression + " for output = "+output);

		Pattern pattern = Pattern.compile(regularExpression);
		Matcher match = pattern.matcher(response);

		if(match.find())
		{
			String actualSupplyPrice = match.group();

			if(Float.parseFloat(actualSupplyPrice) == Float.parseFloat(winSupplyPrice))
			{
				result = "PASS: Chocolate response contains the expected price information.";
			}
			else
			{
				if(output.equalsIgnoreCase("vast"))
				{
					result = "FAIL: Chocolate response contains the price = "+Float.parseFloat(actualSupplyPrice) +" whereas expected = "+Float.parseFloat(winSupplyPrice);
				}
				else
				{
					result = "FAIL: Chocolate response contains the price = "+ actualSupplyPrice +" whereas expected = "+winSupplyPrice;
				}
			}
		}
		else
		{
			result = "FAIL: Chocolate response doesn't contain the price information. ";
		}

		
		logger.info(response);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Price information parsing result: "+result);
		return result;
	}

}
