package projects.chocolate.packageFilters;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;


public class CreateExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
	//--------->>>>>>>>>>> Select all params, which are not selected by ui, put them as -1
	public static String videoInventoryExpression(List<LinkedHashMap<String, String>> values)
	{
		String videoExpresion = "";

		for(int i=0; i<values.size(); i++)
		{
			String paramName = values.get(i).keySet().iterator().next().trim();
			String paramValue = values.get(i).get(paramName).trim();

			if(videoInventory().contains(paramName))
			{				
				videoExpresion = videoExpresion.trim() + getMacro_VideoInventory(paramValue) + "VDO_&";
			}
		}

		if(videoExpresion.endsWith("VDO_&"))
		{
			videoExpresion = videoExpresion.substring(0, videoExpresion.lastIndexOf("VDO_&"));
			return videoExpresion;
		}
		else
		{
			return videoExpresion.trim();
		}
	}

	//get video inventory params
	public static List<String> videoInventory()
	{
		//Video Inventory Type
		List<String> list = new ArrayList<>();

		list.add("Ad Size");
		list.add("Vdo Ad Formats");
		list.add("Has GPS – based Lat/Long");
		list.add("Has IFA – Yes/No");
		list.add("Integration");
		list.add("Clickable");
		list.add("In-Stream");
		list.add("Incentivized");
		list.add("Auto-play");
		list.add("Sound");
		list.add("Skippable");
		list.add("Viewablity Measurable");

		return list;
	}

	//get video inventory param values
	public static String getMacro_VideoInventory(String value)
	{

		switch (value) 
		{
		case "320x480":
			value = "0";
			break;

		case "300x250":
			value = "1";
			break;

		case "492x517":
			value = "2";
			break;

		case "Yes":
			value = "1";
			break;

		case "No":
			value = "0";
			break;

		case "On":
			value = "1";
			break;

		case "Off":
			value = "0";
			break;

		case "Direct":
			value = "1";
			break;

		case "Indirect":
			value = "0";
			break;

		default:
			break;
		}

		return value.trim();
	}
}
