package projects.chocolate.packageFilters;


import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


public class WriteCombinations {

	private static final List<Option> options = new ArrayList<>();
	private static int counter;
	private static final List<String []> combinations = new ArrayList<>();
	private static final String combinationFile = "/Users/Pankaj/Desktop/QA_Automation/qascripting/Vdopia_Automation/tc_data/chocolate/package/PackageParams.xls";
	//private static final String packageCSV = "/Users/Pankaj/Desktop/QA_Automation/qascripting/Vdopia_Automation/tc_data/chocolate/package/packageCSV.csv";

	private static String chocolateURLInitial= "http://54.147.135.82:84/adserver/html5/inwapads/?adFormat=preappvideo";


	public static void main(String[] args) 
	{
		getCombinations();
		writeCombination(combinations);
		writeChocolateURL();	
		writeVideoExpression("video_inventory_type_expr");
	}


	//get all possible combinations
	public static void getCombinations()
	{
		LinkedHashMap<String, String> src = new Package_Values().getParamsMap();

		for (Entry<String, String> srcEntry : src.entrySet()) {

			Option option = new Option(srcEntry.getKey());
			options.add(option);

			for (String val : srcEntry.getValue().split(",")) {
				option.possibleValues.add(val);
			}
		}

		counter = 0;
		next(new String[options.size()], 0);

	}

	private static void next(String[] buffer, int currentIndex) 
	{
		if (currentIndex == options.size()) 
		{
			counter++;
			System.out.println("===============================");
			System.out.println("Counter: " + counter);

			//System.out.println("buffer.length: "+buffer.length + "  combinations.size(): "+combinations.size() );

			String [] combinationsArray = new String[options.size()];

			for (int i = 0; i < buffer.length; i++) 
			{
				//System.out.println(options.get(i).name + ": " + buffer[i]);
				combinationsArray[i] = buffer[i];
			}

			//Add combinationArray to a List
			combinations.add(combinationsArray);
		} 
		else 
		{
			for (String val : options.get(currentIndex).possibleValues) {

				//System.out.println("Current Index: "+currentIndex + " Val: "+val + "   out of:  "+options.get(currentIndex).possibleValues);

				buffer[currentIndex] = val;
				next(buffer, currentIndex + 1);
			}
		}
	}

	//class contains options and param name
	public static class Option {
		public final String name;
		public final List<String> possibleValues = new ArrayList<>();

		public Option(String name) {
			this.name = name;
		}
	}

	//write all combination in excel sheet
	public static void writeCombination(List<String []> combinations)
	{
		try
		{
			WritableWorkbook workbook = Workbook.createWorkbook(new File(combinationFile));
			WritableSheet sheet = workbook.createSheet("Test_Data", 0);

			for(int i=0; i<combinations.size(); i++)
			{				
				for(int j=0; j<combinations.get(i).length; j++)
				{
					//write columns names first
					if(i==0)
					{
						String cont = options.get(j).name.trim();
						sheet.addCell(new Label(j, i, cont));
					}
					//write combination
					else
					{
						String cont = combinations.get(i)[j].trim();
						sheet.addCell(new Label(j, i, cont));
						//System.out.print(cont + "   ");
					}
				}
			}

			workbook.write();
			workbook.close();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	//write chocolate url
	public static void writeChocolateURL()
	{
		try
		{
			Workbook workbook = Workbook.getWorkbook(new File(combinationFile));
			WritableWorkbook writer = Workbook.createWorkbook(new File(combinationFile), workbook);
			WritableSheet sheet = writer.getSheet(0);

			//add Chocolate_URL label at the last column in the first row
			sheet.addCell(new Label(sheet.getColumns(), 0, "Chocolate_URL"));

			for(int row=1; row<sheet.getRows(); row++)
			{
				String url = "";

				for(int column=0; column<sheet.getColumns(); column++)
				{
					//get content of each cell and corresponding column name - to process further  
					String content = sheet.getCell(column, row).getContents().trim();
					String columnLabel = sheet.getCell(column, 0).getContents().trim();

					//get content based on supplied columns 
					url =  url + "&" + formQueryParam(content, columnLabel);

					//add the url only at last column
					if(column == sheet.getColumns()-1)
					{	
						//add initials in final url
						url = chocolateURLInitial + url;

						//add output type js or vast at the end of url, handling here on alternate calls
						if(row%2 ==0){
							url = url + "&" + "output=js";
						}else{
							url = url + "&" + "output=vast";
						}
						sheet.addCell(new Label(column, row, url));
					}
				}
			}

			writer.write();
			writer.close();
			workbook.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	//get query param for creating url
	public static String formQueryParam(String content, String columnLabel)
	{
		String urlContent = "";

		switch (columnLabel) {
		case "Ad Size":

			if(content.equalsIgnoreCase("320x480"))
			{
				urlContent = "size=320x480";
			}
			else if(content.equalsIgnoreCase("300x250"))
			{
				urlContent = "size=300x250";
			}
			else
			{
				urlContent = "size=492x517";
			}

			break;


		case "Has GPS – based Lat/Long":

			if(content.equalsIgnoreCase("Yes"))
			{
				urlContent = "target_param=geoType=1";
			}
			else
			{
				urlContent = "target_param=geoType=2";
			}

			break;

		case "Has IFA – Yes/No":

			if(content.equalsIgnoreCase("Yes"))
			{
				urlContent = "di=BluekaiIFACost_bk";
			}
			else
			{
				urlContent = "di=";
			}

			break;

		case "App/Mobile Targeting":

			if(content.equalsIgnoreCase("app"))
			{
				urlContent = "type=app";
			}
			else
			{
				urlContent = "type=site";
			}

			break;

		case "Site Domain & App Bundle Targeting":

			if(content.contains(".com"))
			{
				urlContent = "domain="+content;
			}
			else
			{
				urlContent = "appBundle="+content;
			}

			break;

		case "Adult Content":

			if(content.equalsIgnoreCase("No Adult Content"))
			{
				urlContent = "pageURL=google.com";
			}
			else
			{
				urlContent = "pageURL=xxx.com";
			}

			break;

		case "Operating system":

			if(content.equalsIgnoreCase("ios"))
			{
				urlContent = "ua=Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A405 Safari/600.1.4";
			}
			else
			{
				urlContent = "ua=Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/BuildID) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36";
			}

			break;

		case "Country":

			if(content.equalsIgnoreCase("United States"))
			{
				urlContent = "ipAddress=65.55.37.104";
			}
			else
			{
				urlContent = "ipAddress=65.55.37.104";
			}

		default:
			break;
		}


		return urlContent;
	}

	//write video inventory expressions
	public static void writeVideoExpression(String labelName)
	{
		try
		{
			System.out.println("Writing expression for: "+labelName);
			Workbook workbook = Workbook.getWorkbook(new File(combinationFile));
			WritableWorkbook writer = Workbook.createWorkbook(new File(combinationFile), workbook);
			WritableSheet sheet = writer.getSheet(0);
			
			int lastColumn = sheet.getColumns();
			//add video_inventory_type_expr label at the last column in the first row
			sheet.addCell(new Label(lastColumn, 0, labelName));

			for(int row=1; row<sheet.getRows(); row++)
			{
				List<LinkedHashMap<String, String>> paramList = new ArrayList<>();
				for(int column=0; column<sheet.getColumns(); column++)
				{
					LinkedHashMap<String, String> hashmap = new LinkedHashMap<>();
					
					//get content of each cell and corresponding column name - to process further  
					String content = sheet.getCell(column, row).getContents().trim();
					String columnLabel = sheet.getCell(column, 0).getContents().trim();
					
					hashmap.put(columnLabel, content);
					paramList.add(hashmap);
				}

				//getting video expression
				System.out.println("Writing "+labelName + " at row: "+row);
				String videoExpression = CreateExpressions.videoInventoryExpression(paramList);
				sheet.addCell(new Label(lastColumn, row, videoExpression));
			}

			writer.write();
			writer.close();
			workbook.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
