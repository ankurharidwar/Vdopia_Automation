package projects.chocolate.packageFilters;


import java.util.LinkedHashMap;


public class Package_Values 
{

	public LinkedHashMap<String, String> getParamsMap() 
	{
		/** 
		 * ******** NOTE: SELECT ATLEAST ONE VALUE FROM EACH CATEGORY SO THAT THERE IS NO -1 GET SAVED FOR ANY EXPRESSION   ********
		 */
		
		LinkedHashMap<String, String> params = new LinkedHashMap<>();

		//Video Inventory Type
		params.put("Ad Size", "320x480, 300x250, 492x517");
		//params.put("Vdo Ad Formats", "Max, Min,	Med");  //as mayank suggested - it can be handled via size param
		params.put("Has GPS – based Lat/Long",	"Yes, No");
		params.put("Has IFA – Yes/No",	"Yes, No");  //send one di
		params.put("Integration", "Direct, Indirect");
		params.put("Clickable",	"Yes, No");
		params.put("In-Stream",	"Yes, No");
		params.put("Incentivized",	"Yes, No");
		params.put("Auto-play",	"Yes, No");
		params.put("Sound",	"On, Off");
		params.put("Skippable",	"Yes, No");
		params.put("Viewablity Measurable", "Yes, No");

		//App Mobile Content  
		params.put("App/Mobile Targeting", "App, Mobile Web");   //type =app/site
		params.put("Site Domain & App Bundle Targeting", "qascritpting.com, qascripting_bundle");  //NEED TO HANDLE INCLUDE/EXCLUDE AT QUERY LEVEL
		params.put("Adult Content", "No Adult Content, Any content"); //pageURL = xxx.com

		//Devices 
		params.put("Operating system", "iOS, Android");  	//NEED TO HANDLE INCLUDE/EXCLUDE AT QUERY LEVEL
		//		params.put("Device ID Types", "IFA, Device Id MD5, Device Id SHA1");
		//		params.put("Device Category", "Smartphone, Apple");
		//		params.put("Device Make", "Samsung");
		//		params.put("Device Model", "iPhone");
		//		params.put("Device OS Version", "9.2.1");

		//Carriers and networks
		//		params.put("Carrier Whitelist", "Airtel");
		//      params.put("ISP Whitelist", "Airtel");
		//		params.put("WiFi Targeting", "Any");

		//Carriers and networks  -- NEED TO HANDLE DMA TARGETING
		params.put("Country", "United States");
		//		params.put("States", "New Jersey");
		//		params.put("Cities", "Carteret");
		//		params.put("Postal Code Targeting", "07008");

		//Data Provider - Bluekai

		return params;
	}

}

