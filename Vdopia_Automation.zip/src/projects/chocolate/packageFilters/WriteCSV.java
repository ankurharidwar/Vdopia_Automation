package projects.chocolate.packageFilters;

import java.io.File;
import java.io.FileWriter;


public class WriteCSV {

	public static void main(String[] args) {


		try
		{
			File file = new File("/Users/Pankaj/Desktop/Test.csv");
			FileWriter writer = new FileWriter(file);

			if(!file.exists()){
				file.createNewFile();}

			String content = "";
			for(int i=0; i<10; i++)
			{
				content = content + "counter1="+i + "," + "counter2="+i+1 + "\n"; 
			}

			writer.write(content);
			writer.close();
			
			System.out.println("CSV written");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
