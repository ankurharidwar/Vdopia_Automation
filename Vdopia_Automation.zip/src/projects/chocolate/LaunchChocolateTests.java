/**
 * Last Changes Done on Jan 19, 2015 2:31:00 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Refactorying chocolate code into keyword driven framework 
 */

package projects.chocolate;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;


import projects.bq.BQHandler;
import projects.chocolate.lib.moduleHandler.LaunchModule;
import projects.chocolate.lib.requestHandler.GetExpectedParamValues;
import projects.chocolate.lib.requestHandler.HeadersLib;
import projects.chocolate.lib.requestHandler.RequestHandler;
import projects.chocolate.lib.utils.ChocolateUtils;
import projects.chocolate.lib.utils.GetChocolateLogs;
import projects.chocolate.lib.utils.ChocolateServerCheck;



import vlib.Excel2Html;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.FileServerLib;
import vlib.MobileTestClass_Methods;
import vlib.SaveResultsToMySql;
import vlib.XlsLib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;


public class LaunchChocolateTests 
{
	String fileNameWithLocation;
	File testResultFile;
	List<String> resultsList = new ArrayList<String>();
	String hudsonBrowser;
	String hudsonLogFileLocation;
	String host;
	String userName;
	String privateKey;
	Session session;
	String tmpHudsonLogFile;
	String postRequestChocolateURL;
	WebDriver driver;
	File hudsonMappings;
	FileServerLib fileserver;
	int fileServerPort;
	String useExistingURL;
	Connection connection;
	Bigquery bqConnection;
	String bqProjectID;
	String currentTestEnvironment;

	boolean driverRequired = true;
	Logger logger = Logger.getLogger(LaunchChocolateTests.class.getName()); 


	/** Before Test Setup
	 * 
	 * @param browser
	 * @param useExistingURL
	 */
	@Parameters({"browser", "useExistingURL"})
	@BeforeClass
	public void BeforeTest(String browser, String useExistingURL) 
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : 		Starting Chocolate Tests ");
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");

		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			hudsonBrowser = browser;

			fileServerPort = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("fileServerPort").toString());

			privateKey = MobileTestClass_Methods.propertyConfigFile.getProperty("chocolatePrivateKey").toString();

			if(privateKey.isEmpty())
			{
				privateKey = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/hudson/hudson.pem.txt");
			}

			/** Get all chocolate login information from config */
			userName = MobileTestClass_Methods.propertyConfigFile.getProperty("chocolateServerUserName").toString();
			host = MobileTestClass_Methods.propertyConfigFile.getProperty("chocolateServerName").toString();
			hudsonLogFileLocation = MobileTestClass_Methods.propertyConfigFile.getProperty("chocolateLogFile").toString();
			tmpHudsonLogFile =  MobileTestClass_Methods.propertyConfigFile.getProperty("tmpChocolateLogFileForCurrentRequest").toString();
			postRequestChocolateURL = MobileTestClass_Methods.propertyConfigFile.getProperty("postRequestChocolateURL").toString();

			/** Creating connection with hudson server. */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Establishing connection with: "+host + "....");
			session = ExecuteCommands.createSessionWithPrivateKey(userName, privateKey, host);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received private key: "+privateKey + " User Name: "+userName + " Host: "+host);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hudson Log Location: "+hudsonLogFileLocation + " Hudson Tmp Log Location For Current Execution: "+tmpHudsonLogFile);

			/** Getting bq project id and bq connection */
			bqProjectID = MobileTestClass_Methods.propertyConfigFile.getProperty("qaBigQueryProjectId").toString();
			bqConnection = new BQHandler().createBqConnection();

			/** Creating a db connection */
			connection = MobileTestClass_Methods.CreateSQLConnection();

			/** Starting chocolate server if it is not started..... */
			currentTestEnvironment = MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString();
			if(currentTestEnvironment.equalsIgnoreCase("qa"))
			{
				if(!ChocolateServerCheck.chocolateServerStatus(session, connection))
				{	
					Assert.fail("Chocolate Server is not started, exiting test...");
				}
			}

			/** getting hudsonMappings file which contains various mappings */
			hudsonMappings = new File(TestSuiteClass.AUTOMATION_HOME.concat("/conf/hudsonMappings.xls").toString());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting hudson mapping excel sheet from: "+hudsonMappings.toString());

			/** Start file server */
			fileserver = new FileServerLib();
			fileserver.FTPStart(fileServerPort);

			/** flag to notify that no urls will be created dynamically, existing urls will be checked. */
			this.useExistingURL = useExistingURL;

			if(TestSuiteClass.isFresh)
			{
				/** Location of Hudson test data. */
				if(useExistingURL.equalsIgnoreCase("Yes"))
				{
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/chocolate/PasteExistingChocolateRequests.xls").toString();
				}
				else
				{
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/chocolate/Chocolate_TestData_requestResponseValidation.xls").toString();
				}

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hudson Test Data File: "+fileNameWithLocation);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result location for Hudson Inbound call validation Tests : " +TestSuiteClass.resultFileLocation);
				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation + "/Chocolate_Results";

				/** Final Result of test suite will be available at this location. */
				testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hudson Result File: "+testResultFile);

				/** In case, user has existing urls, then do not write url just create an empty workbook to paste them. */
				if(useExistingURL.equalsIgnoreCase("Yes"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test URLs will not be created, existing urls will be used from workbook: "+testResultFile.toString());
				}
				/** Write test url */
				else
				{
					ChocolateUtils.writingHudsonTestURLInExcelSheet(testResultFile.toString());
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Chocolate urls are written in file. ");
				}

				/** Setting up driver */
				if(driverRequired){
					driver = MobileTestClass_Methods.WebDriverSetUp(hudsonBrowser, null);
				}
			}
			else
			{

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : 		Starting Chocolate Validation    ");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");

				/** Location of Re-run Hudson test Data. */
				fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/Hudson/requestResponseValidation/requestResponseValidation_ReRun.xls").toString();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result location for ReRun Hudson Inbound call validation Tests : " +TestSuiteClass.resultFileLocation);
				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation + "/Results_Hudson_Inbound_Call_ReRun";

				/** Final result will be available at this location. */
				testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print Test Result file for ReRun: " +testResultFile.getAbsolutePath());

				/** Setting up driver */
				if(driverRequired){
					driver = MobileTestClass_Methods.WebDriverSetUp(hudsonBrowser, null); }
			}
		}
		catch(AssertionError a)
		{
			logger.error(a.getMessage());
		}
		catch (Exception e) 
		{
			try {
				fileserver.FTPStop();
			} catch (Exception e1) {
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while stopping file server. ");
			}

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred in BeforeTest Setup Method: ", e);				
		}
	}


	/** This is the data provider for the below test, it will fetch two columns: Test_URLs and Module
	 * 
	 * @return
	 */
	@DataProvider(name="HudsonTestURLs")
	public String[][] GetTestDataForHudsonRequest()
	{
		try
		{
			String [][] arrTestURL = null;

			arrTestURL = FileLib.FetchDataFromExcelSheet(testResultFile.toString(), "GetRequestURLs_Or_PostRequests", "Module_Name");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Total Test Data Rows Found: "+arrTestURL.length);
			return arrTestURL;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred during setting up Data Provider, returning null. ", e);
			return null;
		}
	}


	/** This method runs the actual test
	 * 
	 * @param chocolateRequest
	 * @param moduleName
	 */
	@Test(dataProvider = "HudsonTestURLs")
	public void chocolateTest(String chocolateRequest, String moduleName)
	{
		String result = "";
		String response = "";
		String dateTimeStamp = "";
		String tmpHudsonLogFile = "";

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ############### TEST STARTED AT: "+MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss")+" #####################");

			boolean isRequestValid = RequestHandler.isRequestValid(chocolateRequest);			

			if(isRequestValid)
			{				
				String timeStamp = MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss");
				String copiedHudsonLog = "/tmp/hudson_"+timeStamp+".log";

				/** Copying hudson.log to temp file */
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Copying "+hudsonLogFileLocation+" to temp file "+ copiedHudsonLog +"....");
				ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "cp " + hudsonLogFileLocation + " " + copiedHudsonLog);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : sending request ....."+ chocolateRequest);

				/** Getting custom headers */
				HashMap<String, String> headers = HeadersLib.setHeaders();

				/** Sending all request through http with custom headers, now browser will not be opened */			
				response = RequestHandler.requestChocolateURL(postRequestChocolateURL, chocolateRequest, headers);

				/** Checking sever is running or not */
				boolean serverRunning = ChocolateUtils.checkServerRunning(response, hudsonBrowser);


				/** Do Validation only If server is running */ 
				if(serverRunning)
				{
					/** Appending time stamp at the end of temp hudson log file name. */

					dateTimeStamp = MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss");
					tmpHudsonLogFile = this.tmpHudsonLogFile + "_" + dateTimeStamp; 

					/** Get the log for current execution using diff command and store output at tmpHudsonLogFile and use this for further processing */
					GetChocolateLogs.getCurrentChocolateLog(session, hudsonLogFileLocation, copiedHudsonLog, tmpHudsonLogFile);

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : hudson log for this iteration is stored at: "+tmpHudsonLogFile);

					/** Get all the required parameters and their expected values in a hash map, which will be used for RTB Object Validation.
					 * If this hashmap is empty, do not proceed to other tests, this can be empty because of invalid apikey or unsupported  
					 * adformat in supplied url.
					 */					
					HashMap<String, String> requiredExpectedParameters = GetExpectedParamValues.getExpectedRequiredParamValues(chocolateRequest, connection);


					/** Create test dynamically based on supplied module. 
					 */
					result = new LaunchModule().launchModules(moduleName, session, chocolateRequest, hudsonMappings, 
							requiredExpectedParameters, tmpHudsonLogFile, connection, driver, response, bqConnection, bqProjectID);

					result = result + "\nLog file for this iteration: "+tmpHudsonLogFile;
				}
				else
				{
					result = result + "SKIP: Server is not running.";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Server is not running. ");
				}
			}
			else
			{
				result = "FAIL: EITHER SUPPLIED GET REQUEST DOESN'T START WITH HTTP(S) OR POST REQUEST IS NOT A VALID JSON. ";
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception. ", e);
			result = result + "\n This test case is stopped because of exception. ";
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result For This Iteration:");
			logger.info(result);
			resultsList.add(result);

			/** generate testNG results */
			getTestNGResults(result);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ########################################### TEST ENDED AT: "+MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss")+" ##############################################");
		}
	}

	/** This method perform assertion to send the results to testNG, thereafter this result will be used in jenkins.
	 * @param result
	 */
	public void getTestNGResults(String result)
	{
		/** forming actual result for testNG Reports, for results containing FAIL, testNG report 
		 * will mark FAIL, for results containing SKIP, SkipException is thrown to tell testNG about skip tests. */

		if(result.toLowerCase().contains("skip"))
		{
			throw new SkipException(result);
		}
		else if(result.toLowerCase().contains("fail"))
		{
			Assert.fail(result);
		}
		else if(result.toLowerCase().contains("pass"))
		{
			Assert.assertTrue(true, result);
		}
	}


	/**
	 * After Test.
	 */
	@AfterClass
	public void afterTest()  
	{
		try
		{
			String resultSheetName;

			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "Hudson";
			}
			else
			{
				resultSheetName = "Hudson_ReRun";
			}

			/** For Total test cases need to be run */
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			if(driverRequired){
				if(driver != null)
				{
					driver.quit();
				}			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** Test: " +" Hudson_InboundRequestResponseTests ****** " +" Ended at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");

			/** Write test results */
			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList);

			/** Updating results to main results sheet */
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());
			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);

			/** Converting excel into HTML */
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			/** Save chocolate results into mysql database */
			SaveResultsToMySql.saveChocolateResults(testResultFile.toString(), TestSuiteClass.suiteStartTime, TestSuiteClass.executedOnMachine, TestSuiteClass.environment);

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				String testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/Hudson/requestResponseValidation/Hudson_ReRun.xls").toString();
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}	

			/** Close db connection */
			connection.close();
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception at the end of Hudson Inbound Request response test: ", e);
		}
		finally
		{			
			/** Stop file server */
			fileserver.FTPStop();

			/** Disconnect session */
			session.disconnect();

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : 		Chocolate Tests Ended ");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : #############################################################################");
		}
	}

}