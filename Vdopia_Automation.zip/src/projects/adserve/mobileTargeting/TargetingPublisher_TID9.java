/**
 * Last Changes Done on Feb 5, 2015 1:24:02 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import vlib.Excel2Html;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import com.mysql.jdbc.Connection;

import java.util.Properties;
import projects.TestSuiteClass;

public class TargetingPublisher_TID9 
{
	String publisherEmail;
	String advertiserEmail;
	String CampaignName;
	String channelNameWithRON;
	String channelNameWithoutRON;
	String finalResultFileLocation;
	String Testbrowser;

	TreeMap <Integer, List<String>> Result_map = new TreeMap<Integer, List<String>>();

	WebDriver driver;
	File testResultFile;
	Connection serveConnection;
	List<String> resultsList = new ArrayList<String>();
	int bannerDelay;
	int nonBannerDelay;
	public static Properties LangConfigFile;
	String fileNameWithLocation;
	String testDataFileLocation_ReRun;

	// Before Class - Running query and creating test data file
	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) 
	{
		// Variable Initialised and declared 
		Testbrowser = browser;
		publisherEmail = "automation_megha@vdopia.com";
		advertiserEmail = "automation_megha@vdopia.com";
		CampaignName = "Auto_Publisher_targeting_03072014183025";
		channelNameWithRON = "Auto_Pub_target_WithRon_04072014";
		channelNameWithoutRON = "Auto_Pub_Target_WithoutRON_04072014121911";

		//test data File Location for ReRun
		testDataFileLocation_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataPublisherTargeting_TID9_ReRun.xls").toString();

		//Initilaize Configuration File
		MobileTestClass_Methods.InitializeConfiguration();

		//Checking for Fresh Run and ReRun
		if(TestSuiteClass.isFresh)
		{
			try
			{
				System.out.println("#############################################################################");
				System.out.println("		STARTING PUBLISHER TARGETING TESTSUIT EXECUTION						 ");
				System.out.println("#############################################################################");

				// Result Location for Publisher Targeting
				System.out.println("Result location for Publisher targeting : " +TestSuiteClass.resultFileLocation);
				finalResultFileLocation = TestSuiteClass.resultFileLocation.concat("/Results_PublisherTargeting_TID9").toString();

				Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();
				String sqlQuery_Channel_WithRON = "select ch.apikey AS Channel_APIKEY, ch.id AS Channel_ID	,chs.additional_settings " +
						"AS Channel_Additional_Settings from channels ch INNER JOIN channel_settings chs ON ch.id = chs.channel_id " +
						"where ch.id=(select id from channels where name IN ('" + channelNameWithRON + "'));";
				String [][] recordOutput_WithRon = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlQuery_Channel_WithRON);

				dbCon =  MobileTestClass_Methods.CreateSQLConnection();
				String sqlQuery_Channel_WithoutRON = "select ch.apikey AS Channel_APIKEY, ch.id AS Channel_ID	,chs.additional_settings " +
						"AS Channel_Additional_Settings from channels ch INNER JOIN channel_settings chs ON ch.id = chs.channel_id " +
						"where ch.id=(select id from channels where name IN ('" + channelNameWithoutRON + "'));";
				String [][] recordOutput_WithoutRon = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlQuery_Channel_WithoutRON);

				dbCon =  MobileTestClass_Methods.CreateSQLConnection();
				String sqlQuery_Campaign = "select cam.id AS Campaign_ID, cam_m.ad_id AS ADS_ID, ad.ad_format AS Ad_Format,IFNULL(cam.custom_details,0) " +
						"AS Custom_Details, CEIL(IFNULL(a.duration,0)) AS Ads_Duration, IFNULL(a.dimension,0) AS Ads_Dimension, IFNULL(a.action_type,0) " +
						"AS Action_Type, cam.device As Device_Type, IFNULL(a.tracker_url,0) AS Tracker_URL from campaign cam " +
						"INNER JOIN campaign_members cam_m on cam.id = cam_m.cid INNER JOIN ads a ON a.id = cam_m.ad_id " +
						"INNER JOIN campaign_target camptar ON cam.id = camptar.cid INNER JOIN targeting t ON camptar.tid = t.id " +
						"INNER JOIN ads ad ON ad.id = cam_m.ad_id where cam.name = '" + CampaignName + "';";
				String [][] recordOutput_Campaign = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlQuery_Campaign);


				if(recordOutput_WithRon.length< 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For Sql Query with RON Setting. ********** ");
					System.out.println();
				}
				else if(recordOutput_WithoutRon.length < 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For Sql Query without RON Setting. ********** ");
					System.out.println();
				}
				else if(recordOutput_Campaign.length < 2 )
				{
					System.out.println();
					System.out.println("******** No Record Found For Sql Query for Campaign. ********** ");
					System.out.println();
				}
				else
				{
					String[][] recordOutput_Channel_WithRon = StringLib.MergeTwoArrayWithColumn(recordOutput_WithRon,recordOutput_Campaign);
					String[][] recordOutput_Channel_WithoutRon = StringLib.MergeTwoArrayWithColumn(recordOutput_WithoutRon,recordOutput_Campaign);

					String[][] recordOutput = StringLib.MergeTwoArrayWithRow(recordOutput_Channel_WithRon,recordOutput_Channel_WithoutRon);
					if(recordOutput.length< 2)
					{
						System.out.println();
						System.out.println("******** No Record Found For This Targeting. ********** ");
						System.out.println();
					}
					else
					{
						//Writing Test Data in Excel Sheet
						fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataPublisherTargeting_TID9.xls").toString();
						FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
						FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);

						System.out.println("Result location for Publisher targeting : " +TestSuiteClass.resultFileLocation);
						String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_PublisherTargeting_TID9").toString();
						testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
					}
				}
			}
			//Exceptions Handled
			catch (Exception e) 
			{
				System.out.println("Exception occured: " + e.getMessage());
			}
		}
		else
		{
			//Code For Rerun
			try {
				System.out.println("#############################################################################");
				System.out.println("		STARTING PUBLISHER TARGETING TESTSUIT RERUN EXECUTION						 ");
				System.out.println("#############################################################################");

				fileNameWithLocation = testDataFileLocation_ReRun;

				//Copy Test Data File In Test Result Folder	
				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_PublisherTargeting_TID26_ReRun").toString();
				testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
			} 
			catch (Exception e) 
			{
				System.out.println("Exception occured: " + e.getMessage());
			}
		}

		//Setting Up Delay for Banner and Non Banners
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());

	}

	// DataProvider Function to iterate over each row
	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{
		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "Test_URLs", "Campaign_ID", "Channel_ID","Ads_Duration", "Channel_Additional_Settings","Tracker_URL", "Destination_URL");
		return arrTestURL;	
	}

	//Function to Open browser, Serv Url and close Browser
	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{
		System.out.println("Now Browsing ad URL: " + adURL);
		driver.get(adURL);

		// Waiting for Ad Serv
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);	// Getting delay value from configuration File
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);
			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep(adWait*1000);	// Getting delay value from database in case of non-banner
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay); // Getting hard code delay value from config in case of non-banner
			}		
		}
		driver.quit();
	}


	// Identify Channel Ron Setting is true or false
	public Integer IdentifyChannelRONSetting(String channel_add_setting)
	{
		int ron_setting = 2;

		List<String> additionalsettings = Arrays.asList(channel_add_setting.split(","));

		for(int i=0; i<additionalsettings.size(); i++)
		{
			if (additionalsettings.get(i).toLowerCase().contains("\"run_untargeted\""))
			{
				List<String> list = Arrays.asList(additionalsettings.get(i).split(":"));
				if(list.get(1).equalsIgnoreCase("true"))
				{
					ron_setting = 1;	// RON Setting is True
				}
				else if(list.get(1).equalsIgnoreCase("false"))
				{
					ron_setting = 0;	// RON Setting is False
				}
				else
				{
					ron_setting =2;		// Unable to Find RON Setting in database
				}
				break;
			}
			else
			{
				ron_setting = 2;	// Unable to get run_untargeted value from database
			}
		}
		return ron_setting;
	}


	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServePublisherTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String expectedTrackerURLs, String destinationURL) 
	{	 
		System.out.println("************** Starting Test: " +" Mobile Publisher Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{
			if(adURL.matches("^http.*"))
			{
				String filterDetails = "";
				int ron_details = IdentifyChannelRONSetting(targetingDetail);	// RON Setting value

				if(ron_details < 2)
				{
					if(ron_details == 0)
					{
						filterDetails = "0";
						System.out.println("RON Setting is false");
					}
					else if(ron_details == 1)
					{
						filterDetails = "1";
						System.out.println("RON Setting is true");
					}
					String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
					System.out.println("Current Time: " +trackerStartTime);

					driver = MobileTestClass_Methods.WebDriverSetUp(Testbrowser,null);

					callDriver(driver, adURL, adFormat, adsDuration);
					String new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, filterDetails, result);

					result = result + new_result;

					System.out.println("Vdopia Tracker Result: " + result);

					//getting third party tracker counts
					result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTime, expectedTrackerURLs, destinationURL);

					System.out.println("FINAL Result: " +result);

					Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));
				}
				else
				{
					System.out.println("Unable to get RON Settings");
					Assert.assertTrue(result.matches("^PASS.*"));
				}
			}
			else
			{
				result = "NOT A VALID URL:";
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(NoClassDefFoundError e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println("This test case is stopped because of Null Pointer Exception. ");
			result = "FAIL" + result + "\n" + "FAIL - " + "This test case is failed becuase of Null Pointer Exception";
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception " + e.getMessage());
			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();
		}
		finally
		{
			resultsList.add(result);
		}
	}


	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "PublisherTarget";
			}
			else
			{
				resultSheetName = "PublisherTarget_ReRun";
			}
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList); 

			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				result.createReRunTestCase(testDataFileLocation_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of Publisher Targeting: " +e.getMessage());
		}
	}
}
