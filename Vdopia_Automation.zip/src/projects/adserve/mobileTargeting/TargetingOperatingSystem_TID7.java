/**
 * Last Changes Done on 5 Mar, 2015 12:07:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import projects.TestSuiteClass;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import vlib.Excel2Html;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import projects.adserve.mobileTargeting.lib.MobileAdvancedTargetingLib;

import com.mysql.jdbc.Connection;


public class TargetingOperatingSystem_TID7 
{
	WebDriver driver;
	File testResultFile;
	Connection serveConnection;
	List<String> resultsList = new ArrayList<String>();
	int bannerDelay;
	int nonBannerDelay;
	public static PropertiesConfiguration osConfigFile;
	String fileNameWithLocation;
	String webdriverBrowser;


	public static void osConfiguration()  
	{	
		try
		{
			osConfigFile = new PropertiesConfiguration();
			String varAutomationHome = TestSuiteClass.AUTOMATION_HOME;
			String osConf = varAutomationHome + "/conf/targetingOperatingSystem_TID7.conf";
			osConfigFile.load(osConf);
		}
		catch(Exception e)
		{
			System.out.println("Error Occured While Reading Mobile OS Config File, Ensure that Conf file is present at path " +TestSuiteClass.AUTOMATION_HOME+"/conf/targetingOperatingSystem_TID7.conf");
		}
	}


	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws RowsExceededException, WriteException, IOException, 
	SQLException, ClassNotFoundException, BiffException, InterruptedException 
	{
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			osConfiguration();

			if(TestSuiteClass.isFresh)
			{
				System.out.println();
				System.out.println("#############################################################################");
				System.out.println("		STARTING MOBILE OPERATING SYSTEM TARGETING TEST SUITE EXECUTION");
				System.out.println("#############################################################################");

				//Getting browser type.
				webdriverBrowser = browser;

				Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();

				String publisherEmail = MobileTestClass_Methods.propertyConfigFile.getProperty("publisherEmail").toString();

				publisherEmail = publisherEmail.replace("[", "");
				publisherEmail = publisherEmail.replace("]", "");

				//Getting query to get targeted data
				String sqlSelectQuery = MobileAdvancedTargetingLib.MySQLQueryForAdvancedTargeting(publisherEmail, "7");
				String [][] recordOutput = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlSelectQuery);

				if(recordOutput.length< 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For This Targeting. ********** ");
					System.out.println();
				}
				else
				{
					//Writing Test Data in Excel Sheet
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataMobileOSTargeting_TID7.xls").toString();
					FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
					FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);

					System.out.println("Result location for Mobile OS targeting : " +TestSuiteClass.resultFileLocation);

					String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_MobileOSTargeting_TID7").toString();
					testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
				}
			}
			else
			{
				System.out.println("#############################################################################");
				System.out.println("		STARTING MOBILE OPERATING SYSTEM TARGETING TESTSUIT RERUN EXECUTION");
				System.out.println("#############################################################################");

				fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataMobileOSTargeting_TID7_ReRun.xls").toString();
				//Copy Test Data File In Test Result Folder	
				String sourceFileNameWithLocation = fileNameWithLocation;
				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_MobileOSTargeting_TID7_ReRun").toString();
				testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);
			}
			//Setting Up Delay for Banner and Non Banners
			bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
			nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured while getting test data from db. " +e.getMessage());
		}
	}


	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{

		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "Test_URLs", "Campaign_ID", "Channel_ID","Ads_Duration", "targetingDetail", "filterDetail", "Tracker_URL", "Destination_URL");

		return arrTestURL;	

	}


	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{
		System.out.println("Now Browsing ad URL: " + adURL);

		driver.get(adURL);

		//Stopping Execution Thread Based On Ad Duration Fetched From Db, if its 0 then setting value from configuration
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);

			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep(adWait*1000);
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay);
			}		
		}

		driver.quit();
	}


	//@Parameters("browser")
	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServeOSTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String filterDetail, String expectedTrackerURLs, String destinationURL)
	{	 
		System.out.println("************** Starting Test: " +" Mobile OS Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{

			if(adURL.matches("^http.*"))
			{
				String trackerStartTime = "";

				String[] OSs = StringLib.StrSplit(targetingDetail, ",");	
				for(String OS: OSs)
				{
					System.out.println("Targeted OS: " +OS);

					String UserAgent = GetOSUserAgent(OS);

					System.out.println("SETTING USER Agent : " + UserAgent);
					String[] capabilities = {"--user-agent="+UserAgent, "--start-maximized"};

					//find current time
					trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
					System.out.println("Tracker Start Time: " +trackerStartTime);

					driver = MobileTestClass_Methods.WebDriverSetUp(webdriverBrowser, capabilities);
					callDriver(driver, adURL, adFormat, adsDuration);

					result = result + OS + ":";
					String new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, filterDetail, result);	//"2014-01-15 10:00:34"

					System.out.println("New Result: " + new_result);

					result = result + new_result;

					System.out.println("Result: " + result);

				}

				//getting third party tracker counts
				result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTime, expectedTrackerURLs, destinationURL);

				System.out.println("FINAL Result: " +result);

				Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));
			}

			else
			{
				result = "NOT A VALID URL:";
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(NoClassDefFoundError e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println("This test case is stopped because of Null Pointer Exception. ");
			result = "FAIL" + result + "\n" + "FAIL - " + "This test case is failed becuase of Null Pointer Exception";
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception " + e.getMessage());
			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();
		}
		finally
		{
			resultsList.add(result);
		}
	}



	public static String GetOSUserAgent(String osType)
	{	
		String UserAgent = "";

		if(osType.toLowerCase().matches("^android.*"))
		{
			UserAgent = osConfigFile.getProperty("Android").toString();
		}
		else if(osType.toLowerCase().matches("^iphone.*"))
		{
			UserAgent = osConfigFile.getProperty("iPhone").toString();
		}
		else if(osType.toLowerCase().matches("^bada.*"))
		{
			UserAgent = osConfigFile.getProperty("Bada").toString();
		}
		else if(osType.toLowerCase().matches("^rim.*"))
		{
			UserAgent = osConfigFile.getProperty("RIM").toString();
		}
		else if(osType.toLowerCase().matches("^symbian.*"))
		{
			UserAgent = osConfigFile.getProperty("Symbian").toString();
		}
		else if(osType.toLowerCase().matches("^windows.*"))
		{
			UserAgent = osConfigFile.getProperty("Windows_Mobile").toString();
		}
		else
		{
			UserAgent = osConfigFile.getProperty("Other").toString();
		}
		
		//Replace [ ] bracket if there any
		if(UserAgent.startsWith("["))
		{
			UserAgent = UserAgent.substring(1,UserAgent.length());
		}
		if(UserAgent.endsWith("]"))
		{
			UserAgent = UserAgent.substring(0,UserAgent.length()-1);
		}
		
		System.out.println("Setting up User Agent for OS Type: "+osType);
		System.out.println("Setting up User Agent as: "+UserAgent);

		return UserAgent;
	}



	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "MobileOSTarg";
			}
			else
			{
				resultSheetName = "MobileOSTarg_ReRun";
			}

			// For Total test cases need to be run
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList);
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				String testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataMobileOSTargeting_TID7_ReRun.xls").toString();
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of Mobile OS Targeting: " +e.getMessage());
		}
	}


}
