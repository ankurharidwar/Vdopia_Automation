/**
 * Last Changes Done on 5 Mar, 2015 12:07:51 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import projects.TestSuiteClass;
import vlib.Excel2Html;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import java.util.Properties;

import projects.adserve.mobileTargeting.lib.MobileAdvancedTargetingLib;


public class TargetingKeyword_TID24 {

	WebDriver driver;
	File testResultFile;
	Connection serveConnection;
	List<String> resultsList = new ArrayList<String>();
	int bannerDelay;
	int nonBannerDelay;
	public static Properties LangConfigFile;
	String fileNameWithLocation;
	String webdriverBrowser;

	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws RowsExceededException, WriteException, IOException, 
	SQLException, ClassNotFoundException, BiffException, InterruptedException 
	{
		MobileTestClass_Methods.InitializeConfiguration();

		if(TestSuiteClass.isFresh)
		{
			System.out.println();
			System.out.println("#############################################################################");
			System.out.println("		STARTING MOBILE KEYWORD TARGETING TEST SUITE EXECUTION");
			System.out.println("#############################################################################");

			//Getting browser type.
			webdriverBrowser = browser;

			Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();

			String publisherEmail = MobileTestClass_Methods.propertyConfigFile.getProperty("publisherEmail").toString();

			publisherEmail = publisherEmail.replace("[", "");
			publisherEmail = publisherEmail.replace("]", "");

			//Getting query to get targeted data
			String sqlSelectQuery = MobileAdvancedTargetingLib.MySQLQueryForAdvancedTargeting(publisherEmail, "24");

			try
			{
				String [][] recordOutput = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlSelectQuery);

				if(recordOutput.length< 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For This Targeting. ********** ");
					System.out.println();
				}
				else
				{	
					//Writing Test Data in Excel Sheet
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataKeywordTargeting_TID24.xls").toString();
					FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
					FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);

					//Write Test URL to browse HTML pages to test Adult Targeting 
					FileLib.WritingTestURLForTargeting(fileNameWithLocation,"Keyword");


					//****************** Creating HTML Test Files *******************************************
					//Reading Server Login Information From Config 
					String host = MobileTestClass_Methods.propertyConfigFile.getProperty("server").toString();
					String userName = MobileTestClass_Methods.propertyConfigFile.getProperty("serverUserName").toString();
					String password = MobileTestClass_Methods.propertyConfigFile.getProperty("serverPassword").toString();

					Session session = ExecuteCommands.createSessionWithPassword(userName, password, host);	//Create Session With Host - qa.vdopia.com



					String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Channel_APIKEY", "Test_URLs", "URL_KEYWORDHTMLPage","targetingDetail");

					int fileCount = 0;	//This Counter will be used to count how many files were written and transferred to server. 
					for (int i=0; i<arrTestURL.length; i++)
					{	
						//In Case Excel Sheet Has Data For Mobile and Online, Then Use Only Online Data 
						if(arrTestURL[i][1].matches("^http.*"))
						{
							String serveURL = arrTestURL[i][1].toString();	//Getting Serve URL
							String content = arrTestURL[i][3].toString();

							String strContent = StringLib.BuildStringForKeywordTargeting(serveURL,content);	//Building HTML Content

							String keywordUrl = arrTestURL[i][2].toString();			//Getting Online Test URL

							String fileName = StringLib.splitFileNameFromURL(keywordUrl);	//Splitting File Name from Test URL, If File Name Is Not Empty Then Execute Below Command	

							if (!(fileName.isEmpty()))
							{	
								ExecuteCommands.ExecuteCommandUsingJsch(session, "echo " + "\""+ strContent + "\"" + " > /mnt/qa/QAAutomation/KeywordTargeting/" + fileName );		//Writing File In Server
								fileCount ++;		//Incrementing File Counter To Record Count Of Files Being Written & Sent To Server.
							}
						}
					}

					ExecuteCommands.EndSession(session);		//Terminating connection with server

					System.out.println();
					System.out.println("TOTAL NUMBER OF HTML FILES SENT TO SERVER: " +fileCount);

					//***************************************************************************************
				}
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println("No Records To Write");
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured while while fetching records from My SQL Db. "+e.getMessage());
			}

			System.out.println("Result location for Keyword targeting : " +TestSuiteClass.resultFileLocation);
			String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_KeywordTargeting_TID24").toString();

			testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
		}
		else
		{
			System.out.println("#############################################################################");
			System.out.println("		STARTING MOBILE KEYWORD TARGETING TEST SUITE RERUN EXECUTION");
			System.out.println("#############################################################################");

			fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataKeywordTargeting_TID24_ReRun.xls").toString();
			//Copy Test Data File In Test Result Folder	
			String sourceFileNameWithLocation = fileNameWithLocation;
			String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_KeywordTargeting_TID24_ReRun").toString();
			testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);
		}

		//Setting Up Delay for Banner and Non Banners
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());

	}


	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{

		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "URL_KEYWORDHTMLPage", "Campaign_ID", "Channel_ID","Ads_Duration", "targetingDetail", "filterDetail", "Tracker_URL", "Destination_URL");

		return arrTestURL;	

	}


	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{

		System.out.println("Now Browsing ad URL: " + adURL);
		driver.get(adURL);

		//Stopping Execution Thread Based On Ad Duration Fetched From Db, if its 0 then setting value from configuration
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);

			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep((adWait+3)*1000);
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay);
			}		
		}

		driver.quit();
	}


	//@Parameters("browser")
	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServeLanguageTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String filterDetail, String expectedTrackerURLs, String destinationURL)  
	{	 
		System.out.println();
		System.out.println("************** Starting Test: " +" Mobile Keyword Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{
			if(adURL.matches("^http.*"))
			{
				//find current time
				String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
				System.out.println("Current Time: " +trackerStartTime);

				driver = MobileTestClass_Methods.WebDriverSetUp(webdriverBrowser,null);
				callDriver(driver, adURL, adFormat, adsDuration);
				String new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, filterDetail, result);
				result = result + new_result;
				System.out.println("Vdopia Tracker Result: " + result);

				//Getting third party tracker counts
				result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTime, expectedTrackerURLs, destinationURL);
				System.out.println("FINAL Result: " +result);
				Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));	
			}
			else
			{
				result = "NOT A VALID URL:";
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(NoClassDefFoundError e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println("This test case is stopped because of Null Pointer Exception. ");
			result = "FAIL" + result + "\n" + "FAIL - " + "This test case is failed becuase of Null Pointer Exception";
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception " + e.getMessage());
			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();
		}
		finally
		{
			resultsList.add(result);
		}
	}


	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "KeywordTargeting";
			}
			else
			{
				resultSheetName = "KeywordTargeting_ReRun";
			}
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList); 

			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				String testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataKeywordTargeting_TID24_ReRun.xls").toString();
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of Keyword Targeting: " +e.getMessage());
		}
	}

}
