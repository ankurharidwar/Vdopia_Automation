/**
 * Last Changes Done on 5 Mar, 2015 12:07:48 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting.lib;

import org.apache.commons.configuration.PropertiesConfiguration;

public class MobileAdvancedTargetingLib 
{


	//This method will return the query according to applicable targeting
	public static String MySQLQueryForAdvancedTargeting(String publisherEmail, String targetingID)
	{
		String sqlSelectQuery = 
				"SELECT pub.email AS Publisher_Email, cam.name AS Campaign_Name, ch.apikey AS Channel_APIKEY, " + 
						" ch.publisher_id AS Publisher_ID, ch.id AS Channel_ID, cam.id AS Campaign_ID, " + 
						" ad.id AS ADS_ID, IFNULL(cam.video_choice,0) AS Video_Choice, IFNULL(cam.custom_details,0) AS Custom_Details, " + 
						" ad.ad_format AS Ad_Format, CEIL(IFNULL(ad.duration,0)) AS Ads_Duration, IFNULL(ad.dimension,0) AS Ads_Dimension, IFNULL(ad.tracker_url,0) AS Tracker_URL, IFNULL(ad.action_type,0) AS Action_Type, " + 
						" camptar.tid AS targetID, camptar.options AS targetingDetail, " + 
						" camptar.useoptions AS filterDetail, t.name AS TargetName, cam.device As Device_Type " + 
						" FROM channels ch INNER JOIN publisher pub ON ch.publisher_id = pub.id " + 
						" INNER JOIN campaign cam ON ch.id = cam.channel_choice " + 
						" INNER JOIN campaign_members camb ON cam.id = camb.cid " + 
						" INNER JOIN ads ad ON ad.id = camb.ad_id " + 
						" INNER JOIN campaign_target camptar ON cam.id = camptar.cid " + 
						" INNER JOIN targeting t ON camptar.tid = t.id " + 
						" AND camb.status = 'enabled' AND cam.status = 'active' AND cam.validto > CURDATE() AND pub.email in ("+ publisherEmail + " ) " +
						" AND cam.device in ('iphone') AND t.id = "+ targetingID +
						" AND camptar.cid NOT IN (SELECT cid FROM campaign_target GROUP BY cid HAVING COUNT(cid) > 1) " +
						" ORDER BY cam.id ASC; ";

		System.out.println("Executing Query To Get The Targeted Data : " + "\n" + sqlSelectQuery);

		return sqlSelectQuery;
	}


	public static String GetValueFromConfigFile(PropertiesConfiguration osConfigFile, String OS)
	{
		String UserAgent = osConfigFile.getProperty(OS).toString();
		if(UserAgent.startsWith("["))
		{
			UserAgent = UserAgent.substring(1,UserAgent.length());
		}
		if(UserAgent.endsWith("]"))
		{
			UserAgent = UserAgent.substring(0,UserAgent.length()-1);
		}
		return UserAgent;
	}

	//	public static void main(String[] args) throws ConfigurationException 
	//	{
	//		PropertiesConfiguration osConfigFile = new PropertiesConfiguration();
	//		String osConf = "/Users/user/Desktop/work/qascripting/Vdopia_Automation/conf/targetingOSVersion_TID3.conf";
	//		osConfigFile.load(osConf);
	//		String abc = GetValueFromConfigFile(osConfigFile,"A_1.5");
	//		System.out.println(abc);
	//	}
}
