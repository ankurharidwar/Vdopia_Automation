/**
 * Last Changes Done on 5 Mar, 2015 12:07:44 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import vlib.Excel2Html;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import projects.adserve.mobileTargeting.lib.MobileAdvancedTargetingLib;

import com.maxmind.geoip.Location;
import com.maxmind.geoip.LookupService;
import com.mysql.jdbc.Connection;
import projects.TestSuiteClass;

public class TargetingLocation_TID22 
{
	String Testbrowser;
	String fileNameWithLocation;
	File testResultFile;
	String testdataFile_Rerun;
	int bannerDelay;
	int nonBannerDelay;
	WebDriver driver;
	List<String> resultsList = new ArrayList<String>();

	// Before Class to create Test Data For Fresh Run and get testdata file location in case of rerun
	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws SQLException, ClassNotFoundException, RowsExceededException, WriteException, IOException, BiffException
	{
		//Get Browser name from testng File
		Testbrowser = browser;

		//Initializing testdata file location for ReRun
		testdataFile_Rerun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataLocationTargeting_TID22_ReRun.xls").toString();

		//Initialize Configuration
		MobileTestClass_Methods.InitializeConfiguration();

		//For Fresh Run
		if(TestSuiteClass.isFresh)
		{
			System.out.println("#############################################################################");
			System.out.println("		STARTING LOCATION TARGETING TESTSUIT EXECUTION");
			System.out.println("#############################################################################");

			Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();

			String publisherEmail = MobileTestClass_Methods.propertyConfigFile.getProperty("publisherEmail").toString();

			publisherEmail = publisherEmail.replace("[", "");
			publisherEmail = publisherEmail.replace("]", "");

			//Getting query to get targeted data
			String sqlSelectQuery = MobileAdvancedTargetingLib.MySQLQueryForAdvancedTargeting(publisherEmail, "22");

			String [][] recordOutput = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlSelectQuery);

			if(recordOutput.length< 2)
			{
				System.out.println();
				System.out.println("******** No Record Found For This Targeting. ********** ");
				System.out.println();
			}
			else
			{	

				//Writing Test Data in Excel Sheet
				fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataLocationTargeting_TID22.xls").toString();
				FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
				FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);

				System.out.println("Result location for Location targeting : " +TestSuiteClass.resultFileLocation);

				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_LocationTargeting_TID22").toString();
				testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
			}
		}
		else
		{
			System.out.println("#############################################################################");
			System.out.println("		STARTING LOCATION TARGETING TESTSUIT RERUN EXECUTION");
			System.out.println("#############################################################################");

			fileNameWithLocation = testdataFile_Rerun;
			//Copy Test Data File In Test Result Folder	
			String sourceFileNameWithLocation = fileNameWithLocation;
			String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_LocationTargeting_TID22_ReRun").toString();
			testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);
		}
		//Setting Up Delay for Banner and Non Banners
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
	}


	//Data Provider Function to get Test Data From Excel File
	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{
		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "Test_URLs", "Campaign_ID", "Channel_ID","Ads_Duration", "targetingDetail", "filterDetail", "Tracker_URL", "Destination_URL");
		return arrTestURL;	
	}

	// Call Driver function to Open Browser, Serv Url, wait for given time and then close the browser
	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{
		System.out.println("Now Browsing ad URL: " + adURL);
		driver.get(adURL);

		//Stopping Execution Thread Based On Ad Duration Fetched From Db, if its 0 then setting value from configuration
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);
			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep(adWait);
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay);
			}		
		}
		driver.quit();
	}


	// Get Internet Service Provider Name.
	public String GetLocationDetails() throws IOException
	{
		Location getLocation;
		String returnString = "";
		try
		{
			URL connection = new URL("http://checkip.amazonaws.com/");			//wgetip.com
			URLConnection con = connection.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String publicIp = reader.readLine();
			String geoIPCity_datFile = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/GeoIP/GeoIPCity.dat");
			LookupService isp = new LookupService(geoIPCity_datFile);
			getLocation = isp.getLocation(publicIp);
			isp.close();
			returnString = getLocation.latitude + "," + getLocation.longitude;
		}
		catch (MalformedURLException e) 
		{
			System.out.println("MalformedURLException occured in getting ISP Details: " + e.getMessage());
		}		
		catch (IOException e) 
		{
			System.out.println("IOException occured in getting ISP Details: " + e.getMessage());
		}
		return returnString;
	}


	// Actual test case Flow
	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServeLocationTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String filterDetail,String expectedTrackerURLs, String destinationURL) throws 
	RowsExceededException, WriteException, BiffException, IOException, InterruptedException, SQLException,
	ClassNotFoundException 
	{	 
		System.out.println("************** Starting Test: " +" Location Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{
			if(adURL.matches("^http.*"))
			{
				String locationDetails = "";
				locationDetails = GetLocationDetails();

				if(locationDetails.equalsIgnoreCase(""))
				{
					result = "UNABLE TO GET LOCATION DETAILS:";
					Assert.assertTrue(result.matches("^PASS.*"));
				}
				else
				{
					String new_result = "";
					
					float currentLatitude = Float.parseFloat(locationDetails.split(",")[0]);
					float currentLongitude = Float.parseFloat(locationDetails.split(",")[1]);
					float minimumLongitude = Float.parseFloat(targetingDetail.split(",")[0]);
					float minimumLatitude = Float.parseFloat(targetingDetail.split(",")[1]);
					float maximumLongitude = Float.parseFloat(targetingDetail.split(",")[2]);
					float maximumLatitude = Float.parseFloat(targetingDetail.split(",")[3]);
					
					//find current time
					String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
					System.out.println("Current Time: " +trackerStartTime);

					driver = MobileTestClass_Methods.WebDriverSetUp(Testbrowser,null);
					callDriver(driver, adURL, adFormat, adsDuration);

					if(minimumLatitude <= currentLatitude && currentLatitude <= maximumLatitude && minimumLongitude <= currentLongitude && currentLongitude <= maximumLongitude)
					{
						new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, filterDetail, result);
					}
					else
					{
						String filterDetails_Final = "";
						if(filterDetail.equalsIgnoreCase("1"))
						{
							filterDetails_Final = "0";
						}
						else
						{
							filterDetails_Final = "1";
						}
						new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, filterDetails_Final, result);
					}

					result = result + new_result;

					System.out.println("Vdopia Tracker Result: " + result);

					//getting third party tracker counts
					result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTime, expectedTrackerURLs, destinationURL);

					System.out.println("FINAL Result: " +result);

					Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));
				}
			}
			else
			{
				result = "NOT A VALID URL:";
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(NoClassDefFoundError e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println("This test case is stopped because of Null Pointer Exception. ");
			result = "FAIL" + result + "\n" + "FAIL - " + "This test case is failed becuase of Null Pointer Exception";
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception " + e.getMessage());
			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();
		}
		finally
		{
			resultsList.add(result);
		}
	}


	// After Class to Write Result for test execution
	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "LocationTarg";
			}
			else
			{
				resultSheetName = "LocationTarg_ReRun";
			}

			// For Total test cases need to be run
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList);
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				result.createReRunTestCase(testdataFile_Rerun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of Location Targeting: " +e.getMessage());
		}
	}
}
