/**
 * Last Changes Done on 5 Mar, 2015 12:07:46 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import java.util.Date;

//import org.apache.commons.configuration.ConfigurationException;
//import org.apache.commons.configuration.PropertiesConfiguration;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

//import org.testng.annotations.AfterTest;


import projects.adserve.mobileTargeting.lib.MobileAdvancedTargetingLib;

import vlib.Excel2Html;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import com.mysql.jdbc.Connection;
import projects.TestSuiteClass;


public class TargetingWeekday_TID2 {

	WebDriver driver;
	File testResultFile;
	Connection serveConnection;
	List<String> resultsList = new ArrayList<String>();
	int bannerDelay;
	int nonBannerDelay;
	String fileNameWithLocation;
	String Testbrowser;
	String testDataFile_ReRun;

	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws RowsExceededException, WriteException, IOException, 
	SQLException, ClassNotFoundException, BiffException, InterruptedException 
	{
		//Get Browser name from testng File
		Testbrowser = browser;
		//Initializing testdata file location for ReRun
		testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataWeekdayTargeting_TID2_ReRun.xls").toString();

		try
		{
			MobileTestClass_Methods.InitializeConfiguration();

			if(TestSuiteClass.isFresh)
			{
				System.out.println();
				System.out.println("#############################################################################");
				System.out.println("		STARTING MOBILE WEEKDAY TARGETING TESTSUIT EXECUTION");
				System.out.println("#############################################################################");

				Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();
				String publisherEmail = MobileTestClass_Methods.propertyConfigFile.getProperty("publisherEmail").toString();

				//replacing [] - which is coming from config file 
				publisherEmail = publisherEmail.replace("[", "");
				publisherEmail = publisherEmail.replace("]", "");

				//Getting query to get targeted data
				String sqlSelectQuery = MobileAdvancedTargetingLib.MySQLQueryForAdvancedTargeting(publisherEmail, "2");
				String [][] recordOutput = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlSelectQuery);

				if(recordOutput.length< 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For This Targeting. ********** ");
					System.out.println();
				}
				else
				{
					//Writing Test Data in Excel Sheet
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataWeekdayTargeting_TID2.xls").toString();
					FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
					FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);
					System.out.println("Result location for weekday targeting : " +TestSuiteClass.resultFileLocation);
					String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation + "/Results_WeekdayTargeting_TID2";
					testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
				}
			}
			else
			{
				System.out.println("#############################################################################");
				System.out.println("		STARTING MOBILE WEEKDAY TARGETING TESTSUIT RERUN EXECUTION");
				System.out.println("#############################################################################");

				fileNameWithLocation = testDataFile_ReRun;
				//Copy Test Data File In Test Result Folder	
				String sourceFileNameWithLocation = fileNameWithLocation;
				String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_WeekdayTargeting_TID2_ReRun").toString();
				testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);
			}

			//Setting Up Delay for Banner and Non Banners
			bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
			nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
		}
		catch(Exception e)
		{
			System.out.println("Exception occured while getting test data from db. " +e.getMessage());
		}
	}


	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{
		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "Test_URLs", "Campaign_ID", "Channel_ID","Ads_Duration", "targetingDetail", "filterDetail", "Tracker_URL", "Destination_URL");
		return arrTestURL;	
	}


	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{
		System.out.println("Now Browsing ad URL: " + adURL);
		driver.get(adURL);

		//Stopping Execution Thread Based On Ad Duration Fetched From Db, if its 0 then setting value from configuration
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);

			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep(adWait*1000);
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay);
			}		
		}
		driver.quit();
	}


	//@Parameters("browser")
	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServeWeekdayTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String filterDetail, String expectedTrackerURLs, String destinationURL) 
	{	 
		System.out.println("************** Starting Test: " +" Mobile Weekday Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{
			String DayfilterDetail = null;

			if(adURL.matches("^http.*"))
			{
				Date now = new Date();  

				SimpleDateFormat Dayformat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely  
				String Day = Dayformat.format(now);
				System.out.println("Filter is applied on days : " + targetingDetail);
				System.out.println("Today day is : " + Day);


				if(StringLib.Strexist(targetingDetail.toLowerCase(), Day.toLowerCase()) == true)
				{

					DayfilterDetail = filterDetail;
				}
				else
				{

					if (Integer.parseInt(filterDetail) == 1)
					{
						DayfilterDetail = "0";

					}
					else
					{
						DayfilterDetail = "1";
					}
				}
				System.out.println("Filter detail for this Test " + DayfilterDetail);
				//find current time
				String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
				System.out.println("Tracker Start Time: " +trackerStartTime);

				driver = MobileTestClass_Methods.WebDriverSetUp(Testbrowser,null);
				callDriver(driver, adURL, adFormat, adsDuration);

				result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTime, DayfilterDetail, result);	//"2014-01-15 10:00:34"

				//getting third party tracker counts
				result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTime, expectedTrackerURLs, destinationURL);

				//resultsList.add(result);
				Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));
			}
			else
			{

				result = "NOT A VALID URL:";
				//resultsList.add("EITHER TEST URL DOESN'T START WITH HTTP OR INVALID FOR MOBILE:");
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(NoClassDefFoundError e)
		{
			System.out.println(e.getMessage());
		}
		catch(NullPointerException e)
		{
			System.out.println("This test case is stopped because of Null Pointer Exception. ");
			result = "FAIL" + result + "\n" + "FAIL - " + "This test case is failed becuase of Null Pointer Exception";
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception " + e.getMessage());
			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();
		}
		finally
		{
			resultsList.add(result);
		}

	}


	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "MobileWeekdayTarg";
			}
			else
			{
				resultSheetName = "MobileWeekdayTarg_ReRun";
			}
			// For Total test cases need to be run
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList); 
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of WeekDay Targeting: " +e.getMessage());
		}
	}
}
