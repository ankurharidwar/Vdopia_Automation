/**
 * Last Changes Done on 5 Mar, 2015 12:07:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileTargeting;


import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

//import org.apache.commons.configuration.ConfigurationException;
//import org.apache.commons.configuration.PropertiesConfiguration;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import vlib.Excel2Html;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.XlsLib;

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import projects.TestSuiteClass;
import java.util.Properties;

import projects.adserve.mobileTargeting.lib.MobileAdvancedTargetingLib;


public class TargetingAdultContent_TID23 {

	WebDriver driver;
	File testResultFile;
	Connection serveConnection;
	List<String> resultsList = new ArrayList<String>();
	int bannerDelay;
	int nonBannerDelay;
	public static Properties LangConfigFile;
	String fileNameWithLocation;
	String webdriverBrowser;

	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws RowsExceededException, WriteException, IOException, 
	SQLException, ClassNotFoundException, BiffException, InterruptedException 
	{
		MobileTestClass_Methods.InitializeConfiguration();

		if(TestSuiteClass.isFresh)
		{
			System.out.println();
			System.out.println("#############################################################################");
			System.out.println("		STARTING MOBILE ADULT CONTENT TARGETING TEST SUITE EXECUTION");
			System.out.println("#############################################################################");

			//Getting browser type.
			webdriverBrowser = browser;

			Connection dbCon =  MobileTestClass_Methods.CreateSQLConnection();

			String publisherEmail = MobileTestClass_Methods.propertyConfigFile.getProperty("publisherEmail").toString();

			publisherEmail = publisherEmail.replace("[", "");
			publisherEmail = publisherEmail.replace("]", "");

			//Getting query to get targeted data
			String sqlSelectQuery = MobileAdvancedTargetingLib.MySQLQueryForAdvancedTargeting(publisherEmail, "23");

			try
			{
				String [][] recordOutput = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArrayWithColumnName(dbCon, sqlSelectQuery);

				if(recordOutput.length< 2)
				{
					System.out.println();
					System.out.println("******** No Record Found For This Targeting. ********** ");
					System.out.println();
				}
				else
				{	
					//Writing Test Data in Excel Sheet
					fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataAdultTargeting_TID23.xls").toString();
					FileLib.WritingMySQLRecordsInExcelSheet(fileNameWithLocation, recordOutput);
					FileLib.WritingTestURLInExcelSheet(fileNameWithLocation);

					//Write Test URL to browse HTML pages to test Adult Targeting 
					FileLib.WritingTestURLForTargeting(fileNameWithLocation,"AdultContent");


					//****************** Creating HTML Test Files *******************************************
					//Reading Server Login Information From Config 
					String host = MobileTestClass_Methods.propertyConfigFile.getProperty("server").toString();
					String userName = MobileTestClass_Methods.propertyConfigFile.getProperty("serverUserName").toString();
					String password = MobileTestClass_Methods.propertyConfigFile.getProperty("serverPassword").toString();

					Session session = ExecuteCommands.createSessionWithPassword(userName, password, host);	//Create Session With Host - qa.vdopia.com


					String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Channel_APIKEY", "Test_URLs", "URL_AdultContentHTMLPage");

					int fileCount = 0;	//This Counter will be used to count how many files were written and transferred to server. 
					for (int i=0; i<arrTestURL.length; i++)
					{	
						//In Case Excel Sheet Has Data For Mobile and Online, Then Use Only Online Data 
						if(arrTestURL[i][1].matches("^http.*"))
						{
							String serveURL = arrTestURL[i][1].toString();	//Getting Serve URL

							String strContent = StringLib.BuildStringForAdultContentTargeting(serveURL);	//Building HTML Content

							String adultContentUrl = arrTestURL[i][2].toString();			//Getting Online Test URL

							String fileName = StringLib.splitFileNameFromURL(adultContentUrl);	//Splitting File Name from Test URL, If File Name Is Not Empty Then Execute Below Command	

							if (!(fileName.isEmpty()))
							{	
								ExecuteCommands.ExecuteCommandUsingJsch(session, "echo " + "\""+ strContent + "\"" + " > /mnt/qa/QAAutomation/AdultContentTargeting/" + fileName );		//Writing File In Server
								fileCount ++;		//Incrementing File Counter To Record Count Of Files Being Written & Sent To Server.
							}
						}
					}

					ExecuteCommands.EndSession(session);		//Terminating connection with server

					System.out.println();
					System.out.println("TOTAL NUMBER OF HTML FILES SENT TO SERVER: " +fileCount);

					//***************************************************************************************
				}
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println("No Records To Write");
			}
			catch (Exception e) 
			{
				System.out.println("Exception occured while while fetching records from My SQL Db. "+e.getMessage());
			}

			//String destinationFileLocationWithOutExtension = TestSuiteClass.AUTOMATION_HOME.concat("/results/adserve/targeting/Test_Results/").concat("TestDataLanguageTargeting_TID26").toString();
			System.out.println("Result location for Language targeting : " +TestSuiteClass.resultFileLocation);
			String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_AdultTargeting_TID23").toString();

			testResultFile = FileLib.CopyExcelFile(fileNameWithLocation, destinationFileLocationWithOutExtension);
		}
		else
		{
			System.out.println("#############################################################################");
			System.out.println("		STARTING MOBILE ADULT CONTENT TARGETING TEST SUITE RERUN EXECUTION");
			System.out.println("#############################################################################");

			fileNameWithLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataAdultTargeting_TID23_ReRun.xls").toString();
			//Copy Test Data File In Test Result Folder	
			String sourceFileNameWithLocation = fileNameWithLocation;
			String destinationFileLocationWithOutExtension = TestSuiteClass.resultFileLocation.concat("/Results_AdultTargeting_TID23_ReRun").toString();
			testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);
		}



		//Setting Up Delay for Banner and Non Banners
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());

	}


	@DataProvider(name="FetchTestURLs")
	public String[][] testURL() throws RowsExceededException, WriteException, BiffException, IOException
	{

		String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(fileNameWithLocation, "Ad_Format", "URL_AdultContentHTMLPage", "Campaign_ID", "Channel_ID","Ads_Duration", "targetingDetail", "filterDetail", "Tracker_URL", "Destination_URL");

		return arrTestURL;	

	}


	public void callDriver(WebDriver driver,String adURL, String adFormat, String adsDuration) throws InterruptedException
	{
		//Adding an adult word in the end of the url to check adult content targeting
		adURL = adURL + "?seduction";

		System.out.println("Now Browsing ad URL: " + adURL);
		driver.get(adURL);

		//Stopping Execution Thread Based On Ad Duration Fetched From Db, if its 0 then setting value from configuration
		if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("appinterstitial")  
				|| adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter"))
		{
			System.out.println("Sleeping Thread for: " +bannerDelay +" seconds");
			Thread.sleep(bannerDelay);
		}
		else 
		{
			int adWait = Integer.parseInt(adsDuration);

			if(adWait > 0)
			{
				System.out.println("Sleeping Thread for: " +adWait +" seconds");
				Thread.sleep((adWait+3)*1000);
			}
			else
			{
				System.out.println("Sleeping Thread for: " +nonBannerDelay +" seconds");
				Thread.sleep(nonBannerDelay);
			}		
		}

		driver.quit();
	}


	//@Parameters("browser")
	@Test(dataProvider = "FetchTestURLs")
	public void MobileAdServeLanguageTargetingTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String targetingDetail, String filterDetail, String expectedTrackerURLs, String destinationURL) throws 
	RowsExceededException, WriteException, BiffException, IOException, InterruptedException, SQLException,
	ClassNotFoundException 
	{	 
		System.out.println();
		System.out.println("************** Starting Test: " +" Mobile Adult Content Targeting   ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
		System.out.println();

		String result = "";
		try
		{
			if(adURL.matches("^http.*"))
			{
				String trackerStartTimeForDesktop = "";

				if(targetingDetail.equalsIgnoreCase("Not Allowed"))
				{
					//find current time
					trackerStartTimeForDesktop = MobileTestClass_Methods.GetCurrentDBTime();
					System.out.println("Tracker Start Time: " +trackerStartTimeForDesktop);

					driver = MobileTestClass_Methods.WebDriverSetUp(webdriverBrowser, null);
					callDriver(driver, adURL, adFormat, adsDuration);

					String new_result = MobileTestClass_Methods.MobileAds_VdopiaTargetingTrackerValidation(adFormat, campaignID, channelID, trackerStartTimeForDesktop, filterDetail, result);	//"2014-01-15 10:00:34"

					result = result + new_result;

					System.out.println("Vdopia Tracker Result: " + result);

					//getting third party tracker counts
					result = "Vdopia Tracker: "+ "\n" + result + "\n" + "Third Party Tracker: "+ "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTimeForDesktop, expectedTrackerURLs, destinationURL);

					System.out.println("FINAL Result: " +result);

					Assert.assertEquals(false, StringLib.Strexist(result, "FAIL"));
				}
				else
				{
					result = "Adult Content Targeting is not applied to this campaign. ";
				}
			}
			else
			{
				result = "NOT A VALID URL:";
				Assert.assertTrue(result.matches("^PASS.*"));
			}
		}
		catch(Exception e)
		{
			System.out.println("This test case is stopped because of exception. " + e.getMessage());
			result = "FAIL:" + "\n" + "This test case is stopped because of exception. ";
			System.out.println(e.getMessage());
		}
		finally
		{
			resultsList.add(result);
		}


	}


	@AfterClass
	public void afterTest() throws RowsExceededException, WriteException, BiffException, IOException, InterruptedException 
	{
		try
		{
			String resultSheetName;
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "AdultContentTargeting";
			}
			else
			{
				resultSheetName = "AdultContentTargeting_ReRun";
			}
			File f = new File(fileNameWithLocation);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList); 

			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());

			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");

			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				String testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/targeting/DataToFormURL/TestDataAdultTargeting_TID23_ReRun.xls").toString();
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception at the end of Adult Content Targeting: " +e.getMessage());
		}
	}

}
