/**
 * Last Changes Done on 10 Jun, 2015 11:20:26 AM
 * Last Changes Done by ${author}
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileAdServe.lib;


import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.browsermob.proxy.ProxyServer;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import projects.bq.BQQueriesLib;


import vlib.CaptureNetworkTrafficLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.UIOperations_BrowserScreenLib;
import vlib.UIOperations_MobileDeviceLib;

import com.google.api.services.bigquery.Bigquery;
import com.mysql.jdbc.Connection;

// TODO: Auto-generated Javadoc
public class MobileAdServingLib 
{

	static Logger logger = Logger.getLogger(MobileAdServingLib.class.getName());


	/** This method will be used for both marketplace and direct serving ads, flag directMarketplaceFlag will decide the value of 
	 * any direct or marketplace specific parameter.
	 * 
	 * @param directMarketplaceFlag
	 * @param driver
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adsDuration
	 * @param expectedImpressionTrackerURLs
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param custom_details
	 * @param destinationURL
	 * @param companionBanner
	 * @param channelSettings
	 * @param bqConnection
	 * @param bqProjectID
	 * @param con
	 * @return
	 */
	@SuppressWarnings({"finally" })
	public static TreeMap<String, TreeMap<String, TreeMap<String, String>>> mobileAdServe(String directMarketplaceFlag, WebDriver driver, String adFormat, 
			String adURL, String campaignID, String channelID, String adsDuration, String expectedImpressionTrackerURLs, String actionType, 
			boolean androidDeviceConnected, boolean iphoneDeviceConnected, String custom_details, String destinationURL, String companionBanner, 
			String channelSettings, Bigquery bqConnection, String bqProjectID, Connection con) 
			{	

		TreeMap<String, TreeMap<String, TreeMap<String, String>>> servingData = new TreeMap<>();
		String otherResult = "";

		try
		{
			/** Getting default d wait for each type of ad format */
			int adWait = MobileAdServingUtilsLib.getAdWaitSeconds(adsDuration, adFormat);

			/** Perform test only if supplied request is valid and starts with http */  
			if(adURL.trim().matches("^http.*"))
			{
				/** Check vast xml conversion for vast ads */
				if(adFormat.equalsIgnoreCase("video") && actionType.equalsIgnoreCase("vastfeed"))
				{
					//otherResult = MobileAdServingUtilsLib.verifyVastParentAdXML(adFormat, actionType , campaignID, adURL, con);
					otherResult = "SKIP: This is a parent vast ad, therefore wasn't served. ";
				}
				/** Serve ad */
				else
				{
					boolean proceedTest;

					if(directMarketplaceFlag.equalsIgnoreCase("marketplace"))
					{
						/** in case of chocolate, proceedTest = true always because this method will be called only 
						 * when there is a winning bidder that means proceedTest = true */
						proceedTest = true;
					}
					else
					{
						/** checking inventory available or unavailable for direct serving ~~ vdopia serving */
						proceedTest = MobileAdServingUtilsLib.proceedServingTest(adURL);
					}

					/** Setting up constructor values to be used while serving ads. */
					dataSetter(custom_details, adFormat, campaignID, channelID, companionBanner, channelSettings);

					/** Get serving result from browser and devices */
					servingData = startServing(directMarketplaceFlag, androidDeviceConnected, iphoneDeviceConnected, 
							proceedTest, driver, adURL, adFormat, campaignID, channelID, adWait, bqConnection, 
							bqProjectID, actionType, con, expectedImpressionTrackerURLs, destinationURL);					
				}
			}
			else
			{
				otherResult = "SKIP: NOT A VALID URL, NOT STARTING WITH HTTP(S). ";
			}
		}
		catch(Exception e)
		{
			otherResult = "FAIL: " + otherResult + e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception. " , e);
		}
		finally
		{
			/** Finally adding otherResult in case of vast ad or invalid requests in the received map servingData */
			servingData = putOtherResult(servingData, adURL, otherResult);

			return servingData;
		}
			}


	/**
	 * This method will put the otherResults into the final servingData map .
	 * 
	 * @param servingData
	 * @param adURL
	 * @param otherResult
	 * @return
	 */
	public static TreeMap<String, TreeMap<String, TreeMap<String, String>>> putOtherResult(TreeMap<String, TreeMap<String, TreeMap<String, String>>>servingData, String adURL, String otherResult)
	{
		String otherResultFromServingData = "";
		try{

			/** in case, received servingData map is empty then create the standard structure and fill the otherResult */
			if(servingData.isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Empty map is received, creating it... ");

				String timeStamp = MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss");

				TreeMap<String, String> youngestChildMap = new TreeMap<>();
				youngestChildMap.put("otherresult", "");

				TreeMap<String, TreeMap<String, String>> elderChildMap = new TreeMap<>();
				elderChildMap.put(adURL, youngestChildMap);

				servingData.put(timeStamp, elderChildMap);
			}

			/** Getting the last child map and then getting the value of key = otherresult */
			otherResultFromServingData = servingData.firstEntry().getValue().firstEntry().getValue().get("otherresult");

		}catch(NullPointerException n)
		{
			otherResultFromServingData = "";
		}

		otherResultFromServingData = otherResultFromServingData + "\n" +otherResult;
		servingData.firstEntry().getValue().firstEntry().getValue().put("otherresult", otherResultFromServingData);

		return servingData;
	}


	/**
	 * This method will drive the serving on browser and device, return type
	 * from device and browser serving methods contains three tree map, like: [
	 * timestamp, [ url/device, [ param, value ] ] ] timestamp is kept as key to
	 * identify one iteration because in case device immediate child map may
	 * have more than one device id in case of multiple attached device.
	 * 
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param proceedTest
	 * @param driver
	 * @param adURL
	 * @param trackerStartTime
	 * @param adFormat
	 * @param campaignID
	 * @param channelID
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @param actionType
	 * @param con
	 * @return
	 */
	public static TreeMap<String, TreeMap<String, TreeMap<String, String>>> startServing(String directMarketplaceFlag, boolean androidDeviceConnected, boolean iphoneDeviceConnected, 
			boolean proceedTest, WebDriver driver, String adURL, String adFormat, String campaignID, String channelID, int adWait, Bigquery bqConnection, 
			String bqProjectID, String actionType, Connection con, String expectedImpressionTrackerURLs, String destinationURL)
			{

		TreeMap<String, TreeMap<String, TreeMap<String, String>>> servingData = new TreeMap<>();

		try
		{
			/******* Ad serving on devices, collect all received maps into servingData **********/
			if(androidDeviceConnected || iphoneDeviceConnected)
			{
				/** deviceData map will contain the data from android and iphone device serving in format like: 
				 * [device id, [keys, values] ]; these maps have to be stored in the final map servingData in a format like:
				 * [ timestamp, <androidData/iPhoneData map>]
				 */
				TreeMap<String, TreeMap<String, String>> deviceData = new TreeMap<>();

				if(androidDeviceConnected)
				{
					deviceData.putAll(getDataFromAndroidServing(directMarketplaceFlag, proceedTest, adFormat, adURL, campaignID, channelID, 
							adWait, bqConnection, bqProjectID, actionType, androidDeviceConnected, iphoneDeviceConnected,expectedImpressionTrackerURLs,destinationURL));
				}
				if(iphoneDeviceConnected)
				{
					deviceData.putAll(getDataFromIphoneServing(directMarketplaceFlag, proceedTest, adFormat, adURL, campaignID, channelID, 
							adWait, bqConnection, bqProjectID, actionType, androidDeviceConnected, iphoneDeviceConnected, expectedImpressionTrackerURLs, destinationURL));
				}

				/** getting timestamp as a key for putting deviceData into servingData tree map corresponding to a time stamp */
				String key = MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss");

				servingData.put(key, deviceData);
			}
			/******* Ad serving on browser **********/
			else				
			{			
				/** Get current db time from BQ */
				String trackerStartTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);

				/** Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib */
				new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTime);

				/** Checking Vast Ad, For Vast, http requests need to be captured to check third party trackers */
				if(adFormat.equalsIgnoreCase("vastfeed"))
				{
					servingData = getDataFromVastServing(directMarketplaceFlag, proceedTest, trackerStartTime, driver, adFormat, adURL, campaignID, channelID,
							adWait, bqConnection, bqProjectID, actionType, androidDeviceConnected, iphoneDeviceConnected, con);
				}
				else
				{
					servingData = getDataFromBrowserServing(directMarketplaceFlag, proceedTest, trackerStartTime, driver, adFormat, adURL, campaignID, channelID, 
							adWait, bqConnection, bqProjectID, actionType, androidDeviceConnected, iphoneDeviceConnected, 
							expectedImpressionTrackerURLs, destinationURL);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while starting the serving.. ", e);
		}

		return servingData;
			}


	/**
	 * This method is a data setter, it will call constructor
	 * UIOperations_MobileDeviceLib and UIOperations_BrowserScreenLib before
	 * serving the ads.
	 * 
	 * @param custom_details
	 * @param adFormat
	 * @param campaignID
	 * @param channelID
	 * @param companionBanner
	 */
	public static void dataSetter(String custom_details, String adFormat, String campaignID, String channelID, String companionBanner, String channelSettings)
	{
		try
		{
			/** Code to get details 'adsByText' , 'learnMoreText' from channelSettings first,
			 *  if not there then get it from custom_details field  */
			JSONObject channelsetting = new JSONObject(channelSettings);
			JSONObject customdetail = new JSONObject(custom_details);

			String adsByText = "";
			try{
				adsByText = channelsetting.getString("vdo_adsby_text").trim();
			}catch(JSONException j){
				adsByText = customdetail.getString("vdo_adsby_text").trim();
			}

			String learnMoreText = "";
			try{
				learnMoreText = channelsetting.getString("vdo_lm_txt").trim();
			}catch(JSONException j)
			{
				learnMoreText = customdetail.getString("vdo_lm_txt").trim();
			}

			String isMaxVideo = "";
			try{
				isMaxVideo = channelsetting.getString("fullscreen").trim();
			}catch(JSONException j)
			{
				try{
					isMaxVideo = customdetail.getString("fullscreen").trim();
				}catch(JSONException ex)
				{}
			}


			if(adFormat.equalsIgnoreCase("video"))
			{
				if(isMaxVideo.equalsIgnoreCase("1"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied video is a Max Video, Learn More text will be checked. ");
				}
				else if(!companionBanner.trim().isEmpty())
				{
					learnMoreText = "";
				}
			}

			/** Initializing constructors.
			 */
			new UIOperations_MobileDeviceLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);
			new UIOperations_BrowserScreenLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);


			//			if(!custom_details.trim().isEmpty())
			//			{
			//				/** Code to get details 'adsByText' , 'learnMoreText' from channelSettings first if not there then get it from custom_details field  */
			//				List<String> list = getAdsByLearnMoreText(custom_details, channelSettings);
			//				String adsByText = list.get(0);
			//				String learnMoreText = list.get(1);
			//
			//				/** Learn More text will not be displayed if a video ad has a companion banner,
			//				 *  only in case of Max Video Learn More will always be displayed.
			//				 *  
			//				 *  First checking the ad format = video then check if its a max video or a video with companion banner
			//				 *  Splitting the received flag and considering the second string to check max video from the supplied Campaign.Custom_Details
			//				 */
			//				String isMaxVideo = MobileTestClass_Methods.getFlagForMaxVideoAndFullScreenBanner(custom_details).split(",")[1].trim();
			//
			//				if(adFormat.equalsIgnoreCase("video"))
			//				{
			//					if(isMaxVideo.equalsIgnoreCase("1"))
			//					{
			//						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied video is a Max Video, Learn More text will be checked. ");
			//					}
			//					else if(!companionBanner.trim().isEmpty())
			//					{
			//						learnMoreText = "";
			//					}
			//				}
			//
			//				/** Initializing constructors.
			//				 */
			//				new UIOperations_MobileDeviceLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);
			//				new UIOperations_BrowserScreenLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);
			//			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while setting up data before serving ads.", e);
		}
	}


	/** This method will return a list containing adsbytext and learnmore text
	 * 
	 * @param custom_details
	 * @param channelSettings
	 * @return
	 */
	public static List<String> getAdsByLearnMoreText(String custom_details, String channelSettings)
	{
		List<String> list = new ArrayList<String>();

		String adsByText = "";

		/** First get adsbytext from channelSettings, if received empty then get from custom_settings */
		adsByText = parseCustomSetting(channelSettings, "ads_by_text");

		/** Getting adsbytext from custom_details, if not received by above code */
		if(adsByText.isEmpty())
		{
			adsByText = parseCustomSetting(custom_details, "vdo_adsby_text");
		}

		/** now getting learn more text from custom_details*/
		String learnMoreText = parseCustomSetting(custom_details, "vdo_lm_txt");

		list.add(adsByText);
		list.add(learnMoreText);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : adsByText: "+adsByText + " learnMoreText: "+learnMoreText);
		return list;
	}


	/** This method will be used to parse custom_details and additional_settings 
	 * 
	 * @param strSettings
	 * @param desiredParam
	 * @return
	 */
	public static String parseCustomSetting(String strSettings, String desiredParam)
	{
		String desiredValue="";

		String[] arrDetails = strSettings.trim().split(",");
		for (String details : arrDetails)
		{
			if(details.contains(desiredParam))
			{
				String[] arrAdsByText = details.split(":");
				desiredParam = arrAdsByText[1].replaceAll("\"","").trim();
			}
		}

		return desiredValue;
	}


	/**
	 * This method will serve the vast ads and check the trackers using a proxy
	 * server.
	 * 
	 * @param proceedTest
	 * @param trackerStartTime
	 * @param driver
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param con
	 * @return
	 */
	@SuppressWarnings("finally")
	public static TreeMap<String, TreeMap<String, TreeMap<String, String>>> getDataFromVastServing(String directMarketplaceFlag, boolean proceedTest, String trackerStartTime, WebDriver driver, String adFormat, String adURL, String campaignID, String channelID, 
			int adWait, Bigquery bqConnection, String bqProjectID, String actionType, boolean androidDeviceConnected, boolean iphoneDeviceConnected, Connection con)
			{
		TreeMap<String, TreeMap<String, TreeMap<String, String>>> servingData = new TreeMap<>();

		try
		{
			String otherResult = "";

			/** Do UI Operation only if inventory is available */
			if(proceedTest)
			{
				otherResult = checkVastAdUsingProxy(driver, adURL, adFormat, adWait, campaignID, channelID, trackerStartTime, bqConnection, bqProjectID, con);
			}
			else
			{
				/** in case proceedTest = false, that means inventory is unavailable for this ad, still browsing for 1.5 sec to get the 
				 * actual trackers in the Big Query */
				driver.get(adURL);
				Thread.sleep(1500);
			}

			/** Get tracker end time from bq */
			String trackerEndTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : DB END Time For Tracker Calculation: " +trackerEndTime);

			/** Getting queries for checking campaign and channel side trackers, also putting other result */
			TreeMap<String, String> data = BQQueriesLib.getQueriesForTrackerCalculation(directMarketplaceFlag, campaignID, channelID, trackerStartTime, trackerEndTime, null, bqConnection, bqProjectID);			
			data.put("otherresult", otherResult);

			/** Adding other required values in data map */
			data = setMapValues(directMarketplaceFlag, data, proceedTest, adFormat, campaignID, channelID, trackerStartTime, actionType, androidDeviceConnected, iphoneDeviceConnected);

			/** Setting up key of final map */
			String key = MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss");

			/** Creating a map to contain the key = adURL and respective data for this key,
			 * for browser serving data using key = adURL whereas in device serving result this key = device id, 
			 * using url here just to maintain the same signature
			 */
			TreeMap<String, TreeMap<String, String>> dataRequestMap = new TreeMap<>();
			dataRequestMap.put(adURL, data);

			/** Finally putting all data into a servingData tree map */
			servingData.put(key, dataRequestMap);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting data for vast serving. ", e);
		}
		finally
		{
			return servingData;
		}
			}


	/**
	 * This method will check the vast ad and corresponding trackers in supplied
	 * vast xml using a proxy.
	 * 
	 * @param driver
	 * @param adURL
	 * @param adFormat
	 * @param adWait
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param bqConnection
	 * @param bqProjectID
	 * @param con
	 * @return
	 */
	public static String checkVastAdUsingProxy(WebDriver driver, String adURL, String adFormat, int adWait, String campaignID, 
			String channelID, String trackerStartTime, Bigquery bqConnection, String bqProjectID, Connection con)
	{
		String otherResult = "";
		try
		{
			/** Start Proxy Server */
			int proxyServerPort = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("proxyServerPort").toString());
			ProxyServer ps = CaptureNetworkTrafficLib.startProxyServer(proxyServerPort);

			/** Browsing URL */
			driver.get(adURL);

			/** Collecting user interaction result like click etc. */
			new UIOperations_BrowserScreenLib(adFormat, adWait, campaignID, channelID, trackerStartTime);
			String textValidationResult = UIOperations_BrowserScreenLib.UITestsOnBrowserScreen(driver, adURL, false, bqConnection, bqProjectID);

			/** Getting http log and fired tracker urls out of http log */
			String httpLog = CaptureNetworkTrafficLib.getHttpLogAfterStoppingProxyServer(ps);
			List<String> servedVastTrackers = CaptureNetworkTrafficLib.getURLsFromNetworkLog(httpLog);

			/** Getting expected tracker urls */
			List<String> expectedVastTrackers = MobileAdServingUtilsLib.getURLsFromVASTXML(campaignID, con);

			/** Getting trackers list- which were not fired */
			String vastTrackerResult = StringLib.CompareTwoList_GetUnMatched(servedVastTrackers, expectedVastTrackers);

			otherResult = vastTrackerResult + "\n" + textValidationResult;
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking vast ad. ", t);
		}
		return otherResult;
	}


	/**
	 * in the new method of checking mobile ad serving, tracker result will not
	 * be created after each iteration, only queries will be created after each
	 * iteration to get tracker result, these queries will be fired at the end
	 * of test to get the tracker result.
	 * 
	 * @param proceedTest
	 * @param trackerStartTime
	 * @param driver
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @return
	 */
	@SuppressWarnings("finally")
	public static TreeMap<String, TreeMap<String, TreeMap<String, String>>> getDataFromBrowserServing(String directMarketplaceFlag, boolean proceedTest, String trackerStartTime, 
			WebDriver driver, String adFormat, String adURL, String campaignID, String channelID, int adWait, Bigquery bqConnection, 
			String bqProjectID, String actionType, boolean androidDeviceConnected, boolean iphoneDeviceConnected, String expectedImpressionTrackerURLs, String destinationURL)
			{
		/** This map will contain data like: 
		 * [timestamp, [adURL, [channelQuery, Q1] ], 
		 * timestamp is being kept instead of url because there may be a duplicate url too in supplied data. 
		 * so that the data returned by methods: getDataFromBrowserServing, getDataFromIphoneServing, getDataFromAndroidServing have same signature
		 */
		TreeMap<String, TreeMap<String, TreeMap<String, String>>> servingData = new TreeMap<>();
		String otherResult = "";

		try
		{
			if(proceedTest)
			{
				/** Browsing URL */
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now Browsing ad URL: " +adURL);
				driver.get(adURL);

				/** Initialize constructor */
				new UIOperations_BrowserScreenLib(adFormat, adWait, campaignID, channelID, trackerStartTime);

				/** Getting result of user interaction */
				otherResult = UIOperations_BrowserScreenLib.UITestsOnBrowserScreen(driver, adURL, false, bqConnection, bqProjectID);
			}
			else
			{
				/** in case proceedTest = false, that means inventory is unavailable for this ad, still browsing for 1.5 sec to get the 
				 * actual trackers ai, ui in Big Query */
				driver.get(adURL);
				Thread.sleep(1500);
			}

			/** Get tracker end time from bq */
			String trackerEndTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : DB END Time For Tracker Calculation: " +trackerEndTime);

			/** Getting queries to check campaign and channel side trackers, also putting other result */
			TreeMap<String, String> data = BQQueriesLib.getQueriesForTrackerCalculation(directMarketplaceFlag, campaignID, channelID, trackerStartTime, trackerEndTime, null, bqConnection, bqProjectID);			
			data.put("otherresult", otherResult);

			/** Adding other required values in data map */
			data = setMapValues(directMarketplaceFlag, data, proceedTest, adFormat, campaignID, channelID, trackerStartTime, actionType, androidDeviceConnected, iphoneDeviceConnected);

			/** Get values to validate third party trackers and add this map to above created data map */
			TreeMap<String, String> thirdPartyTrackerMap = new TreeMap<>();
			if(proceedTest)
			{
				thirdPartyTrackerMap = MobileAdServingUtilsLib.setThirdPartyMapValues(expectedImpressionTrackerURLs, destinationURL, 
						channelID, trackerStartTime, trackerEndTime);

				/** add this map to above created data map */
				data.putAll(thirdPartyTrackerMap);
			}

			/** Creating a map to contain the key = adURL and respective data for this key,
			 * for browser serving data using key = adURL whereas in device serving result this key = device id, 
			 * using url here just to maintain the same signature
			 */
			TreeMap<String, TreeMap<String, String>> dataRequestMap = new TreeMap<>();
			dataRequestMap.put(adURL, data);

			/** Setting up key of final map */
			String key = MobileTestClass_Methods.DateTimeStamp("MMdd_hhmmss");

			/** Finally putting all data into a servingData tree map */
			servingData.put(key, dataRequestMap);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting data from browser serving. ", e);
		}
		finally
		{
			return servingData;
		}

			}


	/**
	 * This method will do serving on iphones.
	 * 
	 * @param proceedTest
	 * @param trackerStartTime
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @return
	 */
	@SuppressWarnings("finally")
	public static TreeMap<String, TreeMap<String, String>> getDataFromIphoneServing(String directMarketplaceFlag, boolean proceedTest, String adFormat, String adURL, String campaignID, String channelID, int adWait, 
			Bigquery bqConnection, String bqProjectID, String actionType, boolean androidDeviceConnected, boolean iphoneDeviceConnected, String expectedImpressionTrackerURLs, String destinationURL)
			{

		/** This map will contain data like: 
		 * [deviceID, [channelQuery, Q1] 
		 */
		TreeMap<String, TreeMap<String, String>> deviceDataMap = new TreeMap<>();

		try
		{
			String iphoneIPs = MobileTestClass_Methods.propertyConfigFile.getProperty("iphoneDeviceIP").toString();
			String[] iphoneDeviceList = StringLib.StrSplit(iphoneIPs,",");
			String otherResult = "";

			for (int i = 0; i < iphoneDeviceList.length; i++) 
			{
				String iphoneIPPort = iphoneDeviceList[i];

				/** Get current db time from BQ */
				String trackerStartTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);

				/** Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib and getting results */
				new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTime);
				otherResult = UIOperations_MobileDeviceLib.testRun_iPhoneDevice(proceedTest, iphoneIPPort, null, adURL, false, adWait, bqConnection, bqProjectID);

				/** Get tracker end time from bq */
				String trackerEndTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : DB END Time For Tracker Calculation: " +trackerEndTime);

				/** Getting queries for campaign and channel side trackers and other result for each device id */
				TreeMap<String, String> dataForEachDevice = BQQueriesLib.getQueriesForTrackerCalculation(directMarketplaceFlag, campaignID, channelID, trackerStartTime, trackerEndTime, null, bqConnection, bqProjectID);

				/** Adding custom text also in other results */
				otherResult = otherResult + "\nAutomation Suite Doesn't Verify cl, pa, upa Trackers On Mobile Device. ";
				dataForEachDevice.put("otherresult", otherResult);

				/** Adding other required values in dataForEachDevice map */
				dataForEachDevice = setMapValues(directMarketplaceFlag, dataForEachDevice, proceedTest, adFormat, campaignID, channelID, trackerStartTime, actionType, androidDeviceConnected, iphoneDeviceConnected);

				/** Get values to validate third party trackers and add this map to above created data map */
				TreeMap<String, String> thirdPartyTrackerMap = new TreeMap<>();
				if(proceedTest)
				{
					thirdPartyTrackerMap = MobileAdServingUtilsLib.setThirdPartyMapValues(expectedImpressionTrackerURLs, destinationURL, 
							channelID, trackerStartTime, trackerEndTime);

					/** add this map to above created data map */
					dataForEachDevice.putAll(thirdPartyTrackerMap);
				}

				/** Creating a tree map to keep data of each device with respect to device id */ 

				deviceDataMap.put(iphoneIPPort, dataForEachDevice);

			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting data for iphone serving. ", e);
		}
		finally
		{
			return deviceDataMap;
		}

			}


	/**
	 * This method will serve the ads on android devices.
	 * 
	 * @param proceedTest
	 * @param trackerStartTime
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @return
	 */
	@SuppressWarnings("finally")
	public static TreeMap<String, TreeMap<String, String>> getDataFromAndroidServing(String directMarketplaceFlag, boolean proceedTest, String adFormat, String adURL, String campaignID, String channelID, int adWait, 
			Bigquery bqConnection, String bqProjectID, String actionType, boolean androidDeviceConnected, boolean iphoneDeviceConnected, String expectedImpressionTrackerURLs, String destinationURL)
			{
		/** This map will contain data like: 
		 * [deviceID, [channelQuery, Q1] 
		 */
		TreeMap<String, TreeMap<String, String>> deviceDataMap = new TreeMap<>();

		try
		{
			List<String> androidDeviceList = UIOperations_MobileDeviceLib.getAndroidDeviceList();

			for(int i=0;i<androidDeviceList.size();i++)
			{
				String deviceID = androidDeviceList.get(i);

				/** Get current db time from BQ */
				String trackerStartTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);

				/** Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib */
				new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTime);

				String otherResult = UIOperations_MobileDeviceLib.testRun_AndroidDevice(proceedTest, deviceID, adURL, false, adWait, bqConnection, bqProjectID);

				/** Get tracker end time from bq */
				String trackerEndTime = BQQueriesLib.getCurrentDBTime(bqConnection, bqProjectID);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : DB END Time For Tracker Calculation: " +trackerEndTime);

				/** Getting queries for campaign and channel side trackers and other results for each device id */
				TreeMap<String, String> dataForEachDevice = BQQueriesLib.getQueriesForTrackerCalculation(directMarketplaceFlag, campaignID, channelID, trackerStartTime, trackerEndTime, null, bqConnection, bqProjectID);

				/** Adding custom text also in other results */
				otherResult = otherResult + "\nAutomation Suite Doesn't Verify cl, pa, upa Trackers On Mobile Device. ";
				dataForEachDevice.put("otherresult", otherResult);

				/** Adding other required values in dataForEachDevice map */
				dataForEachDevice = setMapValues(directMarketplaceFlag, dataForEachDevice, proceedTest, adFormat, campaignID, channelID, trackerStartTime, actionType, androidDeviceConnected, iphoneDeviceConnected);

				/** Get values to validate third party trackers and add this map to above created data map */
				TreeMap<String, String> thirdPartyTrackerMap = new TreeMap<>();
				if(proceedTest)
				{
					thirdPartyTrackerMap = MobileAdServingUtilsLib.setThirdPartyMapValues(expectedImpressionTrackerURLs, destinationURL, 
							channelID, trackerStartTime, trackerEndTime);

					/** add this map to above created data map */
					dataForEachDevice.putAll(thirdPartyTrackerMap);
				}

				/** Creating a tree map to keep data of each device with respect to device id */ 
				deviceDataMap.put(deviceID, dataForEachDevice);	
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting data for android serving. ", e);
		}
		finally
		{
			return deviceDataMap;
		}
			}


	/** This method will add values in supplied map: proceedTest flag, adFormat, campaign id, channel id, trackerStartTimeForDesktop and otherResult
	 *  also in final list to be returned this list will be parsed and the required will be retrieved to do further processing.
	 * 
	 * @param mobileServingData
	 * @param proceedTest
	 * @param adFormat
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param actionType
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @return
	 */
	public static TreeMap<String, String> setMapValues(String directMarketplaceFlag, TreeMap<String, String> mobileServingData, boolean proceedTest, String adFormat, String campaignID, String channelID,
			String trackerStartTime, String actionType, boolean androidDeviceConnected, boolean iphoneDeviceConnected){

		mobileServingData.put("proceedtest", String.valueOf(proceedTest));
		mobileServingData.put("adformat", adFormat);
		mobileServingData.put("campaignid", campaignID);
		mobileServingData.put("channelid", channelID);
		mobileServingData.put("trackerstarttime", trackerStartTime);
		mobileServingData.put("actionType", actionType);
		mobileServingData.put("android", String.valueOf(androidDeviceConnected));
		mobileServingData.put("iphone", String.valueOf(iphoneDeviceConnected));
		mobileServingData.put("directmarketplace", directMarketplaceFlag);

		return mobileServingData;
	}


}