/**
 * Last Changes Done on 10 Jun, 2015 11:28:52 AM
 * Last Changes Done by ${author}
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.adserve.mobileAdServe.lib;

import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.browsermob.proxy.ProxyServer;
import org.openqa.selenium.WebDriver;
import vlib.CaptureNetworkTrafficLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.UIOperations_BrowserScreenLib;
import vlib.UIOperations_MobileDeviceLib;




public class MobileAdServingLegacy {


	/**This method will be used to serve ads
	 * 
	 * @param driver
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adsDuration
	 * @param expectedImpressionTracker
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param custom_details
	 * @param destinationURL
	 * @param companionBanner
	 * @return
	 */

	static Logger logger = Logger.getLogger(MobileAdServingLegacy.class.getName());


	@SuppressWarnings({ "unused", "finally" })
	public static String mobileAdServe(WebDriver driver, String adFormat, String adURL, String campaignID, String channelID, String adsDuration, String expectedImpressionTracker, boolean androidDeviceConnected, boolean iphoneDeviceConnected, String custom_details, String destinationURL, String companionBanner) 

	{

		String result = "";

		String vastTrackerResult = "";

		boolean httpFlag = true;



		try

		{

			String trackerStartTimeForDesktop = "";

			int adWait = Integer.parseInt(adsDuration);

			boolean flagForCloseButtonTestForVideo = false;

			boolean flagCheckThirdPartyTrackers = true;





			if(adURL.matches("^http.*"))

			{

				if(!custom_details.isEmpty())

				{

					// Code to get details 'adsByText' , 'learnMoreText' from custom details field

					String adsByText = "";

					String learnMoreText = "";

					String[] arrDetails = custom_details.split(",");

					for (String details : arrDetails)

					{

						if(details.contains("vdo_lm_txt"))

						{

							String[] arrlearnMoreText = details.split(":");

							learnMoreText = arrlearnMoreText[1].replaceAll("\"","").trim();

						}

						else if(details.contains("vdo_adsby_text"))

						{

							String[] arrAdsByText = details.split(":");

							adsByText = arrAdsByText[1].replaceAll("\"","").trim();

						}

					}



					/** Learn More text will not be displayed if an video ad has a companion banner,

					 *  only in case of Max Video Learn More will always be displayed.

					 *  

					 *  First checking the ad format = video then if max else companion banner

					 *  Splitting the received flag and considering the second string to check max video from the supplied Campaign.Custom_Details

					 */

					String isMaxVideo = MobileTestClass_Methods.getFlagForMaxVideoAndFullScreenBanner(custom_details).split(",")[1].trim();



					if(adFormat.equalsIgnoreCase("video"))

					{

						if(isMaxVideo.equalsIgnoreCase("1"))

						{

							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied video is a Max Video, Learn More text will be checked. ");

						}

						else if(!companionBanner.trim().isEmpty())

						{

							learnMoreText = "";

						}

					}



					/**

					 * Initializing constructors.

					 */

					new UIOperations_MobileDeviceLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);

					new UIOperations_BrowserScreenLib(adFormat, 0, campaignID, channelID, "", adsByText, learnMoreText);

				}



				if(androidDeviceConnected)

				{

					List<String> androidDeviceList = UIOperations_MobileDeviceLib.getAndroidDeviceList();

					for(int i=0;i<androidDeviceList.size();i++)

					{

						//find current time

						String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker Start Time For Ad Serving On Android Device: " +trackerStartTime);



						//Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib

						UIOperations_MobileDeviceLib ui = new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTime);



						String textValidationResult = UIOperations_MobileDeviceLib.testRun_AndroidDevice(true, androidDeviceList.get(i),adURL, flagForCloseButtonTestForVideo, adWait , null, "");

						result = result  + "Android Device ID: " + androidDeviceList.get(i) + " \n " + MobileTestClass_Methods.MobileAds_VdopiaTrackerValidationForUIOperations(adFormat, campaignID, channelID, trackerStartTime, null) + "\n";	//"2014-01-15 10:00:34"

						result = "Vdopia Trackers: "+ "\n" + result + textValidationResult + "\n";

					}

				}



				if(iphoneDeviceConnected)

				{

					String validationResult = "";



					String iphoneIPs = MobileTestClass_Methods.propertyConfigFile.getProperty("iphoneDeviceIP").toString();

					String[] iphoneDeviceList = StringLib.StrSplit(iphoneIPs,",");



					for (int i = 0; i < iphoneDeviceList.length; i++) 

					{

						//find current time

						String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker Start Time For Ad Serving On iPhone: " +trackerStartTime);



						//String iphoneIPPort = MobileTestClass_Methods.propertyConfigFile.getProperty("iphoneDeviceIP").toString();

						String iphoneIPPort = iphoneDeviceList[i];



						//Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib

						UIOperations_MobileDeviceLib ui = new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTime);





						//************************************************************************************************************

						/* This Code Will Be Functional After Finding Solution To Change Proxy in iPhone Device Dynamically  *********



	//Use proxy server in case of VAST Feed Ad Serving

	if(adFormat.equalsIgnoreCase("vastfeed"))

	{

	logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running Test For VAST Ads .....");



	//Start Proxy Server and Get Proxy Settings from this

	ProxyServer ps = CaptureNetworkTrafficLib.StartProxyServer(9090);

	Proxy proxy = CaptureNetworkTrafficLib.GetProxySettingFromProxyServer(ps);



	logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received Proxy From BrowserMob Proxy: "+proxy.getHttpProxy());



	//Perform test here

	validationResult = UIOperations_MobileDeviceLib.TestRun_iPhoneDevice(iphoneIPPort, proxy, adURL, flagForCloseButtonTestForVideo);



	//Capture Http Request and Get the URL list from log

	String httpLog = CaptureNetworkTrafficLib.CaptureHttpRequest(ps);

	List<String> servedVastTrackers = CaptureNetworkTrafficLib.GetURLsFromNetworkLog(httpLog);



	//Getting expected tracker urls

	List<String> expectedVastTrackers = GetURLsFromVASTXML(campaignID);



	//Getting trackers list- which were not fired

	vastTrackerResult = StringLib.CompareTwoList_GetUnMatched(servedVastTrackers, expectedVastTrackers);



	//Collecting results

	validationResult = validationResult + "\n" + "VAST Trackers Not Fired: "+ "\n" + vastTrackerResult;

	}

	else

	{



						 */

						//************************************************************************************************************



						//In case other Other Ad Formats - Normal Ad Serving

						validationResult = UIOperations_MobileDeviceLib.testRun_iPhoneDevice(true, iphoneIPPort, null, adURL, flagForCloseButtonTestForVideo, adWait, null, "");



						//}



						result = result  + "Iphone Device Ip: " + iphoneIPPort + "\n" + MobileTestClass_Methods.MobileAds_VdopiaTrackerValidationForUIOperations(adFormat, campaignID, channelID, trackerStartTime, null) + "\n";	//"2014-01-15 10:00:34"

						result = "Vdopia Trackers: "+ "\n" + result + validationResult;

					}

				}



				if(androidDeviceConnected || iphoneDeviceConnected)

				{

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test executed on attached device. Test ended at: "+MobileTestClass_Methods.DateTimeStamp());

				}

				else

				{

					//find current time

					trackerStartTimeForDesktop = MobileTestClass_Methods.GetCurrentDBTime();

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker Start Time For Ad Serving On Browser: " +trackerStartTimeForDesktop);



					//Initializing Constructor to set the static variables for class UIOperations_MobileDeviceLib

					UIOperations_MobileDeviceLib ui = new UIOperations_MobileDeviceLib(adFormat, adWait, campaignID, channelID, trackerStartTimeForDesktop);



					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now Browsing ad URL: " +adURL + " at time: " +MobileTestClass_Methods.DateTimeStamp());



					String textValidationResult = "";



					//Checking Vast Ad, For Vast, http requests need to be captured to check third party trackers

					if(adFormat.equalsIgnoreCase("vastfeed"))

					{

						//Start Proxy Server
						int proxyServerPort = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("proxyServerPort").toString());
						ProxyServer ps = CaptureNetworkTrafficLib.startProxyServer(proxyServerPort);

						//Browsing URL

						driver.get(adURL);


						Thread.sleep(2000);



						//********USER INTERACTIONS FOR VAST FEED AD  *************



						//Do UI Operation only if VI tracker is fired

						if(!(MobileTestClass_Methods.GetChannelTracker("ui", channelID, trackerStartTimeForDesktop)) && (MobileTestClass_Methods.GetCampaignTracker("vi", campaignID, channelID, trackerStartTimeForDesktop)))

						{

							new UIOperations_BrowserScreenLib(adFormat, adWait, campaignID, channelID, trackerStartTimeForDesktop);

							textValidationResult = UIOperations_BrowserScreenLib.UITestsOnBrowserScreen(driver,adURL,flagForCloseButtonTestForVideo, null, "");

						}

						else

						{

							//in case vi is not fired by above condition then don't check third party trackers

							flagCheckThirdPartyTrackers = false;

							logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Third party check: "+flagCheckThirdPartyTrackers);

						}



						//Getting http log and fired tracker urls out of http log

						String httpLog = CaptureNetworkTrafficLib.getHttpLogAfterStoppingProxyServer(ps);

						List<String> servedVastTrackers = CaptureNetworkTrafficLib.getURLsFromNetworkLog(httpLog);



						//Getting expected tracker urls

						List<String> expectedVastTrackers = MobileAdServingUtilsLib.getURLsFromVASTXML(campaignID);



						//Getting trackers list- which were not fired

						vastTrackerResult = StringLib.CompareTwoList_GetUnMatched(servedVastTrackers, expectedVastTrackers);



						//getting vdopia tracker counts

						result = "Vdopia Trackers: "+ "\n" + MobileTestClass_Methods.MobileAds_VdopiaTrackerValidationForUIOperations(adFormat, campaignID, channelID, trackerStartTimeForDesktop, null) + "\n";	//"2014-01-15 10:00:34"

						result = result + textValidationResult + "\n";

					}

					else

					{

						//Browsing URL

						driver.get(adURL);



						Thread.sleep(2000);

						boolean uiFired = MobileTestClass_Methods.GetChannelTracker("ui", channelID, trackerStartTimeForDesktop);

						boolean viFired = MobileTestClass_Methods.GetCampaignTracker("vi", campaignID, channelID, trackerStartTimeForDesktop);



						//Do UI Operation only if VI tracker is fired

						if(!uiFired && viFired)

						{

							new UIOperations_BrowserScreenLib(adFormat, adWait, campaignID, channelID, trackerStartTimeForDesktop);

							textValidationResult = UIOperations_BrowserScreenLib.UITestsOnBrowserScreen(driver,adURL,flagForCloseButtonTestForVideo, null, "");

						}

						else

						{

							//in case vi is not fired by above condition then don't check third party trackers

							flagCheckThirdPartyTrackers = false;

							logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Third party check: "+flagCheckThirdPartyTrackers);

						}



						result = result  + MobileTestClass_Methods.MobileAds_VdopiaTrackerValidationForUIOperations(adFormat, campaignID, channelID, trackerStartTimeForDesktop, null) + "\n";	//"2014-01-15 10:00:34"

						result = "Vdopia Trackers: "+ "\n" + result + textValidationResult + "\n";

					}

				}





				if(adFormat.equalsIgnoreCase("vastfeed"))

				{

					if(vastTrackerResult.equalsIgnoreCase(""))

					{

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : All Expected Tracker Were Fired. ");

					}

					else

					{

						//getting tracker urls for vast

						result = result + "\n" + "VAST Trackers Not Fired: "+ "\n" + vastTrackerResult;

					}

				}



				//driver.close();



				/** Collecting Third Party Trackers, initializing constructor to declare adFormat value later on to be used in  

				 * method: MobileAds_ThirdPartyTrackerValidation

				 */

				if(flagCheckThirdPartyTrackers)

				{

					new MobileTestClass_Methods((Object)adFormat);

					result = result + "\n" + MobileTestClass_Methods.MobileAds_ThirdPartyTrackerValidation(channelID, trackerStartTimeForDesktop, expectedImpressionTracker, destinationURL);

				}



				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result For This Iteration: " +result);



				if(StringLib.Strexist(result, "FAIL"))

				{

					result = "FAIL:\n" + result;

				}

				else

				{

					result = "PASS:\n" + result;

				}



			}

			else

			{

				httpFlag = false;

				result = "NOT A VALID URL:";

			}

		}

		catch(Exception e)

		{

			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception " , e);

			result = "FAIL" + result + "\n" + "FAIL - " + e.getMessage();

		}

		finally

		{

			//Adding custom Text in results

			if(httpFlag)

			{

				String customText = "";



				if(androidDeviceConnected || iphoneDeviceConnected)

				{

					customText = "\nAutomation Suite Doesn't Verify cl, pa, upa Trackers On Mobile Device. ";

				}

				else

				{

					customText = "\nAutomation Suite Doesn't Verify mu, um, upa Trackers On Desktop Browser.";

				}



				result = result + customText;

			}

			return result;

		}



	}
}
