/**
 * Last Changes Done on 4 Jun, 2015 5:05:13 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */

package projects.adserve.mobileAdServe.lib;


import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import projects.bq.BQQueriesLib;
import projects.chocolate.lib.requestHandler.GetRequestLib;


import vlib.Excel2Html;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.StringLib;
import vlib.VastXmlParse;
import vlib.XlsLib;
import vlib.httpClientWrap;

public class MobileAdServingUtilsLib 
{
	static Logger logger = Logger.getLogger(MobileAdServingUtilsLib.class.getName());


	/** This method will send request to supplied url after changing output = js, if inventory available then return true else false. 
	 * 
	 * @param requestURL
	 * @return
	 */
	public static boolean proceedServingTest(String requestURL)
	{
		boolean proceedTest = false;

		try
		{
			String output = GetRequestLib.getQueryParamsFromGetRequest(requestURL).get("output");
			String adFormat = GetRequestLib.getQueryParamsFromGetRequest(requestURL).get("adFormat");


			/** Get the output parameter from the supplied request, if its js then no problem else remove the output parameter from url
			 * so that default output becomes js.
			 */
			if(!output.equalsIgnoreCase("js"))
			{
				requestURL = requestURL.replace("output", "").trim();
			}

			/** Send the get request to url and check the string "inventory":"available" in received response for adFormats other than 
			 * htmlinter and jsbanner, if found then return true else false. for jsbanner and htmlinter: check the adformat in the response.
			 */
			String response = httpClientWrap.sendGetRequest(requestURL);


			if(adFormat.equalsIgnoreCase("htmlinter") || adFormat.equalsIgnoreCase("jsbanner"))
			{
				response = URLDecoder.decode(response, "UTF-8");

				if(response.contains("iphonetrk"))
				{
					proceedTest = true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : tracker found in response, prceeding to serving test.... ");
				}
			}
			else
			{
				if(response.contains("\"inventory\":\"available\""))
				{
					proceedTest = true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Inventory Available, proceeding to serving test.... ");
				}			
			}
		}
		catch(Exception e)
		{
			proceedTest = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking the availability of inventory. ", e);
		}

		return proceedTest;
	}


	/** This method will check the VAST - Parent Ad XML Verification
	 * 
	 * 
	 * @param adFormat
	 * @param Action_type
	 * @param campaignID
	 * @param adURL
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String verifyVastParentAdXML(String adFormat, String Action_type, String campaignID, String adURL, Connection con)
	{
		String results = "";

		try
		{
			//Checking Parent Vast Ad - XML validation
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This is a Vast Parent Ad. Performing tests of Adserve Server XML response validation.");
			String vast_source_url = VastXmlParse.getVastSourceXML_URL(campaignID, con);

			//This hash map returns the list of impression URLs from the supplied xml
			List<String> SourceImpressionData = VastXmlParse.VastDataParser(vast_source_url, "Impression");

			//This hash map returns the list of tracking event URLs from the supplied xml 
			TreeMap<String, ArrayList<String>> SourceTrackerData = VastXmlParse.VastDataParser(vast_source_url, "Tracking", "event");

			//This is a list
			List<String> AdserveImpressionData = VastXmlParse.VastDataParser(adURL, "Impression");

			//This is a hash map 
			TreeMap<String, ArrayList<String>> AdserveTrackerData = VastXmlParse.VastDataParser(adURL, "Tracking", "event");

			String Impression_result = StringLib.compareLists_impression(AdserveImpressionData, SourceImpressionData);

			List<String> Impression_resultList = Arrays.asList(Impression_result.split(",", 2));

			if(Impression_resultList.get(0) == "false")
			{
				results = "FAIL: Source Vast Feed impression urls are not present in Adserver Vast Response.\n";
			}
			else
			{
				results = "PASS: Source Vast Feed impression urls are present in Adserver Vast Response.\n";
			}

			String Trackers_result = StringLib.compareLists_trackers(AdserveTrackerData, SourceTrackerData);
			List<String> Trackers_resultList = Arrays.asList(Trackers_result.split(",", 2));

			if(Trackers_resultList.get(0) == "false")
			{
				results = results + "FAIL: Source Vast Feed Trackers urls are not present in Adserver Vast Response.";
			}
			else
			{
				results = results + "PASS: Source Vast Feed trackers urls are present in Adserver Vast Response.";
			}
		}
		catch (Exception e) 
		{
			results = "FAIL: Exception occurred while checking VAST XML.";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: VerifyVastParentAdXML. ",e);
		}
		finally
		{
			return results;
		}

	}


	/** This method will return all the urls listed in supplied VAST XML while creating a campaign.
	 * 
	 * @param campaignID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getURLsFromVASTXML (String campaignID, Connection con)
	{
		List<String> urlList = new ArrayList<String>();

		//This is ignored tracker list on desktop browser, for mobile this has to be revised
		String ignoreTrackers = "mute, unmute, pause, play, fullscreen, collapse, expand, resume, rewind, acceptInvitation, close, creativeView";

		try
		{
			String vast_source_url = VastXmlParse.getVastSourceXML_URL(campaignID, con);

			//This hash map returns the list of impression URLs from the supplied xml
			List<String> SourceImpressionData = VastXmlParse.VastDataParser(vast_source_url, "Impression");

			//This hash map returns the list of tracking event URLs from the supplied xml 
			TreeMap<String, ArrayList<String>> SourceTrackerData = VastXmlParse.VastDataParser(vast_source_url, "Tracking", "event");

			//Adding all fetched urls in a list and return that list finally
			//1
			urlList.addAll(SourceImpressionData);

			//2
			for(Entry<String, ArrayList<String>> map : SourceTrackerData.entrySet())
			{
				if(ignoreTrackers.contains(map.getKey()))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This Tracker: "+map.getKey() + " will not be checked on desktop browser. ");
				}
				else
				{
					List<String> fetchedURL = map.getValue();

					//Adding fetched list to URL List
					urlList.addAll(fetchedURL);
				}

			}
		}
		catch(Exception e )
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: GetURLsFromVASTXML. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Returning this url list from VAST XML: ");
			for(int i=0; i<urlList.size(); i++)
			{
				logger.info(urlList.get(i) + "\n");
			}

			return urlList;
		}
	}


	/** This method will return all the urls listed in supplied VAST XML while creating a campaign.
	 * 
	 * @param campaignID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static List<String> getURLsFromVASTXML (String campaignID)
	{
		List<String> urlList = new ArrayList<String>();

		//This is ignored tracker list on desktop browser, for mobile this has to be revised
		String ignoreTrackers = "mute, unmute, pause, play, fullscreen, collapse, expand, resume, rewind, acceptInvitation, close, creativeView";

		try
		{
			String vast_source_url = VastXmlParse.getVastSourceXML_URL(campaignID);

			//This hash map returns the list of impression URLs from the supplied xml
			List<String> SourceImpressionData = VastXmlParse.VastDataParser(vast_source_url, "Impression");

			//This hash map returns the list of tracking event URLs from the supplied xml 
			TreeMap<String, ArrayList<String>> SourceTrackerData = VastXmlParse.VastDataParser(vast_source_url, "Tracking", "event");

			//Adding all fetched urls in a list and return that list finally
			//1
			urlList.addAll(SourceImpressionData);

			//2
			for(Entry<String, ArrayList<String>> map : SourceTrackerData.entrySet())
			{
				if(ignoreTrackers.contains(map.getKey()))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This Tracker: "+map.getKey() + " will not be checked on desktop browser. ");
				}
				else
				{
					List<String> fetchedURL = map.getValue();

					//Adding fetched list to URL List
					urlList.addAll(fetchedURL);
				}

			}
		}
		catch(Exception e )
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: GetURLsFromVASTXML. ", e);
		}
		finally
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Returning this url list from VAST XML: ");
			for(int i=0; i<urlList.size(); i++)
			{
				logger.info(urlList.get(i) + "\n");
			}

			return urlList;
		}
	}

	/** This method will create a html file and send it server to access it from a device later on
	 *  
	 * @param testResultFile
	 * @return
	 */
	public static boolean sendHtmlFileToServerForInviewAd(File testResultFile)
	{
		boolean flag = false;
		try
		{
			String [][]dataForInviewAdServing = FileLib.FetchDataFromExcelSheet(testResultFile.toString(), "Ad_Format", "Test_URLs", "Channel_APIKEY", "Action_Type", "Channel_ID");

			for(int i=0; i<dataForInviewAdServing.length; i++)
			{
				if((dataForInviewAdServing[i][0].equalsIgnoreCase("inview")) && (dataForInviewAdServing[i][3].equalsIgnoreCase("web")))
				{						
					//Reading Server Login Information From Config 
					String host = MobileTestClass_Methods.propertyConfigFile.getProperty("server").toString();
					String userName = MobileTestClass_Methods.propertyConfigFile.getProperty("serverUserName").toString();
					String password = MobileTestClass_Methods.propertyConfigFile.getProperty("serverPassword").toString();
					Session session = ExecuteCommands.createSessionWithPassword(userName, password, host);	//Create Session With Host - qa.vdopia.com
					String apiKey = dataForInviewAdServing[i][2].toString();	//Getting API Key
					String strActionType = dataForInviewAdServing[i][3].toString();
					String channelID = dataForInviewAdServing[i][4].toString();
					String strContent = StringLib.BuildStringForInViewAdFormat(apiKey,strActionType,channelID);
					String url = dataForInviewAdServing[i][1].toString();
					String fileName = StringLib.splitFileNameFromURL(url);
					ExecuteCommands.ExecuteCommandUsingJsch(session, "echo " + "\""+ strContent + "\"" + " > /mnt/qa/QAAutomation/InviewAd/" + fileName );		//Writing File In Server
					ExecuteCommands.EndSession(session);		//Terminating connection with server
					flag = true;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while sending html file to server for Inview Ad Format", e);
		}
		return flag;

	}


	/** This method will return a result list containing the tracker result corresponding to supplied queries.
	 * 
	 * @param queriesForTrackerCalculation
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static List<String> getTrackerResultList(List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> dataForTrackerCalculation, Bigquery bqConnection, String bqProjectID)
	{
		List<String> resultsList = new ArrayList<>();

		for (int i=0; i<dataForTrackerCalculation.size(); i++)
		{
			String results = "";

			try
			{
				/** Getting while tree map from list */
				TreeMap<String, TreeMap<String, TreeMap<String, String>>> parentMap = dataForTrackerCalculation.get(i);

				if(!parentMap.isEmpty())
				{
					/** Getting first child map */
					TreeMap<String, TreeMap<String, String>> firstChildMap = parentMap.firstEntry().getValue();

					/** Now getting results for each key of First Child Map = firstChildMap */
					for(Entry<String, TreeMap<String, String>> childEntrySet : firstChildMap.entrySet())
					{
						/** Getting second child map, it contains all the parameters to calculate tracker results */ 
						TreeMap<String, String> secondChildMap = childEntrySet.getValue();

						/** In case any device is attached, third party tracker will not be checked 
						 * because currently automation doesn't perform click on video ads in mobile device 
						 */
						String thirdPartyResult = "";
						if(Boolean.parseBoolean(secondChildMap.get("android")) || Boolean.parseBoolean(secondChildMap.get("iphone")))
						{
							results = results + "\n" + "Device ID - " +childEntrySet.getKey() + ":" + "\n";
						}
						else
						{
							/** Getting third party tracker result 
							 * Commenting it now.....
							 * */
							//thirdPartyResult = BQQueriesLib.MobileAds_ThirdPartyTrackerValidation(secondChildMap, bqConnection, bqProjectID);
						}

						/** Now get the serving result  */
						String vdopiaTrackerResult = BQQueriesLib.mobileAds_VdopiaTrackerValidationForUIOperations(secondChildMap, bqConnection, bqProjectID);

						/** If the received trackerresult is empty, then add skip */
						if(vdopiaTrackerResult.trim().isEmpty())
						{
							vdopiaTrackerResult = "SKIP: NO DATA RECEIVED FROM BQ. ";
						}

						/** Collecting all results */
						results = results + vdopiaTrackerResult + "\n" + thirdPartyResult;

						/** Get the other result and add that too in results */
						results = results + "\n" + secondChildMap.get("otherresult");
					}
				}
				else
				{
					results = "No Data Received For This Iteration To Calculate Trackers. ";
				}

			}catch(Exception e)
			{
				results = "Exception occurred for this iteration. ";
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting result for this iteration. ", e);
			}

			resultsList.add(results.trim());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Result For This Iteration: "+i+ ":   " +results);
		}

		return resultsList;
	}


	/** Get mobile ad serving trackers from bq.
	 * 
	 * @param queriesForTrackerCalculation
	 * @param bqConnection
	 * @param bqProjectID
	 * @param testResultFile
	 * @return 
	 */
	public static List<String> getMobileAdServingTrackersFromBQ(List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> dataForTrackerCalculation, 
			Bigquery bqConnection, String bqProjectID)
			{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting Mobile Ad Serving Results ....");

		List<String> resultsList= new ArrayList<>();
		try
		{
			/** Wait until a tracker is found in bq of last iteration, rule:
			 * if proceedTest = true, then look for ae for video ad, vi for banner ad of last iteration
			 * else look for ui of last iteration
			 * each query (for ui/vi) wait for 45 sec before retry
			 * total attempt is being = 20
			 * 
			 * Getting data of last test, if last test is a parent vast ad (adformat = video and
			 * actiontype = vastfeed) then dataForTrackerCalculation list needs to be iterated backwards 
			 * until it finds a valid ad for whose trackers were fired, in case of parent vast ad, trackers 
			 * are not fired, only vast xml conversion is checked.
			 */
			int validAdPosition = getValidAdPosition(dataForTrackerCalculation);

			/** Getting a map from the list located at validAdPosition received above */
			TreeMap<String, TreeMap<String, TreeMap<String, String>>> mapContainingValidAd = dataForTrackerCalculation.get(validAdPosition); 

			/** Navigating to the child map containing all the information about queries, channel id  etc..  */
			TreeMap<String, String> childMap = mapContainingValidAd.firstEntry().getValue().firstEntry().getValue();

			/** Getting required values from child map */
			boolean proceedTest = Boolean.parseBoolean(childMap.get("proceedtest"));
			String campaignID = childMap.get("campaignid");
			String channelID = childMap.get("channelid");
			String trackerStartTime = childMap.get("trackerstarttime");
			int attempt = 20;


			/** Consider a case where all the test contains only parent vast ads, in this case childMap will contain only 
			 * otherResults nothing else because parent vast ads are not served therefore campaign id, channel id 
			 * and trackerstarttime all will be null, therefore checking that before waiting for any vi/ui tracker */

			if(!(channelID == null && campaignID == null && trackerStartTime == null))
			{
				/** wait for vi tracker */
				if(proceedTest)
				{
					BQQueriesLib.waitForCampaignTracker("vi", campaignID, channelID, trackerStartTime, attempt, bqConnection, bqProjectID);
				}

				/** wait for ui tracker */
				else
				{
					BQQueriesLib.waitForUiTracker(channelID, trackerStartTime, attempt, bqConnection, bqProjectID);
				}
			}

			/** Getting result from BQ */
			resultsList = MobileAdServingUtilsLib.getTrackerResultList(dataForTrackerCalculation, bqConnection, bqProjectID);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while writing excel sheet. ", e);
		}		
		return resultsList;
			}


	/** This method will write the mobile ad serving results in excel sheet.
	 * 
	 * @param resultsList
	 * @param testResultFile
	 */
	public static void writeMobileAdServingTrackerResults(List<String> resultsList, File testResultFile)
	{
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Writing results in excel sheet: ");
			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Ending Mobile Ad Serving Results Writing Thread ....");

			/** Write html result also */
			writeHtmlResultForServing(testResultFile, "MobileAdServe");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while writing ad serving results. ", e);
		}
	}

	/** This method will iterate the supplied list backwards and find the position of a valid ad, 
	 * dataForTrackerCalculation has structure like: [time, [url/device_id, [ key, value ] ] ] 
	 * 
	 * @param dataForTrackerCalculation
	 * @return
	 */
	public static int getValidAdPosition(List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> dataForTrackerCalculation)
	{
		int position = 0;		
		int j = dataForTrackerCalculation.size()-1;

		for(int i=j; i>=0; i--)
		{
			TreeMap<String, TreeMap<String, TreeMap<String, String>>> hash = dataForTrackerCalculation.get(i);

			/** Navigating to the child map containing all the information about queries etc..  */
			TreeMap<String, String> childMap = hash.firstEntry().getValue().firstEntry().getValue();

			String adFormat = childMap.get("adformat");

			if(adFormat == null){
				adFormat = "";
			}

			String actionType = childMap.get("actiontype");

			if(actionType == null){
				actionType = "";
			}

			if(adFormat.equalsIgnoreCase("video") && actionType.equalsIgnoreCase("vastfeed"))
			{
				continue;
			}
			else if(adFormat.isEmpty() && actionType.isEmpty())
			{
				continue;
			}
			else
			{
				position = i;
				break;
			}
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found the last iteration containing a valid ad: "+position);
		return position;

	}


	/** This method will return the ad wait for supplied ad format in mili seconds.
	 * 
	 * @param adsDuration
	 * @param adFormat
	 * @return
	 */
	public static int getAdWaitSeconds(String adsDuration, String adFormat)  
	{
		int adWait = 0;
		try
		{
			/** Converting received adDuration to second */
			if(!(adsDuration == null || adsDuration.trim().isEmpty()))
			{
				adWait = (Integer.parseInt(adsDuration));
			}

			/** Get ad duration from config for non video ads */
			if (adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("html") 
					|| adFormat.equalsIgnoreCase("appinterstitial") || adFormat.equalsIgnoreCase("jsbanner")
					|| adFormat.equalsIgnoreCase("htmlinter"))
			{
				adWait = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
			}

			/** Get ad duration from config for video ads */
			else if(adFormat.equalsIgnoreCase("video") || adFormat.equalsIgnoreCase("inview") || 
					adFormat.equalsIgnoreCase("vdobanner") || adFormat.equalsIgnoreCase("leadervdo") ||
					adFormat.equalsIgnoreCase("vastfeed"))
			{
				if(adWait > 0)
				{
					/** putting this condition to avoid bad data like ad duration was saved 24049 for ad id = 462524 in production
					 * which was killing selendroid driver and thus failing subsequent tests */
					if(adWait > 45)
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received adwait from db is = "+adWait + ", reconsidering this = "+45);
						adWait = 45;
					}
				}
				else
				{
					adWait = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
				}
			}

		}catch(Exception e)
		{
			adWait = 30;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while  getting adwait, reassigning to 30 sec. ", e);
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : adWait is calculated = "+adWait + " for ad Format = "+adFormat);
		return adWait;
	}


	/** This method cleans all the process.
	 * 
	 * @param suiteStartTime
	 */
	public static void cleanProcesses()
	{
		String strProcess = "chromedriver";
		String strCommand;

		/** Close all the remaining instance of the browser. */
		if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1)
		{
			strCommand = "taskkill /F /IM " + strProcess + ".exe";
		}
		else
		{
			strCommand = "killall " + strProcess;
		}

		/** Running Command */
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running command to close Chromedriver instance if any remaining:");
		logger.info(strCommand);
		try {
			Runtime.getRuntime().exec(strCommand);
		} catch (IOException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error while cleaning up.", e);
		}
	}


	/** This method will write html result of ad serving 
	 * 
	 * @param resultSheetName
	 */
	public static void writeHtmlResultForServing(File testResultFile, String resultSheetName)
	{
		try
		{
			/** Updating results to main results sheet */
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());
			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);

			/** Converting excel into HTML */
			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");
		}
		catch(Exception e)
		{
			logger.error(e);
		}
	}


	/** This method will return the tree map containing all the required values to validate third party trackers in after suite.
	 * 
	 * @param expectedImpressionTracker
	 * @param expectedClickTracker
	 * @param channelID
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static TreeMap<String, String> setThirdPartyMapValues(String expectedImpressionTracker, String expectedClickTracker, String channelID, 
			String trackerStartTime, String trackerEndTime)
			{
		TreeMap<String, String> thirdPartyData = new TreeMap<>();

		String sqlQueryForUniqID = BQQueriesLib.queryForUniqID(channelID, trackerStartTime, trackerEndTime);

		thirdPartyData.put("sqlqueryforuniqid", sqlQueryForUniqID);
		thirdPartyData.put("trackerendtime", trackerEndTime);
		thirdPartyData.put("expectedthirdpartyclicktracker", expectedClickTracker);
		thirdPartyData.put("expectedthirdpartyimpressiontracker", expectedImpressionTracker);

		return thirdPartyData;
			}
}
