/**
 * Last Changes Done on 28 May, 2015 1:43:46 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose: 
 * The purpose of this package is to test all the mobile ad formats without using the UI
 * This package will run on the existing campaigns stored in the database
 * The flow of the execution and the logic is as explained below.
 * 
 * 1. First connect to the database Where the campaigns are stored
 * 2. Create a list of all ACTIVE campaigns and whose EXPIRY DATE is more than today
 *    One parameter that is currently being used in passing the publisher name
 *    and the campaigns of that publisher will be fetched. The publisher name shall 
 *    come from the configuration file. Configuration file is stored at location
 *    AUTOMATION_HOME/conf
 * 3. Store the list of campaigns with all other details (ad format,campaign id etc)
 *    in an excel file which will serve as the TEST DATA for the entire execution.
 *    This TEST DATA shall be overridden each time the suite is executed.
 * 4. Generate the AD Test URL's for all the AD's fetched. This shall be done based
 *    on the adformats. These shall be the http URLS.These URLS are then written into the 
 *    same TEST DATA excel file.
 * 5. Make a copy of the TEST DATA and use it for RESULTS population.
 * 6. Fetch individual URLs and Browse as HTM format in the Browser.
 * 7. Check for the Availability of the AD and than Validate the Trackers from Database.
 * 8. Update the TEST RESULT xls for the PASS/FAIL of the test. 
 * 
 * 
 * Progress: Migrating from mysql to big query, starting normal ad serving 
 * To Do: MobileAds_VdopiaTrackerValidationForUIOperations
 * 
 * */


package projects.adserve.mobileAdServe;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.UIOperations_MobileDeviceLib;
import vlib.XlsLib;
import projects.adserve.mobileAdServe.lib.MobileAdServingLib;
import projects.adserve.mobileAdServe.lib.MobileAdServingUtilsLib;
import projects.bq.*;


import com.mysql.jdbc.Connection;
import com.google.api.services.bigquery.Bigquery;


public class MobileAdServingTests 
{
	private static File testResultFile;
	String testDataFile;
	String testDataFile_ReRun;
	Connection serveConnection;
	static String serveBrowser;
	private static List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> dataForTrackerCalculation = new ArrayList<>();

	boolean androidDeviceConnected;
	boolean iphoneDeviceConnected;
	WebDriver driver;
	String ReRun_tcdata_FileName = "tc_MobileAdServe_ReRun.xls";
	boolean isFreshRun;
	boolean isDeviceConnected;
	static int proxyServerPort;

	private static Bigquery bqConnection;
	private static String bqProjectID;

	Connection mySqlConnection;

	/** This variable will be used in after suite while ad serving writing results */
	private static boolean isMobileAdServingTestSelected = false; 


	static Logger logger = Logger.getLogger(MobileAdServingTests.class.getName());

	/**This is the before test setup
	 * @param browser
	 */
	@Parameters({"browser"})
	@BeforeClass
	public void beforeTest(String browser) 
	{
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			serveBrowser = browser;

			proxyServerPort = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("proxyServerPort").toString());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Proxy Server Port: " +proxyServerPort);

			/** Checking if any Android and Iphone devices attached to computer. */	
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking if any device connected...");
			androidDeviceConnected = UIOperations_MobileDeviceLib.ifAndroidDeviceConnected();

			String iphoneIPs = MobileTestClass_Methods.propertyConfigFile.getProperty("iphoneDeviceIP").toString();
			iphoneDeviceConnected = UIOperations_MobileDeviceLib.ifiPhoneConnected(iphoneIPs);

			/** Start selendroid server if android device is connected */
			if(androidDeviceConnected)
			{
				UIOperations_MobileDeviceLib.launchSelendroidServer();
			}
			
			if(androidDeviceConnected || iphoneDeviceConnected)
			{
				isDeviceConnected = true;

				/** Initializing bq constructor */
				new MobileTestClass_Methods(isDeviceConnected);
				new BQQueriesLib(isDeviceConnected);
			}
			else
			{
				isDeviceConnected = false;
			}

			if(TestSuiteClass.isFresh)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** Starting Test: " +" MobileAdServingTests ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");

				/** Creating mysql db connection */
				mySqlConnection =  MobileTestClass_Methods.CreateSQLConnection();

				/** Creating Big query connection */
				setBqConnection(new BQHandler().createBqConnection());

				/** Setting project id based on current test environment */
				String currentEnv = MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString().trim();
				if(currentEnv.equalsIgnoreCase("qa"))
				{
					setBqProjectID(MobileTestClass_Methods.propertyConfigFile.getProperty("qaBigQueryProjectId").toString());
				}
				else
				{
					setBqProjectID(MobileTestClass_Methods.propertyConfigFile.getProperty("prodBigQueryProjectId").toString());
				}

				/** Get Test Data Excel Sheet */
				testDataFile = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/mobileAdServe/DataToFormURL/MobileAdServe_TestDataToFormURL.xls").toString();

				/** Get test data from mysql db */
				String [][] recordOutput = MobileTestClass_Methods.GetInputDataFromMySQL(mySqlConnection, "iphone");

				/** Write test data in excel sheet */
				FileLib.WritingMySQLRecordsInExcelSheet(testDataFile, recordOutput);
				FileLib.WritingTestURLInExcelSheet(testDataFile);

				/** Sending html file to server for inview ads */
				if(isDeviceConnected)
				{
					MobileAdServingUtilsLib.sendHtmlFileToServerForInviewAd(new File(testDataFile));
				}

				/** Copy Test Data File In Test Result Folder */	
				String sourceFileNameWithLocation = testDataFile;
				String destinationFileLocationWithOutExtension = TestSuiteClass.AUTOMATION_HOME.concat("/results/mobileAdServe/Test_Results/").concat("MoblieAdServe_TestResults").toString();
				setTestResultFile(FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension));
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** Starting ReRun Test: " +" MobileAdServingTests ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");

				testDataFile = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/mobileAdServe/DataToFormURL/MobileAdServe_TestDataToFormURL_ReRun.xls").toString();

				/** Copy Test Data File In Test Result Folder */	
				String sourceFileNameWithLocation = testDataFile;
				String destinationFileLocationWithOutExtension = TestSuiteClass.AUTOMATION_HOME.concat("/results/mobileAdServe/Test_Results/").concat("MoblieAdServe_TestResults_ReRun").toString();
				setTestResultFile(FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension));
			}

			/** Setting up browser only if there is no device connected */
			if(!isDeviceConnected)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up browser ... ");
				/** adding user agent to simulate mobile serving  */
				String userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Mobile/12A4345d Safari/600.1.4";
				String[] capabilities = {"--user-agent="+userAgent, "--start-maximized"};
				driver = MobileTestClass_Methods.WebDriverSetUp(browser, capabilities);
			}
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by Method MobileAdServingTest. ", e);
		}
	}


	/**
	 * This is the data provider for the below test.
	 * 
	 * @return
	 * @throws RowsExceededException
	 * @throws WriteException
	 * @throws BiffException
	 * @throws IOException
	 */
	@DataProvider(name="FetchTestURLs")
	public String[][] getTestDataForAdServing() 
	{
		try
		{
			String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(testDataFile, "Ad_Format", "Test_URLs", "Campaign_ID", "Channel_ID","Ads_Duration",
					"Custom_Details","Tracker_URL", "Action_Type", "Destination_URL", "CompanionBanner", "Channel_Settings");
			return arrTestURL;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred during setting up Data Provider: ", e);
			return null;
		}
	}


	/**  This method runs test.
	 * 
	 * @param adFormat
	 * @param adURL
	 * @param campaignID
	 * @param channelID
	 * @param adsDuration
	 * @param custom_details
	 * @param expectedTrackerURLs
	 * @param actionType
	 * @param destinationURL
	 * @param companionBanner
	 */
	@Test(dataProvider = "FetchTestURLs")
	public void mobileAdServeTest(String adFormat, String adURL, String campaignID, String channelID, String adsDuration, 
			String custom_details, String expectedImpressionTrackerURLs, String actionType, String destinationURL, String companionBanner, String channelSettings)
	{
		TreeMap<String, TreeMap<String, TreeMap<String, String>>> mobileServingData = new TreeMap<>();

		String results = "";
		try
		{
			mobileServingData = MobileAdServingLib.mobileAdServe("direct", driver, adFormat, adURL, campaignID, channelID, adsDuration, expectedImpressionTrackerURLs, actionType, 
					androidDeviceConnected, iphoneDeviceConnected, custom_details, destinationURL, companionBanner, channelSettings, 
					getBqConnection(), getBqProjectID(), mySqlConnection);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception " ,e);
			results = "FAIL" + results + "\n" + e.getMessage();
		}
		finally
		{
			/** Adding queries and other serving data of each iteration 
			 * into a list to be executed at afterTest() */
			dataForTrackerCalculation.add(mobileServingData);
		}
	}


	/** After test
	 * 
	 * @throws RowsExceededException
	 * @throws WriteException
	 * @throws BiffException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@AfterClass
	public void afterClass() 
	{
		try
		{
			String resultSheetName;

			// this is for the case where test is executed first time not for Re-run
			if(TestSuiteClass.isFresh)
			{
				resultSheetName = "MobileAdServe";
			}
			else
			{
				resultSheetName = "MobileAdServe_ReRun";
			}

			File f = new File(testDataFile);
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);

			if(driver != null)
			{
				driver.quit();
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** Test: " +" MobileAdServingTests ****** " +" Ended at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********** Mobile AdServing Results Will Be Generated In A While ..... ****** ");

			/** setting variable isMobileAdServingTestSelected = true in after class so that mobile ad serving
			 * results are written only when this suite is selected. 
			 */
			isMobileAdServingTestSelected = true;

			/* Commenting re-run code 
			if((TestSuiteClass.isFresh) && (result.getFailStatusForTestCase(Data)))
			{
				String testDataFile_ReRun = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/mobileAdServe/DataToFormURL/MobileAdServe_TestDataToFormURL_ReRun.xls").toString(); 
				result.createReRunTestCase(testDataFile_ReRun,resultSheetName,Data);
				String className = getClass().getName();
				TestSuiteClass.rerunClassNames.put(className,null);
			}
			 */
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception at the end of Mobile Ad Serve Test: " ,e);
		}
	}


	/** Getter dataForTrackerCalculation
	 * @return
	 */
	public static List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> getDataForTrackerCalculation() {
		return dataForTrackerCalculation;
	}


	/** Setter dataForTrackerCalculation
	 * @param dataForTrackerCalculation
	 */
	public void setDataForTrackerCalculation(
			List<TreeMap<String, TreeMap<String, TreeMap<String, String>>>> dataForTrackerCalculation) {
		MobileAdServingTests.dataForTrackerCalculation = dataForTrackerCalculation;
	}


	/** Getter bqConnection
	 * @return
	 */
	public static Bigquery getBqConnection() {
		return bqConnection;
	}


	/** Setter bqConnection
	 * @param bqConnection
	 */
	public static void setBqConnection(Bigquery bqConnection) {
		MobileAdServingTests.bqConnection = bqConnection;
	}


	/** Getter bqProjectID
	 * @return
	 */
	public static String getBqProjectID() {
		return bqProjectID;
	}


	/** Setter bqProjectID
	 * @param bqProjectID
	 */
	public static void setBqProjectID(String bqProjectID) {
		MobileAdServingTests.bqProjectID = bqProjectID;
	}


	/**
	 * Getter testResultFile.
	 * 
	 * @return
	 */
	public static File getTestResultFile() {
		return testResultFile;
	}


	/** Setter testResultFile
	 * @param testResultFile
	 */
	public void setTestResultFile(File testResultFile) {
		MobileAdServingTests.testResultFile = testResultFile;
	}


	/** Getter isMobileAdServingTestSelected
	 * @return
	 */
	public static boolean getIsMobileAdServingTestSelected(){
		return isMobileAdServingTestSelected;
	}

}
