/**
 * Last Changes Done on 25 sep, 2015 1:43:46 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose: This class contains the test to validate the tracker url in response, request will send using https:// and
 * expected tracker url will be checked in response those all should start with https:// 
 * */


package projects.adserve.mobileAdServe;


import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.SaveResultsToMySql;
import vlib.XlsLib;
import vlib.httpClientWrap;
import com.mysql.jdbc.Connection;




// TODO: Auto-generated Javadoc
public class MobileAdServing_HttpsCheck 
{
	private static File testResultFile;
	String testDataFile;
	private static List<String> resultsList = new ArrayList<>();
	Connection mySqlConnection;
	WebDriver driver;

	static Logger logger = Logger.getLogger(MobileAdServing_HttpsCheck.class.getName());


	/**
	 * This is the before test setup.
	 * 
	 * @param browser
	 */
	@Parameters({"browser"})
	@BeforeClass
	public void beforeTest(String browser) 
	{
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** Starting Test: " +" MobileAdServing - Https Check ****** " +" at time: " + MobileTestClass_Methods.DateTimeStamp() + " *************");

			/** Creating mysql db connection */
			mySqlConnection =  MobileTestClass_Methods.CreateSQLConnection();

			/** Get Test Data Excel Sheet */
			testDataFile = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/adserve/mobileAdServe/DataToFormURL/MobileAdServe_HttpsCheck.xls").toString();

			/** Get test data from mysql db */
			String [][] recordOutput = MobileTestClass_Methods.GetInputDataFromMySQL(mySqlConnection, "iphone");

			/** Write test data in excel sheet */
			FileLib.WritingMySQLRecordsInExcelSheet(testDataFile, recordOutput);
			FileLib.WritingTestURLInExcelSheet(testDataFile);

			/** Copy Test Data File In Test Result Folder */	
			String sourceFileNameWithLocation = testDataFile;
			String destinationFileLocationWithOutExtension = TestSuiteClass.AUTOMATION_HOME.concat("/results/mobileAdServe/Test_Results/").concat("HttpsCheck_Results").toString();
			testResultFile = FileLib.CopyExcelFile(sourceFileNameWithLocation, destinationFileLocationWithOutExtension);

			driver = MobileTestClass_Methods.WebDriverSetUp(browser, null);
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred in before test. ", e);
		}
	}


	/**
	 * This is the data provider for the below test.
	 * @return
	 */
	@DataProvider(name="FetchTestURLs")
	public String[][] getTestDataForAdServing() 
	{
		try
		{
			String [][] arrTestURL = FileLib.FetchDataFromExcelSheet(testDataFile, "Test_URLs");
			return arrTestURL;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred during setting up Data Provider: ", e);
			return null;
		}
	}


	/**
	 * This method runs test.
	 * 
	 * @param adURL
	 */
	@Test(dataProvider = "FetchTestURLs")
	public void mobileAdServeTest(String adURL)
	{
		String results = "";
		try
		{	
			/** replacing output with space so that default output response will be in js */ 
			adURL = adURL.replace("output", "");

			driver.get(adURL);
			String response = httpClientWrap.sendGetRequest(adURL);
			results = parseResponse(response);
			logger.info(results);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception " ,e);
			results = "FAIL" + results + "\n" + e.getMessage();
		}
		finally
		{
			resultsList.add(results);
		}
	}


	/**
	 * after test.
	 */
	@AfterClass
	public void afterClass() 
	{
		try
		{
			/** Putting total test case count and sheet name in totalTC map */
			File f = new File(testResultFile.toString());
			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			TestSuiteClass.totalTC.put("HttpsCheck", totalTestCase);

			if(driver!=null)
			{
				driver.quit();
			}

			/** write test results */
			MobileTestClass_Methods.WritingTestResultsInExcelSheet(testResultFile, resultsList);

			/** Updating results to main results sheet */
			XlsLib result = new XlsLib();
			String Data[][] = result.dataFromExcel(testResultFile.toString());
			result.updateResultInNewSheet(TestSuiteClass.executionResult, "HttpsCheck", Data);

			/** Save results into mysql database */
			SaveResultsToMySql.saveMobileAdServingResults(testResultFile.toString(), TestSuiteClass.suiteStartTime, TestSuiteClass.executedOnMachine, TestSuiteClass.environment, "HttpsCheck");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception at the end of https check Test: " ,e);
		}
	}


	/** getting those urls which are not started with https.
	 * 
	 * @param response
	 * @return
	 */
	public String parseResponse(String response)
	{
		if(response.isEmpty())
		{
			return "Skip: NO RESPONSE RECEIVED";
		}
		else
		{
			List<String> nonHttpsUrl = new ArrayList<String>();

			String regex = "http:\\\\/\\\\/([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*\\(\\)_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?";
			Pattern pattern = Pattern.compile(regex);

			Matcher match = pattern.matcher(response);

			if(match.find())
			{
				while(match.find())
				{
					String url = match.group();

					/** check only for tracker and cdn urls */
					if(url.contains("iphonetrk") || url.contains("cdn"))
					{
						if(!url.startsWith("https"))
						{
							nonHttpsUrl.add(url);
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NON-HTTPS url: "+url);
						}
					}
				}

				/** forming results */
				if(nonHttpsUrl.isEmpty())
				{
					return "Pass: all urls in received js response are started with https. ";
				}
				else
				{
					return "Fail: These urls are not started with https: "+nonHttpsUrl.toString();
				}
			}
			else
			{
				return "Skip: No http://*.* pattern found in response.";
			}

		}
	}

}