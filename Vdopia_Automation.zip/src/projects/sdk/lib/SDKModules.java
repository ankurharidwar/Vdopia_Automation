package projects.sdk.lib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;



public class SDKModules
{

	WebDriver driver;
	JSONObject jsonTestData;
	JSONObject deviceJsonObject;

	ObjectsHandler objHandler = new ObjectsHandler();
	Logger logger = Logger.getLogger(SDKModules.class.getName());

	/** This constructor will set all the variables - to be used all over the class.
	 *
	 * @param driver
	 * @param jsonTestData
	 * @param deviceJsonObject
	 */
	SDKModules(WebDriver driver, JSONObject jsonTestData, JSONObject deviceJsonObject)
	{
		this.driver = driver;
		this.jsonTestData = jsonTestData;
		this.deviceJsonObject = deviceJsonObject;
	}

	public JSONObject check_template()
	{
		String result;

		result = "SKIP: CONSTRUCTION IN PROGRESS .";

		/** putting result in device json object */
		deviceJsonObject = SDKCommonUtils.putDeviceOtherResult(deviceJsonObject, result);

		/** navigate back to main screen */
		objHandler.navigateBack(driver);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : check_template result: "+result);
		return deviceJsonObject;
	}

	public JSONObject check_talk2me()
	{
		String result;

		result = "SKIP: CONSTRUCTION IN PROGRESS .";

		/** putting result in device json object */
		deviceJsonObject = SDKCommonUtils.putDeviceOtherResult(deviceJsonObject, result);

		/** navigate back to main screen */
		objHandler.navigateBack(driver);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : check_talk2me result: "+result);
		return deviceJsonObject;
	}

	/** Check if skip button is displayed
	 * @return
	 */
	public JSONObject check_skip()
	{
		String result;

		result = "SKIP: CONSTRUCTION IN PROGRESS .";

		/** putting result in device json object */
		deviceJsonObject = SDKCommonUtils.putDeviceOtherResult(deviceJsonObject, result);

		/** navigate back to main screen */
		objHandler.navigateBack(driver);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : check_skip result: "+result);
		return deviceJsonObject;
	}

	/** Check serving module - get all applicable trackers + check if main content is displayed -- after max wait of 35 sec
	 * @return
	 */
	public JSONObject check_serving()
	{
		String result = "";

		try{
			String sdkAdFormat = jsonTestData.getString("adformat");

			/** getting standard ad format like - banner, video, interstitial with respect to sdk ad format */
			String respectiveStandardAdformat = SDKCommonUtils.getAdFormatMappings(sdkAdFormat);
			result = result + new SDKAdHandler().adformatHandler(driver, sdkAdFormat, respectiveStandardAdformat);

			/** save serving results in json object */
			deviceJsonObject = SDKCommonUtils.putDeviceOtherResult(deviceJsonObject, result);

			/** navigate back to main screen */
			objHandler.navigateBack(driver);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : check_serving result: "+result);
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}

		return deviceJsonObject;
	}
}

