/**
 * Last Changes Done on 10 Dec, 2015 5:22:32 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the logic of calculating trackers from big query and logic is:
 * first all tests has to be completed then just before writing the results in excel sheet, this class is called, this class iteartes 
 * the received whole list of json object and get the tracker queries stored in devicedata json array of received json objects, executes queries
 * and stores the result in the same json object list and return it. 
 */
package projects.sdk.lib;


import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;

import com.google.api.services.bigquery.Bigquery;

import projects.bq.BQQueriesLib;
import projects.sdk.SDKAdServingTest;


public class SDKTrackerHandler 
{

	Logger logger = Logger.getLogger(SDKTrackerHandler.class.getName());


	/** This method will iterate the supplied list of json objects backwards and find out the location 
	 * where ifproceed is true. 
	 * 
	 * @param sdkResultList
	 * @return
	 */
	public int getLastValidAdPosition(List<JSONObject> sdkResultList)
	{
		for (int i=sdkResultList.size()-1; i>=0; i--)
		{
			try {
				if(sdkResultList.get(i).getString("ifproceed").equalsIgnoreCase("true"))
				{
					return i;
				}
			} catch (JSONException e) {
				logger.error(e.getMessage());
			}
		}
		return 0;
	}


	/** wait for vi tracker of last valid iteration of supplied list of json.
	 * 
	 * @param bqConnection
	 * @param bqProjectID
	 * @param sdkResultList
	 * @return
	 */
	public boolean waitForTracker(Bigquery bqConnection, String bqProjectID, List<JSONObject> sdkResultList)
	{
		boolean flag = false;
		try
		{
			/** get last valid position */
			int validPos = getLastValidAdPosition(sdkResultList);

			/** get json object of above position */
			JSONObject jsonObj = sdkResultList.get(validPos);
			String channelID = jsonObj.getString("channelid");

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : waiting for tracker started at position: "+validPos + " - found json: "+jsonObj);

			/** get devicedata json array of above json object -- and get the first json of this array to wait for tracker */
			String trackerStartTime = jsonObj.getJSONArray("devicedata").getJSONObject(0).getString("trackerstarttime");
			String trackerEndTime = jsonObj.getJSONArray("devicedata").getJSONObject(0).getString("trackerendtime");

			flag = BQQueriesLib.waitForVdopiaTracker("vi", channelID, trackerStartTime, trackerEndTime, 20, bqConnection, bqProjectID);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		return flag;

		/** wait for ui tracker -- to be implemented later on */
		//BQQueriesLib.waitForUiTracker(channelID, trackerStartTime, attempt, bqConnection, bqProjectID);
	}


	/** Execute all the device queries and save the query result in otherresult key of all json objects.
	 * 
	 * @param bqConnection
	 * @param bqProjectID
	 * @param sdkResultList
	 * @return
	 */
	public List<JSONObject> getDeviceTrackerResult(Bigquery bqConnection, String bqProjectID, List<JSONObject> sdkResultList)
	{
		try
		{
			/** execute device queries if trackers are found in BQ */
			boolean flag = waitForTracker(bqConnection, bqProjectID, sdkResultList);
			if(flag)
			{
				/** iterate the received result list containing json objects */
				for(int i=0; i<sdkResultList.size(); i++)
				{
					/** iterate the devicedata json array and execute the received trackerquery and put the query result in otherresult key */
					for(int j=0; j<sdkResultList.get(i).getJSONArray("devicedata").length(); j++)
					{
						/** get device json object from devicedata json array and get query, adformat etc. */
						String adFormat = sdkResultList.get(i).getString("adformat").trim();
						/** get the standard adformat corresponding to received sdk adformat*/
						adFormat = SDKCommonUtils.getAdFormatMappings(adFormat);

						String trackerQuery = "";
						try{trackerQuery = sdkResultList.get(i).getJSONArray("devicedata").getJSONObject(j).getString("trackerquery");}catch(JSONException jx){}

						String queryResult = getExecutionResult(trackerQuery, adFormat);

						/** append tracker result in existing otherresult key */
						try{
							String otherResult = sdkResultList.get(i).getJSONArray("devicedata").getJSONObject(j).getString("otherresult");
							sdkResultList.get(i).getJSONArray("devicedata").getJSONObject(j).put("otherresult", otherResult+"\n"+queryResult);
						}catch(JSONException e){
							sdkResultList.get(i).getJSONArray("devicedata").getJSONObject(j).put("otherresult", queryResult);
						}
					}
				}
			}
			else
			{
				// NEED TO HANDLE -- PUT "NO SERVING DATA RECEIVED IN BQ" IN OTHERRESULT FOR ALL DEVICE RESULTS
			}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		return sdkResultList;
	}


	/**
	 * execute device tracker queries and get results.
	 * 
	 * @param trackerQuery
	 * @param adFormat
	 * @return
	 */
	public String getExecutionResult(String trackerQuery, String adFormat)
	{
		if(!trackerQuery.isEmpty()){
			Bigquery bqConnection = SDKAdServingTest.getBqConnection();
			String bqProjectID = SDKAdServingTest.getBqProjectID();

			String result = BQQueriesLib.mobileAds_VdopiaTrackerValidationForUIOperations(trackerQuery, trackerQuery, adFormat, bqConnection, bqProjectID);
			return result;
		}
		else{
			return "";
		}
	}

}
