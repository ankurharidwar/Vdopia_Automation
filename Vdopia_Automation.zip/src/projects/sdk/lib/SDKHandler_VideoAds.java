/**
 * Last Changes Done on 17 Dec, 2015 11:52:28 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: THIS CLASS CONTAINS ALL THE SDK VIDEO ADS, CREATING A SEPARATE CLASS - GIVES US MORE GRANULARITY.
 */
package projects.sdk.lib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;


public class SDKHandler_VideoAds 
{
	WebDriver driver;
	SDKHandler_NonVideoAds nonVideoHandler;
	ObjectsHandler objectHandler;
	String sdkAdFormat;

	static Logger logger = Logger.getLogger(SDKHandler_VideoAds.class.getName());

	SDKHandler_VideoAds(WebDriver driver, String sdkAdFormat)
	{
		this.driver = driver;
		this.sdkAdFormat = sdkAdFormat;
		this.nonVideoHandler = new SDKHandler_NonVideoAds();
		this.objectHandler = new ObjectsHandler();
	}

	/** Validate serving for nonclickable template ad.
	 * 
	 * @return
	 */
	public String nonclickable_template()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_NonClickable";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for main content to appear */	
		result = result + "\n" + nonVideoHandler.prerollMainContentCheck(driver, viewLocator);

		return result;
	}

	/** Validate serving of skip template ad.
	 * 
	 * @return
	 */
	public String skip_template()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_StandardSkiptemplate";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for main content to appear */	
		result = result + "\n" + nonVideoHandler.prerollMainContentCheck(driver, viewLocator);

		return result;
	}

	/** Validate serving of talk2me template ad.
	 * 
	 * @return
	 */
	public String talk2me_template()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_Talk2metemplate";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for main content to appear */	
		result = result + "\n" + nonVideoHandler.prerollMainContentCheck(driver, viewLocator);

		return result;
	}

	/** Validate serving of slideout template ad.
	 * 
	 * @return
	 */
	public String slideout_template()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_SlideOutbannertemplate";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for main content to appear */	
		result = result + "\n" + nonVideoHandler.prerollMainContentCheck(driver, viewLocator);

		return result;
	}

	/** Validate serving of swipetoreveal template ad.
	 * 
	 * @return
	 * @throws InterruptedException 
	 */
	public String swipetoreveal_template() throws InterruptedException
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_SwipetoRevealtemplate";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** wait for swipe to reveal template -- swipe to reveal template appears in webview therefore driver has to switch context to webview first
		 * and then wait for the template and then scroll it to right -- (based on configuration) */
		String swipeBannerTemplate = "banner_PrerollAds_SwipetoRevealtemplate";
		//		objectHandler.setDriverContext(driver, "webview");
		//		new ApplyRules().applyRule(driver, swipeBannerTemplate);

		/*********************************************************/

		By byLocator = objectHandler.getByLocator(driver, swipeBannerTemplate);
		if(objectHandler.waitForElement(driver, byLocator, 35, new NoSuchElementException("")))
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Swipe template is visible. ");
			result = result + "\nPASS: Swipe to reveal banner is displayed. ";

			WebElement swipeTemplate = driver.findElement(byLocator);

			Thread.sleep(2000);
			((AndroidDriver<?>)driver).swipe(swipeTemplate.getLocation().x, swipeTemplate.getLocation().y, swipeTemplate.getLocation().x+swipeTemplate.getSize().getWidth()/2, swipeTemplate.getLocation().y, 2);
			Thread.sleep(2000);
		}
		else
		{
			result = result + "\nFAIL: Swipe to reveal banner wasn't displayed. ";
		}		

		return result;
	}

	/** Validate serving of multithumbnail template ad.
	 * 
	 * @return
	 */
	public String multithumbnail_template()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_PrerollAds_MultiThumbnailtemplate";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for main content to appear */	
		result = result + "\n" + nonVideoHandler.prerollMainContentCheck(driver, viewLocator);

		return result;
	}

	/** Validate serving of inview_scrollview ad
	 * 
	 * @return
	 */
	public String inview_scrollview()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_InViewInLine_ScrollViewImplementation";

		/** Scroll until ad view found then click on view and check landing page and after this again scroll view to complete video */
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** scrolling screen again to play the whole ad, moving driver to webview to perform scroll */
		objectHandler.switchDriverContext(driver, sdkAdFormat);
		new ApplyRules().applyRule(driver, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of mrect_inview_video ad
	 * 
	 * @return
	 */
	public String mrect_inview_video()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_MREC_InViewVDO";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of exp_banner_min_video ad
	 * 
	 * @return
	 */
	public String exp_banner_min_video()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_ExpandableBanner_MiniVDO";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of exp_banner_med_video ad
	 * 
	 * @return
	 */
	public String exp_banner_med_video()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_MREC_InViewVDO";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */

		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of inview_tableview ad
	 * 
	 * @return
	 */
	public String inview_tableview()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_InViewInLine_TableViewImplementation";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of full_screen_max_video ad
	 * 
	 * @return
	 */
	public String full_screen_max_video()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_Fullscreen_MaxVDO";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

	/** Validate serving of leaderboard_video ad
	 * 
	 * @return
	 */
	public String leaderboard_video()
	{
		/** wait for ad view, if found then click on it, go to landing page and perform landing page validation */
		String viewLocator = "view_LeaderboardTablet_LeaderVDO";
		String result = nonVideoHandler.landingPageFlow(driver, sdkAdFormat, viewLocator);

		/** finally wait for completion of ad */	
		try {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of ad ... ");
			Thread.sleep(35000);
		} catch (InterruptedException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting error when waiting for complition of ad", e);
		}
		return result;
	}

}
