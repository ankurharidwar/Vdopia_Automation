package projects.sdk.lib;

import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;






public class ApplyRules 
{
	Logger logger = Logger.getLogger(ApplyRules.class.getName());

	public boolean applyRule(WebDriver driver, String viewLocator)
	{
		try
		{
			if(viewLocator.equalsIgnoreCase("view_Fullscreen_Interstitial"))
			{
				Thread.sleep(2000);
			}
			else if(viewLocator.equalsIgnoreCase("view_InViewInLine_ScrollViewImplementation"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Script: ");
				Thread.sleep(1000);

				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", driver.findElement(new ObjectsHandler().getByLocator(driver, viewLocator)));

				Thread.sleep(1000);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Script Executed: ");
			}
			else if(viewLocator.equalsIgnoreCase("banner_PrerollAds_SwipetoRevealtemplate"))
			{
				int count = 0;

				while(true)
				{
					try{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking swipe banner template, attempt: "+count);
						driver.findElement(new ObjectsHandler().getByLocator(driver, viewLocator));

						break;
					}catch(NoSuchElementException n){
						logger.info(n.getMessage());

						Thread.sleep(1500);
					}

					count ++;
				}

			}
			return true;
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
			return false;
		}
	}


	/**
	 *  this apply rule method is to exclude click action on interstitial ads -- call this method for interstitial ad only.
	 * @param viewLocator
	 * @return
	 */
	public boolean applyRule(String viewLocator)
	{
		if(viewLocator.equalsIgnoreCase("view_Fullscreen_Interstitial"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
