/**
 * Last Changes Done on 9 Nov, 2015 11:49:20 AM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains only app integration method and the strings to be written in ApiKey.java
 * for LW SDK and MainActivity.java for MP SDK. in case of change in integrations, change here only. 
 */

package projects.sdk.lib;


import java.io.File;
import java.io.IOException;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.json.JSONObject;


import vlib.ExecuteCommands;
import vlib.FileLib;




public class AppIntegrationLib 
{
	Logger logger = Logger.getLogger(AppIntegrationLib.class.getName());

	
	/** Create apk file for sdk android project, this is a single method to be used for sample app set up for SDK Android.
	 * 
	 * @param androidHome
	 * @param api_KEY_NON_CLICKABLE_PREROLL
	 * @param api_KEY_STANDARD_SKIP
	 * @param api_KEY_TALK2ME
	 * @param api_KEY_SLIDEOUT
	 * @param api_KEY_SWIPE_TO_REVEAL
	 * @param api_KEY_MULTI_THUMBNAIL
	 * @return
	 */
	public File getAPK_AndroidSDK(String androidHome, 
			String api_KEY_STATIC_BANNER, String api_KEY_ANIMATED_BANNER, String api_KEY_MRECT_STATIC_BANNER,
			String api_INVIEW_SCROLLVIEW, String api_KEY_MRECT_INVIEW_VIDEO, String api_KEY_EXP_BANNER_MIN_VIDEO, String api_KEY_EXP_BANNER_MED_VIDEO,
			String api_KEY_INVIEW_TABLEVIEW, String api_KEY_FULL_SCREEN_INTERSTITIAL, String api_KEY_FULL_SCREEN_STATIC_BANNER, String api_KEY_FULL_SCREEN_MAX_VIDEO,
			String api_KEY_LEADERBOARD_VIDEO, String api_KEY_LEADERBOARD_STATIC_BANNER, String api_KEY_LEADERBOARD_ANIMATED_BANNER,
			String api_KEY_NONCLICKABLE_TEMPLATE, String api_KEY_SKIP_TEMPLATE, String api_KEY_TALK2ME_TEMPLATE, 
			String api_KEY_SLIDEOUT_TEMPLATE, String api_KEY_SWIPETOREVEAL_TEMPLATE, String api_KEY_MULTITHUMBNAIL_TEMPLATE)
	{
		File apkFile = null;
		try{
			/** Get APK File Name. */
			String androidExpectedAPKFileName = "app-debug.apk";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Expected Android APK File Name: "+androidExpectedAPKFileName);				

			String androidProject = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/android/VdopiaSDKSample_StandAlone");

			/** copy local local.properties file to android project root location */
			FileUtils.copyFile(new File(TestSuiteClass.AUTOMATION_HOME.concat("/tpt/android_sdk_prerequisite/local.properties")), new File(androidProject+"/local.properties"));

			/** Set local.properties file, in windows local.properties has content like: sdk.dir=D\:\\android_sdk_windows\\sdk */
			if(System.getProperty("os.name").toLowerCase().matches("^windows.*"))
			{
				androidHome = androidHome.replace("\\", "\\\\").replace(":", "\\:"); 
			}
			FileLib.ReplaceSingleLineInFile(androidProject+"/local.properties", "sdk.dir", "sdk.dir=" + androidHome);

			/** Get the ApiKey.java file */  
			String apikeyFile = androidProject.concat("/app/src/main/java/com/vdopia/sample/ApiKey.java");

			/** Write MainActivity.java file for each iteration */
			createApiKeyFileContent_SDKAndroid(apikeyFile,
					api_KEY_STATIC_BANNER,  api_KEY_ANIMATED_BANNER,  api_KEY_MRECT_STATIC_BANNER,
					api_INVIEW_SCROLLVIEW,  api_KEY_MRECT_INVIEW_VIDEO,  api_KEY_EXP_BANNER_MIN_VIDEO,  api_KEY_EXP_BANNER_MED_VIDEO,
					api_KEY_INVIEW_TABLEVIEW,  api_KEY_FULL_SCREEN_INTERSTITIAL,  api_KEY_FULL_SCREEN_STATIC_BANNER,  api_KEY_FULL_SCREEN_MAX_VIDEO,
					api_KEY_LEADERBOARD_VIDEO,  api_KEY_LEADERBOARD_STATIC_BANNER,  api_KEY_LEADERBOARD_ANIMATED_BANNER,
					api_KEY_NONCLICKABLE_TEMPLATE,  api_KEY_SKIP_TEMPLATE,  api_KEY_TALK2ME_TEMPLATE, 
					api_KEY_SLIDEOUT_TEMPLATE,  api_KEY_SWIPETOREVEAL_TEMPLATE,  api_KEY_MULTITHUMBNAIL_TEMPLATE
					);

			/** Create apk file */
			apkFile = SDKSetUp_Android.createAndroidApk(androidProject, androidExpectedAPKFileName);

		}catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while setting up files for MP SDK project files.", t);
		}

		return apkFile;
	}

	/** This method will write the content in MainActivity.java file which contains all the api keys.
	 * 
	 * @param apikeyFileLocation
	 * @param api_KEY_NON_CLICKABLE_PREROLL
	 * @param api_KEY_STANDARD_SKIP
	 * @param api_KEY_TALK2ME
	 * @param api_KEY_SLIDEOUT
	 * @param api_KEY_SWIPE_TO_REVEAL
	 * @param api_KEY_MULTI_THUMBNAIL
	 */
	public void createApiKeyFileContent_SDKAndroid(String apikeyFileLocation, 
			String api_KEY_STATIC_BANNER, String api_KEY_ANIMATED_BANNER, String api_KEY_MRECT_STATIC_BANNER,
			String api_INVIEW_SCROLLVIEW, String api_KEY_MRECT_INVIEW_VIDEO, String api_KEY_EXP_BANNER_MIN_VIDEO, String api_KEY_EXP_BANNER_MED_VIDEO,
			String api_KEY_INVIEW_TABLEVIEW, String api_KEY_FULL_SCREEN_INTERSTITIAL, String api_KEY_FULL_SCREEN_STATIC_BANNER, String api_KEY_FULL_SCREEN_MAX_VIDEO,
			String api_KEY_LEADERBOARD_VIDEO, String api_KEY_LEADERBOARD_STATIC_BANNER, String api_KEY_LEADERBOARD_ANIMATED_BANNER,
			String api_KEY_NONCLICKABLE_TEMPLATE, String api_KEY_SKIP_TEMPLATE, String api_KEY_TALK2ME_TEMPLATE, 
			String api_KEY_SLIDEOUT_TEMPLATE, String api_KEY_SWIPETOREVEAL_TEMPLATE, String api_KEY_MULTITHUMBNAIL_TEMPLATE)
	{
		String classString =
				"package com.vdopia.sample; "+ "\n\n\n" +
						"public final class ApiKey" +"\n"+ 
						"{" +"\n";

		classString = classString + "\n" + "public final static String API_KEY_STATIC_BANNER = \""+ api_KEY_STATIC_BANNER + "\";" +"\n";
		classString = classString + "\n" + "public final static String API_KEY_ANIMATED_BANNER = \""+ api_KEY_ANIMATED_BANNER +"\";" + "\n"; 

		classString = classString + "\n" + "public final static String API_KEY_MRECT_STATIC_BANNER = \"" + api_KEY_MRECT_STATIC_BANNER +"\"; " + "\n";
		classString = classString + "\n" + "public final static String API_KEY_MRECT_INVIEW_VIDEO = \""+ api_KEY_MRECT_INVIEW_VIDEO +"\"; " + "\n";

		classString = classString + "\n" + "public final static String API_KEY_EXP_BANNER_MIN_VIDEO = \""+ api_KEY_EXP_BANNER_MIN_VIDEO +"\";" + "\n"; 
		classString = classString + "\n" + "public final static String API_KEY_EXP_BANNER_MED_VIDEO = \""+ api_KEY_EXP_BANNER_MED_VIDEO +"\";" + "\n"; 

		classString = classString + "\n" + "public final static String API_KEY_FULL_SCREEN_STATIC_BANNER = \""+ api_KEY_FULL_SCREEN_STATIC_BANNER +"\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_FULL_SCREEN_INTERSTITIAL = \""+ api_KEY_FULL_SCREEN_INTERSTITIAL +"\";" + "\n"; 
		classString = classString + "\n" + "public final static String API_KEY_FULL_SCREEN_MAX_VIDEO = \""+ api_KEY_FULL_SCREEN_MAX_VIDEO +"\";" + "\n";		

		classString = classString + "\n" + "public final static String API_KEY_LEADERBOARD_STATIC_BANNER = \""+ api_KEY_LEADERBOARD_STATIC_BANNER +"\";" + "\n"; 
		classString = classString + "\n" + "public final static String API_KEY_LEADERBOARD_ANIMATED_BANNER = \""+ api_KEY_LEADERBOARD_ANIMATED_BANNER +"\";" + "\n"; 
		classString = classString + "\n" + "public final static String API_KEY_LEADERBOARD_VIDEO = \""+ api_KEY_LEADERBOARD_VIDEO +"\";" + "\n" ;

		classString = classString + "\n" + "public final static String API_KEY_INVIEW_SCROLLVIEW = \""+  api_INVIEW_SCROLLVIEW + "\";" + "\n"; 
		classString = classString + "\n" + "public final static String API_KEY_INVIEW_TABLEVIEW = \"" + api_KEY_INVIEW_TABLEVIEW + "\";" + "\n";

		classString = classString + "\n" + "public final static String API_KEY_SKIP_TEMPLATE = \"" + api_KEY_SKIP_TEMPLATE + "\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_TALK2ME_TEMPLATE = \"" + api_KEY_TALK2ME_TEMPLATE + "\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_SLIDEOUT_TEMPLATE = \"" + api_KEY_SLIDEOUT_TEMPLATE + "\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_SWIPETOREVEAL_TEMPLATE = \"" + api_KEY_SWIPETOREVEAL_TEMPLATE + "\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_MULTITHUMBNAIL_TEMPLATE = \"" + api_KEY_MULTITHUMBNAIL_TEMPLATE + "\";" + "\n";
		classString = classString + "\n" + "public final static String API_KEY_NONCLICKABLE_TEMPLATE = \""+ api_KEY_NONCLICKABLE_TEMPLATE + "\";" + "\n";

		classString = classString + "\n" + "}";

		/** Write the above code in MainActivity.java file */
		FileLib.WriteTextInFile(apikeyFileLocation, classString);
	}

	/**
	 * This method will create and copy the universal static lib (.a) in lw sdk
	 * and mp sdk projects - will be one time setup in before test.
	 * 
	 * @param sdkFlag
	 * @return
	 */
	public boolean setUniversalStaticLibForiOS(String sdkFlag)
	{
		boolean flag = false;

		/** at this location .a file will be created */
		String buildDirectory;
		if(sdkFlag.equalsIgnoreCase("mpsdk")){
			buildDirectory = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/MP_UniversalLibs");
		}
		else{
			buildDirectory = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/LW_UniversalLibs");
		}

		/** get the project location */
		String projectLocation;
		if(sdkFlag.equalsIgnoreCase("mpsdk")){
			projectLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/MediaPlayer/Vdopia_Mp.xcodeproj");
		}
		else{
			projectLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/LWSDK_New/test_App.xcodeproj");
		}

		/** update serving instance url in respective defines.h file and then build sdk project to create .a file */

		//-------->>>>> Change this code
		//updateDefinesFile(sdkFlag);


		File universalStaticLib = SDKSetUp_iOS.getiOSUniversalStaticLib(sdkFlag, projectLocation, buildDirectory);

		if(universalStaticLib != null){
			try{
				if(sdkFlag.equalsIgnoreCase("mpsdk")){
					FileUtils.copyFile(universalStaticLib, new File(TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/Media_Player_Sample_App/sdk/libMpSdkLibrary.a")));
					flag = true;
				}
				else{
					FileUtils.copyFile(universalStaticLib, new File(TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/LW_Sample_Apps/AllFormats/LWsdk/liblibrary_vdopia.a")));
					flag = true;
				}
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Universal static lib is copied successfully at project location. " );
			}catch (IOException e) {
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : error occurred while copying .a file to project for sdk: "+sdkFlag, e);
			}
		}
		else{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Universal static lib is not created for sdk: "+sdkFlag);
		}

		return flag;
	}

	/** Create .app file for iOS sample app code, currently serving url is not being changed --> may be future
	 * also all the provision profiles should be set up in system and in master copy.
	 * 
	 * @param jsonTestObejct
	 * @return
	 */
	public File getiOSAppFile(JSONObject  ... jsonTestObejct)
	{
		File appFile = null;
		try
		{
			/** Step 1. Copy all files from master copy to /sdk/iOS/AllFormats */
			String iosMasterCopy = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS_MasterCopy/AllFormats");
			String actualProject = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/AllFormats");
			FileUtils.copyDirectory(new File(iosMasterCopy), new File(actualProject));

			/** Step 2. update all api keys in all files as defined in sdk.iosapp conf */
			setAPIKeys_iOSSampleApp(jsonTestObejct);

			/** Step 3. clean and build app code and return the .app file */
			appFile = SDKSetUp_iOS.createiOSApp("iOSDevice", actualProject);
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return  appFile;
	}

	/** Set api keys in iOS Sample App Project.
	 * 
	 * @param jsonTestObejct
	 */
	public void setAPIKeys_iOSSampleApp(JSONObject  ... jsonTestObejct)
	{
		try
		{
			PropertiesConfiguration property = new PropertiesConfiguration();
			property.load(TestSuiteClass.AUTOMATION_HOME.concat("/conf/sdk.iosapp.integration"));
			String projectLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/iOS/AllFormats");

			for(int i=0; i<jsonTestObejct.length; i++)
			{
				/** Get adformat and APIKey from received jsonObject and get the respective file to be changed from sdk.iosapp.integration file 
				 * master copy of project has all the apikeys in form of macros and these macros are defined in conf file. 
				 * Ultimately all files will be changed by executing sed command */

				String adFormat = jsonTestObejct[i].getString("adformat").toUpperCase().trim();
				String Value = property.getProperty(adFormat).toString().replace("[", "").replace("]", "").trim();

				if(Value !=null)
				{
					String fileLocation = Value.split(",")[0].trim();
					/** adding project location with the file name to get absolute path */
					fileLocation = projectLocation.concat(fileLocation);

					String macro = Value.split(",")[1].trim();
					String apiKeyToReplaceMacro = jsonTestObejct[i].getString("input");

					String sedCommand = " sed -i '' 's/"+macro+"/"+apiKeyToReplaceMacro+"/g'  " +fileLocation;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Command: "+sedCommand);
					ExecuteCommands.ExecuteMacCommand_ReturnsExitStatus(sedCommand);
				}
				else
				{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *********** Received adformat is not supported , check conf:  sdk.iosapp.integration ");
				}
			}
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
	}

}
