package projects.sdk.lib;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class SDKAdHandler {

	Logger logger = Logger.getLogger(SDKAdHandler.class.getName());
	
	/**
	 * This method will handle the standard video ad format validation dynamically.
	 * 
	 * @param driver
	 * @param sdkAdformat
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String videoAds(WebDriver driver, String sdkAdformat)
	{
		String result = "";
		sdkAdformat = sdkAdformat.toLowerCase().trim();
	
		Class videoAdClass = null;
		try {
			videoAdClass = Class.forName(SDKHandler_VideoAds.class.getName());
		} catch (ClassNotFoundException e) {}
	
		if(videoAdClass != null)
		{
			SDKHandler_VideoAds videoAdClassObject = new SDKHandler_VideoAds(driver, sdkAdformat);
	
			Method method = null;
			try {
				method = videoAdClass.getMethod(sdkAdformat);
			} catch (NoSuchMethodException e) {  
				result = "SKIP: This ad format: "+sdkAdformat + " is not being handled, please check the validation file.";
			}
	
			try{
				if(method != null)
				{
					result = (String) method.invoke(videoAdClassObject);
				}
			}catch(InvocationTargetException | IllegalAccessException e){
				logger.error(e.getMessage(), e);
			}
		}
	
		return result;
	}

	/**
	 * This method will call the respective standard ad format validation based
	 * on supplied sdk ad format.
	 * 
	 * @param driver
	 * @param sdkAdformat
	 * @param respectiveStandardAdformat
	 * @param containerBehaviour
	 * @return
	 */
	public String adformatHandler(WebDriver driver, String sdkAdformat, String respectiveStandardAdformat)
	{
	
		String result = "";
	
		if(respectiveStandardAdformat.equalsIgnoreCase("banner"))
		{
			result = new SDKHandler_NonVideoAds().bannerAds(driver, sdkAdformat);
		}
		else if(respectiveStandardAdformat.equalsIgnoreCase("video"))
		{
			result = new SDKAdHandler().videoAds(driver, sdkAdformat);
		}
		else if(respectiveStandardAdformat.equalsIgnoreCase("interstitial"))
		{
			result = new SDKHandler_NonVideoAds().interstitialAds(driver, sdkAdformat);
		}	
	
		return result;
	}

}
