/**
 * Last Changes Done on 17 Dec, 2015 12:47:59 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.sdk.lib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

// TODO: Auto-generated Javadoc
public class SDKHandler_NonVideoAds 
{

	Logger logger = Logger.getLogger(SDKHandler_NonVideoAds.class.getName());

	/**
	 * This method is to perform and verify the serving of the banner ad format.
	 * 
	 * @param driver
	 * @param sdkAdformat
	 * @return
	 */
	public String bannerAds(WebDriver driver, String sdkAdformat)
	{
		String result = "";

		try{
			String viewLocator = "";

			if(sdkAdformat.equalsIgnoreCase("STATIC_BANNER"))
			{
				viewLocator = "view_Banner_StaticBanner";
			}
			else if(sdkAdformat.equalsIgnoreCase("ANIMATED_BANNER"))
			{
				viewLocator = "view_Banner_AnimatedBanner";
			}
			else if(sdkAdformat.equalsIgnoreCase("MRECT_STATIC_BANNER"))
			{
				viewLocator = "view_MREC_StaticBanner";
			}
			else if(sdkAdformat.equalsIgnoreCase("FULL_SCREEN_STATIC_BANNER"))
			{
				viewLocator = "view_Fullscreen_StaticBanner";
			}
			else if(sdkAdformat.equalsIgnoreCase("LEADERBOARD_STATIC_BANNER"))
			{
				viewLocator = "view_LeaderboardTablet_StaticBanner";
			}
			else if(sdkAdformat.equalsIgnoreCase("LEADERBOARD_ANIMATED_BANNER"))
			{
				viewLocator = "view_LeaderboardTablet_AnimatedBanner";
			}

			/** first wait for banner view, then if available then click on view and verify all the check points 
			 * like: [X], share, reload, back, forward, ads by vdopia text and landing page url  */			
			result = landingPageFlow(driver, sdkAdformat, viewLocator);

			/** so that ad stays at screen for sometime */
			Thread.sleep(2500);

		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return result;

	}

	/**
	 * This method will handle the standard interstitial ad format validation.
	 * 
	 * @param driver
	 * @param sdkAdformat
	 * @return
	 */
	public String interstitialAds(WebDriver driver, String sdkAdformat)
	{
		String result = "";

		try{
			String viewLocator = "";

			if(sdkAdformat.equalsIgnoreCase("FULL_SCREEN_INTERSTITIAL"))
			{
				viewLocator = "view_Fullscreen_Interstitial";
			}

			/** first wait for interstitial view, then if available then click on view and verify all the check points 
			 * like: [X], share, reload, back, forward, ads by vdopia text and landing page url  */			
			result = landingPageFlow(driver, sdkAdformat, viewLocator);	

		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * This method receives the ad view locator, then finds ad view webelement,
	 * clicks on it and goes to landing page and does all the validation of
	 * landing page and finally closes landing page and comes back to ad view
	 * screen.
	 * 
	 * @param driver
	 * @param viewLocator
	 * @return
	 */
	public String landingPageFlow(WebDriver driver, String sdkAdFromat, String viewLocator)
	{
		String result = "";

		try
		{			
			/** HIGHLY IMPORTANT -- For LWSDK, ads will be played in webview and for MPSDK ad will be played in native view therefore
			 * for every received ad format, first switch to respective context (LWSDK-Webview and MPSDK-Native) */
			driver = new ObjectsHandler().switchDriverContext(driver, sdkAdFromat);
			/*****************************************************************************************************/			

			/** apply rules -- to handle certain objects like swipe, slide, scroll etc */
			new ApplyRules().applyRule(driver, viewLocator);

			By view = new ObjectsHandler().getByLocator(driver, viewLocator);

			/** wait for view to be visible and clickable */
			if(new ObjectsHandler().waitForElement(driver, view, 10, new WebDriverException("")))
			{	
				/** click on ad screen, only if supplied ad isn't interstitial ad */
				if(!new ApplyRules().applyRule(viewLocator))
				{
					if(new ObjectsHandler().clickElement(driver, view)){
						/** verify landing page elements */
						result = validateLandingPage(driver, sdkAdFromat);
					}
					else{
						result = "SKIP: Couldn't click on ad view.";
					}
				}
			}
			else
			{
				result =  "SKIP: Ad wasn't displayed. ";
			}
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return result;
	}

	/**
	 * verify all the check points like: [X], share, reload, back, forward, ads
	 * by vdopia text and landing page url and close the landing page by
	 * clicking [X] button.
	 * 
	 * @param driver
	 * @return
	 */
	public String validateLandingPage(WebDriver driver, String sdkAdFromat)
	{
		String result = "";

		try{

			/** HIGHLY IMPORTANT: Landing page objects like [X], reload, share buttons etc. are loaded in Native View, therefore
			 * validating these driver context has to be switched to Native_App explicitly for all sdk ad formats, may be before 
			 * coming to this method driver's context is set to webview, therefore this needs to be changed to Native_App.
			 */
			driver = new ObjectsHandler().setDriverContext(driver, "Native_App");
			/****************************************************************************************************************/

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Starting Landing Page Validation... ");

			WebElement element = new ObjectsHandler().getElement(driver, "text_AdsByVdopia_LandingPage");
			if(element != null && element.isDisplayed()){
				result = result + "PASS: AdsByVdopia Text is present on landing page.";
			}else{
				result = result + "FAIL: AdsByVdopia Text is not present on landing page.";
			}

			element = new ObjectsHandler().getElement(driver, "button_Back_LandingPage");
			if(element != null && element.isDisplayed()){
				result = result + "\n" + "PASS: Back button is present on landing page. ";
			}else{
				result = result + "\n" + "FAIL: Back button is not present on landing page. ";
			}

			element = new ObjectsHandler().getElement(driver, "button_Forward_LandingPage");
			if(element != null && element.isDisplayed()){
				result = result + "\n" + "PASS: Forward button is present on landing page. ";
			}else{
				result = result + "\n" + "FAIL: Forward button is not present on landing page. ";
			}

			element = new ObjectsHandler().getElement(driver, "button_Reload_LandingPage");
			if(element != null && element.isDisplayed()){
				result = result + "\n" + "PASS: Reload button is present on landing page. ";
			}else{
				result = result + "\n" + "FAIL: Reload button is not present on landing page. ";
			}

			element = new ObjectsHandler().getElement(driver, "button_Share_LandingPage");
			if(element != null && element.isDisplayed()){
				result = result + "\n" + "PASS: Share icon is present on landing page. ";
			}else{
				result = result + "\n" + "FAIL: Share icon is not present on landing page. ";
			}

			element = new ObjectsHandler().getElement(driver, "button_X_LandingPage");
			if(element != null && element.isDisplayed())
			{
				result = result + "\n" + "PASS: [X] icon is present on landing page. ";
				element.click();
			}else{
				result = result + "\n" + "FAIL: [X] icon is not present on landing page. ";
			}

		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Landing Page Validation Result: "+result);
		return result;

	}

	/** This method will wait until main content is played -- for preroll ads,
	 * any validation on or around main content should be kept here. 
	 * 
	 * @param driver
	 * @return
	 */
	public String prerollMainContentCheck(WebDriver driver)
	{
		String result = "";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for main content . . . .");

		By mainContent = new ObjectsHandler().getByLocator(driver, "mainContent_Video_View");
		if(new ObjectsHandler().waitForElement(driver, mainContent, 35))
		{
			result = "PASS: Main content was displayed after completion of ad. ";
		}
		else
		{
			result = "FAIL: Main content wasn't not displayed after completion of ad. ";
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Main Content: "+ result);
		return result;
	}

	/** This method will wait until main content is displayed.
	 * 
	 * @param driver
	 * @param viewLocator
	 * @return
	 */
	public String prerollMainContentCheck(WebDriver driver, String viewLocator)
	{
		String result = "";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for main content . . . .");

		try{
			By adView = new ObjectsHandler().getByLocator(driver, viewLocator);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(adView));

			result = "FAIL: Main content wasn't not displayed after completion of ad. ";
		}catch(TimeoutException t)
		{	
			result = "Main content might be displayed, require a relook. ";
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Main Content: "+ result);
		return result;
	}

}
