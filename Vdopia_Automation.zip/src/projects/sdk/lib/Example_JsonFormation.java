package projects.sdk.lib;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class Example_JsonFormation {

	/**
	 * @param args
	 * @throws JSONException 
	 */
	public static void main(String[] args) throws JSONException {
		// TODO Auto-generated method stub


		String x = "{ \"row\": \"1\", \"column\": \"1\", \"input\": \"xyz\", \"ifproceed\": \"false\"}";
		JSONObject o = new JSONObject(x);

		JSONObject x1 = new JSONObject("{ \"row\": \"1\", \"column\": \"1\", \"input\": \"xyz\", \"ifproceed\": \"false\"}");
		
		HashMap<String, JSONObject> map = new HashMap<>();
		map.put("x", o);
		map.put("x1", x1);
		
		System.out.println(map.size());
		
		//create device specific json
		JSONObject object = new JSONObject();
		object.put("deviceid1", "122");
		object.put("query1", "q1");

		//put into device json array
		JSONArray array = new JSONArray();
		array.put(object);
		o.put("device", array);
		System.out.println(o.toString());

		//create new json object for new device id
		JSONObject jj = new JSONObject();
		jj.put("deviceid2", "222");
		jj.put("query2", "q2");

		//append into existing device json array
		JSONArray a = o.getJSONArray("device");
		a.put(jj);

		System.out.println(o.toString());
	}

}
