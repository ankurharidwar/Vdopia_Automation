/**
 * Last Changes Done on 5 Mar, 2015 12:07:43 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Changing sdk framework, keeping it more simpler, separating app integration method out of this class. 
 */

package projects.sdk.lib;

import java.io.File;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import vlib.ExecuteCommands;




public class SDKSetUp_iOS 
{

	static Logger logger = Logger.getLogger(SDKSetUp_iOS.class.getName());


	/** This method will build the supplied xcode project and return the .app file to be used by appium server.
	 * Command Without Provisioning Profile: xcodebuild -configuration Release CODE_SIGN_IDENTITY="" CODE_SIGNING_REQUIRED=NO
	 * 
	 * @param iOSDeviceType
	 * @param configurationBuildDir
	 * @param projectLocation
	 * @return
	 */
	public static File createiOSApp(String iOSDeviceType, String projectLocation)
	{
		File appFile = null;

		try		
		{
			//---->>>>>>> Need to see how to use provisioning profile in device while creating build, currently we are saving the correct provisioning
			//--- profile in xcode 
			//String provisionProfile = MobileTestClass_Methods.propertyConfigFile.getProperty("provisioningProfileName").toString();
			//String provisioning = "PROVISIONING_PROFILE="+ provisionProfile +" CODE_SIGN_IDENTITY='iPhone Developer: Srikanth Kakani (8M2AZQ29AC)'";
			
			/** first clean project */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************************ Build is being cleaned ..... ");
			String cleanBuild = "xcodebuild clean -project "+projectLocation.concat("/*.xcodeproj") + " CODE_SIGN_IDENTITY=\"\" CODE_SIGNING_REQUIRED=NO ";
			ExecuteCommands.ExecuteMacCommand_ReturnsOutput(cleanBuild);

			//---->>>>>  NEED TO CHECK THE SDK IN THE BELOW COMMAND, I BELIEVE THE MAC ON WHICH ITS RUNNING SHOULD HAVE THIS SDK
			String compileBuild = "xcodebuild build -project "+ projectLocation.concat("/*.xcodeproj") +" -configuration Release -sdk iphoneos9.2 -target Vdopia\\ LW "; 				
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Command to compile build for iPhone Device: "+compileBuild);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************************ Build is being compiled ..... ");
			String output = ExecuteCommands.ExecuteMacCommand_ReturnsOutput(compileBuild);

			if(output.toString().trim().contains("BUILD SUCCEEDED"))
			{
				appFile = new File(projectLocation.concat("/build/Release-iphoneos/Vdopia LW.app"));
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Build is compiled successfully and .app file is created at: "+appFile.toString() );
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* Build Failed, Compile Output ************* ");
				logger.info(output);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while creating app file. ", e);
		}
		return appFile;
	}

	/**
	 * This method will create a universal static library (.a) file to be used
	 * in LW AND MP SDK PROJECTS and will copy created .a file at the required
	 * place in both sdks project.
	 * 
	 * @param sdkFlag
	 * @param projectLocation
	 * @param buildDirectory
	 * @return
	 */
	public static File getiOSUniversalStaticLib(String sdkFlag, String projectLocation, String buildDirectory)
	{
		File universalStaticLib = null;
		String target;
		String expectedLib;

		/** getting expected varaibles for both sdk */
		if(sdkFlag.equalsIgnoreCase("mpsdk")){
			target = "MpSdkLibrary";
			expectedLib = "libMpSdkLibrary.a";
		}else{
			target = "library_vdopia";
			expectedLib = "liblibrary_vdopia.a";
		}

		/** firstly - clean project */
		String cleanProjectCommand = "xcodebuild clean -project "+ projectLocation +" -target "+ target +" CONFIGURATION_BUILD_DIR='"+ buildDirectory +"'";
		ExecuteCommands.ExecuteMacCommand_ReturnsOutput(cleanProjectCommand);

		/** secondly - build project */
		String buildProjectCommand = "xcodebuild build -project "+ projectLocation +" -target "+ target +" CONFIGURATION_BUILD_DIR='"+ buildDirectory +"' ENABLE_BITCODE=YES";
		String output = ExecuteCommands.ExecuteMacCommand_ReturnsOutput(buildProjectCommand);

		if(output.toString().trim().contains("BUILD SUCCEEDED")){
			universalStaticLib = new File(buildDirectory.concat("/"+expectedLib));
		}
		else{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Universal static lib is not created for sdk: "+sdkFlag);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* Build Output ************* ");
			logger.info(output);
		}
		return universalStaticLib;
	}

}


