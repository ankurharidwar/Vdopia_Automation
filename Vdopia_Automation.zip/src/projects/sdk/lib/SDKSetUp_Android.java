/**
 * Last Changes Done on 5 Mar, 2015 12:07:50 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.sdk.lib;


import java.io.File;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import vlib.FileLib;
import vlib.MobileTestClass_Methods;




public class SDKSetUp_Android 
{
	static Logger logger = Logger.getLogger(SDKSetUp_Android.class.getName());

	/** This method will be used to create an android apk file using gradlew
	 *  
	 * @param androidProjectLocation
	 * @param apkFileName
	 * @return
	 */
	@SuppressWarnings("finally")
	public static File createAndroidApk(String androidProjectLocation, String apkFileName)
	{
		File apk = null;	
		try
		{	
			String outputDir;

			/** In case of windows Ant Clean is failing - because it can't delete one file, so deleting bin using java methods */
			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				outputDir = androidProjectLocation + "\\" + "app\\build\\outputs\\apk";

				File bin = new File(outputDir);

				if(bin.exists())
				{
					if(bin.delete())
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Build is cleaned successfully on Windows ...");
					}
					else
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :  Build is not cleaned on Windows ...");
					}
				}
			}
			else
			{
				outputDir = androidProjectLocation + "/" + "app/build/outputs/apk";

				/** Clean build */
				GradleBuildHandler.gradleBuildHandler(androidProjectLocation, "clean");
			}

			/** Compile and release build */
			if(GradleBuildHandler.gradleBuildHandler(androidProjectLocation, "release"))
			{
				//Check if <>.apk file is created 
				if(FileLib.CheckFileInDirectory(outputDir, apkFileName))
				{
					//Getting apk file location 
					apk = new File(outputDir + "/" + apkFileName);
					logger.info(apkFileName+" is created successfully at: "+outputDir);
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :  Build is not compiled successfully. ");
			}
		}
		catch(Exception e)
		{
			apk = null;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while creating apk file. ",e);
		}
		finally
		{
			return apk;
		}
	}

	// This method is for reference only - just to know the combination in lw sdk -- will be deleted later on
	@SuppressWarnings("finally")
	public static boolean lwSDKAndroid_Reference_DontUse(String file, String serveURL, String channelAPIKey, String adFormat, String adsDimension, String fullscreenBannerFlag, String medMaxVideoFlag, String expandableFlag)
	{
		boolean flag = false;
		String adFlag = "nothing";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SampleApp file received at location: "+file);
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SampleApp file is being updated with the API Key: "+ channelAPIKey +" of supported ad formats....");

		try
		{
			//BANNER
			if(adFormat.equalsIgnoreCase("banner") && (!fullscreenBannerFlag.equalsIgnoreCase("1")) && (!adsDimension.equalsIgnoreCase("728x90")) && (!adsDimension.equalsIgnoreCase("300x250"))	)
			{
				adFlag = "BANNER";				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Static Banner not having size of 728x90 and 300x250...");
			}
			else if(adFormat.equalsIgnoreCase("html") && (!fullscreenBannerFlag.equalsIgnoreCase("1")) && (!adsDimension.equalsIgnoreCase("728x90")) && (!adsDimension.equalsIgnoreCase("300x250"))	)
			{
				adFlag = "BANNER";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Animated Banner not having size of 728x90 and 300x250...");
			}
			//IAB_LEADERBOARD
			else if(adFormat.equalsIgnoreCase("leadervdo"))
			{
				adFlag = "IAB_LEADERBOARD";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Leader Video...");
			}
			else if(adFormat.equalsIgnoreCase("html") && adsDimension.equalsIgnoreCase("728x90"))
			{
				adFlag = "IAB_LEADERBOARD";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Animated Banner of size 728x90...");
			}
			else if(adFormat.equalsIgnoreCase("banner") && adsDimension.equalsIgnoreCase("728x90"))
			{
				adFlag = "IAB_LEADERBOARD";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Banner of size 728x90...");
			}
			//interstitial
			else if(adFormat.equalsIgnoreCase("appinterstitial"))
			{
				adFlag = "interstitial";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Interstitial...");
			}
			else if(adFormat.equalsIgnoreCase("video") && medMaxVideoFlag.equalsIgnoreCase("1") && (!expandableFlag.equalsIgnoreCase("1")) ) 
			{
				adFlag = "interstitial";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Non Expandable Max Video...");
			}
			else if(adFormat.equalsIgnoreCase("banner") && fullscreenBannerFlag.equalsIgnoreCase("1"))
			{
				adFlag = "interstitial";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Full Screen Banner...");
			}
			//EXPANDABLE_BANNER
			else if(adFormat.equalsIgnoreCase("vdobanner"))
			{
				adFlag = "EXPANDABLE_BANNER";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Mini Video...");
			}
			else if(adFormat.equalsIgnoreCase("video") && (!medMaxVideoFlag.equalsIgnoreCase("1")) && expandableFlag.equalsIgnoreCase("1") )
			{
				adFlag = "EXPANDABLE_BANNER";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Expandable Med Video...");
			}
			else if(adFormat.equalsIgnoreCase("video") && medMaxVideoFlag.equalsIgnoreCase("1") && expandableFlag.equalsIgnoreCase("1") )
			{
				adFlag = "EXPANDABLE_BANNER";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Expandable Max Video...");
			}
			//IAB_MRECT
			else if(adFormat.equalsIgnoreCase("video") && (!medMaxVideoFlag.equalsIgnoreCase("1")) && (!expandableFlag.equalsIgnoreCase("1")) )
			{
				adFlag = "IAB_MRECT";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Non Expandable Med Video...");
			}
			else if(adFormat.equalsIgnoreCase("banner") && (!fullscreenBannerFlag.equalsIgnoreCase("1")) && adsDimension.equalsIgnoreCase("300x250"))
			{
				adFlag = "IAB_MRECT";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Banner (No Full Screen) having size 300x250...");
			}
			else if(adFormat.equalsIgnoreCase("html") && (!fullscreenBannerFlag.equalsIgnoreCase("1")) && adsDimension.equalsIgnoreCase("300x250"))
			{
				adFlag = "IAB_MRECT";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sample App  file is modified with the api key of Animated Banner (No Full Screen) having size 300x250...");
			}

			if(adFlag.equalsIgnoreCase("nothing"))
			{
				flag = false;
			}
			else
			{
				//String code = BuildStringForAndroidLWSDK(adFlag, serveURL, channelAPIKey);
				if(true)
				{
					flag = true;		
				}

			}

		}
		catch(Exception  e)
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: CreateSampleFile_LWSDKAndroid. " + e.getMessage());
		}
		finally
		{
			return flag;
		}
	}

	/**
	 * Get android home according to os
	 * @return
	 */
	public static String getAndroidHome()
	{
		String androidHome;
		if(System.getProperty("os.name").matches("^Windows.*"))
		{
			androidHome = MobileTestClass_Methods.propertyConfigFile.getProperty("AndroidSDK_Windows").toString();
		}
		else
		{
			androidHome = MobileTestClass_Methods.propertyConfigFile.getProperty("AndroidSDK_Mac").toString();
		}
		return androidHome;
	}

}



