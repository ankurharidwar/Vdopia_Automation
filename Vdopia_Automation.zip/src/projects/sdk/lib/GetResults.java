/**
 * Last Changes Done on 9 Nov, 2015 12:14:00 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains all method which generates results for android and iphone
 * Intent to have json structure like this, where device node contains the details of each test for each device id
 *
 * {
    "row": "1",
    "column": "1",
    "input": "xyz",
    "ifproceed": "false",
    "devicedata": [
        {
            "deviceid": "123",
            "channelquery": "q1",
            "campaignquery": "q2",
            "otherresult": "skip"
        },
        {
            "deviceid": "321",
            "channelquery": "q1",
            "campaignquery": "q2",
            "otherresult": "skip"
        }
    ]
}
 */

package projects.sdk.lib;

import java.io.File;
import java.util.List;
import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;






// TODO: Auto-generated Javadoc
public class GetResults 
{

	Logger logger = Logger.getLogger(GetResults.class.getName());


	/**
	 * This is a generic method to be used in both lw sdk and mp sdk --&&-- both
	 * ios and android os.
	 * 
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param ipadDeviceConnected
	 * @param appFile
	 * @param deviceList
	 * @param jsonTestData
	 * @return
	 */
	public JSONObject[] getResults(boolean androidDeviceConnected, boolean iphoneDeviceConnected, boolean ipadDeviceConnected,
			File appFile, List<String> deviceList, JSONObject ... jsonTestData)
	{
		for(int i=0;i<deviceList.size();i++)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** Running Test For Device ID: "+deviceList.get(i) + "*********");
			String deviceId = deviceList.get(i);

			/** Setup driver for each device id and required os */
			WebDriver driver = new GetDeviceDriver(30).getDriver(androidDeviceConnected, iphoneDeviceConnected, ipadDeviceConnected, appFile, deviceId);

			/** Iterate the received json array test data, use all the received test data on one device first and then on other device,  
			 * store the results in same received test data array in order to have the latest test results for each device */
			for(int j=0; j<jsonTestData.length; j++)
			{
				JSONObject testData = jsonTestData[j];
				jsonTestData[j] = getDeviceJsonResult(appFile, driver, deviceId, testData);
			}
		}

		return jsonTestData;
	}

	/**
	 * Add SKIP results to supplied json object.
	 * 
	 * @param object
	 * @param apkFile
	 * @param driver
	 * @return
	 */
	public JSONObject putSkipResult(JSONObject object, File apkFile, WebDriver driver)
	{
		String skipResult= "SKIP: ";

		try
		{
			if(apkFile == null)
			{
				skipResult = skipResult + "APK file wasn't created, skipping test.";
				object.put("otherresult", skipResult);
			}

			if(driver == null)
			{
				skipResult = skipResult + "Couldn't setup Driver in device, skipping test.";
				object.put("otherresult", skipResult);
			}

			/** setting up flag*/
			if(apkFile == null || driver == null)
			{
				object.put("executetest", "false");
			}
			else
			{
				object.put("executetest", "true");
			}
		}
		catch(JSONException e)
		{
			logger.error(e);
		}
		return object;
	}

	/**
	 * This method accepts the test data as json object, now this test data will
	 * be used on multiple devices, therefore strategy is: create a new json
	 * object for each device which will contain the device specific information
	 * like campaign query, channel query, device id, tracker start time etc,
	 * then this device specific json object will be added to the json array
	 * [devicedata] in the received test data json object, by doing this we can
	 * maintain all device execution information in the received test data json
	 * it self.
	 * 
	 * Received jsonTestData will have a key "sdk" : "lwsdk" or "sdk" : "mpsdk",
	 * before making any action or validation use this and perform accordingly.
	 * 
	 * @param apkFile
	 * @param driver
	 * @param androidDeviceID
	 * @param jsonTestData
	 * @return
	 */
	public JSONObject getDeviceJsonResult(File apkFile, WebDriver driver, String androidDeviceID, JSONObject jsonTestData)
	{
		try 
		{
			/** Store each device specific information in a DEVICE SPECIFIC json object and put it in json array, for that create a devicedata node - json array. */
			JSONObject deviceJsonObject = new JSONObject();
			deviceJsonObject.put("deviceid", androidDeviceID);

			/** CHECKING IF SUPPLIED APIKEY IS NOT BLANK USING FLAG ifproceed (WHICH IS SET AT THE TIME OF READING TEST DATA SHEET AND IS NON-PERISHABLE
			 * VARAIBLE), THEN LOOK FOR OTHER REASON BEFORE PROCCEDING TEST */
			if(jsonTestData.getString("ifproceed").equalsIgnoreCase("true"))
			{
				/** flag executetest is set for each device before proceeding for test and after checking if driver was setup correctly */
				deviceJsonObject = new GetResults().putSkipResult(deviceJsonObject, apkFile, driver);

				/** if every requisite found to be okay then proceed test */
				if(deviceJsonObject.getString("executetest").equalsIgnoreCase("true"))
				{
					/**
					 * CREATE A METHOD WHICH WILL ACCEPT THE SUPPLIED jsonTestData AND deviceJsonObject JSON OBJECTS AND ADD DEVICE SPECIFIC 
					 * INFORMATION ONLY IN JSON deviceJsonObject AND RETURN THIS.
					 */					
					deviceJsonObject = new SDKPerformActions().performAction(driver, jsonTestData, deviceJsonObject); 
				}
			}
			else
			{	
				/** Append results for each iteration */
				deviceJsonObject.put("otherresult", "SKIP: NO API KEY WAS PROVIDED.");
			}

			/** Before putting deviceJsonObject in json array = devicedata, check if it already exists in jsonTestData */
			try{
				jsonTestData.getJSONArray("devicedata").put(deviceJsonObject);
			}catch(JSONException e)
			{
				/** Put deviceJsonObject in a json array with a key devicedata and value as deviceJsonObject */
				JSONArray deviceJsonArray = new JSONArray();
				deviceJsonArray.put(deviceJsonObject);

				/** append json array in the received jsonTestData */
				jsonTestData.put("devicedata", deviceJsonArray);
			}
		} catch (JSONException e) 
		{
			logger.error(e);
		}

		return jsonTestData;
	}

}
