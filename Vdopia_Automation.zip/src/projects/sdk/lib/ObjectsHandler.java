/**
 * Last Changes Done on 7 Dec, 2015 3:58:52 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change:  This class contains generic method to perform actions.
 */
package projects.sdk.lib;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;





// TODO: Auto-generated Javadoc
public class ObjectsHandler 
{

	Logger logger = Logger.getLogger(ObjectsHandler.class.getName());

	/** This method will intelligently handles the explicit wait of 5 sec before performing a click on the supplied object.
	 * 
	 * @param driver
	 * @param byLocator
	 * @return
	 */
	public boolean clickElement(WebDriver driver, By byLocator)
	{
		boolean result = false;

		try{
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(byLocator));

			WebElement element = driver.findElement(byLocator);
			element.click();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Clicked Element: "+byLocator);

			//			if(driver instanceof AndroidDriver<?>)
			//			{
			//				if(((AndroidDriver<?>)driver).getContext().equalsIgnoreCase("NATIVE_APP"))
			//				{
			//					((AndroidDriver<?>)driver).performTouchAction(new TouchAction((MobileDriver) driver).longPress(element));
			//					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Touched Element: "+byLocator);
			//				}
			//				else
			//				{
			//					element.click();
			//					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Clicked Element: "+byLocator);
			//				}
			//			}

			result = true;
		}
		catch(TimeoutException t){
			logger.error(t.getMessage() );
		}
		catch (StaleElementReferenceException e) {
			driver.findElement(byLocator).click();
		}
		catch(Exception n){
			logger.error(n.getMessage(), n);
		}

		return result;
	}

	/**
	 * Get element definition from configuration.
	 * 
	 * @param driver
	 * @param elementName
	 * @return
	 */
	public WebElement getElement(WebDriver driver, String elementName)
	{
		WebElement element = null;
		String xpath =  "";
		try{
			xpath = SDKCommonUtils.getSDKProperty(driver, elementName);
			By byLocator = By.xpath(xpath);
			element = driver.findElement(byLocator);

		}catch(NoSuchElementException t){
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking the element with xpath: "+xpath, t);
		}
		catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		return element;
	}

	/**
	 * Get by locator definition from configuration.
	 * 
	 * @param driver
	 * @param elementName
	 * @return
	 */
	public By getByLocator(WebDriver driver, String elementName)
	{
		By byLocator = null;
		String xpath =  "";
		try{
			xpath = SDKCommonUtils.getSDKProperty(driver, elementName);
			byLocator = By.xpath(xpath);
		}
		catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		return byLocator;
	}

	/**
	 * Wait until the supplied element is visible .
	 * 
	 * @param driver
	 * @param element
	 * @return
	 */
	public boolean waitForElement(WebDriver driver, By byLocator, long timeout)
	{
		if(byLocator !=null)
		{
			try
			{
				WebDriverWait wait = new WebDriverWait(driver, timeout);
				wait.until(ExpectedConditions.visibilityOfElementLocated(byLocator));

				return true;
			}
			catch(TimeoutException t)
			{
				logger.error(t.getMessage());
				return false;
			}
		}
		else{
			return false;
		}
	}

	/**
	 * Wait until the supplied element is visible .
	 * 
	 * @param driver
	 * @param element
	 * @return
	 */
	public boolean waitForElement(WebDriver driver, By byLocator, long timeout, Exception e)
	{
		if(byLocator !=null)
		{
			try
			{
				if(driver instanceof AndroidDriver<?>){
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Wait Contexts: "+((AndroidDriver<?>)driver).getContext().toString());
				}else if(driver instanceof IOSDriver<?>){
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Wait Contexts: "+((IOSDriver<?>)driver).getContext().toString());
				}

				WebDriverWait wait = new WebDriverWait(driver, timeout);

				if(e instanceof WebDriverException)
				{
					wait.until(ExpectedConditions.visibilityOfElementLocated(byLocator));
					wait.until(ExpectedConditions.elementToBeClickable(byLocator));
				}
				else if (e instanceof NoSuchElementException)
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
				}

				return true;
			}
			catch(TimeoutException t)
			{
				logger.error(t.getMessage());
				return false;
			}
		}
		else{
			return false;
		}
	}

	/**
	 * This method will be utilized for navigation.
	 * 
	 * @param driver
	 * @param adformat
	 * @return
	 */
	public boolean menuNavigation(WebDriver driver, String adformat)
	{
		boolean flag = false;
		try
		{
			List<String> navigationFlow = Arrays.asList(SDKCommonUtils.getSDKProperty(driver, adformat.toUpperCase()).split("~~~~"));
			for(int i=0; i<navigationFlow.size(); i++)
			{
				By byLocator = null;
				byLocator = getByLocator(driver, navigationFlow.get(i).trim());
				flag = clickElement(driver, byLocator);
			}
		}
		catch(Exception e)
		{
			flag = false;
		}		

		return flag;
	}

	/** This code will set the supplied context of supplied driver.
	 * 
	 * @param driver
	 * @param context
	 * @return
	 */
	public WebDriver setDriverContext(WebDriver driver, String context)
	{
		try
		{
			Thread.sleep(1000);

			Set<String> availableContext = null;
			String currentContext = null;

			if(driver instanceof AndroidDriver<?>){
				availableContext = ((AndroidDriver<?>)driver).getContextHandles();
				currentContext = ((AndroidDriver<?>)driver).getContext();
			}
			else if(driver instanceof IOSDriver<?>){
				availableContext = ((IOSDriver<?>)driver).getContextHandles();
				currentContext = ((IOSDriver<?>)driver).getContext();
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Available Driver Contexts: "+availableContext.toString() + " & Current Driver Context:  "+currentContext);

			if(context.equalsIgnoreCase("webview"))
			{
				if(availableContext.contains("WEBVIEW_com.vdopia.sample"))
				{
					dynamicWaitToSetContext(driver, "WEBVIEW_com.vdopia.sample");
				}
				else
				{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied "+context + " is not present in app. ");
				}
			}
			else
			{
				dynamicWaitToSetContext(driver, "NATIVE_APP");
			}
		}
		catch(Exception e)
		{
			logger.info(e.getMessage(), e);
		}
		return driver;
	}

	/** This method makes max 5 attempts -- while setting up desired contexts based on received driver.
	 * 
	 * @param driver
	 * @param context
	 * @throws InterruptedException
	 */
	public void dynamicWaitToSetContext(WebDriver driver, String expectedContext) throws InterruptedException
	{
		int count = 0;

		while(count <= 5)
		{
			String currentContext = "";

			/** getting current context using received driver */
			if(driver instanceof AndroidDriver<?>){
				currentContext = ((AndroidDriver<?>)driver).getContext();
			}else if(driver instanceof IOSDriver<?>){
				currentContext = ((IOSDriver<?>)driver).getContext();
			}

			/** if current context and expected context is not same then set it else break it. */
			if(!currentContext.equalsIgnoreCase(expectedContext))
			{
				Thread.sleep(1000);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up context = "+expectedContext + " ..... ");

				if(driver instanceof AndroidDriver<?>){
					((AndroidDriver<?>)driver).context(expectedContext);
				}else if(driver instanceof IOSDriver<?>){
					((IOSDriver<?>)driver).context(expectedContext);
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Current Context: "+currentContext);
				break;
			}

			count ++;
			Thread.sleep(1000);
		}
	}


	/**
	 * Switch driver context according to the supplied sdkAdfromat.
	 * @param driver
	 * @param sdkAdFromat
	 * @return
	 */
	public WebDriver switchDriverContext(WebDriver driver, String sdkAdFromat)
	{
		String sdkType = SDKCommonUtils.getSDKType_AdFormatMappings(sdkAdFromat);
		if(sdkType.equalsIgnoreCase("LWSDK")){
			driver = new ObjectsHandler().setDriverContext(driver, "webview");
		}
		else
		{
			driver = new ObjectsHandler().setDriverContext(driver, "native");
		}

		return driver;
	}

	/** Navigate back to main menu screen.
	 * 
	 * @param driver
	 * @return
	 */
	public boolean navigateBack(WebDriver driver)
	{
		try{
			new ObjectsHandler().setDriverContext(driver, "Native_App");
			driver.navigate().back();
			return true;
		}catch(Exception t){
			logger.error(t.getMessage(), t);
			return false;
		}
	}

}
