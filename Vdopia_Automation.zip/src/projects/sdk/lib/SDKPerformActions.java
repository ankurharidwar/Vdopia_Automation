/**
 * Last Changes Done on 9 Nov, 2015 2:38:15 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the methods which will be used to perform actions for each supplied tests and gather result of each device 
 * in json format.
 */
package projects.sdk.lib;


import java.util.Iterator;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import projects.bq.BQQueriesLib;
import projects.sdk.SDKAdServingTest;


public class SDKPerformActions 
{
	Logger logger = Logger.getLogger(SDKPerformActions.class.getName());

	JSONObject adformatTcMaping = new JSONObject(); 

	/**
	 *  This constructor will set the ad format and test case mapping and thus this josn object will be available
	 *  for whole class to use it further.
	 * @param jsonObject
	 */
	SDKPerformActions()
	{
		adformatTcMaping = SDKAdServingTest.getAdformatTcMaping();
	}

	/** This method will perform action.
	 * 
	 * @param driver
	 * @param jsonTestData
	 * @param deviceJsonObject
	 * @return
	 * @throws JSONException
	 */
	public JSONObject performAction(WebDriver driver, JSONObject jsonTestData, JSONObject deviceJsonObject) 
	{
		try
		{
			String adformat = jsonTestData.getString("adformat");
			String validationJsonObject = adformatTcMaping.getString(adformat);

			JSONObject modules = new JSONObject(validationJsonObject);
			@SuppressWarnings("unchecked")
			Iterator<String> it = modules.keys();

			while(it.hasNext())
			{
				String moduleName = it.next();

				if(modules.getString(moduleName).equalsIgnoreCase("yes"))
				{
					String trackerStartTime = "";
					String trackerEndTime = "";

					/** getting tracker start time for tracker calculation for serving module only */
					if(moduleName.equalsIgnoreCase("check_serving")){
						trackerStartTime = BQQueriesLib.getCurrentDBTime(SDKAdServingTest.getBqConnection(), SDKAdServingTest.getBqProjectID());
					}

					/** go to test starting stage -- may need to change this method for ios app */
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********** Moving To Main Menu For Ad Format: "+adformat + " ****************** ");
					new ObjectsHandler().menuNavigation(driver, adformat);

					/** perform test -- by calling each applicable module written in class SDKModules.java */
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running Module: "+moduleName + " for ad format: "+adformat);
					deviceJsonObject = launchModules(moduleName, driver, jsonTestData, deviceJsonObject);

					/** putting a break between each module */
					try{Thread.sleep(1500);}catch(Exception e){}

					/** getting tracker end time for tracker calculation for serving module only */
					if(moduleName.equalsIgnoreCase("check_serving")){
						trackerEndTime = BQQueriesLib.getCurrentDBTime(SDKAdServingTest.getBqConnection(), SDKAdServingTest.getBqProjectID());						
						String channelID = jsonTestData.getString("channelid");
						String trackerQuery = BQQueriesLib.queryToGetVdopiaTrackers(channelID, trackerStartTime, trackerEndTime);

						/** putting tracker query and result in device json object */
						deviceJsonObject.put("trackerquery", trackerQuery);
						deviceJsonObject.put("trackerstarttime", trackerStartTime);
						deviceJsonObject.put("trackerendtime", trackerEndTime);
					}
				}
			}
		}catch(JSONException j){
			logger.error(j.getMessage(), j);
		}

		return deviceJsonObject;		
	}

	/** This method will call and execute the supplied method dynamically using reflection technique.
	 * 
	 * @param moduleName
	 * @param driver
	 * @return
	 */
	public JSONObject launchModules(String moduleName, WebDriver driver, JSONObject jsonTestData, JSONObject deviceJsonObject)
	{
		JSONObject result = new JSONObject();

		Class<?> moduleClass = null;
		try {
			moduleClass = Class.forName(SDKModules.class.getName());
		} catch (ClassNotFoundException t) {logger.error(t.getMessage());}

		/** proceed if class is found */
		if(moduleClass != null){
			Method module = null;

			try {
				module = moduleClass.getMethod(moduleName.toLowerCase().trim());
			} catch (NoSuchMethodException e) {
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Supplied module: "+moduleName+ " is not supported.");
			}

			/** proceed if method is found */
			if(module != null){
				SDKModules object = new SDKModules(driver, jsonTestData, deviceJsonObject);

				try {
					result = (JSONObject) module.invoke(object);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}

		return result;
	}

}
