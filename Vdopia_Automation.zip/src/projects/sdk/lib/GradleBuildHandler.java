package projects.sdk.lib;

import projects.TestSuiteClass;import org.apache.log4j.Logger;


import vlib.ExecuteCommands;



public class GradleBuildHandler {

	static Logger logger = Logger.getLogger(GradleBuildHandler.class.getName());

	//This method will be used to clean build using ant clean command
	@SuppressWarnings("finally")
	public static boolean gradleBuildHandler(String projectLocation, String task)
	{
		String gradlewPath = "";
		String build_gradle = "";

		if(System.getProperty("os.name").matches("^Windows.*"))
		{
			gradlewPath = projectLocation.concat("\\gradlew.bat");
			build_gradle = projectLocation.concat("\\build.gradle");
		}
		else
		{
			gradlewPath = projectLocation.concat("/gradlew");
			build_gradle = projectLocation.concat("/build.gradle");
		}

		boolean flag = false;
		try
		{	
			String output = "";
			String buildCommand;

			if(task.equalsIgnoreCase("clean")){
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** BUILD IS BEING CLEANED ************");
				buildCommand = gradlewPath + " -b " + build_gradle + " clean";
			}
			else{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** BUILD IS BEING RELEASED ************");
				buildCommand = gradlewPath + " -b " + build_gradle + " assembleDebug";
			}

			if(System.getProperty("os.name").matches("^Windows.*"))
			{				
				output = ExecuteCommands.ExecuteCommand_ReturnsOutput(new String[]{"cmd.exe", "/C", buildCommand});
			}
			else
			{
				ExecuteCommands.ExecuteMacCommand_ReturnsOutput("chmod +x "+gradlewPath);
				output = ExecuteCommands.ExecuteMacCommand_ReturnsOutput(buildCommand);
			}

			if(output.contains("BUILD SUCCESSFUL"))
			{
				flag = true;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Build task: "+task + " is successful. ...");
			}
			else
			{
				flag = false;
				logger.info(output);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Build task: "+task + " is not successful. ...");
			}
		}
		catch(Exception e)
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : error occurred while build "+task +  ",  "+e.getMessage());
		}
		finally
		{
			return flag;
		}
	}

}
