/**
 * Last Changes Done on 5 Nov, 2015 12:37:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package projects.sdk.lib;


import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.google.api.services.bigquery.Bigquery;
import com.mysql.jdbc.Connection;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.XlsLib;
import vlib.httpClientWrap;



// TODO: Auto-generated Javadoc
public class SDKCommonUtils {

	static Logger logger = Logger.getLogger(SDKCommonUtils.class.getName());

	/** This method will read the supplied spread sheet and return the 2D array consisting of json objects. 
	 * 
	 * @param fileLocation
	 * @return
	 */
	public static JSONObject[][] readSpreadSheetAsJson(String fileLocation, Connection connection)  
	{
		Workbook book = null;
		JSONObject [][]dataArray = null;

		try{
			book = Workbook.getWorkbook(new File(fileLocation));		
			Sheet sheet = book.getSheet(0);

			/** creating an array to store all the cell information */
			dataArray = new JSONObject[sheet.getRows()-1][sheet.getColumns()];

			if(book != null)
			{
				for(int i=1; i<sheet.getRows(); i++)		
				{
					for(int j=0; j<sheet.getColumns(); j++)	
					{	
						String input = "";
						String columnName = "";
						try{ 
							input = sheet.getCell(j, i).getContents().trim();
							/** get column names */
							columnName = sheet.getCell(j, 0).getContents().trim();
						}catch(Exception e){logger.error(e.getMessage());}

						String row = String.valueOf(i);
						String column = String.valueOf(j);

						/** create a json object containing input, row, column, columnName and a flag- ifproceed of each cell  */
						JSONObject jsonObj = new JSONObject();
						jsonObj.put("row", row);
						jsonObj.put("column", column);
						jsonObj.put("input", input);
						jsonObj.put("adformat", columnName.toLowerCase());

						/** putting more information */
						jsonObj = new SDKCommonUtils().applyRule(jsonObj, connection);

						/** storing json in array */
						dataArray[i-1][j] = jsonObj;
					}
				}
			}
		}
		catch (Exception e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while reading spreadsheet.", e);
		}
		finally{
			book.close();		
		}

		return dataArray;
	}

	/** Append more information json test data object to be used -- in sdk
	 * 
	 * @param jsonObj
	 * @param connection
	 * @return
	 */
	public JSONObject applyRule(JSONObject jsonObj, Connection connection)
	{
		try
		{
			/** adding ifproceed key in above created json object - to be used while performing tests */
			String ifproceed = "false";
			String input = jsonObj.getString("input");

			if(!input.isEmpty())
			{
				ifproceed = "true"; 
				HashMap<String, String> dbInfo = DBLib.getSDKInformation(input, connection);

				/** putting db information in received json object, template_information key from dbInfo map will always have a json value. */
				jsonObj.put("channelid", dbInfo.get("channelid"));

				String template_layout = dbInfo.get("template_layout");
				if(template_layout !=null	&&	!template_layout.isEmpty()){
					JSONObject templatesJson = new JSONObject(template_layout);
					jsonObj.put("template_layout", templatesJson);
				}
			}

			jsonObj.put("ifproceed", ifproceed);

		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return jsonObj;
	}

	/**
	 * This method will write the supplied array in the supplied spreadsheet.
	 * 
	 * @param fileLocation
	 * @param resultsList
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static boolean writeExcelSheetWithJsonData(String fileLocation, List<JSONObject> resultsList, Bigquery bqConnection, String bqProjectID) 
	{
		boolean flag = false;
		WritableWorkbook writable = null;
		Workbook book =  null;
		try
		{
			/** before writing sdk results, collect all the tracker result */
			resultsList = new SDKTrackerHandler().getDeviceTrackerResult(bqConnection, bqProjectID, resultsList);

			book = Workbook.getWorkbook(new File(fileLocation));
			writable = Workbook.createWorkbook(new File(fileLocation), book);

			if(book != null)
			{
				WritableSheet sheet = writable.getSheet(0);
				for(int i=0; i<resultsList.size(); i++)
				{
					JSONObject json = resultsList.get(i);

					/** check each received json object and iterate the devicedata array and collect all the 
					 * otherresult values and put it outside devicedata json in key result */
					json = putResultNode(json);

					String result = json.getString("result");
					String input = json.getString("input");
					String row = json.getString("row");
					String column = json.getString("column");

					String content = "Input: "+input + "\nResult: " + result;

					Label label = new Label(Integer.parseInt(column), Integer.parseInt(row), content);
					sheet.addCell(label);
				}
			}

			flag = true;
		}
		catch (Exception e) 
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while writing spreadsheet. ", e);
		}
		finally
		{
			try {
				writable.write();
				writable.close(); } catch (WriteException | IOException e) { }
			book.close();		
		}
		return flag;
	}

	/** This method will itrate the devicedata json array in the received json object and collect all values of key "otherresult"
	 * and put those values in key result outside the json array.
	 * 
	 * @param json
	 * @return
	 */
	public static JSONObject putResultNode(JSONObject json)
	{
		try {
			JSONArray devicedata = json.getJSONArray("devicedata");

			String result = "";
			for(int i=0; i<devicedata.length(); i++)
			{
				JSONObject deviceResults = devicedata.getJSONObject(i);
				result = result + deviceResults.getString("deviceid") + ":\n" + deviceResults.getString("otherresult") + "\n";
			}
			json.put("result", result);

		} catch (JSONException e) {
			try {
				json.put("result", "NO RESULT RECEIVED FOR THIS ITERATION.");
			} catch (JSONException e1) {}
		}

		return json;
	}

	/** This method will kill appium service.
	 */
	public static void killAppiumServer()
	{
		try
		{
			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				ExecuteCommands.ExecuteCommand_ReturnsOutput(new String[]{"cmd.exe", "/C", "taskkill /f /im node.exe"});
			}
			else
			{
				ExecuteCommands.ExecuteMacCommand_ReturnsOutput("killall node");
			}
		}
		catch(Exception e)
		{

		}
	}

	/** This method will kill all required process after test completion. */
	public static void sdkTestCleanUp()
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Clean up Appium Session . . . . ");
		try
		{
			String androidHome;
			String cmd = null;
			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				androidHome = MobileTestClass_Methods.propertyConfigFile.getProperty("AndroidSDK_Windows").toString();
				cmd = androidHome+"\\platform-tools\\adb kill-server";

				//Kill adb server
				ExecuteCommands.ExecuteCommand_ReturnsOutput(new String[]{"cmd.exe", "/C", cmd});
			}
			else
			{
				androidHome = MobileTestClass_Methods.propertyConfigFile.getProperty("AndroidSDK_Mac").toString();
				cmd = androidHome+"/platform-tools/adb kill-server";

				//Kill adb server
				ExecuteCommands.ExecuteMacCommand_ReturnsOutput(cmd);

				//Kill Simulator
				ExecuteCommands.ExecuteMacCommand_ReturnsOutput("killall \"iPhone Simulator\"");
			}

			//Kill Appium service
			SDKCommonUtils.killAppiumServer();

		}catch(Exception e){	}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sessions Cleaned...");
	}

	/**
	 * This method will create a bat file for windows and sh file for appium
	 * containing log file option, launch location of appium server to start the
	 * appium server.
	 * 
	 * @return
	 */
	public static boolean startAppiumServer() 
	{		
		//Kill any Existing Appium Before Starting new session
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Stopping any running instance of appium. ");
		try{SDKCommonUtils.killAppiumServer();}catch(Exception  e){}

		boolean flag = false;
		File logFile = null;
		String commandFile = null;

		if(System.getProperty("os.name").matches("^Windows.*"))
		{
			//Getting temp dir
			String tempDir = System.getProperty("java.io.tmpdir").toString();
			logFile = new File(tempDir+"\\applog"+"_"+MobileTestClass_Methods.DateTimeStamp()+".txt");

			commandFile = TestSuiteClass.AUTOMATION_HOME.concat("\\tpt\\appium_commands.bat");

			String appiumCmdLocation_Windows = MobileTestClass_Methods.propertyConfigFile.getProperty("appiumCmdLocationForWindows").toString();

			String nodeExe = appiumCmdLocation_Windows.concat("\\node.exe");
			String appiumJs = appiumCmdLocation_Windows.concat("\\node_modules\\appium\\bin\\Appium.js");

			String strText = "start /B " + nodeExe + "  " + appiumJs + " -g " + logFile.toString() + " --full-reset --command-timeout 90 ";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****** STARTING APPIUM SERVER USING COMMAND: "+strText);
			FileLib.WriteTextInFile(commandFile, strText);
		}
		else
		{
			logFile = new File("/tmp/applog"+"_"+MobileTestClass_Methods.DateTimeStamp()+".txt");
			commandFile = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/appium_commands.sh");

			String strText = "export PATH=$PATH:/usr/local/bin; /usr/local/bin/appium -g " + logFile.toString() + " --full-reset --command-timeout 90 " ;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****** STARTING APPIUM SERVER USING COMMAND: "+strText);
			FileLib.WriteTextInFile(commandFile, strText);
		}

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Command File: "+ commandFile +" to start appium service. ");
			Runtime.getRuntime().exec(commandFile);

			/** wait until appium server is started */
			flag = waitForAppiumServer();
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There were some issues while executing command to launch appium service. ",e);
		}

		return flag;
	}


	/** This method starts ios_webkit_debug_proxy server, which enables appium server to spawn through webviews.
	 * CONCERN: CURRENTLY THIS CODE IS HANDLING ONLY ONE DEVICE, LATER ON NEED TO CHNAGE THIS CODE TO ENABLE MULTIPLE DEVICES. 
	 * 
	 * @param udid
	 * @return
	 */
	public static boolean startiOSWebkitDebugProxyServer(String udid) 
	{		
		//Kill any Existing ios_webkit_debug_proxy Before Starting new session
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Stopping any running instance of ios_webkit_debug_proxy. ");
		ExecuteCommands.ExecuteMacCommand_ReturnsOutput("killall ios_webkit_debug_proxy");

		boolean flag = false;
		String commandFile = null;

		if(!System.getProperty("os.name").matches("^Windows.*"))
		{
			String strText = " export PATH=$PATH:/usr/local/bin; /usr/local/bin/ios_webkit_debug_proxy -c "+udid+":27753 -d ";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****** STARTING ios_webkit_debug_proxy SERVER USING COMMAND: "+strText);

			commandFile = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/ios_webkit_debug_proxy.sh");
			FileLib.WriteTextInFile(commandFile, strText);
		}

		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Command File: "+ commandFile +" to start ios_webkit_debug_proxy server. ");
			ExecuteCommands.ExecuteMacCommand_ReturnsOutput("chmod +x "+commandFile);
			Runtime.getRuntime().exec(commandFile);

			/** wait until appium server is started */
			flag = waitForiOSWebkitDebugProxy();
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There were some issues while executing command to launch ios_webkit_debug_proxy server. ",e);
		}

		return flag;
	}


	/** This method will wait maximum for 1500 * 5 = 7500 milliseconds until appium server is up and running
	 * by checking the output of request: http://localhost:4723/wd/status
	 * 
	 * @return
	 */
	public static boolean waitForAppiumServer()
	{
		boolean flag = false;

		for(int i=0; i<=20; i++)
		{		
			String status = httpClientWrap.sendGetRequest("http://localhost:4723/wd/status");

			if(!status.isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : appium service has been launched successfully. ");

				flag = true;
				break;
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : appium service has not been launched, waiting to get started .... attempt: "+i);

			try {Thread.sleep(3000);} catch (InterruptedException e) {}
		}

		return flag;
	}


	/** This method will wait maximum for 1500 * 5 = 7500 milliseconds until iOSWebkitDebugProxy server is up and running
	 * by checking the output of request: http://localhost:27753
	 * 
	 * @return
	 */
	public static boolean waitForiOSWebkitDebugProxy()
	{
		boolean flag = false;

		for(int i=0; i<=20; i++)
		{		
			String status = httpClientWrap.sendGetRequest("http://localhost:27753");

			if(!status.isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iOSWebkitDebugProxy service has been launched successfully. ");

				flag = true;
				break;
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iOSWebkitDebugProxy service has not been launched, waiting to get started .... attempt: "+i);

			try {Thread.sleep(3000);} catch (InterruptedException e) {}
		}

		return flag;
	}

	/**
	 * Re-Start appium common for windows and mac, in case appium server doesn't
	 * come up at first time then kill all running instances of appium and start
	 * it again.
	 * 
	 * @return
	 */
	public static boolean restartAppiumServer()
	{
		boolean flag = false;

		//Start appium service, if not started successfully then restart
		if(SDKCommonUtils.startAppiumServer())
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : appium service started successfully. ");
			flag = true;
		}
		else
		{	
			//Kill Appium service
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Cleaning any exisiting appium session . . . . ");
			SDKCommonUtils.killAppiumServer();

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Starting new appium session . . . . "); 

			if(SDKCommonUtils.startAppiumServer())
			{
				flag = true;
			}
			else
			{
				flag = false;
			}
		}

		return flag;
	}

	/**
	 * kill chromedriver only if its not responsive.
	 * 
	 * @return
	 */
	public static void chromeDriverHandler()
	{
		while(true)
		{
			try
			{
				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :  *********** Checking if chromedriver is responsive ....... *********** ");

				String url = "http://127.0.0.1:9515/wd/hub/sessions";
				JSONObject response = new JSONObject(httpClientWrap.sendGetRequest(url));

				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Chrome driver response: "+response.toString());

				JSONArray valueJsonArray = response.getJSONArray("value");
				if(valueJsonArray.length()<1)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******* No Response Received From Chromedriver, Killing Chromedriver ********** ");
					Runtime.getRuntime().exec("killall chromedriver");
				}
			}
			catch(Exception e)
			{
				//logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error - Couldn't kill chromedriver. ");
			}

			try {Thread.sleep(2000);} catch (InterruptedException e) {}
		}
	}

	/**Handle chrome driver in a thread.
	 * 
	 * @return
	 */
	public static Thread chromeDriverHandlerThread()
	{
		Thread chromeDriverHandler = new Thread(new Runnable() {
			public void run() {
				SDKCommonUtils.chromeDriverHandler();
			}
		});

		return chromeDriverHandler; 
	}

	/** Getting the mapping of ad format and test mapping.
	 * 
	 * @param fileName
	 * @param sheetName
	 * @return
	 */
	public static JSONObject getKeywordMappings()
	{
		JSONObject mappingJson = new JSONObject();

		try{
			Workbook book = Workbook.getWorkbook(new File(TestSuiteClass.AUTOMATION_HOME.concat("/conf/sdkValidation.xls")));
			Sheet sheet = book.getSheet("TC_Keyword_Mappings");

			int keywordsColumn = sheet.findLabelCell("Keywords").getColumn();

			//for each column
			for(int i=2; i<sheet.getColumns(); i++)
			{
				JSONObject keywordJson = new JSONObject();

				String adFormat = sheet.getCell(i, 0).getContents().trim().toLowerCase();

				//for each row
				for (int j=1; j<sheet.getRows(); j++)
				{
					String ifApplicable = sheet.getCell(i, j).getContents().trim();
					String keyword = sheet.getCell(keywordsColumn, j).getContents().trim();

					keywordJson.put(keyword, ifApplicable);
				}

				/** creating json containing {adformat, {keyword, yes/no}} */
				mappingJson.put(adFormat, keywordJson);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting the mapping of keywords and ad formats. ", e);
		}
		return mappingJson;
	}

	/** This method will get the value of supplied property either from sdk.properties.android or sdk.properties.os depending 
	 * upon type of driver is being used.
	 * 
	 * @param key
	 * @return
	 */
	public static String getSDKProperty(WebDriver driver, String key)
	{
		File conf = null;
		if(driver instanceof AndroidDriver<?>)
		{
			conf = new File(TestSuiteClass.AUTOMATION_HOME.toString().concat("/conf/sdk.properties.android"));	
		}
		else if(driver instanceof IOSDriver<?>)
		{
			conf = new File(TestSuiteClass.AUTOMATION_HOME.toString().concat("/conf/sdk.properties.ios"));
		}

		if(conf != null)
		{
			PropertiesConfiguration property = null;
			try {
				property = new PropertiesConfiguration(conf);
			} catch (ConfigurationException e) {}

			String value = property.getProperty(key).toString().trim();
			return value;
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****** Received Driver is: "+driver.toString() + " Which is neither ios driver nor android driver. ");
			return null;
		}
	}

	/** Put other result in supplied device json object.
	 * 
	 * @param deviceJsonObject
	 * @param otherresult
	 * @return
	 */
	public static JSONObject putDeviceOtherResult(JSONObject deviceJsonObject, String otherresult)
	{
		String result;
		try{
			result = deviceJsonObject.getString("otherresult");
			result = result + "\n" + otherresult;

			deviceJsonObject.put("otherresult", result);
		}catch(JSONException e)
		{
			try {
				deviceJsonObject.put("otherresult", otherresult);
			} catch (JSONException e1) {
			}
		}
		return deviceJsonObject;
	}

	/**
	 * Get standard ad format respective to sdk ad format.
	 * @param sdkAdFormat
	 * @return
	 */
	public static String getAdFormatMappings(String sdkAdFormat)
	{
		HashMap<String, String> map = XlsLib.getHashMapFromExcelsheet(TestSuiteClass.AUTOMATION_HOME.concat("/conf/sdkValidation.xls"), "AdFormat_Mappings", "SDK_AdFormats", "Standard_AdFormats");

		String adformat = map.get(sdkAdFormat.toLowerCase());
		return adformat;
	}

	/** Get the sdk type with the respect to supplied sdk ad format -- this will be used while 
	 * switching the context of driver to Native_App or Webview.
	 * 
	 * @param sdkAdFormat
	 * @return
	 */
	public static String getSDKType_AdFormatMappings(String sdkAdFormat)
	{
		HashMap<String, String> map = XlsLib.getHashMapFromExcelsheet(TestSuiteClass.AUTOMATION_HOME.concat("/conf/sdkValidation.xls"), "AdFormat_Mappings", "SDK_AdFormats", "SDK_Type");

		String adformat = map.get(sdkAdFormat.toLowerCase());
		return adformat;
	}

}
