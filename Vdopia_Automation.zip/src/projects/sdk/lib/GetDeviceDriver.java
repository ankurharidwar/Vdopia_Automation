package projects.sdk.lib;


import java.io.File;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import vlib.MobileTestClass_Methods;



public class GetDeviceDriver {

	static Logger logger = Logger.getLogger(GetDeviceDriver.class.getName());

	long timeout;

	public GetDeviceDriver(long timeout)
	{
		this.timeout = timeout;
	}

	/** Setup webdriver for android device / simulator
	 *  
	 * @param apkFile
	 * @param androidDeviceID
	 * @return
	 */
	public WebDriver setupAndroidDriver(File appFile, String deviceID)
	{
		WebDriver driver = null;

		try
		{
			DesiredCapabilities capabilities = new DesiredCapabilities();

			capabilities.setCapability("deviceName", "Android");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: deviceName = Android");

			capabilities.setCapability("platformName", "Android");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: platformName = Android");

			capabilities.setCapability("app", appFile.getAbsolutePath());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: app = "+appFile.getAbsolutePath());

			capabilities.setCapability("serial", deviceID);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: serial = "+deviceID);
			
			capabilities.setCapability("newCommandTimeout", "120");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: newCommandTimeout = 120");

			capabilities.setCapability("chromedriverExecutable", TestSuiteClass.AUTOMATION_HOME.concat("/tpt/chromedriver"));
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: chromedriverExecutable = "+TestSuiteClass.AUTOMATION_HOME.concat("/tpt/chromedriver"));

			/** dont use this capability, creating problem -- raised a bug in github */
			//			capabilities.setCapability("autoWebview", true);
			//			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: autoWebview = "+true);

			try{
				driver = new AndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), capabilities);
			}catch(Exception e){
				logger.error(e.getMessage(), e);
			}

			driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added Driver Timeout = "+timeout +" Sec. ");

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Context:   "+((AndroidDriver<?>)driver).getContext());
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Android Driver wasn't setup correctly. ", e);
		}
		return driver;					
	}

	/** Get iOS driver for iPhone.
	 * 
	 * @param appFile
	 * @param ipadORiPhone
	 * @param deviceUDID
	 * @return
	 */
	public WebDriver setupiPhoneDriver(File appFile, String deviceID)
	{
		WebDriver driver = null;

		try
		{			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up driver, adding all required capabilities... ");

			DesiredCapabilities capabilities = new DesiredCapabilities();

			capabilities.setCapability(CapabilityType.BROWSER_NAME, "iOS");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: BROWSER_NAME = iOS");

			capabilities.setCapability("platformName", "iOS");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: platformName = iOS");

			capabilities.setCapability("deviceName", "iPhone");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: deviceName = iPhone");

			capabilities.setCapability("udid", deviceID);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : UDID: "+deviceID+" capability is added to driver for the attached Device. ");

			capabilities.setCapability("newCommandTimeout", "120");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: newCommandTimeout = 120");
			
			//=====> This capability is not applicable to ios driver
			//capabilities.setCapability("chromedriverExecutable", TestSuiteClass.AUTOMATION_HOME.concat("/tpt/chromedriver"));
			//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: chromedriverExecutable = "+TestSuiteClass.AUTOMATION_HOME.concat("/tpt/chromedriver"));

			capabilities.setCapability("app", appFile.getAbsolutePath());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: app = "+ appFile.getAbsolutePath());

			capabilities.setCapability("waitForAppScript", true);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: waitForAppScript = "+ true);
			
			capabilities.setCapability("autoAcceptAlerts", true);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: autoAcceptAlerts = "+ true);
			
			driver = new IOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
		}
		catch(Exception e)
		{			
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iPhone driver wasn't setup correctly. ", e);			
		}
		return driver;

	}

	/**  Get iOS driver for iPad.
	 * 
	 * @param appFile
	 * @param deviceID
	 * @return
	 */
	public WebDriver setupiPadDriver(File appFile, String deviceID)
	{
		WebDriver driver = null;

		try
		{			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up driver, adding all required capabilities... ");

			DesiredCapabilities capabilities = new DesiredCapabilities();

			//Add Browser Name
			capabilities.setCapability(CapabilityType.BROWSER_NAME, "iOS");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: BROWSER_NAME = iOS");

			//Add Platform
			capabilities.setCapability("platformName", "iOS");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: platformName = iOS");

			//Add device type
			capabilities.setCapability("deviceName", "iPad");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: deviceName = iPad");

			String ipadOS = MobileTestClass_Methods.propertyConfigFile.getProperty("iPadOSVersion").toString();

			//Optional - probable default is 7.0
			capabilities.setCapability(CapabilityType.VERSION, ipadOS);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: VERSION = "+ipadOS);

			//Only for iPhone device - Add UDID (Stored in Configuration File)
			capabilities.setCapability("udid", deviceID);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : UDID: "+deviceID+" capability is added to driver for the attached Device. ");

			//Get the .app file to install and launch app in simulator / device
			capabilities.setCapability("app", appFile.getAbsolutePath());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Added capability: app = "+ appFile.getAbsolutePath());

			//Retry driver setup with max three attempts in case failure
			int i =1;
			while(i<=3)
			{
				try
				{
					//Create an instance of RemoteWebDriver and connect to the Appium server can be used for simulator.
					driver = new RemoteWebDriver(new URL("http://localhost:4723/wd/hub"), capabilities);
					//Thread.sleep(5000);

					//Adding implicit time outs
					driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
					break;
				}
				catch(Exception e)
				{
					driver = null;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while installing app in mobile device. "+e.getMessage());

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Driver session wasn't started successfully, hence retrying... attempt# "+i);
					i = i+1;
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred: ", e);
				}
			}
		}
		catch(Exception e)
		{			
			driver = null;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: SetupDriverAndApp_iPhoneDevice. ", e);			
		}
		return driver;

	}

	/**
	 * Get driver based on connected device. 
	 * 
	 * @param androidDeviceConnected
	 * @param iphoneDeviceConnected
	 * @param ipadDeviceConnected
	 * @param appFile
	 * @param deviceID
	 * @return
	 */
	public WebDriver getDriver(boolean androidDeviceConnected, boolean iphoneDeviceConnected,
			boolean ipadDeviceConnected, File appFile, String deviceID)
	{
		if(androidDeviceConnected)
		{
			return setupAndroidDriver(appFile, deviceID); 
		}
		else if(ipadDeviceConnected)
		{
			return setupiPadDriver(appFile, deviceID);
		}
		else if(iphoneDeviceConnected)
		{
			return setupiPhoneDriver(appFile, deviceID);
		}
		else
		{
			return null;
		}

	}

}
