/**
 * Last Changes Done on 5 Mar, 2015 12:07:45 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains the test of android lw sdk, here dataprovider method will supply the apikey in form of json object,
 * these apikeys will be integrated into sample app and then android project will be compiled to create apk file and this file will be installed in
 * device and test will be executed. Before running this class, make sure android project is set according doc located at: Vdopia_Automation/docs/SDK-Test-Data-Setup.txt
 * 
 * For iOS: 
 * MPSDK: 
 * 1. create an .a file with the name of libMpSdkLibrary of mp sdk project located at ../tc_data/iOS/MediaPlayer after changing serve url
 * in file /tc_data/sdk/iOS/MediaPlayer/mpsdk/Mdefines.h - This is to be done in before test
 * 
 * 2. copy this .a file at ../tc_data/iOS/Media_Player_Sample_App/sdk/libMpSdkLibrary.a
 * in iOS project and then proceed for test. 
 * 
 * THIS CLASS SOLELY SHOULD DRIVE THE TEST FOR BOTH LIGHT WEIGHT AND MEDIA PLAYER SDK.
 */

package projects.sdk;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.chrome.handler.ChromedriverHandler;
import com.google.api.services.bigquery.Bigquery;
import com.mysql.jdbc.Connection;

import projects.bq.BQHandler;
import projects.sdk.lib.AppIntegrationLib;
import projects.sdk.lib.GetResults;
import projects.sdk.lib.SDKCommonUtils;
import projects.sdk.lib.SDKSetUp_Android;


import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.UIOperations_MobileDeviceLib;


public class SDKAdServingTest 
{
	File sdk_testResultFile;
	String sdkTestDataFile;
	List<JSONObject> sdkResultList = new ArrayList<>();

	List<String> androidDeviceList;
	boolean androidDeviceConnected;

	boolean iphoneDeviceConnected;
	boolean ipadDeviceConnected;

	List<String> ipadDeviceList = new ArrayList<>();
	List<String> iPhoneDeviceList = new ArrayList<>();

	static JSONObject adformatTcMaping = new JSONObject(); 

	private static Bigquery bqConnection;
	private static String bqProjectID;
	private static Connection connection;

	static Logger logger = Logger.getLogger(SDKAdServingTest.class.getName());


	/** Before Test Setup.
	 */
	@BeforeClass
	public void beforeClass() 
	{
		try
		{			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** STARTING AD SERVING TEST **************");

			/** initialize configuration */
			MobileTestClass_Methods.InitializeConfiguration();

			/** getting big query and mysql connection details */
			connection = MobileTestClass_Methods.CreateSQLConnection();

			bqConnection = new BQHandler().createBqConnection();
			if(MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString().trim().equalsIgnoreCase("qa")){
				bqProjectID = MobileTestClass_Methods.propertyConfigFile.getProperty("qaBigQueryProjectId").toString().trim();
			}
			else{
				bqProjectID = MobileTestClass_Methods.propertyConfigFile.getProperty("prodBigQueryProjectId").toString().trim();
			}

			/** Now test data file will not be written rather a static file is kept having existing data */
			sdkTestDataFile = TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/sdk/tc_data_sdk.xls").toString();

			/** Copy Test Data File In Test Result Folder */
			sdk_testResultFile = FileLib.CopyExcelFile(sdkTestDataFile, TestSuiteClass.AUTOMATION_HOME.concat("/results/sdk/Test_Results/").concat("SDK_TestResults").toString());

			/** Android Setup: Get all the attached android device id */
			androidDeviceConnected = UIOperations_MobileDeviceLib.ifAndroidDeviceConnected();
			if(androidDeviceConnected){
				androidDeviceList = UIOperations_MobileDeviceLib.getAndroidDeviceList();
			}

			/** iOS related stuff will not be applicable on windows */
			if(System.getProperty("os.name").matches("^Windows.*")){
				ipadDeviceConnected = false;
				iphoneDeviceConnected = false;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iOS setup will not be done on windows. ");
			}
			else{
				/** Checking if any iPhone device is attached to computer */ 
				iphoneDeviceConnected = UIOperations_MobileDeviceLib.ifiPhoneConnected();
				if(iphoneDeviceConnected){
					iPhoneDeviceList = UIOperations_MobileDeviceLib.getUDID_iPhone();
				}

				/** Checking if any ipad device is attached to computer, a command will be executed to find UDID of iphone then only test will be executed.*/ 
				ipadDeviceList = UIOperations_MobileDeviceLib.getUDID_iPad();
				if(ipadDeviceConnected){
					ipadDeviceConnected = UIOperations_MobileDeviceLib.ifiPadConnected();
				}
			}

			if(!ipadDeviceConnected && !iphoneDeviceConnected && !androidDeviceConnected)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Nether android nor ios device is attached to this computer, therefore appium service will not be started.. ");
				Assert.fail("******** Nether android nor ios device is attached to this computer. **********");
			}
			else
			{
				/** NEED TO REVISIT::::: checking if .a file is created and copied in project location for both lw and mp sdk -- only if any iOS device is found */
				//				if(ipadDeviceConnected || iphoneDeviceConnected){
				//					if(!new AppIntegrationLib().setUniversalStaticLibForiOS("lwsdk") || !new AppIntegrationLib().setUniversalStaticLibForiOS("mpsdk")){
				//						Assert.fail("********** UNIVERSAL STATIC LIB (.a) FILE WASN'T SET SUCCESSFULLY, ABORTING TEST *************");
				//					}
				//				}

				/** in case any attached device is found, start appium server, if appium server is not started then abort the test */
				boolean appiumStartFlag = SDKCommonUtils.restartAppiumServer();

				if(!appiumStartFlag)
				{
					Assert.fail("********** APPIUM SERVER WASN'T STARTED, ABORTING TEST *************");
				}
				else
				{
					/** read spreadsheet /conf/sdkValidation.xls containing the mapping of ad format and keywords */
					adformatTcMaping = SDKCommonUtils.getKeywordMappings();

					/** Handle chrome driver in a thread, calling the external jar */
					//SDKCommonUtils.chromeDriverHandlerThread().start();

					ChromedriverHandler.chromeDriverHandlerThread().start();

					/** Staring ios_webkit_debug_proxy server along with appium server, 
					 * ========>>>>>>> CURRENTLY SUPPORTING ONLY ONE DEVICE , LATER ON NEEDS TO CHNAGE THIS CODE ======>>>>> */
					SDKCommonUtils.startiOSWebkitDebugProxyServer(iPhoneDeviceList.get(0));
				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred in before test. ", e);
		}

	}

	/** Get all the rows from the supplied test data file and get the data of all the cells and their location in form 
	 * of json object and return an array of json objects.  
	 * 
	 * @return
	 */
	@DataProvider(name="getSdkTestData")
	public JSONObject[][] getTestDataForSDK() 
	{
		JSONObject[][] arrTestURL = SDKCommonUtils.readSpreadSheetAsJson(sdkTestDataFile, connection);
		return arrTestURL;
	}

	/**
	 * This method executes the actual test on android mp sdk project, supplied
	 * test data for this test is in json format like: { "input" : "xyz", "row"
	 * : "2", "column" : "2" } At the end of each test, "result": "xyz" also
	 * need to be collected.
	 * 
	 * @param sequence
	 * @param api_KEY_NONCLICKABLE_TEMPLATE
	 * @param api_KEY_SKIP_TEMPLATE
	 * @param api_KEY_TALK2ME_TEMPLATE
	 * @param api_KEY_SLIDEOUT_TEMPLATE
	 * @param api_KEY_SWIPETOREVEAL_TEMPLATE
	 * @param api_KEY_MULTITHUMBNAIL_TEMPLATE
	 * @param api_KEY_STATIC_BANNER
	 * @param api_KEY_ANIMATED_BANNER
	 * @param api_KEY_MRECT_STATIC_BANNER
	 * @param api_INVIEW_SCROLLVIEW
	 * @param api_KEY_MRECT_INVIEW_VIDEO
	 * @param api_KEY_EXP_BANNER_MIN_VIDEO
	 * @param api_KEY_EXP_BANNER_MED_VIDEO
	 * @param api_KEY_INVIEW_TABLEVIEW
	 * @param api_KEY_FULL_SCREEN_INTERSTITIAL
	 * @param api_KEY_FULL_SCREEN_STATIC_BANNER
	 * @param api_KEY_FULL_SCREEN_MAX_VIDEO
	 * @param api_KEY_LEADERBOARD_VIDEO
	 * @param api_KEY_LEADERBOARD_STATIC_BANNER
	 * @param api_KEY_LEADERBOARD_ANIMATED_BANNER
	 */
	@Test(dataProvider="getSdkTestData")
	public void sdkTest(JSONObject sequence, JSONObject api_KEY_NONCLICKABLE_TEMPLATE, JSONObject api_KEY_SKIP_TEMPLATE, JSONObject api_KEY_TALK2ME_TEMPLATE, 
			JSONObject api_KEY_SLIDEOUT_TEMPLATE, JSONObject api_KEY_SWIPETOREVEAL_TEMPLATE, JSONObject api_KEY_MULTITHUMBNAIL_TEMPLATE,

			JSONObject api_KEY_STATIC_BANNER, JSONObject api_KEY_ANIMATED_BANNER, JSONObject api_KEY_MRECT_STATIC_BANNER,
			JSONObject api_INVIEW_SCROLLVIEW, JSONObject api_KEY_MRECT_INVIEW_VIDEO, JSONObject api_KEY_EXP_BANNER_MIN_VIDEO, 
			JSONObject api_KEY_EXP_BANNER_MED_VIDEO, JSONObject api_KEY_INVIEW_TABLEVIEW, JSONObject api_KEY_FULL_SCREEN_INTERSTITIAL, 
			JSONObject api_KEY_FULL_SCREEN_STATIC_BANNER, JSONObject api_KEY_FULL_SCREEN_MAX_VIDEO, JSONObject api_KEY_LEADERBOARD_VIDEO,
			JSONObject api_KEY_LEADERBOARD_STATIC_BANNER, JSONObject api_KEY_LEADERBOARD_ANIMATED_BANNER
			)
	{
		try
		{
			if(iphoneDeviceConnected)
			{
				File appFile = new AppIntegrationLib().getiOSAppFile(api_KEY_NONCLICKABLE_TEMPLATE, api_KEY_SKIP_TEMPLATE, api_KEY_TALK2ME_TEMPLATE, 
						api_KEY_SLIDEOUT_TEMPLATE, api_KEY_SWIPETOREVEAL_TEMPLATE, api_KEY_MULTITHUMBNAIL_TEMPLATE,

						api_KEY_STATIC_BANNER, api_KEY_ANIMATED_BANNER, api_KEY_MRECT_STATIC_BANNER,
						api_INVIEW_SCROLLVIEW, api_KEY_MRECT_INVIEW_VIDEO, api_KEY_EXP_BANNER_MIN_VIDEO, 
						api_KEY_EXP_BANNER_MED_VIDEO, api_KEY_INVIEW_TABLEVIEW, api_KEY_FULL_SCREEN_INTERSTITIAL, 
						api_KEY_FULL_SCREEN_STATIC_BANNER, api_KEY_FULL_SCREEN_MAX_VIDEO, api_KEY_LEADERBOARD_VIDEO,
						api_KEY_LEADERBOARD_STATIC_BANNER, api_KEY_LEADERBOARD_ANIMATED_BANNER);

				//********* Only for debugging ****
				//File appFile = new File("/Users/Pankaj/Desktop/QA_Automation/qascripting/Vdopia_Automation/tc_data/sdk/iOS/AllFormats/build/Release-iphoneos/Vdopia LW.app");

				/** get results from all connected devices and store it in a List of JsonObject */
				List<JSONObject> deviceResultsList = Arrays.asList( 
						new GetResults().getResults(false, true, false, appFile, iPhoneDeviceList, 
								api_KEY_NONCLICKABLE_TEMPLATE, api_KEY_SKIP_TEMPLATE, api_KEY_TALK2ME_TEMPLATE, 
								api_KEY_SLIDEOUT_TEMPLATE, api_KEY_SWIPETOREVEAL_TEMPLATE, api_KEY_MULTITHUMBNAIL_TEMPLATE,

								api_KEY_STATIC_BANNER, api_KEY_ANIMATED_BANNER, api_KEY_MRECT_STATIC_BANNER,
								api_INVIEW_SCROLLVIEW, api_KEY_MRECT_INVIEW_VIDEO, api_KEY_EXP_BANNER_MIN_VIDEO, 
								api_KEY_EXP_BANNER_MED_VIDEO, api_KEY_INVIEW_TABLEVIEW, api_KEY_FULL_SCREEN_INTERSTITIAL, 
								api_KEY_FULL_SCREEN_STATIC_BANNER, api_KEY_FULL_SCREEN_MAX_VIDEO, api_KEY_LEADERBOARD_VIDEO,
								api_KEY_LEADERBOARD_STATIC_BANNER, api_KEY_LEADERBOARD_ANIMATED_BANNER
								));

				/** add all device results to a global result list */
				sdkResultList.addAll(deviceResultsList);
			}

			if(ipadDeviceConnected)
			{
				//yet to implement
			}

			if(androidDeviceConnected)
			{
				/** get apk file to be installed in each device */
				File apkFile = new AppIntegrationLib().getAPK_AndroidSDK(SDKSetUp_Android.getAndroidHome(),

						api_KEY_STATIC_BANNER.getString("input"),  api_KEY_ANIMATED_BANNER.getString("input"),  api_KEY_MRECT_STATIC_BANNER.getString("input"),
						api_INVIEW_SCROLLVIEW.getString("input"),  api_KEY_MRECT_INVIEW_VIDEO.getString("input"),  api_KEY_EXP_BANNER_MIN_VIDEO.getString("input"),  
						api_KEY_EXP_BANNER_MED_VIDEO.getString("input"), api_KEY_INVIEW_TABLEVIEW.getString("input"),  api_KEY_FULL_SCREEN_INTERSTITIAL.getString("input"), 
						api_KEY_FULL_SCREEN_STATIC_BANNER.getString("input"),  api_KEY_FULL_SCREEN_MAX_VIDEO.getString("input"), api_KEY_LEADERBOARD_VIDEO.getString("input"),
						api_KEY_LEADERBOARD_STATIC_BANNER.getString("input"),  api_KEY_LEADERBOARD_ANIMATED_BANNER.getString("input"),

						api_KEY_NONCLICKABLE_TEMPLATE.getString("input"),  api_KEY_SKIP_TEMPLATE.getString("input"),  api_KEY_TALK2ME_TEMPLATE.getString("input"), 
						api_KEY_SLIDEOUT_TEMPLATE.getString("input"),  api_KEY_SWIPETOREVEAL_TEMPLATE.getString("input"),  api_KEY_MULTITHUMBNAIL_TEMPLATE.getString("input")

						);

				//************** JUST FOR DEBUGGING PURPOSE *******************************************
				//File apkFile = new File("/Users/Pankaj/Desktop/QA_Automation/qascripting/Vdopia_Automation/tc_data/sdk/android/VdopiaSDKSample_StandAlone/app/build/outputs/apk/app-debug.apk");


				/** get results from all connected devices and store it in a List of JsonObject */
				List<JSONObject> deviceResultsList = Arrays.asList( 
						new GetResults().getResults(true, false, false, apkFile, androidDeviceList, 
								api_KEY_NONCLICKABLE_TEMPLATE, api_KEY_SKIP_TEMPLATE, api_KEY_TALK2ME_TEMPLATE, 
								api_KEY_SLIDEOUT_TEMPLATE, api_KEY_SWIPETOREVEAL_TEMPLATE, api_KEY_MULTITHUMBNAIL_TEMPLATE,

								api_KEY_STATIC_BANNER, api_KEY_ANIMATED_BANNER, api_KEY_MRECT_STATIC_BANNER,
								api_INVIEW_SCROLLVIEW, api_KEY_MRECT_INVIEW_VIDEO, api_KEY_EXP_BANNER_MIN_VIDEO, 
								api_KEY_EXP_BANNER_MED_VIDEO, api_KEY_INVIEW_TABLEVIEW, api_KEY_FULL_SCREEN_INTERSTITIAL, 
								api_KEY_FULL_SCREEN_STATIC_BANNER, api_KEY_FULL_SCREEN_MAX_VIDEO, api_KEY_LEADERBOARD_VIDEO,
								api_KEY_LEADERBOARD_STATIC_BANNER, api_KEY_LEADERBOARD_ANIMATED_BANNER
								));

				/** add all device results to a global result list */
				sdkResultList.addAll(deviceResultsList);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : This test case is stopped because of exception. ", e);
		}
	}

	/**
	 * Write Results.
	 */
	@SuppressWarnings("deprecation")
	@AfterClass
	public void tearDown()  
	{
		try
		{
			/** stopping chrome driver thread */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Stopping Monitoring Thread ... ");
			ChromedriverHandler.chromeDriverHandlerThread().stop();

			/** write sdk results in excel sheet */
			SDKCommonUtils.writeExcelSheetWithJsonData(sdk_testResultFile.toString(), sdkResultList, bqConnection, bqProjectID);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ************** SDK AdServing Test Ended ****** " );


			/** Updating results to main results sheet, NEED TO REVISIT THIS CODE LATER ON */
			//			String resultSheetName;
			//			resultSheetName = "LWSDK_AdServe";
			//
			//			File f = new File(testDataFile);
			//			int totalTestCase = (XlsLib.getTotalRowOfExcelWorkbook(f))-1;
			//			TestSuiteClass.totalTC.put(resultSheetName, totalTestCase);
			//			
			//			XlsLib result = new XlsLib();
			//			String Data[][] = result.dataFromExcel(testResultFile.toString());
			//
			//			result.updateResultInNewSheet(TestSuiteClass.executionResult, resultSheetName, Data);
			//
			//			Excel2Html.GenerateResultExcelintoHTML(testResultFile.toString(), TestSuiteClass.resultFileLocation + "/" + resultSheetName + ".html");			
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred at the end of SDK Test.", e);
		}
		finally
		{
			//Cleaning Session
			SDKCommonUtils.sdkTestCleanUp();
		}
	}

	/** getter - adformatTcMaping */
	public static JSONObject getAdformatTcMaping()
	{
		return adformatTcMaping;
	}

	/** Getter bqConnection
	 * @return
	 */
	public static Bigquery getBqConnection() {
		return bqConnection;
	}

	/** Getter bqProjectID
	 * @return
	 */
	public static String getBqProjectID() {
		return bqProjectID;
	}

	/** Getter my connection
	 * @return
	 */
	public static Connection getConnection() {
		return connection;
	}

}
