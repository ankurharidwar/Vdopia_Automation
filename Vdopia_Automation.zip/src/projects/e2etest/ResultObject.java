package projects.e2etest;

import java.util.concurrent.atomic.AtomicBoolean;

public class ResultObject {

	String result;	
	AtomicBoolean ifBidderWon;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public AtomicBoolean getIfBidderWon() {
		return ifBidderWon;
	}

	public void setIfBidderWon(AtomicBoolean ifBidderWon) {
		this.ifBidderWon = ifBidderWon;
	}
	
}
