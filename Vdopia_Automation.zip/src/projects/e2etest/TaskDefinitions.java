package projects.e2etest;


import java.util.Date;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import org.json.JSONObject;

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import vlib.FileLib;
import vlib.MobileTestClass_Methods;


public class TaskDefinitions {

	Logger logger = Logger.getLogger(TaskDefinitions.class.getName());

	/** This method will return the executable task -- which will be executed by an executor.
	 * 
	 * @param driverFile
	 * @param mapAllTasksFromDriverSheet
	 * @param taskID
	 * @param freeJsontestDataID
	 * @param channelTestData
	 * @param campaignTestData
	 * @param bidderTestData
	 * @param packageTestData
	 * @param dealTestData
	 * @param connection
	 * @param taskResult
	 * @param sessionServe
	 * @param jsonObjectRepo
	 * @param sessionBidder
	 * @param bigQueryConnection
	 * @param bqProjectId
	 * @return
	 */
	@SuppressWarnings("finally")
	public synchronized Object executePortalTask( String driverFile,  TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskID,  String freeJsontestDataID,  TreeMap<String, TreeMap<String, String>> channelTestData,  TreeMap<String, TreeMap<String, String>> campaignTestData,
			TreeMap<String, TreeMap<String, String>> bidderTestData, TreeMap<String, TreeMap<String, String>> packageTestData, TreeMap<String, 
			TreeMap<String, String>> dealTestData,  Connection connection,  Session sessionServe, 
			JSONObject jsonObjectRepo,  Session sessionBidder, Bigquery bigQueryConnection,  String bqProjectId)
	{

		boolean flag = false;
		String result = "";
		try
		{
			/** generating a uniq id for each thread - to be used for logging */
			TestSuiteClass.UNIQ_EXECUTION_ID.set(taskID);

			/** get free json test data map */
			HashMap<String, String> jsonTestDataMap = LaunchE2ETest.jsonTestDataMap.get(freeJsontestDataID);

			/** merge the free test data map in to subsequent bidder, campaign, channel and other maps to be used later on */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Setting up test data maps.... ");
			
			TreeMap<String, TreeMap<String, String>> finalChannelTestData = new TestSetup().getFinalTestDataMap(channelTestData, jsonTestDataMap, taskID);
			TreeMap<String, TreeMap<String, String>> finalCampaignTestData = new TestSetup().getFinalTestDataMap(campaignTestData, jsonTestDataMap, taskID);
			TreeMap<String, TreeMap<String, String>> finalBidderTestData = new TestSetup().getFinalTestDataMap(bidderTestData, jsonTestDataMap, taskID);
			TreeMap<String, TreeMap<String, String>> finalPackageTestData = new TestSetup().getFinalTestDataMap(packageTestData, jsonTestDataMap, taskID);
			TreeMap<String, TreeMap<String, String>> finalDealTestData = new TestSetup().getFinalTestDataMap(dealTestData, jsonTestDataMap, taskID);

			/** clear targeting of every test data -- this will cleared again by the test cases also -->
			 * doing it here at first time is beneficial coz if Bidder is set to No in driver test case, then this code
			 * will make this bidder approved and thus will be utilized in test execution. */
			if(MobileTestClass_Methods.propertyConfigFile.getProperty("[clearTargeting]").equals("yes")){

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Clearing targeting now for test data id - "+freeJsontestDataID);
				new TestSetup().clearAllTargeting(taskID, connection, finalBidderTestData, finalCampaignTestData, 
						finalChannelTestData, finalPackageTestData, finalDealTestData);
			}

			/** perform the test setup on UI and collect all the results here */
			TreeMap<String, String> testsetupResultsMap = new TestSetup().performPortalActions(mapAllTasksFromDriverSheet, taskID, finalChannelTestData, 
					finalCampaignTestData, finalBidderTestData, finalPackageTestData, finalDealTestData, jsonObjectRepo, connection);
			result = testsetupResultsMap.get("result");

			/** New design - separating portal and chocolate tasks, now if portal task is completed successfully then only proceed for
			 * chocolate task - based on a flag. Now objects will be used to store all the required values to be used for chocolate tasks 
			 */
			AtomicBoolean ifProceedChocolateTask = new AtomicBoolean(false);
			if(!testsetupResultsMap.get("campaignStatus").equalsIgnoreCase("fail") && !testsetupResultsMap.get("channelStatus").equalsIgnoreCase("fail") 
					&& !testsetupResultsMap.get("bidderStatus").equalsIgnoreCase("fail") && !testsetupResultsMap.get("packageStatus").equalsIgnoreCase("fail") 
					&& !testsetupResultsMap.get("dealStatus").equalsIgnoreCase("fail")){

				/** setting up flag to true if portal is successful */
				ifProceedChocolateTask = new AtomicBoolean(true);
			}

			/** to execute chocolate task, adding all required values to objects and put it in a static map - to be referred by chocolate task executor only */
			TaskObjects taskObject = new TaskObjects();
			taskObject.setBigQueryConnection(bigQueryConnection);
			taskObject.setBqProjectId(bqProjectId);
			taskObject.setConnection(connection);
			taskObject.setDriverFile(driverFile);
			taskObject.setFinalBidderTestData(finalBidderTestData);
			taskObject.setFinalCampaignTestData(finalCampaignTestData);
			taskObject.setFinalChannelTestData(finalChannelTestData);
			taskObject.setFinalDealTestData(finalDealTestData);
			taskObject.setFinalPackageTestData(finalPackageTestData);
			taskObject.setMapAllTasksFromDriverSheet(mapAllTasksFromDriverSheet);
			taskObject.setSessionBidder(sessionBidder);
			taskObject.setSessionServe(sessionServe);
			taskObject.setTaskID(taskID);
			taskObject.setResult(result);
			taskObject.setIfProceedChocolateTask(ifProceedChocolateTask);
			taskObject.setPortalTaskEndTime(new Date().getTime());
			taskObject.setRetrychocolatetest(new AtomicBoolean(false));

			/** update chocolate task map */
			LaunchE2ETest.mapAllTasksForChocolate.put(taskID, taskObject);

			/** updating result map once while portal execution and second time while chocolate execution that way -- Pass will be from 
			 * chocolate and Fail will be from here */
			LaunchE2ETest.taskResult.put(taskID, TestSuiteClass.UNIQ_EXECUTION_ID.get()+":\n"+result);

			/** Marking the status = 1 for the SUCCESSFUL portal completed tasks and for failures marking 1000 to show these as COMPLETED TASKS so that Chocolate task doesn't get triggered */
			if(ifProceedChocolateTask.get()){
				LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).put("status", String.valueOf(new TaskCompletionCode().getCode_portalTaskCompletion()));
			}else{
				LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).put("status", String.valueOf(new TaskCompletionCode().getCode_allTasksCompletion()));
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Marking Completed - task Id: " +taskID + " Status for chocolate task: "+ifProceedChocolateTask);

			/** this flag says - that there is no exception in this execution */
			flag = true;
		}catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Occurred while executing Portal Test - "+e.getMessage(), e);
		}
		finally
		{
			/** this flag says - that there is no exception in this execution */
			if(!flag)
			{
				/** Marking the status = 0 for this uncompleted tasks only in case of exception, so that it can be picked up again */
				new TaskHandler().setTaskIDFree(taskID);

				/** possible reason for infinite loop - was in case of exception, we are freeing up portal task but not the test data */
				new TaskHandler().setTestDataIdFree(freeJsontestDataID);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + " Portal Task Re-Assigned Because Exception .. ");		
				return TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Portal Task Re-Assigned";
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + "Portal Task Completed .. ");
				return TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Portal Task Completed";
			}
		}
	}


	/** This is a separate task to be executed at chocolate server by a separate executor 
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskID
	 * @param sessionServe
	 * @param sessionBidder
	 * @param connection
	 * @param finalChannelTestData
	 * @param finalCampaignTestData
	 * @param finalBidderTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 * @param bigQueryConnection
	 * @param bqProjectId
	 * @param driverFile
	 * @return
	 */
	public synchronized Object executeChocolateTask(TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskID,
			Session sessionServe, Session sessionBidder, Connection connection,
			TreeMap<String, TreeMap<String, String>> finalChannelTestData, TreeMap<String, 
			TreeMap<String, String>> finalCampaignTestData,
			TreeMap<String, TreeMap<String, String>> finalBidderTestData, 
			TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData,
			Bigquery bigQueryConnection, String bqProjectId, String driverFile, String result, TaskObjects testObject)
	{

		try
		{			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Executing chocolate task .... ");

			/** Setup Requisites - like setting up delay, requisite format is like: {"delayinsec": "10","a1": "b1"} */
			new TestSetup().setupTestPrerequisites(mapAllTasksFromDriverSheet, taskID);

			/** getting serve url from the generic tag */
			String tag = FileLib.ReadContentOfFile(TestSuiteClass.AUTOMATION_HOME.concat("/tpt/tag.txt"));
			String serveURL = new E2EGenericMethods().getServeURLFromChannelTag(tag);

			/** check if rules are required to be applied, if yes then, get urls in form of JsonArray from Driver Sheet */
			if(new RulesForURL().ifURLRulesRequired(taskID, mapAllTasksFromDriverSheet))
			{
				result = result + " ---  " + new ValidationHandler().performValidation_AfterApplyingURLRules(taskID, mapAllTasksFromDriverSheet, 
						finalCampaignTestData, finalChannelTestData, finalBidderTestData, finalPackageTestData, finalDealTestData, 
						connection, sessionServe, sessionBidder, driverFile, serveURL, bigQueryConnection, bqProjectId);
			}

		}catch(Exception e)
		{
			result = result + "  --- " + e.getMessage();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}
		finally
		{
			/** updating result map once while portal execution and second time while chocolate execution that way -- Pass will be from 
			 * chocolate and Fail will be from here */
			LaunchE2ETest.taskResult.put(taskID, TestSuiteClass.UNIQ_EXECUTION_ID.get()+":\n"+result);

			/** check if retry is required */
			new TaskHandler().ifRetryChocolateTest(taskID, result, testObject);
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + "Chocolate Task Completed .. ");
		return TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Chocolate Task Completed";

	}
}
