package projects.e2etest;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

public class LaunchValidationModules {

	Logger logger = Logger.getLogger(LaunchValidationModules.class.getName());


	/** This method will perform the validations received from driver sheet using reflection, user can supply multiple modules in a 
	 * comma separated way. 
	 * 
	 * @param methodName
	 * @param tag
	 * @param taskID
	 * @param driverFile
	 * @param mapAllTasksFromDriverSheet2
	 * @param channelTestData2
	 * @param campaignTestData2
	 * @param bidderTestData2
	 * @param packageTestData2
	 * @param dealTestData2
	 * @param con
	 * @param sessionServe
	 * @param sessionBidder
	 * @return
	 */
	public String launchValidationModule (String methodName, String tag,
			String taskID, String driverFile, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet2, 
			TreeMap<String, TreeMap<String, String>> channelTestData2, TreeMap<String, TreeMap<String, String>> campaignTestData2, 
			TreeMap<String, TreeMap<String, String>> bidderTestData2, TreeMap<String, TreeMap<String, String>> packageTestData2, 
			TreeMap<String, TreeMap<String, String>> dealTestData2, Connection con, Session sessionServe, Session sessionBidder, 
			Bigquery bigQueryConnection, String bqProjectId)
	{
		Object validationResult = "";
		try
		{
			Class<?> validationsClass = null;

			try {
				validationsClass = Class.forName(ValidationModules.class.getName());
			} catch (ClassNotFoundException e) {}

			if(validationsClass != null)
			{
				methodName = methodName.toString().trim().toLowerCase();
				
				if(methodName.contains(","))
				{
					List<String> methods = Arrays.asList(methodName.split(","));

					/** iterate the method list */
					for(String methodNames : methods)
					{
						validationResult = validationResult + "\n" + invokeMethods(methodNames, validationsClass, tag, 
								taskID, driverFile, mapAllTasksFromDriverSheet2, channelTestData2, campaignTestData2, 
								bidderTestData2, packageTestData2, dealTestData2, con, sessionServe, sessionBidder, bigQueryConnection, bqProjectId);
					}
				}
				else
				{
					validationResult = validationResult + "\n" + invokeMethods(methodName, validationsClass, tag, 
							taskID, driverFile, mapAllTasksFromDriverSheet2, channelTestData2, campaignTestData2, 
							bidderTestData2, packageTestData2, dealTestData2, con, sessionServe, sessionBidder, bigQueryConnection, bqProjectId);
				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + ": " +e.getMessage(), e);
		}

		return (String) validationResult;
	}


	/** this method invokes modules in a reflection way.
	 * 
	 * @param methodName
	 * @param validationsClass
	 * @param tag
	 * @param taskID
	 * @param driverFile
	 * @param mapAllTasksFromDriverSheet2
	 * @param channelTestData2
	 * @param campaignTestData2
	 * @param bidderTestData2
	 * @param packageTestData2
	 * @param dealTestData2
	 * @param con
	 * @param sessionServe
	 * @param sessionBidder
	 * @return
	 */
	public Object invokeMethods(String methodName, Class<?> validationsClass, String tag,
			String taskID, String driverFile, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet2, 
			TreeMap<String, TreeMap<String, String>> channelTestData2, TreeMap<String, TreeMap<String, String>> campaignTestData2, 
			TreeMap<String, TreeMap<String, String>> bidderTestData2, TreeMap<String, TreeMap<String, String>> packageTestData2, 
			TreeMap<String, TreeMap<String, String>> dealTestData2, Connection con, Session sessionServe, Session sessionBidder,
			Bigquery bigQueryConnection, String bqProjectId)
	{
		Object validationResult = "";

		try
		{
			Method method = null;
			try {				
				method = validationsClass.getMethod(methodName);
			} catch (NoSuchMethodException e) {
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ methodName+" doesn't exist, check this again. ");
			} 

			/** proceed only if supplied method exists */
			if(method != null)
			{
				HashMap<Object, Object> responseMap = new ValidationHandler().getChocolateResponse(taskID, tag);
				
				if((int)responseMap.get("statuscode") == 200)
				{
					ValidationModules validationObj = new ValidationModules(taskID, driverFile, mapAllTasksFromDriverSheet2, 
							channelTestData2, campaignTestData2, bidderTestData2, packageTestData2, 
							dealTestData2, con, sessionServe, sessionBidder, bigQueryConnection, bqProjectId, responseMap, tag);
					validationResult = methodName + " Result: " +(String) method.invoke(validationObj);
				}
				else
				{
					validationResult = validationResult+" SKIP: Request wasn't processesed successfully, got status code: "+responseMap.get("statuscode");
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Request wasn't processesed successfully, got status code: "+responseMap.get("statuscode"));
				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+e.getMessage(), e);
		}

		return validationResult;
	}
}
