package projects.e2etest;

import java.net.URLEncoder;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.mysql.jdbc.Connection;

import projects.chocolate.lib.utils.AerospikeHandler;
import vlib.DBLib;
import vlib.httpClientWrap;


public class RulesForURL {

	Logger logger = Logger.getLogger(RulesForURL.class.getName());

	@Test
	public void test() {

		try{

			String tag = "https://pooja.serve.qa.vdopia.com/adserver/html5/inwapads/?sleepAfter=0&adFormat=preappvideo&ak=60cf13cc6d1a2bd8889393974880c6db&version=1.0&fullscreen=1&vdo=1&dimension=[DIMENSION]&invtracker=[INVTRACKER]&pubct=[pub_click_trk]&pubendTrk=[pubendTrk]&dmacro=[DMACRO]&type=[type]&pageURL=[WEB_PAGE_URL]&domain=[domain]&siteName=[SITE_NAME]&requester=[requester]&appBundle=[BUNDLE_NAME/PACKAGE_NAME]&appName=[APP_NAME]&appDomain=[appDomain]&appStoreURL=[appStoreURL]&category=[CATEGORY]&refURL=[REFERER_URL]&requesterClose=[requesterClose]&autorender=[autorender]&dnt=[dnt]&di=[DEVICE_ID]&dif=[DEVICE_ID_FORMAT]&ipAddress=&ua=[ua]&showCanvas=&bannerSize=[bannerSize]&size=[size]&closeTimeout=[closeTimeout]&locbot=[locbot]&dimm=[dimm]&dims=[dims]&diim=[diim]&diis=[diis]&dium=[dium]&dius=[dius]&channelType=[app/site]&apiFramework=[apiFramework]&displayManager=[displayManager]&displayManagerVer=[displayManagerVer]&size=320x480&target_params=sex=[sex]|birthday=[birthday]|ethnicity=[ethnicity]|age=[age]|maritalstatus=[maritalstatus]|postalcode=[postalcode]|currpostal=[currpostal]|dmacode=[\"501\",\"505\"]|latlong=[LATITUDE/LONGITUDE]|geoType=[geoType]|geo=[geo]|metro=[metro]|keywords=[keywords]|telhash=[telhash]|emailhash=[emailhash]&cb=[timestamp]";
			String[] tags = tag.split("\\?", 2);
			tags[1] = URLEncoder.encode(tags[1], "UTF-8");
			tag = tags[0]+"?"+tags[1];
			String response = httpClientWrap.sendGetRequest(tag);
			System.out.println("response is :"+ response);
		}
		catch(Exception e)
		{System.out.println(e);}


	}

	/**
	 * This method will apply the rules written in Rule_For_URL column in test driver sheet to replace the macros in serving tag
	 * Sample Data : 
	 * 
	 * {
	"applyRule": "yes",
	"url": {
		"replaceMacro": [{
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[SITE_NAME]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[Targeting_Data]",
			"action": "parseJson",
			"readNode": "targeting.appsitetargeting.include.site list"
		}, {
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[appDomain]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[Apps (bundle)]",
			"action": "none"
		}, {
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[ak]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[ChannelName]",
			"action": "executeQuery"
		}, {
			"readDataFromWorkbook": "None",
			"macroName": "[invert]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[ChannelID]",
			"action": ["parseJson", "executeQuery"],
			"readNode": "targeting.appsitetargeting.filterin.site"
		}]
	}
}
	 * 
	 * @param tag
	 * @param taskId
	 * @param mapAllTasksFromDriverSheet
	 * @param testDataSheetLocation
	 * @return
	 */
	public String applyRuleToFormTag(String tag, String taskId, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, TreeMap<String, TreeMap<String, String>> finalCampaignTestData, 
			TreeMap<String, TreeMap<String, String>> finalChannelTestData, TreeMap<String, TreeMap<String, String>> finalBidderTestData, TreeMap<String, TreeMap<String, String>> finalPackageTestData, TreeMap<String, TreeMap<String, String>> finalDealTestData, Connection connection)
	{
		try{

			TreeMap<String, String> driverJsonData = mapAllTasksFromDriverSheet.get(taskId);

			/** getting column Rule_For_URL to create url - which will always be in json format  */
			String rule_For_URL = driverJsonData.get("Rule_For_URL");
			JSONObject jsonRules = new JSONObject(rule_For_URL);

			/** apply rule, if applyRule = yes*/
			if (jsonRules.getString("applyRule").equalsIgnoreCase("yes"))
			{
				/** getting details from key = url from received json obj */
				JSONObject rules = jsonRules.getJSONObject("url");

				JSONArray replaceMacroJsonArray = rules.getJSONArray("replaceMacro");

				/** iterate the replaceMacro json array  */
				for(int i = 0; i < replaceMacroJsonArray.length(); i++)
				{
					/** create json object of each values from json array */
					JSONObject replaceMacroJsonObj = replaceMacroJsonArray.getJSONObject(i);

					/** check if test data sheet need to be read out */
					if(replaceMacroJsonObj.getString("readDataFromWorkbook").equalsIgnoreCase("Test_Data"))
					{

						String dataSheetName = replaceMacroJsonObj.getString("readDataFromSheet");

						/** getting test data in a map like {task : {key : value }} (its not json) for the supplied task id */
						TreeMap<String, String> testDataMap = new TreeMap<>();

						if(dataSheetName.toLowerCase().contains("campaign")){
							testDataMap = finalCampaignTestData.get(taskId);
						}else if(dataSheetName.toLowerCase().contains("channel")){
							testDataMap = finalChannelTestData.get(taskId);
						}else if(dataSheetName.toLowerCase().contains("bidder")){
							testDataMap = finalBidderTestData.get(taskId);
						}else if(dataSheetName.toLowerCase().contains("package")){
							testDataMap = finalPackageTestData.get(taskId);
						}else if(dataSheetName.toLowerCase().contains("deal")){
							testDataMap = finalDealTestData.get(taskId);
						}

						/** get the tag after replacing all the desired macros */
						tag = executeActions(replaceMacroJsonObj, tag, testDataMap, connection, taskId);
					}

					/** no need to read sheet */
					else
					{
						tag = executeActions(replaceMacroJsonObj, tag, null, connection, taskId);
					}
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Macro has to be replaced from testdata sheet only");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage(), e);
		}

		return tag;
	}


	/** This method will apply the rules written in Rule_For_URL column in test driver sheet to replace the macros in serving tag, only
	 * difference is - this method will accept the URL json object coz the sample data will have url as JsonArray.  
	 * 
	 * 
	 * Sample Data:
	 *  {
	"applyRule": "yes",
	"url": [{
		"replaceMacro": [{
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[SITE_NAME]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[Targeting_Data]",
			"action": "parseJson",
			"readNode": "targeting.appsitetargeting.include.site list"
		}, {
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[appDomain]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[Apps (bundle)]",
			"action": "none"
		}, {
			"readDataFromWorkbook": "Test_Data",
			"macroName": "[ak]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[ChannelName]",
			"action": "executeQuery"
		}, {
			"readDataFromWorkbook": "None",
			"macroName": "[invert]",
			"readDataFromSheet": "Campaign",
			"readColumn": "[ChannelID]",
			"action": ["parseJson", "executeQuery"],
			"readNode": "targeting.appsitetargeting.filterin.site"
		}]
	}]
}
	 * 
	 * @param tag
	 * @param taskId
	 * @param mapAllTasksFromDriverSheet
	 * @param finalCampaignTestData
	 * @param finalChannelTestData
	 * @param finalBidderTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 * @param connection
	 * @param rules
	 * @return
	 */
	public String applyRuleToFormTag(String tag, String taskID, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, TreeMap<String, 
			TreeMap<String, String>> finalCampaignTestData, TreeMap<String, TreeMap<String, String>> finalChannelTestData, 
			TreeMap<String, TreeMap<String, String>> finalBidderTestData, TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData, Connection connection, JSONObject urls)
	{
		try{

			JSONArray replaceMacroJsonArray = urls.getJSONArray("replaceMacro");

			/** iterate the replaceMacro json array  */
			for(int i = 0; i < replaceMacroJsonArray.length(); i++)
			{
				/** create json object of each values from json array */
				JSONObject replaceMacroJsonObj = replaceMacroJsonArray.getJSONObject(i);

				/** check if test data sheet need to be read out */
				if(replaceMacroJsonObj.getString("readDataFromWorkbook").equalsIgnoreCase("Test_Data"))
				{

					String dataSheetName = replaceMacroJsonObj.getString("readDataFromSheet");

					/** getting test data in a map like {task : {key : value }} (its not json) for the supplied task id */
					TreeMap<String, String> testDataMap = new TreeMap<>();

					if(dataSheetName.toLowerCase().contains("campaign")){
						testDataMap = finalCampaignTestData.get(taskID);
					}else if(dataSheetName.toLowerCase().contains("channel")){
						testDataMap = finalChannelTestData.get(taskID);
					}else if(dataSheetName.toLowerCase().contains("bidder")){
						testDataMap = finalBidderTestData.get(taskID);
					}else if(dataSheetName.toLowerCase().contains("package")){
						testDataMap = finalPackageTestData.get(taskID);
					}else if(dataSheetName.toLowerCase().contains("deal")){
						testDataMap = finalDealTestData.get(taskID);
					}

					/** get the tag after replacing all the desired macros */
					tag = executeActions(replaceMacroJsonObj, tag, testDataMap, connection, taskID);
				}

				/** no need to read sheet */
				else
				{
					tag = executeActions(replaceMacroJsonObj, tag, null, connection, taskID);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage(), e);
		}

		return tag;
	}


	/** This method read the Rule_For_URL column values from Driver Sheet, it returns an Object of URLs and furthet Object will be parsed and 
	 * Rules will be applied on every url.
	 * 
	 * @param taskId
	 * @param mapAllTasksFromDriverSheet
	 * @return
	 */
	public Object getURLsFromDriverSheet(String taskID, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet)
	{
		Object urls = null;

		try{
			TreeMap<String, String> driverJsonData = mapAllTasksFromDriverSheet.get(taskID);

			/** getting column Rule_For_URL to create url - which will always be in json format  */
			String rule_For_URL = driverJsonData.get("Rule_For_URL");
			JSONObject jsonRules = new JSONObject(rule_For_URL);

			/** apply rule, if applyRule = yes*/
			if (jsonRules.getString("applyRule").equalsIgnoreCase("yes"))
			{
				/** getting details from key = url from received json obj */
				urls = jsonRules.get("url");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage(), e);
		}

		return urls;
	}


	/** Check if rules are required to be applied for any url. 
	 * 
	 * @param taskID
	 * @param mapAllTasksFromDriverSheet
	 * @return
	 */
	public boolean ifURLRulesRequired(String taskID, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet)
	{
		try{
			TreeMap<String, String> driverJsonData = mapAllTasksFromDriverSheet.get(taskID);

			/** getting column Rule_For_URL to create url - which will always be in json format  */
			String rule_For_URL = driverJsonData.get("Rule_For_URL");
			logger.info("Rule for url:" +rule_For_URL);
			JSONObject jsonRules = new JSONObject(rule_For_URL);

			/** apply rule, if applyRule = yes*/
			if (jsonRules.getString("applyRule").equalsIgnoreCase("yes"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage(), e);
			return false;
		}
	}


	/**
	 * This method is for execute actions provided in Rule_For_URL column in test driver sheet
	 * @param action
	 * @param replaceMacroJsonObj
	 * @param macroName
	 * @param tag
	 * @param columnData
	 * @param jsonTestData
	 * @return 
	 */
	public String executeActions(JSONObject replaceMacroJsonObj, String tag, TreeMap<String, String> testDataMap, Connection connection, String taskID)
	{

		try{

			String macroName = replaceMacroJsonObj.getString("macroName");
			
			String readColumn = "";
			if(replaceMacroJsonObj.has("readColumn"))
			{
				readColumn = replaceMacroJsonObj.getString("readColumn");
			}
			
			/**  getting data from the received test data map form the key: readColumn */
			String desiredDataForAction = "";
			if(!readColumn.isEmpty())
			{
				desiredDataForAction = testDataMap.get(readColumn);
				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" Data For Key: "+readColumn + " While Creating URL: "+desiredDataForAction);
			}

			/** parsing the action key to decide the further action */
			if(replaceMacroJsonObj.getString("action").trim().equalsIgnoreCase("parseJson"))
			{
				/** if action is parseJson then create json object of supplied desiredData and get the desired node to be read from the desiredData */
				String readNode = replaceMacroJsonObj.getString("readNode");

				/** get the value of node location from the supplied test data */
				String macroValue = (String) new E2EGenericMethods().parseSpecificNodeFromJson(desiredDataForAction, readNode);

				/** replace value of macro */
				tag = tag.replace(macroName, macroValue);
			}

			/** in case of executeQuery, get the data and supply to query 
			 * --------->  NEED TO MAKE IT GENERIC WAY OF EXECUTING QUERY -------> */
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("executeQuery"))
			{
				if(replaceMacroJsonObj.getString("macroName").equalsIgnoreCase("[ak]"))
				{
					String apiKey = new DBLib(connection).getChannelAPIKey(desiredDataForAction);
					tag = tag.replace(macroName, apiKey);
				}
			}

			/** in case - none, then replace the macro with the desired test data */
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("none"))
			{
				tag = tag.replace(macroName, desiredDataForAction);
			}

			/** in case - getMacroValue, then replace the macro with the MacroValue key, if readDataFromWorkbook = none then use desiredDataForAction
			 * to as macroValue */
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("getMacroValue"))
			{
				String macroValue;

				if(replaceMacroJsonObj.getString("readDataFromWorkbook").equalsIgnoreCase("none"))
				{
					if(replaceMacroJsonObj.getString("macroName").equalsIgnoreCase("[ua]"))
					{
						macroValue= URLEncoder.encode(replaceMacroJsonObj.getString("macroValue"), "UTF-8");
					}
					else
					{
						macroValue = replaceMacroJsonObj.getString("macroValue");
					}
				}
				else
				{
					macroValue = desiredDataForAction;
				}
				if(tag.contains(macroName))
				{
					tag = tag.replace(macroName, macroValue);
				}
				else if(tag.contains(URLEncoder.encode(macroName, "UTF-8")))
				{
					macroName = URLEncoder.encode(macroName, "UTF-8");
					tag = tag.replace(macroName, macroValue);
				}
				else if(macroName.equalsIgnoreCase("[adFormat]"))
				{
					String adFormat = tag.substring(tag.indexOf("adFormat=")+9, tag.indexOf("&", tag.indexOf("adFormat=")));
					tag = tag.replace(adFormat, macroValue);
				}
						
			}

			/**
			 *  in case we have to change url macros with relative values of test data value
			 */

			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("getRelativeValue"))
			{
				String macroValue = null;

				if(replaceMacroJsonObj.getString("macroName").equalsIgnoreCase("[apiFramework]"))
				{
					if(desiredDataForAction.equalsIgnoreCase("vpaid"))
					{
						macroValue = "2";
					}
					if(desiredDataForAction.equalsIgnoreCase("mraid1"))
					{
						macroValue = "3";
					}
					if(desiredDataForAction.equalsIgnoreCase("mraid2"))
					{
						macroValue = "5";
					}

				}

				if(tag.contains(macroName))
				{
					tag = tag.replace(macroName, macroValue);
				}
				else if(tag.contains(URLEncoder.encode(macroName, "UTF-8")))
				{
					macroName = URLEncoder.encode(macroName, "UTF-8");
					tag = tag.replace(macroName, macroValue);
				}

			}

			/** in case - addMacro, then add the macro with the MacroValue */
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("addMacro"))
			{
				String macroToBeAdded = replaceMacroJsonObj.getString("macroName").trim();
				String macroValue = replaceMacroJsonObj.getString("macroValue").trim();

				tag = tag.concat("&"+macroToBeAdded+"="+macroValue);
			}
			/** setting up aerospike categories for lr and bk */
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("setAerospikeKey"))
			{
				String macroValue;
				desiredDataForAction = testDataMap.get(readColumn);
				macroValue = AerospikeHandler.setAerospikeCategories("34.198.8.53", desiredDataForAction, taskID);					

				tag = tag.replace(macroName, macroValue);
			}
			if(replaceMacroJsonObj.getString("action").equalsIgnoreCase("changeHttpProtocol"))
			{
				String macroValue = replaceMacroJsonObj.getString("macroValue").trim();
				if(macroValue.equalsIgnoreCase("https"))
				{
					if(tag.startsWith("https"))
					{
						logger.info("Provided and available protocals are already same");
					}
					else if(tag.startsWith("http"))
					{
						tag = tag.replace("http", "https");
					}

				}
				else if(macroValue.equalsIgnoreCase("http"))
				{
					if(tag.startsWith("http"))
					{
						logger.info("Provided and available protocals are already same");
					}
					else if(tag.startsWith("https"))
					{
						tag = tag.replace("https", "http");
					}

				}

			}

		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return tag;
	}
}
