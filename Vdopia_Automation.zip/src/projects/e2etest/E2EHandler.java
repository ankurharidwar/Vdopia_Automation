package projects.e2etest;



import java.io.File;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.Test;

import com.mysql.jdbc.Connection;

import projects.TestSuiteClass;
import projects.portal.GetObjectRepoAsJson;
import projects.portal.ReadTestCases;
import projects.portal.TestCaseObjects;
import projects.portal.WriteTestResults;



public class E2EHandler 
{

	/**
	 * @param args
	 * @throws SQLException 
	 */
	@Test
	public void main() throws SQLException 
	{
		String runabletestCaseFile = "/Users/Pankaj/Desktop/qaAutomation/qascripting/Vdopia_Automation/tc_cases/e2e/Test.xls";

		//Connection connectionServe = MobileTestClass_Methods.CreateServeSQLConnection();

		String objectRepo = TestSuiteClass.AUTOMATION_HOME.concat("/object_repository/portalObjectRepository/transformerPortal_ObjectRepository.xls");
		JSONObject jsonObjectRepo = new GetObjectRepoAsJson().getObjectRepoAsJson(objectRepo);

		executeTestCases(new File(runabletestCaseFile), null, jsonObjectRepo);
		//connectionServe.close();
	}

	/** This method will execute the supplied test cases using keyword driven framework.
	 * 
	 * @param runabletestCaseFile
	 * @return
	 */
	public boolean executeTestCasesold(File runabletestCaseFile, Connection connection, JSONObject jsonObjectRepo)
	{
		boolean Result = false;
		ReadTestCases getrunnabletestcases = new ReadTestCases();

		/**
		 * Get all runnable test case id which has RUN = Yes from execution control sheet 
		 */
		List <String> tc_id = getrunnabletestcases.getRunnableTestCases(runabletestCaseFile.toString());

		/**
		 * Get results of runnable test case id into a hashmap
		 */
		HashMap<String, Boolean> map = new HashMap<>();
		map = getrunnabletestcases.getRunnableTestStepsID(tc_id, runabletestCaseFile.toString(), connection, jsonObjectRepo);

		/** Write test results */
		WriteTestResults writeResults = new WriteTestResults();
		Result = writeResults.writeTestCaseResult(runabletestCaseFile, map);
		return Result;
	}


	/** This method will execute the supplied test cases using keyword driven framework.
	 * 
	 * @param runabletestCaseFile
	 * @return
	 */
	public synchronized boolean executeTestCases(File runabletestCaseFile, Connection connection, JSONObject jsonObjectRepo)
	{
		boolean Result = false;

		try
		{
			ReadTestCases readTest = new ReadTestCases();

			/** load test case objects */
			List<TestCaseObjects> testCaseObjectList = readTest.getRunnableTestCaseObjects(runabletestCaseFile.toString());

			/** execute and write results */
			for(TestCaseObjects testCaseObject : testCaseObjectList)
			{
				/** supply the updated test case object which contains the results also */
				testCaseObject = readTest.executeTestCaseObject(testCaseObject, connection, jsonObjectRepo);
				new WriteTestResults().writeTestObjectResults(runabletestCaseFile, testCaseObject);
			}

			Result = true;
		}catch (Exception e) {
			Result = false;
		}

		return Result;
	}

}
