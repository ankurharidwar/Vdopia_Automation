package projects.e2etest;

import java.util.TreeMap;
import java.util.regex.Pattern;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import vlib.ExecuteCommands;


public class BidderHandler {

	Logger logger = Logger.getLogger(BidderHandler.class.getName());

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	/** Check if any bidder for the supplied task was picked up or not. 
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public boolean checkIfBidderWasPickedUp(TreeMap<String,String> bidderTestDataMapOfTaskID, Connection con, 
			Session sessionBidder)
	{
		/** get bidder log file where bid request and bid response will be recorded */  
		String filename = getBidderLogFile(bidderTestDataMapOfTaskID, con);

		/** Verify if Bidder Request and Response file is created, this php script has to be smart enough to handle GET and POST request */
		String request = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionBidder, "cat /tmp/"+filename+"request");
		String bidderId = bidderTestDataMapOfTaskID.get("[BidderID]");

		/** if request is empty that means bidder wasn't picked up */
		int i = 0;
		while(i<5)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " For Bidder: "+bidderId +", finding bidder request file: "+filename + " ...  Attempt: "+i+" in server: "+sessionBidder.getHost());

			if(!request.isEmpty())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " Bidder: "+bidderId +" was picked up, bidder request file: "+filename+" in server: "+sessionBidder.getHost());
				break;
			}
			else
			{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {}
				request = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionBidder, "cat /tmp/"+filename+"request");
				i++;
			}
		}
		if(i<5)
		{
			return true;
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " Bidder: "+bidderId +" was not picked up, tried to find bidder request file: "+filename+" in server: "+sessionBidder.getHost());
			return false;
		}

	}


	/** Check if the desired bidder returned the ad or not
	 * 1. RTB - there should be a node - adm in json response and it shouldn't empty  
	 * 2. VAST - there should be a valid vast format non - empty response  
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public boolean checkIfBidderReturnedAd(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, 
			Session sessionBidder)
	{
		try
		{
			/** get bidder response */
			String response = getBidderResponse(bidderTestDataMapOfTaskID,con, sessionBidder);
			logger.info("Bidder response is: "+response);

			/** if response is not empty that means bidder responded */
			if(!response.isEmpty())
			{
				/** get bidder type - rtb / vast */
				String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");

				if(connectionType.contains("rtb"))
				{
					try{
						JSONObject json = new JSONObject(response);
						JSONArray seatbid = json.getJSONArray("seatbid");
						JSONArray bid = seatbid.getJSONObject(0).getJSONArray("bid");
						String adm = bid.getJSONObject(0).getString("adm");

						if(!adm.isEmpty()){

							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder Responded With Ad. ");
							return true;
						}else{

							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder Responded Without Ad. ");
							return false;
						}
					}catch(JSONException j){
						logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+j.getMessage() , j);
						return false;
					}
				}
				else
				{
					/** get vast/vpaid bidder response */
					if(response.toLowerCase().contains("mediafiles")){
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder Responded With Ad. ");
						return true;
					}
					else if(response.toLowerCase().contains("wrapper")){
						return true;
					}

					else{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder Responded Without Ad. ");
						return false;
					}
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder response was empty.");
				return false;
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get(), e);
			return false;
		}

	}


	/** Return the bidder ad, in case of rtb bidder send adm node else send whole response.
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public String getBidderReturnedAd(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, 
			Session sessionBidder)
	{
		String response = null;
		try
		{
			/** get bidder response */
			response = getBidderResponse(bidderTestDataMapOfTaskID,con, sessionBidder);

			/** get bidder type - rtb / vast */
			String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");

			/** in case of rtb bidder return only adm node else return full response */
			if(connectionType.contains("rtb"))
			{
				try{
					JSONArray seatbid = new JSONObject(response).getJSONArray("seatbid");
					JSONObject bid = seatbid.getJSONObject(0).getJSONArray("bid").getJSONObject(0);
					response = bid.getString("adm");
				}catch(JSONException j){
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+j.getMessage() , j);
				}
			}
			else
			{
				/** get vast/vpaid bidder response */
				return response;
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get(), e);
		}
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder returned ad :"+response);
		return response;
	}


	/** This method will return the bidder response written in a file created by smart php.
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public String getBidderResponse(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, Session sessionBidder)
	{
		String response="";
		try
		{
			/** Get Bidder Test Data Map from test data map of provided task id */ 

			/** get bidder log file where bid request and bid response will be recorded */  
			String filename = getBidderLogFile(bidderTestDataMapOfTaskID, con);

			/** Get Bidder Response file, **php script is smart enough to handle GET and POST request */
			response = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionBidder, "cat /tmp/"+filename+"response");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder Response :"+response);
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + ": "+e.getMessage(), e);
		}
		return response;
	}


	/** This method returns the log file name by from bidder url - stored in DB
	 *  with respect to bidder id this log file contains the request and response details
	 * 
	 * @param bidderTestDataMapOfTaskID
	 * @param con
	 * @return
	 */
	public String getBidderLogFile(TreeMap<String, String> bidderTestDataMapOfTaskID, Connection con) 
	{
		String filename = null;
		try
		{
			String BidderID = bidderTestDataMapOfTaskID.get("[BidderID]");

			/** Execute the query to get the bidder end point url */
			String sqlQuery = "select BidderURL from hudsonBidder where bidderId = '"+BidderID+"';";
			//System.out.println("Running Query in DB : " + sqlQuery);

			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
			String BidderURL = "";
			while(rs.next())
			{
				BidderURL = rs.getString("BidderURL");
			}

			filename = BidderURL.substring(BidderURL.indexOf("filename")+9, BidderURL.length());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bidder log File name :"+filename);
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);	
		}
		return filename;
	}


	/** Get the bid request from bidder log file as json object  for rtb bidder only
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public JSONObject getRTBBidder_Request(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, 
			Session sessionBidder)
	{
		JSONObject bidPost = null;
		try
		{
			/** Verify if Bidder Request and Response file is created, this php script has to be smart enough to handle GET and POST request */
			String request = getBidderRequest(bidderTestDataMapOfTaskID, con, sessionBidder);

			/** if request is empty that means bidder wasn't picked up */
			if(!request.isEmpty())
			{
				String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");
				if(connectionType.contains("rtb"))
				{
					bidPost = new JSONObject(request);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Bid post :"+bidPost);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +": Exception occurred - ", e);
		}

		return bidPost;
	}


	/** This method will return the bid request -- for both rtb and vast,
	 * we need to handle returned request (like create json object or use it as string ) in other methods based on usage.
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public String getBidderRequest(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, 
			Session sessionBidder)
	{
		String request="";
		try
		{
			/** get bidder log file where bid request and bid response will be recorded */  
			String filename = getBidderLogFile(bidderTestDataMapOfTaskID, con);
			String bidderID = bidderTestDataMapOfTaskID.get("[BidderID]");

			/** Verify if Bidder Request and Response file is created, this php script has to be smart enough to handle GET and POST request */
			request = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionBidder, "cat /tmp/"+filename+"request");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " Bid request file :"+request + " For Bidder: "+bidderID);

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ " : Exception: ", e);
		}

		return request;
	}


	/** This method will give the requested bidder url by chocolate, the request file will be written by php.  
	 * 
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @return
	 */
	public String getVastBidder_Request(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, 
			Session sessionBidder)
	{
		String bidPost = "";
		try
		{
			/** Verify if Bidder Request and Response file is created, this php script has to be smart enough to handle GET and POST request */
			String request = getBidderRequest(bidderTestDataMapOfTaskID, con, sessionBidder);
			logger.info("Requested bidder url by chocolate :"+request);
			/** if request is empty that means bidder wasn't picked up */
			if(!request.isEmpty())
			{
				String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");
				if(connectionType.contains("vast"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Vast bidder request" + request);
					return request;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +": Exception occurred - ", e);
		}

		return bidPost;
	}


	/** This method will check if the desired bidder - which was setup for this test, won or not. How we are checking this:
	 * smart php adds a node <Impression><![CDATA[ qaautomation_bidder_file_"+bidderLogFile ]]></Impression> in the bidder's response 
	 * and if this bidder wins, then this tag appears final chocolate response. bidderLogFile is a random and Unique number which is stored as bid Request URL
	 * for both RTB and VAST bidder.  
	 * 
	 * @param chocolateResponse
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @return
	 */
	public boolean checkIfDesiredBidderWon(String chocolateResponse, TreeMap<String,String> bidderTestDataMapOfTaskID, Connection con)
	{
		String bidderLogFile = getBidderLogFile(bidderTestDataMapOfTaskID, con);
		String BidderID = bidderTestDataMapOfTaskID.get("[BidderID]");
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Chocolate Response :"+ chocolateResponse);

		if(chocolateResponse.contains("qaautomation_bidder_file_"+bidderLogFile))
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ "Desired bidder: "+BidderID+ " won");
			return true;
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Desired bidder: "+BidderID +" didn't win. ");
			return false;
		}
	}

	/**
	 * This method will verify the deal id value in bidder response
	 * @param bidderTestDataMapOfTaskID
	 * @param con
	 * @param sessionBidder
	 * @return
	 */
	public boolean checkIfBidderResponseWithCorrectDealID(TreeMap<String,String> bidderTestDataMapOfTaskID,TreeMap<String,String> dealTestDataMapOfTaskID,Connection con, Session sessionBidder)
	{
		String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");
		if(connectionType.contains("rtb"))
		{
			String bidderResponse = new	BidderHandler().getBidderResponse(bidderTestDataMapOfTaskID, con, sessionBidder);
			String expectedDealID = dealTestDataMapOfTaskID.get("[DealID]");
			if(bidderResponse.contains("\"dealid\":"))
			{
				Pattern p= Pattern.compile("\"dealid\":");
				String [] s=p.split(bidderResponse);
				String s1 = s[1];
				Pattern p2= Pattern.compile("\"");
				String [] s2=p2.split(s1);
				String s3 = s2[1];
				String [] s4=p2.split(s3);
				String dealID = s4[0];
				if(dealID.equals(expectedDealID))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Bidder responded with correct deal id : "+dealID);
					return true;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Expected deal id was : "+expectedDealID+ " but actual deal id is : "+dealID);
					return false;
				}

			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Bidder responded without deal id");
				return false;
			}
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": It's not a RTB bidder so deal id will not be send in response");
			return true;
		}

	}

	/**
	 * This method will verify the deal id value send in bidder request
	 * @param bidderTestDataMapOfTaskID
	 * @param dealTestDataMapOfTaskID
	 * @param con
	 * @param sessionBidder
	 * @return
	 */
	public boolean checkIfBidderWasPostedCorrectDealID(TreeMap<String,String> bidderTestDataMapOfTaskID,TreeMap<String,String> dealTestDataMapOfTaskID,Connection con, Session sessionBidder)
	{
		String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");
		if(connectionType.contains("rtb"))
		{
			String bidderRequest = new BidderHandler().getBidderRequest(bidderTestDataMapOfTaskID, con, sessionBidder);
			String expectedDealID = dealTestDataMapOfTaskID.get("[DealID]");
			if(bidderRequest.contains("{\"deals\":"))
			{
				Pattern p= Pattern.compile("{\"deals\":");
				String [] s=p.split(bidderRequest);
				String s1 = s[1];
				Pattern p2= Pattern.compile("id\":\"");
				String [] s2=p2.split(s1);
				String s3 = s2[1];
				Pattern p3= Pattern.compile("\"");
				String [] s4=p3.split(s3);
				String dealID = s4[0];
				if(dealID.equals(expectedDealID))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Bidder requested with correct deal id : "+dealID);
					return true;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Expected deal id was : "+expectedDealID+ " but actual deal id is : "+dealID);
					return false;
				}

			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Bidder request without deal id");
				return false;
			}
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": It's not a RTB bidder so deal id will not be send in request");
			return true;
		}


	}


}
