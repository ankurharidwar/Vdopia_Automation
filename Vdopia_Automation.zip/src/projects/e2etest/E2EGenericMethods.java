package projects.e2etest;


import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import jxl.Sheet;
import jxl.Workbook;

import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import mobi.mtld.da.Properties;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import projects.chocolate.lib.utils.GetDeviceInformation;
import projects.portal.ReadTestCases;
import projects.portal.WriteTestResults;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.IntegerLib;
import vlib.MobileTestClass_Methods;
import vlib.SaveResultsToMySql;

/**
 * This class contains the generic methods of end to end testing flow
 * @author ankuragarwal
 *
 */


public class E2EGenericMethods {

	static Logger logger = Logger.getLogger(E2EGenericMethods.class.getName());

	@Test
	public void test ()
	{

		String x = getDeviceInfo("ostargeting", "Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13E238");
		System.out.println("Gotcha : "+x);
	}


	/**
	 * This method will copy the provided test cases in result folder by adding the task name and timestamp 
	 * in the name of test cases. 
	 * @param testCaseName
	 * @param taskName
	 * @return
	 */
	public String copyTC(String testCaseName, String taskName)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Provided testcase name: "+testCaseName+ "and Task name: "+taskName);

		String tcGenericLocation = TestSuiteClass.AUTOMATION_HOME.toString();
		String testCaseFileLocation = tcGenericLocation.concat("/tc_cases/e2e/").concat(testCaseName+".xls");

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Source test case file location: "+testCaseFileLocation);

		String resultTestCaseFile = tcGenericLocation.concat("/results/e2e/"+taskName+"/").concat(testCaseName.concat("_Executed_"+MobileTestClass_Methods.DateTimeStamp("hhmssSSS")+".xls"));
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination test cases file location: "+resultTestCaseFile);

		/** Copy main tc sheet to result sheet */
		try {
			FileUtils.copyFile(new File(testCaseFileLocation), new File(resultTestCaseFile));
		} catch (IOException e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred when copying the edit test cases: ", e);
		}

		return resultTestCaseFile;
	}


	/**
	 * This method will execute the test cases (Channel,campaign, bidder) 
	 * 
	 * @param resultTestCaseFile
	 * @param driverMap
	 * @return
	 */
	public boolean executeTestCases(String resultTestCaseFile, TreeMap<String, String> setupMap, Connection connection, JSONObject jsonObjectRepo)
	{
		boolean result = false;
		try{

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Test Cases located at file location: "+resultTestCaseFile);

			/** setting required test cases as YES */
			getSetUpTestCases(resultTestCaseFile, setupMap);

			/** Add Result column in result test case sheet */
			setResultColumn(resultTestCaseFile);

			/** execute test cases */
			result = new E2EHandler().executeTestCases(new File(resultTestCaseFile), connection, jsonObjectRepo);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured when executing edit test cases: ",e);
		}
		return result;

	}


	/**
	 * This method will add the result column in the test case file
	 * @param resultTestCaseFile
	 */
	public void setResultColumn(String resultTestCaseFile)
	{
		try
		{
			/** Setting prerequisute for running required test cases */
			ReadTestCases readTest = new ReadTestCases();
			String testStepResultColumnLabel = readTest.tcStepResultColumn;
			String testStepSheetName = readTest.testStepSheet;

			WriteTestResults writeResult = new WriteTestResults();
			writeResult.addResultColumn(new File(resultTestCaseFile), testStepSheetName, testStepResultColumnLabel);

			String testSummaryResultColumnLabel = readTest.tcSummaryResultColumn;
			String testSummarySheetName = readTest.testCaseSummarySheet;
			writeResult.addResultColumn(new File(resultTestCaseFile), testSummarySheetName, testSummaryResultColumnLabel);
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}
	}


	/**
	 * This method will read only those tasks from driver sheet for which Execute is set to Yes.
	 *  
	 * @param driverSheetLocation
	 * @return
	 */
	public TreeMap<String, TreeMap<String, String>> readDriverSheet(String driverSheetLocation)
	{
		TreeMap<String, TreeMap<String, String>> getDriverData = new TreeMap<>();
		String sheetName = "driver";

		TreeMap<String, TreeMap<String, String>> executableDriverMap = new TreeMap<>();

		try{
			/** getting whole driver sheet in a map */
			getDriverData = getCompleteDataFromExcelSheet(driverSheetLocation, sheetName);

			/** getting only those data for which Execute is set to Yes */
			Set<String> tasks = getDriverData.keySet();

			for(String task : tasks)
			{				
				if(getDriverData.get(task).get("Execute").trim().equalsIgnoreCase("Yes"))
				{
					/** add a Atomic Boolean - status - false for each executable task */
					getDriverData.get(task).put("state", String.valueOf(new AtomicBoolean(false)));
					getDriverData.get(task).put("status", String.valueOf(new AtomicInteger(new TaskCompletionCode().getCode_LoadData())));
					executableDriverMap.put(task, getDriverData.get(task));
				}
			}			
		}
		catch(Exception e){
			logger.error(" Exception occurred when reading the driver sheet", e);
		}

		logger.info("Total Task Size: "+executableDriverMap.size());
		return executableDriverMap;
	}


	/** This method will be used to get the while test data in a map in a format like: <TASKID, <<MACRO, VALUES>, <MACRO1, VALUE1>>>
	 * it has to be executed while performing set up.
	 * 
	 * @param testDataFile
	 * @param expectedTaskID
	 * @return
	 */
	public TreeMap<String, TreeMap<String, String>> readTestDataSheet(String testDataFile, String expectedDataSheet)
	{
		TreeMap<String, TreeMap<String, String>> dataMap = new TreeMap<>();
		try{

			/** get expected data sheet name */
			String sheetName = new E2EGenericMethods().getTestDataSheet(expectedDataSheet);
			dataMap = getCompleteDataFromExcelSheet(testDataFile, sheetName);
		}

		catch(Exception e){
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when reading the test data sheet", e);
		}
		return dataMap;
	}


	/** Get test Data sheet name based on supplied expected test data sheet flag 
	 * 
	 * @param expectedDataSheet
	 * @return
	 */
	public String getTestDataSheet(String expectedDataSheet)
	{
		if(expectedDataSheet.equalsIgnoreCase("Channel"))
		{
			expectedDataSheet = "Channel_Data";
		}
		else if(expectedDataSheet.equalsIgnoreCase("Campaign"))
		{
			expectedDataSheet = "Campaign_Data";
		}
		else if(expectedDataSheet.equalsIgnoreCase("Bidder"))
		{
			expectedDataSheet = "Bidder_data";
		}
		else if(expectedDataSheet.equalsIgnoreCase("Package"))
		{
			expectedDataSheet = "Package_data";
		}
		else if(expectedDataSheet.equalsIgnoreCase("Deal"))
		{
			expectedDataSheet = "Deal_data";
		}
		else
		{
			expectedDataSheet = "";
		}

		return expectedDataSheet;
	}


	/**
	 * This method will read the data sheet and return it into a hash map
	 * @return
	 */
	public TreeMap<String, HashMap<String, String>> getInputJsonData() 
	{
		TreeMap<String, HashMap<String, String>> jsonMap = new TreeMap<>();

		try{
			String jsonFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tc_data/e2e/e2e.input.json");

			if(MobileTestClass_Methods.propertyConfigFile.getProperty("[debugMode]").toString().equalsIgnoreCase("yes"))
			{
				jsonFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tc_data/e2e/e2e.input.json.debug");
			}
			else
			{
				jsonFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tc_data/e2e/e2e.input.json");
			}

			JSONObject inputJson = new JSONObject(FileLib.ReadContentOfFile(jsonFile));

			Iterator<?> keys = inputJson.keys();
			while(keys.hasNext())
			{
				HashMap<String, String> map = new HashMap<>();

				/** create json object of each received value from inout data */
				String key = (String) keys.next();
				JSONObject values = inputJson.getJSONObject(key);

				/** storing json value in a map */
				Iterator<?> jsonKeys = values.keys();
				while(jsonKeys.hasNext())
				{
					String jsonKey = (String) jsonKeys.next();
					map.put(jsonKey, (String) values.get(jsonKey));
					map.put("status", String.valueOf(new AtomicBoolean(false)));
				}

				jsonMap.put(key, map);
			}
		}
		catch(Exception e){
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when getting the json data ",e);
		}
		return jsonMap;
	}

	/**
	 * This method will read complete data from excel sheet and returns a hash map eg: HashMap<String, HashMap<String, String>>
	 * @param DataFile
	 * @param sheetName
	 * @return
	 */
	public TreeMap<String, TreeMap<String, String>> getCompleteDataFromExcelSheet(String DataFile, String sheetName)
	{
		TreeMap<String, TreeMap<String, String>> dataMap = new TreeMap<>();
		try{

			Workbook book = Workbook.getWorkbook(new File(DataFile));
			Sheet sheet = book.getSheet(sheetName);

			for(int row=1; row<sheet.getRows(); row++)
			{
				String taskID = "";

				/** get macro and value in map for each row */
				TreeMap<String, String> Map = new TreeMap<>();

				/** adding portal url macro in test data map - to be used while setting up test case */
				String portalInstance = MobileTestClass_Methods.propertyConfigFile.getProperty("[portal]").toString().trim();
				Map.put("[portal]", portalInstance);

				for(int column=1; column<sheet.getColumns(); column++)
				{
					/** get task id for each data map */
					taskID = sheet.getCell(0, row).getContents().trim();

					/** getting row and column of given task id */
					String testDataMacroName = sheet.getCell(column, 0).getContents().trim();
					String testDataValue = sheet.getCell(column, row).getContents().trim();

					Map.put(testDataMacroName, testDataValue);
				}

				/** collect all data in map */
				dataMap.put(taskID, Map);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when read the data from excel sheet", e);
		}
		return dataMap;
	}


	/**
	 * This method will read single data from excel sheet and returns a hash map eg: HashMap<String, HashMap<String, String>>
	 * @param DataFile
	 * @param sheetName
	 * @return
	 */
	public HashMap<String, HashMap<String, String>> getSingleDataFromDriverSheet(String DataFile, String sheetName)
	{
		HashMap<String, HashMap<String, String>> driverMap = new HashMap<>();
		try{

			Workbook book = Workbook.getWorkbook(new File(DataFile));
			WritableWorkbook copiedBook = Workbook.createWorkbook(new File(DataFile), book);	
			WritableSheet sheet = copiedBook.getSheet(sheetName);
			int statusColumn = sheet.findCell("Status", 0, 0, sheet.getColumns(), 0, false).getColumn();
			for(int row=1; row<sheet.getRows(); row++)
			{
				String taskID = "";

				/** get macro and value in map for each row */
				HashMap<String, String> Map = new HashMap<>();
				String status = sheet.getCell(statusColumn, row).getContents().toString();
				if(!(status.equalsIgnoreCase("done") || status.equalsIgnoreCase("in progress")))
				{
					/** get task id for each data map */
					taskID = sheet.getCell(0, row).getContents().trim();

					for(int column=1; column<sheet.getColumns(); column++)
					{
						/** getting row and column of given task id */
						String testDataMacroName = sheet.getCell(column, 0).getContents().trim();
						String testDataValue = sheet.getCell(column, row).getContents().trim();

						Map.put(testDataMacroName, testDataValue);
					}
					/** collect all data in map */
					driverMap.put(taskID, Map);
					Label statusLabel = new Label(statusColumn,row,"in progress");
					sheet.addCell(statusLabel);
					break;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when read the data from excel sheet", e);
		}
		return driverMap;
	}


	public HashMap<String, HashMap<String, String>> getSingleDataFromDataSheet(String DataFile, String sheetName, String taskName)
	{
		HashMap<String, HashMap<String, String>> dataMap = new HashMap<>();
		try{

			Workbook book = Workbook.getWorkbook(new File(DataFile));
			Sheet sheet = book.getSheet(sheetName);

			for(int row=1; row<sheet.getRows(); row++)
			{
				String taskID = sheet.getCell(0, row).getContents().trim();
				HashMap<String, String> Map = new HashMap<>();
				if(taskID.equalsIgnoreCase(taskName))
				{
					for(int column=1; column<sheet.getColumns(); column++)
					{
						/** getting row and column of given task id */
						String testDataMacroName = sheet.getCell(column, 0).getContents().trim();
						String testDataValue = sheet.getCell(column, row).getContents().trim();

						Map.put(testDataMacroName, testDataValue);
					}
					/** collect all data in map */
					dataMap.put(taskID, Map);
					break;
				}

			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when read the data from excel sheet", e);
		}
		return dataMap;
	}


	/** This method will replace the macros in  test case sheet
	 * 
	 * @param map
	 * @param taskID
	 * @param tcLocation
	 * @return
	 */
	public synchronized boolean replaceMacrosInSetUpTC(TreeMap<String, TreeMap<String, String>> testData, String taskID, String tcLocation)
	{
		boolean flag = false;

		try{
			ReadTestCases readTestCase = new ReadTestCases();
			String teststepsSheet = readTestCase.testStepSheet;
			String tcStepDataColumn = readTestCase.tcStepDataColumn;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Writing test step data in sheet: "+teststepsSheet);

			/** getting map containing data for the supplied task id */
			TreeMap<String, String> dataMap = testData.get(taskID);

			/** Get the existing workbook */
			Workbook book = Workbook.getWorkbook(new File(tcLocation));
			WritableWorkbook copiedBook = Workbook.createWorkbook(new File(tcLocation), book);	
			WritableSheet sheet = copiedBook.getSheet(teststepsSheet);
			int data_Column = sheet.findCell(tcStepDataColumn, 0, 0,sheet.getColumns(), 0 , false).getColumn();

			for(int row =1; row<sheet.getRows(); row++)
			{
				/** getting macro name from input data column from test case sheet. */
				String inputData = sheet.getCell(data_Column,row).getContents().toString();

				/** first, the input data should be parsed to find any residing macro then that macro needs 
				 * to be replaced with the value -- use regex. */ 
				String dataAfterMacroReplacement = replaceMacro(inputData, dataMap);

				Label data_label = new Label(data_Column, row, dataAfterMacroReplacement);
				sheet.addCell(data_label);
			}

			copiedBook.write();
			copiedBook.close();
			book.close();
			flag = true;

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : macros replaced successfully: "+teststepsSheet);
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while writing test data in test case sheet. ", e);
		}
		return flag;
	}


	/** This method will replace the macros in received string from the received data map containing macro name and their values.
	 * 
	 * @param macroList
	 * @param inputData
	 * @param dataMap
	 * @return
	 */
	public String replaceMacro(String inputData, TreeMap<String, String> dataMap)
	{
		String regex = "(\\[.[^,]*?\\])";
		List<String> macroList = new vlib.StringLib().getRegxMatches(inputData, regex);

		if(macroList.isEmpty())
		{
			return inputData;
		}
		else
		{	
			/** replace macro in input data only if the none of regex macro list is present in dataMap */
			if(getMatch(macroList, dataMap))
			{
				for(int i=0; i<macroList.size(); i++)
				{
					String macroName = macroList.get(i);

					if(dataMap.containsKey(macroName))
					{
						String macroValue = dataMap.get(macroName.trim());
						inputData = inputData.replace(macroName, macroValue);
					}
				}
			}
			else
			{
				return inputData;
			}
		}

		/** parse again to check if there is any other macro remaining to be replaced */
		inputData = replaceMacro(inputData, dataMap);

		return inputData;
	}


	/** This method will be used with replaceMacro method while applying regex --> what it does -> it checks if the any of the supplied list element
	 *  is present in supplied map.
	 * 
	 * @param list
	 * @param map
	 * @return
	 */
	public boolean getMatch(List<String> macroList, TreeMap<String, String> dataMap)
	{
		boolean flag = false;
		for(int i =0; i<macroList.size(); i++)
		{
			if(dataMap.keySet().contains(macroList.get(i)))
			{
				return true;
			}
			else
			{
				continue;
			}
		}

		return flag;
	}


	/**
	 * 
	 * @param fileNameWithLocation
	 * @param setupMap
	 * @return
	 */
	public Boolean getSetUpTestCases(String fileNameWithLocation, TreeMap<String, String> setupMap)		
	{	
		WritableSheet sheet = null;
		Workbook book = null;
		WritableWorkbook copiedBook = null;
		boolean flag = false;
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test Case Summary File is : "+fileNameWithLocation);
		//List<String> tc_id = new ArrayList<String>();

		ReadTestCases readTest = new ReadTestCases();

		try{
			book = Workbook.getWorkbook(new File(fileNameWithLocation));
			copiedBook = Workbook.createWorkbook(new File(fileNameWithLocation), book);

			String summarySheet = readTest.testCaseSummarySheet;

			sheet = copiedBook.getSheet(summarySheet);
			//System.out.println(sheet.getRows() + " , " +summarySheet);

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Please check the file location, Error occured while loading file: "+fileNameWithLocation, e);
		}

		try
		{
			//Finding "Run" and "Label" column in the Test Case Summary excel sheet

			String tcSummaryLabelColumn = readTest.tcSummaryLabelColumn;
			String tcSummaryTCIdColumn = readTest.tcStepTCIdColumn;
			String tcSummaryRunColumn = readTest.tcSummaryRunColumn;

			int label_column = sheet.findCell(tcSummaryLabelColumn, 0, 0,sheet.getColumns(), 0 , false).getColumn();
			int id_column = sheet.findCell(tcSummaryTCIdColumn, 0, 0, sheet.getColumns(),0, false).getColumn();
			int run_column = sheet.findCell(tcSummaryRunColumn, 0, 0,sheet.getColumns(), 0 , false).getColumn();
			int rowCount = sheet.getRows();

			//logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Test Case Summary File has label column is: "+label_column + ", run column is :" + run_column+ ", Rows: "+rowCount);

			for(int row=1;row<rowCount;row++)
			{
				String label = sheet.getCell(label_column, row).getContents().trim();
				String tc_id = sheet.getCell(id_column, row).getContents().trim();

				/**
				 * We are using the Label to differentiate the TC not by TC id  
				 */
				if((label.equalsIgnoreCase("channel") && setupMap.get("Channel").equalsIgnoreCase("yes"))
						|| (label.equalsIgnoreCase("campaign") && setupMap.get("Campaign").equalsIgnoreCase("yes"))
						|| (label.equalsIgnoreCase("bidder") && setupMap.get("Bidder").equalsIgnoreCase("yes"))
						|| (label.equalsIgnoreCase("package") && setupMap.get("Package").equalsIgnoreCase("yes")) 
						|| (label.equalsIgnoreCase("deal") && setupMap.get("Deal").equalsIgnoreCase("yes")) )
				{
					//String testcaseID = sheet.getCell(id_column, row).getContents().trim();
					Label lblColumnName = new Label(run_column, row, "Yes");
					sheet.addCell(lblColumnName);

					logger.info("Test Case: "+ tc_id +" is set to execute by setting up flag: RUN = YES. ");
				}
				else{
					Label lblColumnName = new Label(run_column, row, "No");
					sheet.addCell(lblColumnName);

					logger.info("Test Case: "+ tc_id +" is set to execute by setting up flag: RUN = YES. ");
				}

			}
			copiedBook.write();
			copiedBook.close();
			book.close();
			flag = true; 
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while reading Test Case Summary File :" +fileNameWithLocation, e);
		}

		return flag;
	}


	/**
	 *  Get test case status from execute test status and return this result.
	 * @param tcLocation
	 * @return
	 */
	public TreeMap<String, String> getTCStatusFromSummarySheet(String tcLocation)
	{

		TreeMap<String, String> resultMap = new TreeMap<>();
		try{
			Workbook book = Workbook.getWorkbook(new File(tcLocation));
			ReadTestCases readTest = new ReadTestCases();
			String sheetNeme = readTest.testCaseSummarySheet;
			Sheet sheet = book.getSheet(sheetNeme);
			int tcLabelcolumn = sheet.findCell(readTest.tcSummaryLabelColumn, 0, 0, sheet.getColumns(),0,false).getColumn();
			int tcResultscolumn = sheet.findCell(readTest.tcSummaryResultColumn, 0, 0, sheet.getColumns(),0, false).getColumn();

			for(int i=1; i < sheet.getRows(); i++)
			{
				String tcLabel = sheet.getCell(tcLabelcolumn, i).getContents().trim();
				String results = sheet.getCell(tcResultscolumn, i).getContents().trim();

				/**  in case Test Case result is PASS then marking it as Success so that TestNG may not mark the whole result
				 * Pass if there is no Result other than Test Case Results. */
				if(results.trim().equalsIgnoreCase("PASS"))
				{
					results = "Success";
				}
				resultMap.put(tcLabel, results);
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when getting the TC status from summary sheet ",e);
		}
		return resultMap;
	}


	/** This method will write the supplied task status in driver file 
	 * 
	 * @param driverFile
	 * @param taskID
	 * @param taskStatus
	 * @return
	 */
	public boolean writeValuesInExcelSheet(String driverFile, String taskID, String columnName, String value)
	{
		boolean flag = false;
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" :Driver file location- "+ driverFile + " And Value: "+value);

		try
		{				
			Workbook book = Workbook.getWorkbook(new File(driverFile));

			WritableWorkbook copiedbook = Workbook.createWorkbook(new File(driverFile), book);
			WritableSheet driverSheet = copiedbook.getSheet(0);

			int columnTaskStatus = driverSheet.findCell(columnName, 0, 0, driverSheet.getColumns(), 0, false).getColumn();
			int rowTaskID = driverSheet.findCell(taskID, 0, 0, driverSheet.getColumns(), driverSheet.getRows(), false).getRow();

			Label label = new Label(columnTaskStatus, rowTaskID, value);
			driverSheet.addCell(label);

			copiedbook.write();
			copiedbook.close();
			book.close();

			flag = true;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}

		return flag;
	}


	/** Write results in sheet 
	 * 
	 * @param driverFile
	 * @param taskResult
	 * @return
	 */
	public boolean writeTaskResults(String driverFile, HashMap<String, String> taskResult)
	{
		boolean flag = false;

		try
		{			
			logger.info("Writing task results in spreadsheet ... ");
			Workbook book = Workbook.getWorkbook(new File(driverFile));

			WritableWorkbook copiedbook = Workbook.createWorkbook(new File(driverFile), book);
			WritableSheet driverSheet = copiedbook.getSheet(0);

			int columnTaskID = driverSheet.findCell("Task_ID", 0, 0, driverSheet.getColumns(), 0, false).getColumn();
			int columnResults = driverSheet.findCell("Result", 0, 0, driverSheet.getColumns(), 0, false).getColumn();

			for(Entry<String, String> en : taskResult.entrySet())
			{
				String taskID = en.getKey();
				String result = en.getValue();

				/** find row containing the task id */
				int rowTaskID = driverSheet.findCell(taskID, 0, columnTaskID, 0, driverSheet.getRows(), false).getRow();

				/** add result in sheet */
				Label label = new Label(columnResults, rowTaskID, result);
				driverSheet.addCell(label);
			}

			copiedbook.write();
			copiedbook.close();
			book.close();

			flag = true;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}

		return flag;
	}



	/** This method keep a wait on the thread if the supplied file is locked for editing.
	 * 
	 * @param driverFile
	 */
	public void IfFileLocked(String driverFile)
	{
		boolean flag = false;

		while(!flag)
		{
			try{
				FileUtils.touch(new File(driverFile));
				logger.info("File is Un-locked. ");
				flag = true;
			}catch(IOException io){
				flag = false;
				logger.info("File is locked. ");

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {}
			}
		}
	}


	/** This method will write the supplied map in driver file 
	 * 
	 * @param driverFile
	 * @param taskID
	 * @param taskStatus
	 * @return
	 */
	public boolean writeMapInExcelSheet(String driverFile, String taskID, String columnName, HashMap<String, String> dataMap)
	{
		boolean flag = false;
		try
		{
			Workbook book = Workbook.getWorkbook(new File(driverFile));
			WritableWorkbook copiedbook = Workbook.createWorkbook(new File(driverFile), book);
			WritableSheet driverSheet = copiedbook.getSheet(0);

			int columnTaskStatus = driverSheet.findCell(columnName, 0, 0, driverSheet.getColumns(), 0, false).getColumn();
			int rowTaskID = driverSheet.findCell(taskID, 0, 0, driverSheet.getColumns(), driverSheet.getRows(), false).getRow();

			Set<String> maps = dataMap.keySet();
			for(String map : maps)
			{
				Label label = new Label(columnTaskStatus, rowTaskID, map);
				driverSheet.addCell(label);
			}
			copiedbook.write();
			copiedbook.close();
			book.close();

			flag = true;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}

		return flag;
	}


	/** This method will get the serve url from channel tag.  
	 * 
	 * @param tag
	 * @return
	 */
	public String getServeURLFromChannelTag(String tag)
	{
		String startingStr = "<script language='javascript' src='";
		String endingStr = "'></script>";
		String serveURL = tag.substring(tag.indexOf(startingStr)+startingStr.length(), tag.indexOf(endingStr));

		/** replace actual apikey with a macro [ak] */
		String ak = serveURL.substring(serveURL.indexOf("ak=")+3, serveURL.indexOf("&", serveURL.indexOf("ak=")));
		serveURL = serveURL.replace(ak, "[ak]");
		serveURL = serveURL+";caller=[caller]";
		serveURL = serveURL+";output=[output]";
		serveURL = serveURL.replace("https", "http");
		//String adFormat = serveURL.substring(serveURL.indexOf("adFormat=")+9, serveURL.indexOf("&", serveURL.indexOf("adFormat=")));
		//serveURL = serveURL.replace(adFormat, "[adFormat]");
		serveURL = serveURL.replace(serveURL.substring(serveURL.indexOf("http://")+7, serveURL.indexOf("/adserver")), "[instance]");

		//serveURL = serveURL.replace("serve.qa.vdopia.com", "[instence]");

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Serve URL from received tag: "+serveURL);

		return serveURL;
	}


	/** This method will return the value of supplied node from the given location like: targeting.appsitetargeting.include.site list
	 * Challenge - all the supplied location should json obj and not json array  
	 * 
	 * @param jsonString
	 * @param readNode
	 * @return
	 */
	public Object parseSpecificNodeFromJson(String jsonString, String readNode)
	{
		Object object = "";

		try {

			JSONObject json = new JSONObject(jsonString);
			String [] arr = readNode.split("\\.");

			JSONObject obj = json;
			for(int i=0; i<arr.length; i++)
			{
				String key = arr[i];

				try
				{
					obj = obj.getJSONObject(key);

				}catch(JSONException j){
					object = obj.getString(key);
				}
			}

		} catch (Exception e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}

		return object;
	}


	/** This method will return the default value of supplied macro from conf/targeting.default.data -- randomly.
	 * 
	 * @param macroName
	 * @return
	 */
	public String getTargetingDefaultValue(String macroName, String macroData, String targetingName)
	{
		String macroValue = "";

		try{

			/** get default user agent only in these case else get default data from config */
			if(targetingName.equalsIgnoreCase("ostargeting") || targetingName.equalsIgnoreCase("osversiontargeting") || targetingName.equalsIgnoreCase("devicecapabilitytargeting") || targetingName.equalsIgnoreCase("mobiledevicetypetargeting"))
			{
				macroValue = new E2EGenericMethods().getDeviceInfo(targetingName, macroData);
			}
			else
			{
				PropertiesConfiguration property = new PropertiesConfiguration(TestSuiteClass.AUTOMATION_HOME.toString().concat("/conf/targeting.default.data"));

				String value = property.getProperty(macroName).toString().replace("[", "").replace("]", "");
				List<String> macroValuesList = Arrays.asList(value.split(","));

				/** get a random value from the config */
				int randomNumber = IntegerLib.GetRandomNumber(macroValuesList.size(), 1);
				macroValue = macroValuesList.get(randomNumber-1).trim();
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" Exception occured while getting values of macro: "+macroName + ", and targeting name: "+targetingName + ", and macro data: "+macroData, e);
		}
		return macroValue;

	}


	/** This method will return the device user agent with respect to received targeting. 
	 * 
	 * @param targetingName
	 * @param osVersion
	 * @param osName
	 * @return
	 */
	public String getDeviceInfo(String targetingName, String userAgentUsedInTestData)
	{
		String defaultUserAgent = "";

		try
		{
			/** get device information using device atlas of supplied ua */
			Properties property = new GetDeviceInformation().getDeviceProperties(userAgentUsedInTestData);
			String osVersion = property.get("osVersion").asString();
			String osName = property.get("osName").asString();
			String vendor = property.get("vendor").asString();

			String device;
			if(property.get("isTablet").asBoolean()){
				device = "Tablet";
			}else{
				device = "Phone";
			}

			/** get default values from db */
			String sql = "";
			if(targetingName.equalsIgnoreCase("ostargeting"))
			{
				sql = "select user_agent AS user_agent from testData_DeviceInfo where os_name <> '"+osName+"'  and IFNULL(user_agent,'') <> '' limit 1; ";
			}
			else if(targetingName.equalsIgnoreCase("osversiontargeting"))
			{
				sql = "select user_agent AS user_agent from testData_DeviceInfo where os_version <> '"+osVersion+"' and os_name = '"+osName+"'  and IFNULL(user_agent,'') <> '' limit 1; ";
			}
			else if(targetingName.equalsIgnoreCase("devicecapabilitytargeting"))
			{
				sql = "select user_agent AS user_agent from testData_DeviceInfo where device_type <> '"+device+"'  and IFNULL(user_agent,'') <> '' limit 1; ";
			}
			else if(targetingName.equalsIgnoreCase("mobiledevicetypetargeting"))
			{
				sql = "select user_agent AS user_agent from testData_DeviceInfo where vendor not like '%"+vendor+"%'  and IFNULL(user_agent,'') <> '' limit 1; ";
			}

			/** get data from qaautomation db */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" Executing Query To Get UA: "+sql);

			Connection connection = SaveResultsToMySql.getAutomationConnection();
			Statement statement = (Statement) connection.createStatement();
			ResultSet recordset = (ResultSet) statement.executeQuery(sql);

			if(recordset.next()){
				defaultUserAgent = recordset.getString("user_agent").toString().trim();
			}

			connection.close();
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+e.getMessage(), e);
		}

		return defaultUserAgent;
	}

	/**
	 * This method will mail the chocolate log files
	 * @param sessionChocolateServer
	 */
	public static void mailChocolateLog(Session sessionChocolateServer, String chocolateTag, String buildNumber)
	{
		ExecuteCommands.ExecuteCommandUsingJsch(sessionChocolateServer, "cd /tmp; rm -rf logToMail.sh*; wget https://s3.amazonaws.com/automation-qa/logToMail.sh;");
		ExecuteCommands.ExecuteCommandUsingJsch(sessionChocolateServer, "sudo sh /tmp/logToMail.sh "+chocolateTag + "  " +buildNumber);
	}

	/**
	 * This method will mail the bidder request response files
	 * @param sessionBidder
	 */
	public static void mailBidderFiles(Session sessionBidder, String chocolateTag, String buildNumber)
	{
		ExecuteCommands.ExecuteCommandUsingJsch(sessionBidder, "cd /tmp; rm -rf mailBidderFile.sh*; wget https://s3.amazonaws.com/automation-qa/mailBidderFile.sh;");
		ExecuteCommands.ExecuteCommandUsingJsch(sessionBidder, "sudo sh /tmp/mailBidderFile.sh "+chocolateTag + "  " +buildNumber);
	}

	/**
	 * This method will mail the chocolate logs and bidders file for debugging
	 * @param sessionChocolateServer
	 * @param sessionBidder
	 */
	public static void mailDataForDebug(Session sessionChocolateServer,Session sessionBidder, String chocolateTag, String buildNumber)
	{
		mailChocolateLog(sessionChocolateServer, chocolateTag, buildNumber);
		mailBidderFiles(sessionBidder, chocolateTag, buildNumber);
	}

}


