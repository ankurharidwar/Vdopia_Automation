package projects.e2etest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import projects.TestSuiteClass;
import vlib.MobileTestClass_Methods;

public class TaskHandler {


	Logger logger = Logger.getLogger(TaskHandler.class.getName());


	/** start chocolate task based on supplied task id 
	 * 
	 * @param taskId
	 * @return
	 */
	public synchronized Object startChocolateTask(String taskId)
	{
		/** generating a uniq id for each thread - to be used for logging */
		TestSuiteClass.UNIQ_EXECUTION_ID.set(taskId);

		TaskObjects testObject = LaunchE2ETest.mapAllTasksForChocolate.get(taskId);

		new TaskDefinitions().executeChocolateTask(LaunchE2ETest.mapAllTasksFromDriverSheet, taskId, LaunchE2ETest.sessionServe, 
				LaunchE2ETest.sessionBidder, LaunchE2ETest.connectionServe, testObject.getFinalChannelTestData(), 
				testObject.getFinalCampaignTestData(), testObject.getFinalBidderTestData(), 
				testObject.getFinalPackageTestData(), testObject.getFinalDealTestData(), 
				LaunchE2ETest.bigQueryConnection, LaunchE2ETest.bqProjectId, LaunchE2ETest.driverFileLocation, 
				testObject.getResult(), testObject);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + " Chocolate Task Assigned .. ");
		return TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Chocolate Task Assigned";
	}


	/** Check if any chocolate task is ready to pick up after portal task completion
	 * 
	 * @param taskObject
	 * @param taskID
	 * @return
	 */
	public boolean ifChocolateTaskReadyToPickUp (String taskID){

		boolean flag = false;

		try
		{
			TaskObjects taskObject = LaunchE2ETest.mapAllTasksForChocolate.get(taskID);

			/** if supplied task Object contains the AtomicBoolean true then only proceed for chocolate task */
			if(taskObject.getIfProceedChocolateTask().get()){

				/** check if the wait time is passed after portal task, which is 10 mins now then only pick chocolate task */
				double timeDifferenceSec = (new Date().getTime() - taskObject.getPortalTaskEndTime())/1000;

				/** get configured delay from driver sheet */
				String requisite = LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).get("Requisites");
				double delay = Double.parseDouble(new JSONObject(requisite).get("delayinsec").toString());

				if(timeDifferenceSec >= delay){
					flag =  true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + taskID +" is ready to pick up for chocolate tasks ... " );
				}
			}	
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+ e.getMessage(), e);
		}
		return flag;
	}


	/** this will iterate the global map LaunchE2ETest.mapAllTasksFromDriverSheet and look for those task id which has 
	 * status = String.valueOf(new AtomicInteger(1)) that means portal task is completed and ready for chocolate task
	 * 
	 * @return
	 */
	public synchronized String getFreeTaskIDForChocolateExecution()
	{
		String freeTaskId = null;

		for(Entry<String, TreeMap<String, String>> en : LaunchE2ETest.mapAllTasksFromDriverSheet.entrySet())
		{
			/** first check if there is any portal task - completed */
			TreeMap<String, String> taskMap = en.getValue();

			if(taskMap.containsKey("status"))
			{
				if(taskMap.get("status").equalsIgnoreCase(String.valueOf(new TaskCompletionCode().getCode_portalTaskCompletion())))
				{
					String taskId = en.getKey();

					/** now check if this taskID qualifies the criteria to proceed for chocolate task */
					if(ifChocolateTaskReadyToPickUp(taskId))
					{
						freeTaskId = taskId;

						/** before picking up chocolate task - mark it with status = 2 to avoid this picking up again */
						taskMap.put("status", String.valueOf(new AtomicInteger(new TaskCompletionCode().getCode_chocolateTaskPickedup())));
						LaunchE2ETest.mapAllTasksFromDriverSheet.put(freeTaskId, taskMap);

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " +"  Gotcha ... finally returning free task id for chocolate task: "+freeTaskId);
						break;
					}
				}
			}
		}

		return freeTaskId;
	}


	/** This method will return the free test data 
	 * 
	 * @return
	 */
	public synchronized String getFreeJsonTestDataID()
	{
		String testdataid = null;

		for(Entry<String, HashMap<String, String>> en : LaunchE2ETest.jsonTestDataMap.entrySet())
		{
			/** get the FREE TASK for which boolean is set to false */
			if(en.getValue().get("status").equalsIgnoreCase(String.valueOf(false)))
			{
				testdataid = en.getKey();

				/** block the data with atomic boolean = true*/
				HashMap<String, String> taskMap = LaunchE2ETest.jsonTestDataMap.get(testdataid);
				taskMap.put("status", String.valueOf(new AtomicBoolean(true)));
				LaunchE2ETest.jsonTestDataMap.put(testdataid, taskMap);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + "Returning Free Json Test Data ID: "+testdataid);
				break;
			}
			else
			{
				continue;
			}
		}

		return testdataid;
	}


	/** This will return the free task, only one thread can use this one at a time
	 * 
	 * @return
	 */
	public synchronized String getFreeTaskIDForPortalExecution()
	{
		String taskid = null;

		for(Map.Entry<String, TreeMap<String, String>> en : LaunchE2ETest.mapAllTasksFromDriverSheet.entrySet())
		{
			/** get the FREE TASK for which boolean is set to false */
			if(en.getValue().get("state").equalsIgnoreCase(String.valueOf(false)))
			{
				taskid = en.getKey();

				TreeMap<String, String> taskMap = LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskid);

				/** putting atomic boolean as flag so that it doesn't get picked up again 
				 * also putting up an atomic integer to show the status 
				 * like 0 for in progress and 1000 for completed */

				taskMap.put("state", String.valueOf(new AtomicBoolean(true)));
				taskMap.put("status", String.valueOf(new AtomicInteger(new TaskCompletionCode().getCode_TaskPickedupFirstTime())));
				LaunchE2ETest.mapAllTasksFromDriverSheet.put(taskid, taskMap);

				break;
			}
			else
			{
				continue;
			}

		}

		return taskid;
	}


	/** This method will iterate the driver map and check if there is all tasks are completed or in progress 
	 * by checking state key which is an atomic integer 
	 * 
	 * @return
	 */
	public synchronized boolean IfAllTasksNotCompleted()
	{
		boolean flag = false;
		for(Map.Entry<String, TreeMap<String, String>> en : LaunchE2ETest.mapAllTasksFromDriverSheet.entrySet())
		{
			/** get the IN PROGRESS TASK for which STATE is set to 0 */
			if(en.getValue().get("status").equalsIgnoreCase(String.valueOf(new TaskCompletionCode().getCode_allTasksCompletion())))
			{
				flag = true;
				continue;
			}
			else
			{
				return false;
			}
		}

		return flag;
	}


	/** Free a taskID --> this scenario comes up when there is no free test data and a free task is picked up  --> in this case task will not be executed because of no test data
	 * and while picking up free task, we setup an atomic flag = true so that it doesn't get picked up again. Now in this case when task is picked up but not executed the code hangs in infinite loop
	 * Solution - if a free task is picked up and not executed then Free that task again.
	 * 
	 * @param taskid
	 * @return
	 */
	public synchronized void setTaskIDFree(String taskid)
	{
		TreeMap<String, String> taskMap = LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskid);

		/** putting atomic boolean as flag so that it doesn't get picked up again 
		 * also putting up an atomic integer to show the status 
		 * like 0 for in progress and 1000 for completed */

		taskMap.put("state", String.valueOf(new AtomicBoolean(false)));
		taskMap.put("status", String.valueOf(new AtomicInteger(new TaskCompletionCode().getCode_TaskPickedupFirstTime())));
		LaunchE2ETest.mapAllTasksFromDriverSheet.put(taskid, taskMap);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Surprised ******* Freeing up task id: "+taskid);
	}


	/** Free a test data id, this will come up when a portal task is reassigned coz of exception and no test data is free
	 * 
	 * @param testDataId
	 */
	public synchronized void setTestDataIdFree(String testDataId)
	{
		HashMap<String, String> dataMap = LaunchE2ETest.jsonTestDataMap.get(testDataId);

		dataMap.put("status", String.valueOf(new AtomicBoolean(false)));
		LaunchE2ETest.jsonTestDataMap.put(testDataId, dataMap);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Surprised ******* Freeing up test data id: "+testDataId);
	}


	/** get a free chocolate task
	 * 
	 * @return
	 */
	public synchronized Object getChocolateTask()
	{
		try
		{
			String taskID = new TaskHandler().getFreeTaskIDForChocolateExecution();

			/** execute tests only if there is a free task */
			if(taskID != null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Chocolate TASK ID: "+taskID +" Is Pickedup  .... ");

				/**  You definitely need to give executor while using supplyAsync to control the execution, don't need to wait for
				 * the completion of any compleatablefuture  */
				CompletableFuture.supplyAsync(() ->  new TaskHandler().startChocolateTask(taskID), LaunchE2ETest.chocolateTaskExecutor);
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID + " : " + e.getMessage(), e);
		}

		return TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : CHOCOLATE TASK ASSIGNED";
	}


	/** This method assigns tasks synchronously 
	 * 
	 * @param channelTestData
	 * @param campaignTestData
	 * @param bidderTestData
	 * @param packageData
	 * @param dealTestData
	 * @param portalCompletableFutures
	 * @return
	 */
	public synchronized Object assignTasks(TreeMap<String, TreeMap<String,String>> channelTestData, TreeMap<String, 
			TreeMap<String,String>> campaignTestData, TreeMap<String, TreeMap<String,String>> bidderTestData, 
			TreeMap<String, TreeMap<String,String>> packageData, TreeMap<String, TreeMap<String,String>> dealTestData)
	{
		try
		{
			/** always monitor the main map and get the free portal task */
			while(!new TaskHandler().IfAllTasksNotCompleted()){

				/** get portal tasks */
				new TaskHandler().getPortalTask(channelTestData, campaignTestData, bidderTestData, packageData, dealTestData);

				Thread.sleep(2000);

				/** get chocolate tasks */
				new TaskHandler().getChocolateTask();
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}
		return TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : TASK COMPLETED ";
	}


	/** add portal tasks 
	 * 
	 * @param channelTestData
	 * @param campaignTestData
	 * @param bidderTestData
	 * @param packageData
	 * @param dealTestData
	 * @return
	 */
	public synchronized Object getPortalTask(TreeMap<String, TreeMap<String,String>> channelTestData, TreeMap<String, 
			TreeMap<String,String>> campaignTestData, TreeMap<String, TreeMap<String,String>> bidderTestData, 
			TreeMap<String, TreeMap<String,String>> packageData, TreeMap<String, TreeMap<String,String>> dealTestData)
	{
		try
		{
			String taskID = new TaskHandler().getFreeTaskIDForPortalExecution();

			/** execute tests only if there is a free test data and task */
			if(taskID != null){

				String testDataID = new TaskHandler().getFreeJsonTestDataID();

				if(testDataID != null){
					logger.info("TASK ID: "+taskID +" Being Executed With Test Data ID: "+testDataID);

					CompletableFuture.supplyAsync(() ->  new TaskDefinitions().executePortalTask(LaunchE2ETest.driverFileLocation, 
							LaunchE2ETest.mapAllTasksFromDriverSheet, taskID, testDataID, channelTestData, campaignTestData, bidderTestData, 
							packageData, dealTestData,  LaunchE2ETest.connectionServe,  LaunchE2ETest.sessionServe, LaunchE2ETest.jsonObjectRepo, 
							LaunchE2ETest.sessionBidder,  LaunchE2ETest.bigQueryConnection,  LaunchE2ETest.bqProjectId), LaunchE2ETest.portalTaskExecutor);				
				}else{

					new TaskHandler().setTaskIDFree(taskID);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" : Freeing up- "+ taskID + " For test data id: "+testDataID );
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}

		return TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : PORTAL TASK ASSIGNED ";
	}


	/** Handle retry chocolate tests, so far no impact of using this code - adding more time therefore - driving by config 
	 * 
	 * @param taskID
	 * @param result
	 * @param testObject
	 * @return
	 */
	public synchronized boolean ifRetryChocolateTest(String taskID, String result, TaskObjects testObject)
	{
		/** check for config file, if set to yes then only retry */
		if(MobileTestClass_Methods.propertyConfigFile.getProperty("[retryTest]").toString().equalsIgnoreCase("yes"))
		{
			/** in case of chocolate result contains skip then retry, checking retrychocolatetest flag so that its not repeated again */
			if(result.toLowerCase().contains("skip") && !testObject.getRetrychocolatetest().get())
			{
				/** Marking the status = 1 for skip tests so that it can be picked again */
				LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).put("status", String.valueOf(new TaskCompletionCode().getCode_portalTaskCompletion()));

				/** set atmoic boolean to true in case of retry and update end time */
				LaunchE2ETest.mapAllTasksForChocolate.get(taskID).setRetrychocolatetest(new AtomicBoolean(true));
				LaunchE2ETest.mapAllTasksForChocolate.get(taskID).setPortalTaskEndTime(new Date().getTime());

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Marking Retry Test - Chocolate Tasks Map For task Id: " +taskID);
			}
			else
			{
				/** Marking the status = 1000 for the chocolate completed tasks, FOR WHOLE COMPLETION status will be 1000 */
				LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).put("status", String.valueOf(new TaskCompletionCode().getCode_allTasksCompletion()));
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Marking Completed - Chocolate Tasks Map For task Id: " +taskID);
			}
		}
		else
		{
			/** Marking the status = 1000 for the chocolate completed tasks, FOR WHOLE COMPLETION status will be 1000 */
			LaunchE2ETest.mapAllTasksFromDriverSheet.get(taskID).put("status", String.valueOf(new TaskCompletionCode().getCode_allTasksCompletion()));
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Retry -NA, Marking Completed - Chocolate Tasks Map For task Id: " +taskID);
		}
		return true;
	}

}


