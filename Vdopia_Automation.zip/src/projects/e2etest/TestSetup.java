package projects.e2etest;


import projects.portal.Keywords;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONObject;
import org.testng.Assert;

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;


public class TestSetup 
{

	static Logger logger = Logger.getLogger(TestSetup.class.getName());


	public String driverResultColumn = "";
	public String driverTaskStatusColumn = "";
	private String driverSheetName = "";
	public String driverURLColumn = "";

	private String dataChannelSheetName = "";
	private String dataCampaignSheetName = "";
	private String dataBidderSheetName = "";
	private String dataPackageSheetName = "";
	private String dataDealSheetName = "";

	private String dataChannelNameColumnName = "";
	private String dataCampaignNameColumnName = "";
	private String dataBidderNameColumnName = "";
	private String dataPackageNameColumnName = "";
	private String dataDealNameColumnName = "";

	private String dataCampaignIDColumnName = "";
	private String dataChannelIDColumnName = "";
	private String dataBidderIDColumnName = "";
	private String dataBidderRequestURLColumnName = "";
	//private String dataBidderConnectionTypeColumnName = "";


	private String dataPackageIDColumnName = "";
	private String dataDealIDColumnName = "";

	private String dataChannelTaskIdColumnName = "";

	/**
	 * Constructor to initialize --> 
	 */
	TestSetup() 
	{
		driverResultColumn = "Result";
		driverTaskStatusColumn = "Task_Status";
		driverSheetName = "driver";
		driverURLColumn = "URL";

		dataChannelSheetName = "Channel_Data";
		dataCampaignSheetName = "Campaign_Data";
		dataBidderSheetName = "Bidder_Data";
		dataPackageSheetName = "Package_Data";
		dataDealSheetName = "Deal_Data";

		dataChannelTaskIdColumnName = "[TASK_ID]";

		dataChannelNameColumnName = "[ChannelName]";
		dataCampaignNameColumnName = "[CampaignName]";
		dataBidderNameColumnName = "[BidderName]";
		dataPackageNameColumnName = "[PackageName]";
		dataDealNameColumnName = "[DealName]";

		dataChannelIDColumnName = "[ChannelID]";
		dataCampaignIDColumnName = "[CampaignID]";
		dataBidderIDColumnName = "[BidderID]";
		dataPackageIDColumnName = "[PackageID]";
		dataDealIDColumnName = "[DealID]";

		dataBidderRequestURLColumnName = "[Bid Request URL]";
		//dataBidderConnectionTypeColumnName = "[Connection Type]";
	}



	/** This method sets up bidder by executing bidder test cases after replacing macros in it.
	 * 
	 * @param dataFileLocation
	 * @param mapAllTasksFromDriverSheet
	 * @param taskName
	 * @return
	 */
	public String bidderSetup(TreeMap<String, TreeMap<String, String>> bidderTestData, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskName, Connection connection, JSONObject jsonObjectRepo)
	{
		@SuppressWarnings("unused")
		boolean status = false;
		String result = "";

		try
		{
			/**
			 *  Copy required Test Cases as decided by Driver Sheet having a name of Task from Driver sheet + timestamp.
			 */
			String tcLocation = new E2EGenericMethods().copyTC("E2E_Bidder_Test_Cases",taskName);

			/**
			 * Pick the input from data sheet and replace the respective macros into test cases sheet
			 */
			status = new E2EGenericMethods().replaceMacrosInSetUpTC(bidderTestData, taskName, tcLocation);

			if(status=true)
			{
				TreeMap<String, String> setupMap = mapAllTasksFromDriverSheet.get(taskName);
				status = false;

				/** execute edit test cases of channel, campaign and bidder as per driver sheet */
				status = new E2EGenericMethods().executeTestCases(tcLocation, setupMap, connection, jsonObjectRepo);
			}

			if(status=true)
			{
				TreeMap<String, String> resultMap = new E2EGenericMethods().getTCStatusFromSummarySheet(tcLocation);
				result = resultMap.get("bidder");
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}
		return result;
	}


	/** This method will updated the test data in campaign test case and execute campaign test case.
	 * 
	 * @param dataFileLocation
	 * @param mapAllTasksFromDriverSheet
	 * @param taskName
	 * @return
	 */
	public String campaignSetup(TreeMap<String, TreeMap<String, String>> campaignTestData, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet,
			String taskName, Connection connection, JSONObject jsonObjectRepo)
	{
		@SuppressWarnings("unused")
		boolean status = false;
		String result = "";

		try
		{
			if(campaignTestData.containsKey(taskName))
			{
				/**
				 *  Copy required Test Cases as decided by Driver Sheet having a name of Task from Driver sheet + timestamp.
				 */
				String tcLocation = new E2EGenericMethods().copyTC("E2E_Campaign_Test_Cases",taskName);

				/**
				 * Pick the input from data sheet and replace the respective macros into test cases sheet
				 */
				status = new E2EGenericMethods().replaceMacrosInSetUpTC(campaignTestData, taskName, tcLocation);

				if(status=true)
				{
					TreeMap<String, String> setupMap = mapAllTasksFromDriverSheet.get(taskName);
					status = false;

					/** execute edit test cases of channel, campaign and bidder as per driver sheet */
					status = new E2EGenericMethods().executeTestCases(tcLocation, setupMap, connection, jsonObjectRepo);
				}
				if(status=true)
				{
					new E2EGenericMethods();
					TreeMap<String, String> resultMap = new E2EGenericMethods().getTCStatusFromSummarySheet(tcLocation);
					result = resultMap.get("campaign");
				}

			}else
			{
				result = "There is no campaign test data for supplied test: "+taskName;
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}

		return result;
	}


	/** This method will set up channel -->
	 * 1. Copy channel test case
	 * 2. Update test case data from Test Data Sheet -- Replace Macros
	 * 3. Execute This Test case    
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskName
	 * @return
	 */
	public synchronized String channelSetup(TreeMap<String, TreeMap<String, String>> channelTestData, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskName, Connection connection, JSONObject jsonObjectRepo)
	{
		boolean status = false;
		String result = "";

		try
		{
			if(channelTestData.containsKey(taskName))
			{
				/**
				 *  Copy required Test Cases as decided by Driver Sheet having a name of Task from Driver sheet + timestamp.
				 */
				String tcLocation = new E2EGenericMethods().copyTC("E2E_Channel_Test_Cases",taskName);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Channel Test Case is copied at: "+tcLocation);

				/**
				 * Pick the input from data sheet and replace the respective macros into test cases sheet
				 */
				status = new E2EGenericMethods().replaceMacrosInSetUpTC(channelTestData, taskName, tcLocation);

				/** if macros are replaced successfully then execute test cases */
				if(status=true)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Macros were replaced successfully in channel test case .. ");
					TreeMap<String, String> setupMap = mapAllTasksFromDriverSheet.get(taskName);
					status = false;

					/** execute edit test cases of channel, campaign and bidder as per driver sheet */
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Channel Test Cases ... ");
					status = new E2EGenericMethods().executeTestCases(tcLocation, setupMap, connection, jsonObjectRepo);
				}
				
				if(status=true)
				{
					new E2EGenericMethods();
					TreeMap<String, String> resultMap = new E2EGenericMethods().getTCStatusFromSummarySheet(tcLocation);
					result = resultMap.get("channel");
				}
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Macros replaced status  "+status);
			}
			else
			{
				result = "There is no channel test data for supplied test: "+taskName;
			}
		}catch(Exception e)
		{
			result = "Exception occurred while setting up channel. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Exception occurred while test setup. ",e);
		}

		return result;
	}

	/** This method will set up package -->
	 * 1. Copy package test case
	 * 2. Update test case data from Test Data Sheet -- Replace Macros
	 * 3. Execute This Test case    
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskName
	 * @return
	 */
	public String packageSetup(TreeMap<String, TreeMap<String, String>> packageTestData, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskName, Connection connection, JSONObject jsonObjectRepo)
	{
		@SuppressWarnings("unused")
		boolean status = false;
		String result = "";

		try
		{
			if(packageTestData.containsKey(taskName))
			{
				/**
				 *  Copy required Test Cases as decided by Driver Sheet having a name of Task from Driver sheet + timestamp.
				 */
				String tcLocation = new E2EGenericMethods().copyTC("E2E_Package_Test_Cases",taskName);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Package Test Case is copied at: "+tcLocation);

				/**
				 * Pick the input from data sheet and replace the respective macros into test cases sheet
				 */
				status = new E2EGenericMethods().replaceMacrosInSetUpTC(packageTestData, taskName, tcLocation);

				/** if macros are replaced successfully then execute test cases */
				if(status=true)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Macros were replaced successfully in package test case .. ");
					TreeMap<String, String> setupMap = mapAllTasksFromDriverSheet.get(taskName);
					status = false;

					/** execute edit test cases of channel, campaign and bidder as per driver sheet */
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Package Test Cases ... ");
					status = new E2EGenericMethods().executeTestCases(tcLocation, setupMap, connection, jsonObjectRepo);
				}

				if(status=true)
				{
					new E2EGenericMethods();
					TreeMap<String, String> resultMap = new E2EGenericMethods().getTCStatusFromSummarySheet(tcLocation);
					result = resultMap.get("package");
				}
			}
			else
			{
				result = "There is no package test data for supplied test: "+taskName;
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " +e.getMessage(), e);
		}

		return result;
	}

	/** This method will set up package -->
	 * 1. Copy deal test case
	 * 2. Update test case data from Test Data Sheet -- Replace Macros
	 * 3. Execute This Test case    
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskName
	 * @return
	 */
	public String dealSetup(TreeMap<String, TreeMap<String, String>> dealTestData, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			String taskName, Connection connection, JSONObject jsonObjectRepo)
	{
		@SuppressWarnings("unused")
		boolean status = false;
		String result = "";

		try
		{
			if(dealTestData.containsKey(taskName))
			{
				/**
				 *  Copy required Test Cases as decided by Driver Sheet having a name of Task from Driver sheet + timestamp.
				 */
				String tcLocation = new E2EGenericMethods().copyTC("E2E_Deal_Test_Cases",taskName);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Deal Test Case is copied at: "+tcLocation);


				/**
				 * Pick the input from data sheet and replace the respective macros into test cases sheet
				 */
				status = new E2EGenericMethods().replaceMacrosInSetUpTC(dealTestData, taskName, tcLocation);

				/** if macros are replaced successfully then execute test cases */
				if(status=true)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Macros were replaced successfully in deal test case .. ");
					TreeMap<String, String> setupMap = mapAllTasksFromDriverSheet.get(taskName);
					status = false;

					/** execute edit test cases of channel, campaign and bidder as per driver sheet */
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing Deal Test Cases ... ");
					status = new E2EGenericMethods().executeTestCases(tcLocation, setupMap, connection, jsonObjectRepo);
				}

				if(status=true)
				{
					new E2EGenericMethods();
					TreeMap<String, String> resultMap = new E2EGenericMethods().getTCStatusFromSummarySheet(tcLocation);
					result = resultMap.get("deal");
				}
			}
			else
			{
				result = "There is no deal test data for supplied test: "+taskName;
			}
		}catch(Exception e)
		{	
			result = "Exception while test set up. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+e.getMessage(), e);
		}

		return result;
	}


	/** This method will copy the test data file into results folder and update the test data sheet with the supplied input json test data
	 * 
	 * @return
	 */
	public String updateTestDataWithJsonInput(Session session, TreeMap<String, HashMap<String, String>> mapAllTasksFromDriverSheet)
	{
		String destinationFileLocation = "";

		try
		{
			/** read json input file as hash map in a format like {"campaign": {"key" : "value" }*/
			TreeMap<String, HashMap<String, String>> jsonMap = new E2EGenericMethods().getInputJsonData();

			/** copy test data file to results folder */
			String testDataFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tc_data/e2e/E2E_Test_Data.xls");
			destinationFileLocation = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/Test_Data/").concat("Test_Data.xls");
			FileUtils.copyFile(new File(testDataFile), new File(destinationFileLocation));

			/** update test data file with json input values */
			new TestSetup().addJsonDataToTestDataSheet(session, jsonMap, destinationFileLocation, mapAllTasksFromDriverSheet);

		}catch(Exception t)
		{
			destinationFileLocation = "";
			logger.error(t.getMessage(), t);
		}
		return destinationFileLocation;
	}


	/**
	 * This method will copy the driver sheet and add columns - URL, Task_Status and Results in driver sheet and return the copied driver file location
	 * 
	 * @param resultTestCaseFile
	 */
	public String addLabels_DriverSheet()
	{
		String destinationFileLocation = "";
		boolean flag = false;

		try
		{
			/** 1. copy driver sheet in results folder */
			String genericLocation = "";
			genericLocation = TestSuiteClass.AUTOMATION_HOME.toString().concat("/e2e.driver/E2E_Test_Driver.xls");

			destinationFileLocation = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/Driver/E2E_Test_Driver.xls");
			FileUtils.copyFile(new File(genericLocation), new File(destinationFileLocation));

			flag = true;
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		/** write driver sheet only if it is copied */
		if(flag)
		{
			Workbook book = null;
			WritableWorkbook copiedBook = null;
			try
			{
				/**2. adding columns in copied driver sheet */
				File driverFile = new File(destinationFileLocation);
				book = Workbook.getWorkbook(driverFile);
				copiedBook = Workbook.createWorkbook(driverFile, book);

				WritableSheet sheet = copiedBook.getSheet(driverSheetName);

				Label urlLblColumnName = new Label(sheet.getColumns(), 0, driverURLColumn);
				logger.info("Adding label: "+urlLblColumnName.getContents() +" column in file: "+destinationFileLocation + " in sheet: "+driverSheetName);
				sheet.addCell(urlLblColumnName);

				Label taskStatusLblColumnName = new Label(sheet.getColumns(), 0, driverTaskStatusColumn);
				logger.info("Adding label: "+taskStatusLblColumnName.getContents() +" column in file: "+destinationFileLocation + " in sheet: "+driverSheetName);
				sheet.addCell(taskStatusLblColumnName);


				Label resultLblColumnName = new Label(sheet.getColumns(), 0, driverResultColumn);
				logger.info("Adding label: "+resultLblColumnName.getContents() +" column in file: "+destinationFileLocation + " in sheet: "+driverSheetName);
				sheet.addCell(resultLblColumnName);
			}catch(Exception t)
			{
				logger.error(t.getMessage(), t);
			}
			finally {
				try{
					copiedBook.write();
					copiedBook.close();
					book.close();
				}catch(Exception e){
					logger.error(e.getMessage());
				}	
			}
		}

		return destinationFileLocation;
	}


	/**
	 * This method will copy the jsonData to test data excel sheet 
	 * @param json
	 * @param fileLocation
	 * @return
	 */
	public void addJsonDataToTestDataSheet(Session session, TreeMap<String, HashMap<String, String>> jsonMap, String fileLocation, 
			TreeMap<String, HashMap<String, String>> mapAllTasksFromDriverSheet)
	{
		Workbook book = null;
		WritableWorkbook copiedbook = null;
		try{
			book = Workbook.getWorkbook(new File(fileLocation));
			copiedbook = Workbook.createWorkbook(new File(fileLocation), book);
			WritableSheet channelSheet = copiedbook.getSheet(dataChannelSheetName);
			WritableSheet campaignSheet = copiedbook.getSheet(dataCampaignSheetName);
			WritableSheet bidderSheet = copiedbook.getSheet(dataBidderSheetName);
			WritableSheet packageSheet = copiedbook.getSheet(dataPackageSheetName);
			WritableSheet dealSheet = copiedbook.getSheet(dataDealSheetName);

			/** getting column locations where input data has to be written */
			int channelSheetChannelIDColumn = channelSheet.findCell(dataChannelIDColumnName, 0, 0, channelSheet.getColumns(), 0, false).getColumn();
			int channelSheetChannelNameColumn = channelSheet.findCell(dataChannelNameColumnName, 0, 0, channelSheet.getColumns(), 0, false).getColumn();
			int channelSheetTaskIDColumn = channelSheet.findCell(dataChannelTaskIdColumnName, 0, 0, channelSheet.getColumns(), 0, false).getColumn();

			int campaignSheetTaskIDColumn = channelSheet.findCell(dataChannelTaskIdColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			int campaignSheetChannelNameColumn = campaignSheet.findCell(dataChannelNameColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			int campaignColumn = campaignSheet.findCell(dataCampaignNameColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			int campaignSheetCampaignIDColumn = campaignSheet.findCell(dataCampaignIDColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			int campaignSheetChannelIDColumn = campaignSheet.findCell(dataChannelIDColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			//int campaignSheetDealNameColumn = campaignSheet.findCell(dataDealNameColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();
			int campaignSheetDealIDColumn = campaignSheet.findCell(dataDealIDColumnName, 0, 0, campaignSheet.getColumns(), 0, false).getColumn();

			int bidderSheetTaskIDColumn = bidderSheet.findCell(dataChannelTaskIdColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();
			int bidderColumn = bidderSheet.findCell(dataBidderNameColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();
			int bidderSheetBidderIDColumn = bidderSheet.findCell(dataBidderIDColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();
			int bidderSheetChannelNameColumn = bidderSheet.findCell(dataChannelNameColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();
			int bidderRequestURLColumn = bidderSheet.findCell(dataBidderRequestURLColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();
			//int bidderConnectionTypeColumn = bidderSheet.findCell(dataBidderConnectionTypeColumnName, 0, 0, bidderSheet.getColumns(), 0, false).getColumn();

			int packageSheetTaskIDColumn = packageSheet.findCell(dataChannelTaskIdColumnName, 0, 0, packageSheet.getColumns(), 0, false).getColumn();
			int packageColumn = packageSheet.findCell(dataPackageNameColumnName, 0, 0, packageSheet.getColumns(), 0, false).getColumn();
			int packageSheetPackageIDColumn = packageSheet.findCell(dataPackageIDColumnName, 0, 0, packageSheet.getColumns(), 0, false).getColumn();
			int packageSheetChannelNameColumn = packageSheet.findCell(dataChannelNameColumnName, 0, 0, packageSheet.getColumns(), 0, false).getColumn();

			int dealSheetTaskIDColumn = dealSheet.findCell(dataChannelTaskIdColumnName, 0, 0, dealSheet.getColumns(), 0, false).getColumn();
			int dealColumn = dealSheet.findCell(dataDealNameColumnName, 0, 0, dealSheet.getColumns(), 0, false).getColumn();
			int dealSheetDealIDColumn = dealSheet.findCell(dataDealIDColumnName, 0, 0, dealSheet.getColumns(), 0, false).getColumn();
			int dealSheetPackageNameColumn = dealSheet.findCell(dataPackageNameColumnName, 0, 0, dealSheet.getColumns(), 0, false).getColumn();
			int dealSheetBidderNameColumn = dealSheet.findCell(dataBidderNameColumnName, 0, 0, dealSheet.getColumns(), 0, false).getColumn();

			int counter = 1;

			/** iterating the received task id map which contains all the Yes tasks */
			for(Entry<String, HashMap<String, String>> map : mapAllTasksFromDriverSheet.entrySet())
			{
				/** reseting the counter when counter is > the iterated row --> resetting counter when json data is written */
				if(!jsonMap.containsKey(String.valueOf(counter)))
				{
					counter = 1;
				}
				HashMap<String, String> jsonDataMap = jsonMap.get(String.valueOf(counter));

				/** get the taskId from driver sheet, received from mapAllTasksFromDriverSheet map */
				String taskID = map.getKey();

				/** getting data from json input */
				String channelName = jsonDataMap.get("channel_name");
				String channelID = jsonDataMap.get("channel_id");

				String campaignName = jsonDataMap.get("campaign_name");
				String campaignID = jsonDataMap.get("campaign_id");

				String bidderName = jsonDataMap.get("bidder_name");
				String bidderID = jsonDataMap.get("bidder_id");

				String packageName = jsonDataMap.get("package_name");
				String packageID = jsonDataMap.get("package_id");

				String dealName = jsonDataMap.get("deal_name");
				String dealID = jsonDataMap.get("deal_id");

				/** adding labels -- campaign name, campaign id, channel name, channel id, bidder name, bidder id, package name, package id, deal name and deal id in respective sheets */

				/** adding labels in channel sheet */
				/** now find the taskId in every sheet and write the data in the row respective of this taskid */
				int row = channelSheet.findCell(taskID, 0, 0,channelSheetTaskIDColumn, channelSheet.getRows(), false).getRow();
				Label channelSheetChannelNameLabel = new Label(channelSheetChannelNameColumn, row, channelName);
				channelSheet.addCell(channelSheetChannelNameLabel);

				Label channelSheetChannelIDLabel = new Label(channelSheetChannelIDColumn, row, channelID);
				channelSheet.addCell(channelSheetChannelIDLabel);

				/** adding labels in campaign sheet, find task id in campaign sheet and write the data */
				row = campaignSheet.findCell(taskID, 0, 0,campaignSheetTaskIDColumn, campaignSheet.getRows(), false).getRow();
				Label campaignNameLabel = new Label(campaignColumn, row, campaignName);
				campaignSheet.addCell(campaignNameLabel);


				Label campaignSheetChannelNameLabel = new Label(campaignSheetChannelNameColumn, row, channelName);
				campaignSheet.addCell(campaignSheetChannelNameLabel);

				Label campaignSheetChannelIDLabel = new Label(campaignSheetChannelIDColumn, row, channelID);
				campaignSheet.addCell(campaignSheetChannelIDLabel);

				Label campaignSheetCampaignIDLabel = new Label(campaignSheetCampaignIDColumn, row, campaignID);
				campaignSheet.addCell(campaignSheetCampaignIDLabel);

				Label campaignSheetDealIDLabel = new Label(campaignSheetDealIDColumn, row, dealID);
				campaignSheet.addCell(campaignSheetDealIDLabel);

				/** adding labels in bidder sheet */
				row = bidderSheet.findCell(taskID, 0, 0,bidderSheetTaskIDColumn, bidderSheet.getRows(), false).getRow();
				Label bidderLabel = new Label(bidderColumn, row, bidderName);
				bidderSheet.addCell(bidderLabel);

				Label bidderIDLabel = new Label(bidderSheetBidderIDColumn, row, bidderID);
				bidderSheet.addCell(bidderIDLabel);

				Label bidderSheetChannelNameLabel = new Label(bidderSheetChannelNameColumn, row, channelName);
				bidderSheet.addCell(bidderSheetChannelNameLabel);

				/** setup bidder end point in qa.vdopia.com */
				String str_bidderEndpoint = bidderSheet.getCell(bidderRequestURLColumn, row).getContents().trim();
				//String str_connectType = bidderSheet.getCell(bidderConnectionTypeColumn, row).getContents().trim();
				Label bidderEndpoint = new Label(bidderRequestURLColumn, row, new TestSetup().setupBidderEndPoint(session, str_bidderEndpoint, null));
				bidderSheet.addCell(bidderEndpoint);

				/** adding labels in package sheet */
				row = packageSheet.findCell(taskID, 0, 0,packageSheetTaskIDColumn, packageSheet.getRows(), false).getRow();
				Label packageLabel = new Label(packageColumn, row, packageName);
				packageSheet.addCell(packageLabel);

				Label packageIDLabel = new Label(packageSheetPackageIDColumn, row, packageID);
				packageSheet.addCell(packageIDLabel);

				Label packageSheetChannelNameLabel = new Label(packageSheetChannelNameColumn, row, channelName);
				packageSheet.addCell(packageSheetChannelNameLabel);

				/** adding labels in deal sheet */
				row = dealSheet.findCell(taskID, 0, 0,dealSheetTaskIDColumn, dealSheet.getRows(), false).getRow();
				Label dealLabel = new Label(dealColumn, row, dealName);
				dealSheet.addCell(dealLabel);

				Label dealIDLabel = new Label(dealSheetDealIDColumn, row, dealID);
				dealSheet.addCell(dealIDLabel);

				Label dealSheetPackageNameLabel = new Label(dealSheetPackageNameColumn, row, packageName);
				dealSheet.addCell(dealSheetPackageNameLabel);

				Label dealSheetBidderNameLabel = new Label(dealSheetBidderNameColumn, row, bidderName);
				dealSheet.addCell(dealSheetBidderNameLabel);

				counter ++;
			}

		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when copy json data to test data excel sheet", e);
		}
		finally {

			try {
				copiedbook.write();
				copiedbook.close();
				book.close();
			}catch(Exception e){
				logger.error(e.getMessage(), e);
			}
		}
	}


	/** Copy and Execute the tag generation TC and save the tag into a file(/tpt/tag.txt) and return the content of file.
	 */
	public String channelTagSetup(Connection connection, JSONObject jsonObjectRepo)
	{
		String tag = "";

		try
		{
			String tagGenerationTCLocation = TestSuiteClass.AUTOMATION_HOME.concat("/tc_cases/e2e/TagGeneration_Test_Cases.xls");
			String copyTagFile = TestSuiteClass.AUTOMATION_HOME.concat("/results/e2e/ChannelTag/ChannelTagGeneration.xls");
			FileUtils.copyFile(new File(tagGenerationTCLocation), new File(copyTagFile));

			new E2EGenericMethods().setResultColumn(copyTagFile);
			new E2EHandler().executeTestCases(new File(copyTagFile), connection, jsonObjectRepo);
			tag = FileLib.ReadContentOfFile(TestSuiteClass.AUTOMATION_HOME.toString()+"/tpt/tag.txt");
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Channel tag is written in file: "+tag);
		return tag;
	}


	/**
	 * This method will get the default header data from config as per provided macroName and put it into headers map
	 * @param macroName
	 * @param macroData
	 */
	public HashMap<String, String> getDefaultHeadersValues(String macroName, String macroData, String targetingName)
	{
		HashMap<String, String> headers = new HashMap<>();
		String macroDataFromConfig = new E2EGenericMethods().getTargetingDefaultValue(macroName, macroData, targetingName);

		try{
			if(!macroData.equalsIgnoreCase(macroDataFromConfig))
			{
				/** get macro name and use the default value if this from config */
				headers.put(macroName, macroDataFromConfig);
			}
			else
			{
				macroDataFromConfig = new E2EGenericMethods().getTargetingDefaultValue(macroName, macroData, targetingName).trim();

				/** get macro name and use the default value if this from config */
				headers.put(macroName, macroDataFromConfig);
			}
		}
		catch(Exception e)
		{
			logger.error("Exception occurred when putting default headers data into hearders map");
		}
		return headers;
	}


	/**
	 * This method will get the default value from config as per provided macroName and replace it into tag
	 * @param macroName
	 * @param macroData
	 */
	public String replaceDefaultMacrosValues(String tag, String macroName, String macroData, String targetingName)
	{
		try{

			String macroDataFromConfig = new E2EGenericMethods().getTargetingDefaultValue(macroName, macroData, targetingName).trim();

			/** get default data from config, if that matches with input then get again */
			if(!macroData.equalsIgnoreCase(macroDataFromConfig))
			{
				/** get macro name and use the default value if this from config */
				tag = replaceMacroData(tag, macroDataFromConfig, macroName);
			}
			else
			{
				/** get macro name and use the default value if this from config */
				macroDataFromConfig = new E2EGenericMethods().getTargetingDefaultValue(macroName, macroData, targetingName).trim();
				tag = replaceMacroData(tag, macroDataFromConfig, macroName);
			}

		}
		catch(Exception e)
		{
			logger.error("Exception occurred when replacing default macros values into tag");
		}
		return tag;

	}


	/**
	 * replace macro from the supplied tag, find macro first and if not found then encode macro and find again and then replace
	 *  
	 * @param tag
	 * @param macroData
	 * @param macroName
	 * @return
	 */
	public String replaceMacroData(String tag, String macroData, String macroName)
	{
		try
		{
			macroData = URLEncoder.encode(macroData, "UTF-8");
			if(tag.contains(macroName))
			{
				tag = tag.replace(macroName, macroData);
			}
			else
			{
				macroName = URLEncoder.encode(macroName, "UTF-8");
				tag = tag.replace(macroName, macroData);
			}}
		catch(Exception e)
		{

		}
		return tag;
	}


	/** This method will parse any macro in the supplied map and then create dynamic data for that macro and put it in the same map
	 * like [CategoryId] in bidder test data can be: [bk|lr|bk&lr|bk]
	 * to handle this we'll get data from mysql for these category and put it in map 
	 * like: [bk_123|lr_1221|bk_333&lr_88|bk_9789] 
	 * 
	 * @param testData
	 * @return
	 */
	public TreeMap<String, TreeMap<String,String>> createDynamicTestData(TreeMap<String, TreeMap<String,String>> testData, Connection connection)
	{
		/** parse the supplied map */
		for(Entry<String, TreeMap<String, String>> map : testData.entrySet())
		{
			String taskId = map.getKey().toString();
			TreeMap<String, String> testdataMap = map.getValue();

			/** get the [CategoryId] macro and check if the vaue of this key is macro i.e. starts with [ or not */
			if(testdataMap.containsKey("[CategoryId]") && !testdataMap.get("[CategoryId]").isEmpty() && testdataMap.get("[CategoryId]").startsWith("["))
			{
				String value = parseCategoryIdMacro(testdataMap.get("[CategoryId]"), connection);
				value = parseCategoryIdMacro(value, connection);

				logger.debug("Task ID: "+taskId + " Category Values: "+value);

				/** update this map */
				testdataMap.put("[CategoryId]", value);

				/** update the map based on taskid */
				testData.put(taskId, testdataMap);
			}

		}

		return testData;
	}


	/** this method will parse the supplied categoryid macro and replace it with actual 
	 * value sample macro [bk|lr|bk&lr|bk] and actual value to be returned: [bk_123|lr_1221|bk_333&lr_88|bk_9789]
	 * 
	 * @param macro
	 * @param connection
	 * @return
	 */
	public String parseCategoryIdMacro(String macro, Connection connection)
	{  
		macro = macro.replace("[", "").replace("]", "").trim().toUpperCase();
		macro = replaceCategory(macro, "BK", connection);
		macro = replaceCategory(macro, "LR", connection);

		return macro;
	}


	/** replace the category with the values form db */
	public String replaceCategory (String str, String replaceChar, Connection connection)
	{
		List<String> categoryNotToBeIncludedAgain = new ArrayList<>();

		String category = "";
		int i = str.indexOf(replaceChar);

		while(i>=0)
		{
			i = str.indexOf(replaceChar, i+1);

			if(i>=0){

				/** sending same category id again so that it doesn't picked up again in next iteration */
				category = getcategoryFromDB(connection, replaceChar, parseList(categoryNotToBeIncludedAgain));

				/** add this category in a list - not to be included again */
				categoryNotToBeIncludedAgain.add(category);

				/** replace bluekai and liveramp category with BLUEKAI_1231 and LIVERAMP_2323 */
				if(replaceChar.equalsIgnoreCase("BK")) 
				{
					str = str.replaceFirst(replaceChar, "bluekai"+"_"+category);
				}
				else
				{
					str = str.replaceFirst(replaceChar, "liveramp"+"_"+category);
				}

			}
		}

		return str;
	}


	/** get category from db and return the string in format like lr_<category>
	 * 
	 * @param connection
	 * @param replaceChar
	 * @return
	 */
	public String getcategoryFromDB(Connection connection, String replaceChar, String categoryID)
	{
		String sql = "select category_id from provider_categories where provider_prefix = '"+replaceChar+"_' AND category_id NOT IN ("+categoryID +") limit 1; ";
		String category = new DBLib().getCategory(connection, sql);
		return category;
	}


	/** Parse list based on usage 
	 * 
	 * @param categoryNotToBeIncludedAgain
	 * @return
	 */
	public String parseList(List<String> categoryNotToBeIncludedAgain)
	{

		if(categoryNotToBeIncludedAgain.isEmpty())
		{
			return "''";
		}
		else
		{
			return categoryNotToBeIncludedAgain.toString().replace("[", "").replace("]", "").trim();
		}

	}


	/** This method will download bidder end point in qa.vdopia.com - received from the bidder test data sheet 
	 * don't download if url like bidders.qa.vdopia.com 
	 * and finally wrap the bidder end point in smart php 
	 * 
	 * @param session
	 * @param bidderEndPoint
	 * @return
	 */
	public String setupBidderEndPoint(Session session, String bidderEndPoint, String connectionType)
	{
		String uniqueID = UUID.randomUUID().toString();
		String url= null;
		String bidderFile = null;
		try
		{
			if(bidderEndPoint.contains("bidders.qa.vdopia.com/bidder.php"))
			{
				return bidderEndPoint;
			}
			else if(bidderEndPoint.toLowerCase().trim().contains("adserver/rtb/adrequest/hudson"))
			{
				bidderFile = "adserver/rtb/adrequest/hudson";
			}
			else 
			{
				bidderFile = bidderEndPoint.substring(bidderEndPoint.lastIndexOf("/")+1, bidderEndPoint.length());

				/** check if file exists, if not then download it on server */
				Object checkIfExists = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "cat /var/www/ads/"+bidderFile+"; ");
				if(checkIfExists.toString().isEmpty())
				{
					ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(session, "cd /var/www/ads/; sudo wget "+bidderEndPoint+";");
				}
			}

			/** update bidder end point with smart php */
			if(bidderEndPoint.startsWith("https://")){

				if(bidderFile.equalsIgnoreCase("adserver/rtb/adrequest/hudson"))
				{
					url= "https://uat.serve.qa.vdopia.com/"+bidderFile;
				}
				else if (connectionType.contains("rtb"))
				{
					url= "https://bidders.qa.vdopia.com/"+bidderFile;
				}
				else
				{
					/** sending vastfile = <BidderFileName> parameter also, to be used smart php only in case of Vast Connection to reduce timeout */
					url= "https://bidders.qa.vdopia.com/"+bidderFile+"&auction_id=[%VDO_BID_ID%]&vastfile="+bidderFile;
				}
				return "https://bidders.qa.vdopia.com/bidder.php?bidderurl="+url+"&filename=#time#"+"_"+uniqueID;

			}else{

				if(bidderFile.equalsIgnoreCase("adserver/rtb/adrequest/hudson"))
				{
					url= "http://uat.serve.qa.vdopia.com/"+bidderFile;
				}
				else if (connectionType.contains("rtb"))
				{
					url= "http://bidders.qa.vdopia.com/"+bidderFile;
				}
				else
				{
					/** sending vastfile = <BidderFileName> parameter also, to be used smart php only in case of Vast Connection to reduce timeout */
					url= "http://bidders.qa.vdopia.com/"+bidderFile+"&auction_id=[%VDO_BID_ID%]&vastfile="+bidderFile;
				}
				return "http://bidders.qa.vdopia.com/bidder.php?bidderurl="+url+"&filename=#time#"+"_"+uniqueID;
			}
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ":"+ e.getMessage(),e);
			return "http://bidders.qa.vdopia.com/bidder.php?bidderurl="+url+"&filename=#time#"+"_"+uniqueID;
		}
	}


	/** This method will wrap the bidder end point in a smart php and return the final bidder map. 
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param bidderTestData
	 * @param sessionServe
	 * @return
	 */
	public TreeMap<String, TreeMap<String,String>> updateBidderEndPoint(TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, 
			TreeMap<String, TreeMap<String,String>> bidderTestData, Session sessionServe )
	{
		for(Map.Entry<String, TreeMap<String,String>> en : mapAllTasksFromDriverSheet.entrySet())
		{
			logger.info("Updating bidder end point for taskId :"+en.getKey());

			try{		
				TreeMap<String,String> bidderMap = bidderTestData.get(en.getKey());

				if(bidderMap.containsKey("[Bid Request URL]"))
				{
					String bidderEndPoint = bidderMap.get("[Bid Request URL]").toString().trim();
					String connectionType = bidderMap.get("[Connection Type]").toString().trim();

					/** get smart php end point */
					bidderEndPoint = setupBidderEndPoint(sessionServe, bidderEndPoint, connectionType);
					bidderMap.put("[Bid Request URL]", bidderEndPoint);
					bidderTestData.put(en.getKey(), bidderMap);

					logger.info("Updated bidder end point: "+bidderEndPoint +" for taskId :"+en.getKey());
				}
				else
				{
					logger.info("[Bid Request URL] key not found for taskId :"+en.getKey());
				}				
			}
			catch(Exception e)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ":" + e.getMessage(),e);
			}
		}

		return bidderTestData;
	}


	/** This method will merge the jsontestdata with the module test data, because the module data is final therefore
	 * can't be changed thats why - we need store map values in another map.
	 * 
	 * @param moduleTestData
	 * @param jsonTestData
	 * @param taskID
	 * @return
	 */
	public TreeMap<String, TreeMap<String, String>> getFinalTestDataMap(TreeMap<String, TreeMap<String, String>> moduleTestData,
			HashMap<String, String> jsonTestDataMap, String taskID)
	{
		TreeMap<String, TreeMap<String, String>> finalModuleTestDataMap = new TreeMap<>();

		try
		{
			/** store moduletestdata - for channel, campaign, bidder etc.. in map for the supplied taskid */
			TreeMap<String, String> map = moduleTestData.get(taskID);

			/** copy json data in moduletestdata map */
			map.putAll(jsonTestDataMap);

			/** copy the merged map in the final map with the supplied task id */
			finalModuleTestDataMap.put(taskID, map);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " +" Exception while merging data for task id: "+taskID, e);
		}
		return finalModuleTestDataMap;
	}


	/** This method will merge the jsontestdata with the module test data, because the module data is final therefore
	 * can't be changed thats why - we need store map values in another map.
	 * 
	 * @param moduleTestData
	 * @param jsonTestData
	 * @param taskID
	 * @return
	 */
	public TreeMap<String, TreeMap<String, String>> getFinalTestDataMap(TreeMap<String, TreeMap<String, String>> moduleTestData,
			HashMap<String, String> jsonTestDataMap, String taskID, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet)
	{
		TreeMap<String, TreeMap<String, String>> finalModuleTestDataMap = new TreeMap<>();

		try
		{
			/** store moduletestdata - for channel, campaign, bidder etc.. in map for the supplied taskid */
			TreeMap<String, String> map = moduleTestData.get(taskID);

			/**  setting no value in json test data for those test cases which are not required to be executed */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Campaign").equalsIgnoreCase("no"))
			{
				jsonTestDataMap.put("[CampaignName]", "");
				jsonTestDataMap.put("[CampaignID]", "");
			}
			if(mapAllTasksFromDriverSheet.get(taskID).get("Channel").equalsIgnoreCase("no"))
			{	
				jsonTestDataMap.put("[ChannelID]", "");
				jsonTestDataMap.put("[ChannelName]", "");
			}
			if(mapAllTasksFromDriverSheet.get(taskID).get("Bidder").equalsIgnoreCase("no"))
			{
				jsonTestDataMap.put("[BidderName]", "");
				jsonTestDataMap.put("[BidderID]", "");
			}
			if(mapAllTasksFromDriverSheet.get(taskID).get("Package").equalsIgnoreCase("no"))
			{
				jsonTestDataMap.put("[PackageID]", "");
				jsonTestDataMap.put("[PackageName]", "");
			}
			if(mapAllTasksFromDriverSheet.get(taskID).get("Deal").equalsIgnoreCase("no"))
			{
				jsonTestDataMap.put("[DealName]", "");
				jsonTestDataMap.put("[DealID]", "");
			}

			/** copy json data in moduletestdata map */
			map.putAll(jsonTestDataMap);

			/** copy the merged map in the final map with the supplied task id */
			finalModuleTestDataMap.put(taskID, map);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " +" Exception while merging data for task id: "+taskID, e);
		}
		return finalModuleTestDataMap;
	}



	/** This is method handles all the ui test setup, in case any new setup on ui - add code here  
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskID
	 * @param finalChannelTestData
	 * @param finalCampaignTestData
	 * @param finalBidderTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 * @param jsonObjectRepo
	 * @param connection
	 * @return
	 */
	public TreeMap<String, String> performPortalActions(TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, String taskID,
			TreeMap<String, TreeMap<String, String>> finalChannelTestData, TreeMap<String, TreeMap<String, String>> finalCampaignTestData, 
			TreeMap<String, TreeMap<String, String>> finalBidderTestData, TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData, JSONObject jsonObjectRepo, Connection connection
			)
	{
		TreeMap<String, String> testsetupResultsMap = new TreeMap<>();

		String channelStatus = "not_executed";
		String campaignStatus = "not_executed";
		String bidderStatus = "not_executed";
		String packageStatus = "not_executed";
		String dealStatus = "not_executed";
		String result = "not_executed";

		try
		{
			/** 1. Setup Campaign first and run memcamp so that we have campaign entry in memecamp table and avoid any collision of memcamp cron by other threads */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Campaign").equalsIgnoreCase("yes"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding Campaign set up in callable task. ");
				campaignStatus = new TestSetup().campaignSetup(finalCampaignTestData, mapAllTasksFromDriverSheet, taskID, connection, jsonObjectRepo);
			}
			else
			{
				String campaignid = finalCampaignTestData.get(taskID).get("[CampaignID]");

				String sql = "update campaign set review_status = 'Pending Review' where id = "+campaignid+";";
				new DBLib().executeUpdateInsertQuery(connection, sql);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Disabling Campaign id: "+campaignid + " coz this test is set to no. ");
			}

			/** 2. Setup channel if campaign is set up successfully. */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Channel").equalsIgnoreCase("yes") && !campaignStatus.equalsIgnoreCase("fail"))
			{	
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding Channel set up in callable task. ");
				channelStatus = new TestSetup().channelSetup(finalChannelTestData, mapAllTasksFromDriverSheet, taskID, connection, jsonObjectRepo);
			}
			else
			{
				String channelID = finalChannelTestData.get(taskID).get("[ChannelID]");

				String sql = "update channels set market_place_setting = 'no_bidders' where id = "+channelID+";";
				new DBLib().executeUpdateInsertQuery(connection, sql);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Disabling Channel id: "+channelID + " coz this test is set to either no or coz of campaignStatus: "+campaignStatus);
			}

			/** 3. Setup bidder if campaign and channel are set up successfully. */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Bidder").equalsIgnoreCase("yes") && !campaignStatus.equalsIgnoreCase("fail") && !channelStatus.equalsIgnoreCase("fail"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding Bidder set up in callable task. ");
				bidderStatus = new TestSetup().bidderSetup(finalBidderTestData, mapAllTasksFromDriverSheet, taskID, connection, jsonObjectRepo);
			}
			else
			{
				String bidderID = finalBidderTestData.get(taskID).get("[BidderID]");

				String sql = "update hudsonBidder set BidderStatus = 'Disapproved' where BidderId = '"+bidderID+"';";
				new DBLib().executeUpdateInsertQuery(connection, sql);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Disabling bidderID: "+bidderID + " coz campaignStatus: "+campaignStatus +" or channelStatus: "+channelStatus + " bidder test is no.");
			}

			/** 3a. Setup package if above setup is successful */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Package").equalsIgnoreCase("yes") && !campaignStatus.equalsIgnoreCase("fail") && !channelStatus.equalsIgnoreCase("fail") 
					&& !bidderStatus.equalsIgnoreCase("fail"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding Package set up in callable task. ");
				packageStatus = new TestSetup().packageSetup(finalPackageTestData, mapAllTasksFromDriverSheet, taskID, connection, jsonObjectRepo);
			}
			else
			{
				String packageID = finalPackageTestData.get(taskID).get("[PackageID]");

				String sql = "update packages set status = 'inactive' where id = "+packageID+";";
				new DBLib().executeUpdateInsertQuery(connection, sql);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Disabling packageID: "+packageID + " coz campaignStatus: "+campaignStatus +" or channelStatus: "+channelStatus 
						+ " or bidderStatus: "+bidderStatus +" package test is no.");
			}

			/** 3b. Setup deal if above setup is successful */
			if(mapAllTasksFromDriverSheet.get(taskID).get("Deal").equalsIgnoreCase("yes") && !campaignStatus.equalsIgnoreCase("fail") && !channelStatus.equalsIgnoreCase("fail") 
					&& !bidderStatus.equalsIgnoreCase("fail") && !packageStatus.equalsIgnoreCase("fail"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Adding Deal set up in callable task. ");
				dealStatus = new TestSetup().dealSetup(finalDealTestData, mapAllTasksFromDriverSheet, taskID, connection, jsonObjectRepo);
			}
			else
			{
				String dealID = finalDealTestData.get(taskID).get("[DealID]");

				String sql = "update deals set status = 'pause' where deal_id = '"+dealID+"';";
				new DBLib().executeUpdateInsertQuery(connection, sql);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Disabling dealID: "+dealID + " coz campaignStatus: "+campaignStatus +" or channelStatus: "+channelStatus 
						+ " or bidderStatus: "+bidderStatus + " or packageStatus: "+packageStatus +" deal test is no.");
			}

			/** Get default result */
			result = "Setup: Campaign: "+campaignStatus + ", Channel: "+channelStatus + ", Bidder: "+bidderStatus + ", Package: "+packageStatus + ", Deal: "+dealStatus;

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": " +e.getMessage());
		}

		/** keep all results in a map */
		testsetupResultsMap.put("channelStatus", channelStatus);
		testsetupResultsMap.put("campaignStatus", campaignStatus);
		testsetupResultsMap.put("bidderStatus", bidderStatus);
		testsetupResultsMap.put("packageStatus", packageStatus);
		testsetupResultsMap.put("dealStatus", dealStatus);
		testsetupResultsMap.put("result", result);

		return testsetupResultsMap;
	}


	/** setup prerequisites here.  
	 * like setting up delay, requisite format is like: {"delayinsec": "10","a1": "b1"} 
	 * 
	 * @param mapAllTasksFromDriverSheet
	 * @param taskID
	 */
	public void setupTestPrerequisites(TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, String taskID)
	{
		try{
			/** not doing anything here, wait is taken outside */
			//			JSONObject requisite = new JSONObject(mapAllTasksFromDriverSheet.get(taskID).get("Requisites"));
			//			int delay = Integer.parseInt(requisite.getString("delayinsec").trim())*1000;
			//
			//			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +": Applying delay of: " +delay +" for task: "+taskID);
			//			Thread.sleep(delay);
			//			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +": Applied delay of: " +delay +" for task: "+taskID);

		}catch(Exception j){}
	}


	/** Clear targeting of the respective test data --> 
	 * 
	 * @param taskID
	 * @param connection
	 * @param finalBidderTestData
	 * @param finalCampaignTestData
	 * @param finalChannelTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 */
	public void clearAllTargeting(String taskID, Connection connection, TreeMap<String, TreeMap<String, String>> finalBidderTestData, 
			TreeMap<String, TreeMap<String, String>> finalCampaignTestData, 
			TreeMap<String, TreeMap<String, String>> finalChannelTestData, 
			TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData)
	{
		try
		{
			/** Clear all targeting of campaign,channel,bidder and package before move further, not executing from test cases now as 
			 * it is being executed in all cases */

			String channelID = finalChannelTestData.get(taskID).get("[ChannelID]");
			String bidderID = finalBidderTestData.get(taskID).get("[BidderID]");
			String bidderName = finalBidderTestData.get(taskID).get("[BidderName]");
			String campaignID = finalCampaignTestData.get(taskID).get("[CampaignID]");
			String packageID = finalPackageTestData.get(taskID).get("[PackageID]");
			String dealID = finalDealTestData.get(taskID).get("[DealID]");

			new Keywords(connection, null).clearbiddertargeting(null, null, bidderID+":"+channelID);
			new Keywords(connection, null).clearcampaigntargeting(null, null, campaignID);
			new Keywords(connection, null).clearchanneltargeting(null, null, channelID);
			new Keywords(connection, null).clearpackagetargeting(null, null, packageID);
			new Keywords(connection, null).cleardealtargeting(null, null, dealID+":"+bidderName);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" Cleared all targeting. ");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ " : Exception occured when clearing all targetings. ",e);
		}
	}

	/**
	 * This method will create the json data by fetch the data from DB
	 * @param connection
	 * @param result
	 * @return
	 */
	public static void createJsonDataFromDB(ResultSet campaignResult, ResultSet channelResult,ResultSet bidderResult,ResultSet dealResult,ResultSet packageResult)
	{
		int i = 0;
		JSONObject jsonCompleteData = new JSONObject();
		try {
			while(campaignResult.next() && channelResult.next() && bidderResult.next() && dealResult.next() && packageResult.next() )
			{
				JSONObject jsonSingleData = new JSONObject();
				String channelName = channelResult.getString("name");
				jsonSingleData.put("[ChannelName]", channelName);
				String channelID = channelResult.getString("id");
				jsonSingleData.put("[ChannelID]", channelID);
				String publisherEmail = channelResult.getString("publisher_email");
				jsonSingleData.put("[PublisherEmail]", publisherEmail);

				String campaignName = campaignResult.getString("name");
				jsonSingleData.put("[CampaignName]", campaignName);
				String campaignID = campaignResult.getString("id");
				jsonSingleData.put("[CampaignID]", campaignID);

				String bidderName = bidderResult.getString("BidderIdentifier");
				jsonSingleData.put("[BidderName]", bidderName);
				String bidderID = bidderResult.getString("BidderId");
				jsonSingleData.put("[BidderID]", bidderID);

				String packageName = packageResult.getString("name");
				jsonSingleData.put("[PackageName]", packageName);
				String packageID = packageResult.getString("id");
				jsonSingleData.put("[PackageID]", packageID);

				String dealName = dealResult.getString("name");
				jsonSingleData.put("[DealName]", dealName);
				String dealID = dealResult.getString("deal_id");
				jsonSingleData.put("[DealID]", dealID);
				jsonCompleteData.put(String.valueOf(i),jsonSingleData);
				i++;
			}
			FileLib.WriteTextInFile(TestSuiteClass.AUTOMATION_HOME.concat("/tc_data/e2e/e2e.input.json"), jsonCompleteData.toString());
			if(jsonCompleteData.length() == 0)
			{
				Assert.fail("Failed : As json data is blanked");
			}
		} catch (Exception e) {
			logger.error("Exception occured when creating json data from db",e);
		}

	}

	/**
	 * This method will get the data from DB and then create the json data
	 * @param con
	 */
	public static void createJsonData(Connection con, int limit)
	{
		try{

			/** ignoring those bidders which have same name */
			String campaignQuery = " select cam.id as id, cam.name as name from campaign cam "+
					" inner join campaign_members camm "+ 
					" on cam.id = camm.cid "+
					" inner join ads ad "+
					" on camm.ad_id = ad.id "+
					" where cam.advertiser_id in (select id from advertiser where email = 'vdopiaadvertiser@vdopia.com') "+ 
					" and cam.name not in (select name from campaign group by name having count(name) > 1) "+
					" and cam.device ='iphone' "+
					" and ad.ad_format = 'video' "+
					" order by cam.id desc limit "+limit;

			logger.info("Campaign Data SQL : "+campaignQuery);

			String updateCampaignDataSql = " update campaign set createdate = '2016-05-27 05:10:19', review_status = 'Disapproved', "
					+ " validfrom = '2016-05-27 05:10:19', "
					+ " validto = '2020-05-27 05:10:19' ;";

			/** update campaign data - date */
			new DBLib().executeUpdateInsertQuery(con, updateCampaignDataSql);

			ResultSet campaignResult = MobileTestClass_Methods.ExecuteMySQLQueryReturnsResultSet(con, campaignQuery);

			String channelQuery = " select ch.id as id, ch.name as name, pub.email as publisher_email from channels ch "
					+ " join publisher pub on ch.publisher_id = pub.id "
					+ " and ch.allow_sitetargeting = 1"
					+ " and ch.channel_type = 'iphone' and ch.name not in (select name from channels group by name having count(name) > 1) "
					+ " and ( ch.name not like '%+%' and ch.name not like '%(%' and ch.name not like '%\\'%' and "
					+ " ch.name not like '%\\|%' AND ch.name not like '%€%' AND ch.name not like '%,%' "
					+ " AND ch.name not like '%Â»%' and ch.name <> 'SSP_Web Design Gallery' and ch.name not like '%?%' and ch.name not like '%Ä±%' ) " 
					+ " order by ch.id desc limit "+limit;

			logger.info("channel Data SQL : "+channelQuery);

			ResultSet channelResult = MobileTestClass_Methods.ExecuteMySQLQueryReturnsResultSet(con, channelQuery);

			String bidderQuery = " select BidderId,BidderIdentifier from hudsonBidder "
					+ " where AdvertiserId in "
					+ " (select id from advertiser where email = 'vdopiaadvertiser@vdopia.com') "
					+ " and "
					+ " BidderIdentifier not in "
					+ " (select BidderIdentifier from hudsonBidder group by BidderName having count(BidderIdentifier) > 1) order by id desc limit "+limit;

			logger.info("Bidder Data SQL : "+bidderQuery);
			ResultSet bidderResult = MobileTestClass_Methods.ExecuteMySQLQueryReturnsResultSet(con, bidderQuery);

			/** Update the status of all bidder as Disapproved */
			String bidderUpdateStatusQurey = "update hudsonBidder set BidderStatus = 'Disapproved'";
			new DBLib().executeUpdateInsertQuery(con, bidderUpdateStatusQurey);

			String dealQuery = "select name, deal_id from deals where name not in "
					+ " (select name from deals group by name having count(name) > 1) order by id desc limit "+limit;

			logger.info("Deal Data SQL : "+dealQuery);
			ResultSet dealResult = MobileTestClass_Methods.ExecuteMySQLQueryReturnsResultSet(con, dealQuery);

			String dealStatusQurey = "update deals set status = 'pause'";
			new DBLib().executeUpdateInsertQuery(con, dealStatusQurey);

			String packageQuery = "select id, name from packages "
					+ " where name not in "
					+ " (select name from packages group by name having count(name) > 1) order by id desc limit "+limit;

			logger.info("Package Data SQL : "+packageQuery);
			ResultSet packageResult = MobileTestClass_Methods.ExecuteMySQLQueryReturnsResultSet(con, packageQuery);

			String packageStatusQuery = "update packages set status = 'inactive'";
			new DBLib().executeUpdateInsertQuery(con, packageStatusQuery);

			createJsonDataFromDB(campaignResult, channelResult, bidderResult, dealResult, packageResult);
		}
		catch (Exception e) {
			logger.error("Exception occured when creating json data from db",e);
		}
	}


}
