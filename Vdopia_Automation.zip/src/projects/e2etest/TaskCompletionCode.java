package projects.e2etest;

public class TaskCompletionCode {

	
	/** Task Completion Status definition
	 * 
	 * 0 -> Portal Task Picked Up (In Progress)
	 * 1 -> Portal Task Completed (Ready For Chocolate)
	 * 2 -> Chocolate Task Picked Up (In Progress)
	 * 1000 -> Chocolate Task Completed (Ready With All Results - Whole Task Completed)
	 */

	private int code_LoadData = -1;
	
	private int code_TaskPickedupFirstTime = 0;
	private int code_portalTaskCompletion = 1;

	private int code_chocolateTaskPickedup = 2;
	private int code_chocolateTaskCompletion = 3;

	private int code_allTasksCompletion = 1000;
	


	public int getCode_portalTaskCompletion() {
		return code_portalTaskCompletion;
	}

	public void setCode_portalTaskCompletion(int code_portalTaskCompletion) {
		this.code_portalTaskCompletion = code_portalTaskCompletion;
	}

	public int getCode_chocolateTaskPickedup() {
		return code_chocolateTaskPickedup;
	}

	public void setCode_chocolateTaskPickedup(int code_chocolateTaskPickedup) {
		this.code_chocolateTaskPickedup = code_chocolateTaskPickedup;
	}

	public int getCode_chocolateTaskCompletion() {
		return code_chocolateTaskCompletion;
	}

	public void setCode_chocolateTaskCompletion(int code_chocolateTaskCompletion) {
		this.code_chocolateTaskCompletion = code_chocolateTaskCompletion;
	}

	public int getCode_allTasksCompletion() {
		return code_allTasksCompletion;
	}

	public void setCode_allTasksCompletion(int code_allTasksCompletion) {
		this.code_allTasksCompletion = code_allTasksCompletion;
	}

	public int getCode_TaskPickedupFirstTime() {
		return code_TaskPickedupFirstTime;
	}

	public void setCode_TaskPickedupFirstTime(int code_TaskPickedupFirstTime) {
		this.code_TaskPickedupFirstTime = code_TaskPickedupFirstTime;
	}

	public int getCode_LoadData() {
		return code_LoadData;
	}

	public void setCode_LoadData(int code_LoadData) {
		this.code_LoadData = code_LoadData;
	}


}
