package projects.e2etest;


import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.UUID;

import projects.TestSuiteClass;
import vlib.MobileTestClass_Methods;

import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

public class ValidationModules {

	Logger logger = Logger.getLogger(ValidationModules.class.getName());

	String driverFile;
	TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet;
	String taskID;
	TreeMap<String, TreeMap<String, String>> channelTestData;
	TreeMap<String, TreeMap<String, String>> campaignTestData;
	TreeMap<String, TreeMap<String, String>> bidderTestData;
	TreeMap<String, TreeMap<String, String>> packageTestData;
	TreeMap<String, TreeMap<String, String>> dealTestData;
	Connection con;
	Session sessionServe;
	Session sessionBidder;
	Bigquery bigQueryConnection;
	String bqProjectId;
	HashMap<Object, Object> responseMap;
	String tag;


	/** Constructor 
	 * 
	 * @param taskID
	 * @param driverFile
	 * @param mapAllTasksFromDriverSheet2
	 * @param channelTestData2
	 * @param campaignTestData2
	 * @param bidderTestData2
	 */
	public ValidationModules(String taskID, String driverFile, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet2, 
			TreeMap<String, TreeMap<String, String>> channelTestData2, TreeMap<String, TreeMap<String, String>> campaignTestData2, 
			TreeMap<String, TreeMap<String, String>> bidderTestData2, TreeMap<String, TreeMap<String, String>> packageTestData2, 
			TreeMap<String, TreeMap<String, String>> dealTestData2, Connection con, Session sessionServe, Session sessionBidder, 
			Bigquery bigQueryConnection, String bqProjectId, HashMap<Object, Object> responseMap, String tag) 
	{
		this.taskID = taskID;
		this.driverFile = driverFile;
		this.mapAllTasksFromDriverSheet = mapAllTasksFromDriverSheet2; 
		this.channelTestData = channelTestData2;
		this.campaignTestData = campaignTestData2;
		this.bidderTestData = bidderTestData2;
		this.packageTestData = packageTestData2;
		this.dealTestData = dealTestData2;
		this.con = con;
		this.sessionServe = sessionServe;
		this.sessionBidder = sessionBidder;
		this.bigQueryConnection = bigQueryConnection;
		this.bqProjectId = bqProjectId;
		this.responseMap = responseMap;
		this.tag = tag;
	}


	public String test_method()
	{
		return "Test Passed";
	}

	/**
	 * This method will replace the macros used while validating targeting in the serving URL
	 * 
	 * @param tag
	 * @param taskId
	 * @param testDataSheetLocation
	 * @return
	 */
	public String validate_targeting()
	{
		String result = "FAIL";
		String key = null;
		String originalTag = tag;

		String adAvailable = "AD";
		String adUnAvailable = "No_Ad";
		HashMap<String, String> headers = new HashMap<>();

		try{

			/** Wait for entry in memcamp after edit the campaign */
			Thread.sleep(3000);

			/** Get the complete test data map from the provided location and from Campaign sheet coz it contains the Targeting data  
			 * Get the test data map of provided task id*/ 
			TreeMap<String, String> campaignTestDataMapOfTaskID = campaignTestData.get(taskID);

			/** Get the targeting data*/
			String targeting_data = campaignTestDataMapOfTaskID.get("[Targeting_Data]");
			JSONObject jsonData = new JSONObject(targeting_data);
			JSONObject targetingJsonData = jsonData.getJSONObject("targeting");

			/** Apply iteration on applied targeting*/
			Iterator<?> targetingKeys = targetingJsonData.keys();

			/** iterating all types of used targeting */
			while(targetingKeys.hasNext())
			{
				String targetingName = (String) targetingKeys.next();
				JSONObject targetingData = targetingJsonData.getJSONObject(targetingName);

				/** Apply iteration on targeting data like keys = include, exclude etc. */
				Iterator<?> specificTargetingKeys = targetingData.keys();
				while(specificTargetingKeys.hasNext())
				{
					/** getting include or exclude -- used in targeting */
					key = (String) specificTargetingKeys.next();
					JSONObject includeExcludeData = targetingData.getJSONObject(key);

					/** get the key = replaceMacro or replaceHeader -- to be used to proceed further */
					JSONArray replaceVariable = new JSONArray();
					if(includeExcludeData.getJSONArray("replaceMacro").length() != 0)
					{
						replaceVariable = includeExcludeData.getJSONArray("replaceMacro");
					}
					else if(includeExcludeData.getJSONArray("replaceHeader").length() != 0)
					{
						replaceVariable = includeExcludeData.getJSONArray("replaceHeader");
					}

					/** handle all targetings except direct-indirect, ronsetting, app-mobile, channel targeting,weekday targeting */
					if(!targetingName.equalsIgnoreCase("directindirecttargeting") && !targetingName.equalsIgnoreCase("ronsettingtargeting") && !targetingName.equalsIgnoreCase("appvsmobilewebtargeting") && !targetingName.equalsIgnoreCase("channeltargeting") && !targetingName.equalsIgnoreCase("weekdaytargeting") && !targetingName.equalsIgnoreCase("dealtargeting"))
					{

						/** Apply the loop to get all the macro provided in replaceVariable json Array to perform the desired test */
						tag = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "no").get("tag").get("tag");
						headers = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "no").get("header");

						/** perform the test based on the supplied test data ... */
						if(key.equalsIgnoreCase("include"))
						{
							result  = new ValidationHandler().validateResponse(tag, adAvailable, headers);
						}
						else if(key.equalsIgnoreCase("exclude"))
						{
							result  = new ValidationHandler().validateResponse(tag, adUnAvailable, headers);
						}

						/** restoring the original tag */
						tag = originalTag;
						headers.clear();

						/** now setting up request with default macro values of the above used macros */
						tag = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "yes").get("tag").get("tag");
						headers = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "yes").get("header");

						if(key.equalsIgnoreCase("include"))
						{
							result = result + new ValidationHandler().validateResponse(tag, adUnAvailable, headers);

							tag = originalTag;
							headers.clear();						

							tag = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "no").get("tag").get("tag");
							headers = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "no").get("header");
						}
						else if(key.equalsIgnoreCase("exclude"))
						{
							result = result + new ValidationHandler().validateResponse(tag, adAvailable, headers);

							/** get macro name and use the default value if this from config */
							tag = originalTag;
							headers.clear();

							tag = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "yes").get("tag").get("tag");
							headers = new ValidationHandler().test(includeExcludeData, replaceVariable, tag, targetingName, "yes").get("header");
						}
					}
					else if(!targetingName.equalsIgnoreCase("weekdaytargeting"))
					{
						/** perform the test based on the supplied test data ... */
						if(key.equalsIgnoreCase("include"))
						{
							result  = new ValidationHandler().validateResponse(tag, adAvailable, headers);
						}
						else if(key.equalsIgnoreCase("exclude"))
						{
							result  = new ValidationHandler().validateResponse(tag, adUnAvailable, headers);
						}
					}
					else if(targetingName.equalsIgnoreCase("weekdaytargeting"))
					{
						//JSONObject includeExcludeJson = jsonData.getJSONObject(key);
						String day = includeExcludeData.getString("day");
						if(key.equalsIgnoreCase("include"))
						{
							if(day.equalsIgnoreCase("today"))
							{
								result  = new ValidationHandler().validateResponse(tag, adAvailable, headers);
							}
							else if(day.equalsIgnoreCase("NotToday"))
							{
								result  = new ValidationHandler().validateResponse(tag, adUnAvailable, headers);
							}
						}
						else if(key.equalsIgnoreCase("exclude"))
						{
							if(day.equalsIgnoreCase("today"))
							{
								result  = new ValidationHandler().validateResponse(tag, adUnAvailable, headers);
							}
							else if(day.equalsIgnoreCase("NotToday"))
							{
								result  = new ValidationHandler().validateResponse(tag, adAvailable, headers);
							}
						}
					}
				}
			}

			originalTag= tag;

		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred when replacing targeting macros from serving URL", e);
		}
		return result;
	}


	/** This method will verify the functionality of ATS, it is implemented in two stage:
	 * 1. DSP Request Side Validation
	 * 2. Chocolate and DSP response validation
	 * 
	 * Number of scenarios covered: 10
	 * @param tag
	 * @return
	 */
	public String validate_ats_functionality()
	{
		/** append di to have data in biq query */
		tag = tag.concat(";di="+taskID+"_"+UUID.randomUUID());
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" Received tag: "+ tag);

		String result = "NOT_YET_SET";
		TreeMap<String,String> bidderTestDataOfTaskID = bidderTestData.get(taskID);
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + ": Serving Tag :"+tag);
			String chocolateResponse = (String) responseMap.get("response");

			/** DSP side validation */
			result = new ValidationHandler().validate_ats_dsp_request(bidderTestDataOfTaskID, con, sessionBidder, tag);

			/** Chocolate Response and DSP Response validation */
			if(!result.contains("Fail"))
			{
				result =  result + " " + new ValidationHandler().validate_ats_response(chocolateResponse, tag,bidderTestDataOfTaskID, con, sessionBidder);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": ATS SSP Final result : "+result);
			}
			else
			{
				result =  result + " SKIP: As request was not send so response need not to verify";
			}

		}
		catch(Exception e)
		{
			result = result + " SKIP: Couldn't verify this because of some unknown exception. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ " : validate_ats_functionality Error: " + e.getMessage(), e);
		}
		return result;
	}


	/**
	 * This method is to validate the moat functionality
	 * @param tag
	 * @return
	 */
	public String validate_moat()
	{	
		/** append di to have data in biq query */
		tag = tag.concat(";di="+taskID+"_"+UUID.randomUUID());
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" Received tag: "+ tag);

		String result = "";
		TreeMap<String,String> bidderTestDataOfTaskID = bidderTestData.get(taskID);
		TreeMap<String,String> campaignTestDataOfTaskID = campaignTestData.get(taskID);
		TreeMap<String,String> packageTestDataOfTaskID = packageTestData.get(taskID);
		String connectionType = bidderTestDataOfTaskID.get("[Connection Type]");
		ValidationHandler validatehandler = new ValidationHandler(); 

		try{
			@SuppressWarnings("static-access")
			TreeMap<String, String> urlParamMap = validatehandler.getURLParam(tag);

			String outputValue = urlParamMap.get("output");
			String callerValue = urlParamMap.get("caller");
			String adFormatValue = urlParamMap.get("adFormat");
			String chocolateResponse = (String) responseMap.get("response");

			/** check if bidder was picked up */
			TreeMap<Object, Object> bidderMap = validatehandler.isBidderPicked(tag, connectionType, bidderTestDataOfTaskID, taskID, con, sessionBidder);

			/** check if desired bidder won */
			if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataOfTaskID,con)){
				/** Find the result after comparing between actual and expected moat details */
				result = (String) validatehandler.validateMoatDetails(chocolateResponse, con, bidderTestDataOfTaskID, campaignTestDataOfTaskID,packageTestDataOfTaskID, outputValue, callerValue, adFormatValue, sessionBidder, taskID).get("result");

				/** Collecting results --> 
				 * checking if moat is enabled at Strawberry side */
				if(new ValidationHandler().ifMoatEnabledAtStrawberry(campaignTestDataOfTaskID, bidderTestDataOfTaskID))
				{
					result = " moat is enabled at strawberry side: "+ result;
				}
				else
				{
					if(new ValidationHandler().ifMoatEnabledAtChocolate(bidderTestDataOfTaskID, packageTestDataOfTaskID)){
						result = " moat is enabled at chocolate side: " +result;
					}
					else{
						result = " moat is not enabled at chocolate side also : " +result;
					}
				}
			}
			else{
				result = result + "SKIP : Desired bidder didn't win";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't win");

				/** checking if bidder was picked up - further checking why it didn't win */
				if(!(boolean) bidderMap.get("status"))
				{
					result = result + bidderMap.get("result");
				}

				/** check if ad was returned */
				else if(!new BidderHandler().checkIfBidderReturnedAd(bidderTestDataOfTaskID, con, sessionBidder))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't return the ad");
					result = result + "SKIP : Desired bidder didn't return the ad";
				}
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + result);
		}
		catch(Exception e)
		{
			result = result + " SKIP: Couldn't verify this because of some unknown exception. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + ": "+ " Exception occurred when validating moat functionality", e);
		}
		return result;

	}


	/**
	 * This method will validate the functionality of LR
	 * @param tag
	 * @return
	 */
	public String validate_lr_category()
	{
		String result = "";
		TreeMap<String,String> bidderTestDataOfTaskID = bidderTestData.get(taskID);
		TreeMap<String,String> packageTestDataOfTaskID = packageTestData.get(taskID);
		TreeMap<String,String> campaignTestDataOfTaskID = campaignTestData.get(taskID);
		TreeMap<String,String> dealTestDataOfTaskID = dealTestData.get(taskID);

		try{

			String chocolateResponse = (String) responseMap.get("response");

			/** check if desired bidder was picked up */
			if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataOfTaskID, con, sessionBidder))
			{
				/** check if ad was returned */
				if(new BidderHandler().checkIfBidderReturnedAd(bidderTestDataOfTaskID, con, sessionBidder))
				{
					/** check if desired bidder won */
					if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataOfTaskID,con))
					{
						String packageCategoryId = packageTestDataOfTaskID.get("[CategoryId]");
						String bidderCategoryId = bidderTestDataOfTaskID.get("[CategoryId]");
						String campaignCategoryId = campaignTestDataOfTaskID.get("[CategoryId]");

						/**  Validation the category saved in DB */
						result = result + new ValidationHandler().validateCategoryExpression(bidderTestDataOfTaskID, packageTestDataOfTaskID, 
								campaignTestDataOfTaskID, con,packageCategoryId,bidderCategoryId,campaignCategoryId);

						/** Validate the category in BQ */
						result = result + new ValidationHandler().validateCategoryInBQ(bidderTestDataOfTaskID, dealTestDataOfTaskID, con, sessionBidder,
								packageCategoryId,bidderCategoryId,campaignCategoryId,bigQueryConnection,bqProjectId);
					}

					else
					{
						result = result + "SKIP : Desired bidder didn't win";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't win");
					}
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't return the ad");
					result = result + "SKIP : Desired bidder didn't return the ad";
				}
			}
			else
			{
				result = result + "SKIP : Desired bidder didn't picked";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't picked");
			}
		}
		catch(Exception e)
		{
			result = result + " SKIP: Couldn't verify this because of some unknown exception. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Exception occured when validating LR functionality",e);
		}

		return result;
	}

	
	/**
	 * This method will validate the functionality of BK
	 * @param tag
	 * @return
	 */
	public String validate_bk_category()
	{
		String result = "";
		TreeMap<String,String> bidderTestDataOfTaskID = bidderTestData.get(taskID);
		TreeMap<String,String> packageTestDataOfTaskID = packageTestData.get(taskID);
		TreeMap<String,String> campaignTestDataOfTaskID = campaignTestData.get(taskID);
		TreeMap<String,String> dealTestDataOfTaskID = dealTestData.get(taskID);

		try{

			String chocolateResponse = (String) responseMap.get("response");

			/** check if desired bidder was picked up */
			if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataOfTaskID, con, sessionBidder))
			{
				/** check if ad was returned */
				if(new BidderHandler().checkIfBidderReturnedAd(bidderTestDataOfTaskID, con, sessionBidder))
				{
					/** check if desired bidder won */
					if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataOfTaskID,con))
					{
						String packageCategoryId = packageTestDataOfTaskID.get("[CategoryId]");
						String bidderCategoryId = bidderTestDataOfTaskID.get("[CategoryId]");
						String campaignCategoryId = campaignTestDataOfTaskID.get("[CategoryId]");

						/**  Validation the category saved in DB */
						result = result + new ValidationHandler().validateCategoryExpression(bidderTestDataOfTaskID, packageTestDataOfTaskID, 
								campaignTestDataOfTaskID, con,packageCategoryId,bidderCategoryId,campaignCategoryId);

						/** Validate the category in BQ */
						result = result + new ValidationHandler().validateCategoryInBQ(bidderTestDataOfTaskID, dealTestDataOfTaskID, con, sessionBidder,
								packageCategoryId,bidderCategoryId,campaignCategoryId,bigQueryConnection,bqProjectId);
					}

					else
					{
						result = result + "SKIP : Desired bidder didn't win";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't win");
					}
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't return the ad");
					result = result + "SKIP : Desired bidder didn't return the ad";
				}
			}
			else
			{
				result = result + "SKIP : Desired bidder didn't picked";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't picked");
			}

		}
		catch(Exception e)
		{
			result = result + " SKIP: Couldn't verify this because of some unknown exception. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Exception occured when validating LR functionality",e);
		}

		return result;
	}

	
	/**
	 * This method will validate the ad id from the chocolate response
	 * @param tag
	 * @return
	 */
	public String validate_adid()
	{
		String result = "/n";
		TreeMap<String,String> bidderTestDataOfTaskID = bidderTestData.get(taskID);
		try{

			String chocolateResponse = (String) responseMap.get("response");

			/** check if desired bidder was picked up */
			if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataOfTaskID, con, sessionBidder))
			{
				/** check if ad was returned */
				if(new BidderHandler().checkIfBidderReturnedAd(bidderTestDataOfTaskID, con, sessionBidder))
				{
					/** check if desired bidder won */
					if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataOfTaskID,con))
					{	
						/** get bidder response */
						String bidderResponse = new BidderHandler().getBidderResponse(bidderTestDataOfTaskID,con, sessionBidder);
						logger.info("Bidder response is: "+bidderResponse);
						new ValidationHandler().validateAdId(bidderResponse, chocolateResponse);
					}
					else
					{
						result = result + "SKIP : Desired bidder didn't win";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't win");
					}
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't return the ad");
					result = result + "SKIP : Desired bidder didn't return the ad";
				}
			}
			else
			{
				result = result + "SKIP : Desired bidder didn't picked";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Desired bidder didn't picked");
			}
		}
		catch(Exception e)
		{
			result = result + " SKIP: Couldn't verify this because of some unknown exception. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Exception occured when validating Ad ID",e);
		}

		return result;
	}

	
	/**
	 * This method will Validate the ad serving features
	 * @param tag
	 * @return
	 */
	public String validate_adserving()
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Starting serving module ... ");

		String result = "";
		WebDriver driver = MobileTestClass_Methods.WebDriverSetUp("chrome", null);

		TreeMap<String, String> urlPramMap = ValidationHandler.getURLParam(tag);
		String output = null;
		try
		{
			output = urlPramMap.get("output");
		}
		catch(NullPointerException e)
		{
			output = "js";
		}

		result = result + new ValidationHandler().adServing(responseMap, driver, taskID, output, sessionBidder);

		driver.quit();

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " serving module result: "+result);
		
		return result;
	}


}



