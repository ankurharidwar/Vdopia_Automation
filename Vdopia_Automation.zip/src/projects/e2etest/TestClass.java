package projects.e2etest;

import java.io.File;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONObject;
import org.testng.annotations.Test;

import com.jcraft.jsch.Session;

import projects.TestSuiteClass;
import projects.portal.GetObjectRepoAsJson;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;

public class TestClass {

	public static void main(String[] args) throws ParseException, InterruptedException {		

		long a1 = new java.util.Date().getTime();

		/*
		String date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(a);

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date1 = sdf.parse("07/12/2017 10:39:29");
		Date date2 = sdf.parse("07/12/2017 11:39:29");
		 */

		Thread.sleep(2500);

		long a2 = new java.util.Date().getTime();

		double diff = (a2 - a1);

		double diff1 = diff/1000;

		//double diffh = TimeUnit.MICROSECONDS.toSeconds(diff);

		System.out.println( a2 + "  ----  " + a1 + " ---- " +" ---- " + diff + "  ----  " + diff1);


	}

	public static void jsonCreation()
	{
		try{
			String tag = FileLib.ReadContentOfFile(TestSuiteClass.AUTOMATION_HOME.concat("/tpt/tag.txt"));
			System.out.println(new E2EGenericMethods().getServeURLFromChannelTag(tag));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public void test()
	{
		String category = "LR_2343|LR_235|BK_54545&LR_3453|BK_35346|BK_434";

		List<String> sortedORCategory = new LinkedList<>();
		String sortedCategory = null;
		try
		{
			List<String> categoryAndList = Arrays.asList(category.split("&"));
			for(int i=0;i<categoryAndList.size();i++)
			{
				List<String> categoryOrList = Arrays.asList(categoryAndList.get(i).split("\\|"));
				List<String> categoryOrListBK = new LinkedList<>();
				List<String> categoryOrListLR = new LinkedList<>();
				for(int j=0;j<categoryOrList.size();j++)
				{
					if(categoryOrList.get(j).contains("BK"))
					{
						categoryOrListBK.add(categoryOrList.get(j));
					}
					else if(categoryOrList.get(j).contains("LR"))
					{
						categoryOrListLR.add(categoryOrList.get(j));
					}

				}
				categoryOrListBK.sort(Comparator.comparing(String::length));	
				String categoryOrBKList = String.join("|", categoryOrListBK);

				categoryOrListLR.sort(Comparator.comparing(String::length));	
				String categoryOrLRList = String.join("|", categoryOrListLR);

				sortedORCategory.add(categoryOrBKList + "|" + categoryOrLRList);
				categoryOrListBK.clear();
				categoryOrListLR.clear();


				//Collections.sort(categoryOrList);
				//Collections.sort(categoryOrList, Comparator.comparing(String::compareTo).thenComparingInt(String::length));
				//categoryOrList.sort(Comparator.comparing(String::length).thenComparing(String::compareTo));
				//Collections.sort(categoryOrList,Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
				//Collections.sort(categoryOrList, new MyComparator());
				System.out.println("Categor List :"+sortedORCategory);
				//sortedORCategory.add(String.join("|", categoryOrListBK,categoryOrListLR));
			}
			sortedCategory = String.join("&", sortedORCategory);
		}
		catch(Exception e)
		{
			System.out.println("Exception : "+e);
			//logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " :Exception occured when sorting category ",e);
		}
		//String sortedCategory = new ValidationHandler().sortedCategories(category);	
		System.out.println("Sorted Category is: "+sortedCategory);
	}

	//@Test
	public void executeTestCase()
	{
		String objectRepo = TestSuiteClass.AUTOMATION_HOME.concat("/object_repository/portalObjectRepository/transformerPortal_ObjectRepository.xls");
		JSONObject jsonObjectRepo = new GetObjectRepoAsJson().getObjectRepoAsJson(objectRepo);

		new E2EHandler().executeTestCases(new File("/Users/Pankaj/Downloads/E2E_Package_Test_Cases_Executed_113440285.xls"), 
				MobileTestClass_Methods.CreateServeSQLConnection(), jsonObjectRepo); 
	}


	@Test
	public void test1()
	{
		String bidderServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[bidderserver]").toString().trim();
		String automationPemFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/qa-automation.pem");
		Session sessionBidder = ExecuteCommands.createSessionWithPrivateKey("ec2-user", automationPemFile, bidderServer);

		String sourceLocation="/Users/Shared/Jenkins/Desktop/qascripting/Vdopia_Automation/results/e2e/TASK_ATSValidation_RTB_Bidder_Secure_Request_Response_01//TASK_ATSValidation_RTB_Bidder_Secure_Request_Response_01.serve"; 
		String destinationLocation = "/tmp";

		vlib.ExecuteCommands.ExecuteCommandUsingJsch_CopyFileFromLocalToRemote(sessionBidder, sourceLocation, destinationLocation);
	}

}

