package projects.e2etest;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import projects.bq.BQHandler;
import projects.bq.BQQueriesLib;
import projects.chocolate.lib.VastHandlerLib;
import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.IntegerLib;
import vlib.MobileTestClass_Methods;
import vlib.httpClientWrap;

import org.w3c.dom.*;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

public class ValidationHandler {

	static Logger logger = Logger.getLogger(ValidationHandler.class.getName());


	public static void main(String[] args) throws URISyntaxException {
		// TODO Auto-generated method stub
		String url = "http://mukesh.serve.qa.vdopia.com/adserver/html5/inwapads/?inline=1&slide=1&fullscreen=0&sleepAfter=0&adFormat=preappvideo&ak=nK1lUp&version=1.0&vdo=1&pageURL=%5BWEB_PAGE_URL%5D&siteName=%5BSITE_NAME%5D&appBundle=%5BBUNDLE_NAME/PACKAGE_NAME%5D&appName=%5BAPP_NAME%5D&category=%5BCATEGORY%5D&refURL=%5BREFERER_URL%5D&di=%5BDEVICE_ID%5D&dif=%5BDEVICE_ID_FORMAT%5D&channelType=%5Bapp/site%5D&apiFramework=2&displayManager=%5BdisplayManager%5D&displayManagerVer=%5BdisplayManagerVer%5D&target_params=latlong%3D%5BLATITUDE%2FLONGITUDE%5D&cb=%5Btimestamp%5D&loop=0;output=js";
		// url = "http://www.example.com/something.html?one=1&two=2&three=3&three=3a";
		List<NameValuePair> params = URLEncodedUtils.parse(new URI(url), "UTF-8");

		for (NameValuePair param : params) {
			System.out.println(param.getName() + " : " + param.getValue());
		}

	}


	/**
	 * This method will validate the response of the serving url
	 * @param tag
	 * @param expectedResponse
	 * @param headers
	 * @return
	 */
	public String validateResponse(String tag, String expectedResponse, HashMap<String, String> headers)
	{
		String result = "";
		String response = "";

		try{
			if(headers.isEmpty())
			{
				response = httpClientWrap.sendGetRequest(tag);
			}
			else
			{
				response = httpClientWrap.sendGetRequest(tag, headers);
			}

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sending Request To: "+ tag + "\n Response is:  "+response);

			if(response.contains("Error Code: 202, Error Message:"))
			{
				result = "FAIL: URL is not correct, URL: "+tag;
			}
			else
			{
				if(expectedResponse.equalsIgnoreCase("Ad"))
				{
					if(response.contains("Ad id"))
					{
						result = "Expected: Ad, TEST PASSED : "+tag +"\n";
					}
					else
					{
						result = "Expected: Ad, TEST FAILED : "+tag +"\n";
					}
				}

				else if(expectedResponse.equalsIgnoreCase("No_Ad"))
				{
					if(!response.contains("Ad id"))
					{
						result = "Expected: No_Ad, TEST PASSED : "+tag +"\n";
					}
					else
					{
						result = "Expected: No_Ad, TEST FAILED : "+tag +"\n";
					}
				}

			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " +e.getMessage(), e);
		}
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *************  Result: "+result + "  ****************** ");

		return result;

	}

	public HashMap<String,HashMap<String,String>> test(JSONObject includeExcludeData, JSONArray replaceVariable, String tag, String targetingName, 
			String useDefaultData)
	{

		/** saving tag and map both in another map like: {tag: {tag: value }, header: {header name:  header value}}  */
		HashMap<String,HashMap<String,String>> map = new HashMap<>();

		try
		{
			HashMap<String, String> headers = new HashMap<>();

			for(int i = 0; i < replaceVariable.length(); i++)
			{
				/** get macro name from repalceMacro/replaceHeader key -- to be replaced in tag/header */
				String macroName = replaceVariable.getString(i).trim();

				/** now get the final data which needs to be replaced for macro = macroName, encode data */
				String macroData = includeExcludeData.getString(macroName).trim();

				if(includeExcludeData.getJSONArray("replaceMacro").length() != 0)
				{
					if(useDefaultData.equalsIgnoreCase("Yes"))
					{
						tag = new TestSetup().replaceDefaultMacrosValues(tag, macroName, macroData, targetingName);
					}
					else
					{
						tag = new TestSetup().replaceMacroData(tag, macroData, macroName);
					}
				}
				else if(includeExcludeData.getJSONArray("replaceHeader").length() != 0)
				{
					if(useDefaultData.equalsIgnoreCase("Yes"))
					{
						headers = new TestSetup().getDefaultHeadersValues(macroName, macroData, targetingName);
					}
					else
					{
						headers.put(macroName, macroData);
					}
				}

				HashMap<String, String> tagMap = new HashMap<>();
				tagMap.put("tag", tag);

				map.put("tag",  tagMap);
				map.put("header", headers);
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Received include Exclude Data: "+includeExcludeData.toString() + " and replace variable: "+replaceVariable, e);
		}

		return map;
	}

	/**
	 *  This method will check the VAST Bidder Request with respect to the chosen Bidder side security type. 
	 *  
	 * @param tag
	 * @param securityType
	 * @param vastBidderRequest
	 * @return
	 */
	public String validateProtocolForVastBidder(String tag, String vastBidderRequest, String securityType)
	{
		String result = "";

		try{
			if(tag.startsWith("https://"))
			{
				if(vastBidderRequest.startsWith("https://"))
				{	
					result = result+ "PASSED: VAST Bidder was accessed with https protocol in case of security type = "+securityType+ " and secure supply.";
				}
				else{
					result = result+ "FAIL: VAST Bidder was not accessed with https protocol in case of security type = "+securityType+ " and secure supply.";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Received VAST Bidder Request:  "+vastBidderRequest);
				}
			}
			else
			{
				if(vastBidderRequest.startsWith("http://"))
				{	
					result = result+ "PASSED: VAST Bidder was accessed with http protocol in case of security type = "+securityType+ " and non secure supply.";
				}
				else
				{
					if(securityType.equalsIgnoreCase("secure_only_url"))
					{
						result = result+ "PASSED: VAST Bidder was accessed with https protocol in case of security type =  "+securityType+ " and non secure supply.";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Received VAST Bidder Request:  "+vastBidderRequest);
					}

					else
					{
						result = result+ "FAIL: VAST Bidder was not accessed with http protocol in case of security type =  "+securityType+ " and non secure supply.";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": Received VAST Bidder Request:  "+vastBidderRequest);
					}

				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage(), e);
		}
		return result;
	}

	/** Checking if the rtb bidder has received the correct value of secure param in bid request. 
	 * 
	 * @param bidpost
	 * @param tag
	 * @return
	 */
	public String validateProtocolForRTBBidder(JSONObject bidpost, String tag)
	{
		String result = "";

		try{
			String secureParam = bidpost.getJSONArray("imp").getJSONObject(0).getString("secure");

			if(tag.startsWith("https://"))
			{
				if(secureParam.equalsIgnoreCase("1"))
				{
					result = result+ "PASSED: secure=1 was sent in bid post for  secure request. ";
				}
				else
				{
					result = result+ "FAIL: secure Value was supplied as: "+secureParam+" in data to be posted for  secure rtb request";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " Received Bid Post: "+bidpost);
				}
			}
			else
			{
				if(secureParam.equalsIgnoreCase("0"))
				{
					result = result+ "PASSED: secure=0 was sent in bid post for non secure request. ";
				}
				else
				{
					result = result+ "FAIL: secure Value was supplied as: "+secureParam+" in data to be posted for non secure rtb request";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " Received Bid Post: "+bidpost);
				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + e.getMessage() + "\n Received Bid Post: "+bidpost, e);
		}

		return result;
	}

	/** This method validates ATS features at DSP side -- RTB Request and VAST Requests 
	 * 
	 * @param bidderTestDataMapOfTaskID
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionServe
	 * @param tag
	 * @return
	 */
	public String validate_ats_dsp_request(TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, Session sessionBidder, String tag)
	{
		String result = "";
		try
		{
			/** get bidder type - rtb / vast */
			String connectionType = bidderTestDataMapOfTaskID.get("[Connection Type]");
			String securityType = bidderTestDataMapOfTaskID.get("[Security Type]");

			/** Verified if the desired bidder was picked up in this request, if not picked up there will be no bid request in filename 
			 * or there will be no filename, proceed only if bidder was picked up */
			if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataMapOfTaskID, con, sessionBidder))
			{
				if(connectionType.contains("rtb"))
				{
					/** check this after creating a json object */
					JSONObject bidpost = new BidderHandler().getRTBBidder_Request(bidderTestDataMapOfTaskID,con, sessionBidder);
					result =  result + new ValidationHandler().validateProtocolForRTBBidder(bidpost, tag);
				}
				else if(connectionType.contains("vast") || connectionType.contains("vpaid"))
				{
					String vastBidderRequest = new BidderHandler().getVastBidder_Request(bidderTestDataMapOfTaskID,con, sessionBidder);
					result = result + "\n" + new ValidationHandler().validateProtocolForVastBidder(tag, vastBidderRequest,securityType);
				}
			}
			else
			{
				if(tag.startsWith("https://") && (connectionType.contains("vast") || connectionType.contains("vpaid")) && securityType.equalsIgnoreCase("non_secure_only_url"))
				{
					result = result + "Pass: Bidder is not participating in auction as request is secure but bidder security type is non secure only" ;
				}
				else
				{
					result = "******** Fail -- TO BE INVESTIGATED ******** NOT SURE WHY BIDDER WASN'T PICKED UP ****** ";
				}
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ " Exception: "+e.getMessage(), e);
		}

		return result;
	}

	/** This method will verify the response of bidder with respect to ATS validation
	 * 
	 * @param chocolateResponse
	 * @param tag
	 * @return
	 */
	public String validate_ats_response(String chocolateResponse, String tag, TreeMap<String,String> bidderTestDataMapOfTaskID,Connection con, Session sessionBidder)
	{
		String result = "";
		HashMap<String, String> headers = new HashMap<>();

		/** check if desired bidder was picked up */
		if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataMapOfTaskID, con, sessionBidder))
		{
			/** Verified that correct response is send back to chocolate with ads by a bidder */
			if(new BidderHandler().checkIfBidderReturnedAd(bidderTestDataMapOfTaskID,con, sessionBidder))
			{
				/** Firstly validate the response of the serving url */
				if(tag.startsWith("http://"))
				{
					result = result+validateResponse(tag, "Ad", headers);
					/** Have to validate that our bidder won or not */
					if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataMapOfTaskID, con))
					{
						result = result+" Pass :Desired bidder won.";
					}
					else
					{
						result = result+" Fail :Desired bidder didn't win.";
					}
				}
				else if(tag.startsWith("https://"))
				{	
					/** get the bidder ad */
					String bidderAd = new BidderHandler().getBidderReturnedAd(bidderTestDataMapOfTaskID,con, sessionBidder);

					if(bidderAd.contains("http:")){
						if(!new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataMapOfTaskID, con))
						{
							result = result+"Passed: As expected, our bidder doesn't participated in aution.";
						}
						else
						{
							result = result+"Fail : Unexpectely, our bidder participated in aution.";
						}
					}
					else if(bidderAd.contains("https:")){
						//then ad should be served -- check for Ad
						result = result+validateResponse(tag, "Ad", headers);
						/** Have to validate that our bidder won or not */
						if(new BidderHandler().checkIfDesiredBidderWon(chocolateResponse, bidderTestDataMapOfTaskID, con))
						{
							result = result+" Pass: Desired bidder won.";
						}
						else
						{
							result = result+" Fail: Desired bidder didn't win.";
						}
					}
				}
			}
			else
			{
				result = "SKIP: Desired Bidder Didn't Respond With An Ad. ";
			}
		}

		return result;
	}

	/**
	 * This method will validate that request is Vpaid enabled or not.
	 * @param tag
	 * @return
	 */
	public boolean isVpaidEnabledSupply(String tag)
	{
		boolean isVpaid = false;
		TreeMap<String, String> urlParamMap = getURLParam(tag);
		String outputValue = urlParamMap.get("output");
		String apiFrameworkValue = urlParamMap.get("apiFramework");
		if(outputValue.equalsIgnoreCase("vast") && (apiFrameworkValue.equalsIgnoreCase("2")))
		{
			isVpaid = true;
		}
		else 
		{
			isVpaid = false;
		}
		return isVpaid;
	}

	/**
	 * This method with return the query parameters of url
	 * @param tag
	 * @return
	 */
	public static TreeMap<String, String> getURLParam(String tag)
	{
		TreeMap<String, String> urlPramMap = new TreeMap<>();
		List<NameValuePair> params = null;
		try {
			params = URLEncodedUtils.parse(new URI(tag), "UTF-8");
		} catch (URISyntaxException e) {
			logger.error("Getting exception when getting url parameter",e);
		}
		for (NameValuePair param : params) {
			urlPramMap.put(param.getName(), param.getValue());
		}
		return urlPramMap;
	}

	/**
	 * This method will validate that bidder is moat enabled or not
	 * @param bidderData
	 * @return
	 */
	public static boolean isMoatEnabledBidder(TreeMap<String, String> bidderTestData)
	{
		boolean isMoatEnabled = false;
		String moatEnabled = bidderTestData.get("[EnableMoatViewabilityMeasurement]");
		if(moatEnabled.equalsIgnoreCase("yes"))
		{
			isMoatEnabled = true;
		}
		else
		{
			isMoatEnabled = false;
		}
		return isMoatEnabled;
	}

	/**
	 * This method will validate that package is moat enabled or not
	 * @param packageTestData
	 * @return
	 */
	public static boolean isMoatEnabledPackage(TreeMap<String, String> packageTestData)
	{
		boolean isMoatEnabled = false;
		String moatEnabled = packageTestData.get("[Enable Moat]");
		if(moatEnabled.equalsIgnoreCase("yes"))
		{
			isMoatEnabled = true;
		}
		else
		{
			isMoatEnabled = false;
		}
		return isMoatEnabled;
	}

	/**
	 * This method will validate that bidder is vdopia bidder or not
	 * @param bidderData
	 * @return
	 */
	public static boolean isVdopiaBidder(TreeMap<String, String> bidderTestData)
	{
		boolean vdopiaBidder = false;
		String bidder = bidderTestData.get("[Vdopia Bidder]");
		if(bidder.equalsIgnoreCase("yes"))
		{
			vdopiaBidder = true;
		}
		else
		{
			vdopiaBidder = false;
		}
		return vdopiaBidder;
	}

	/**
	 * This method will validate that campaign is moat enabled or not
	 * @param bidderData
	 * @return
	 */
	public static boolean isMoatEnabledCampaign(TreeMap<String, String> campaignTestData)
	{
		boolean isMoatEnabled = false;
		String moatEnabled = campaignTestData.get("[Viewability Measurement with Moat]");
		if(moatEnabled.equalsIgnoreCase("select"))
		{
			isMoatEnabled = true;
		}
		else
		{
			isMoatEnabled = false;
		}
		return isMoatEnabled;
	}

	/** This method will perform validation after changing the instance -- vanilla, chocolate etc. and return the collective results.
	 * Prerequisite - > method will receive the serveURL after applying all rules. 
	 * 
	 * @param sessionServe
	 * @param connection
	 * @param serveURL
	 * @param result
	 * @param mapAllTasksFromDriverSheet
	 * @param taskID
	 * @param driverFile
	 * @param finalChannelTestData
	 * @param finalCampaignTestData
	 * @param finalBidderTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 * @return
	 */
	public String perform_InstanceWiseValidations(Session sessionServe, Session sessionBidder, Connection connection, String serveURL, 
			TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, String taskID, String driverFile,
			TreeMap<String, TreeMap<String, String>> finalChannelTestData, TreeMap<String, TreeMap<String, String>> finalCampaignTestData,
			TreeMap<String, TreeMap<String, String>> finalBidderTestData, TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData, Bigquery bigQueryConnection, String bqProjectId)
	{

		String result = "";
		try
		{
			/** store the received default url before processing it further */
			String defaultServeURL = serveURL;

			/** Get the json data of driver sheet corresponding to supplied task id **/
			TreeMap<String, String> jsonTestData = mapAllTasksFromDriverSheet.get(taskID);

			/** Get the data for "End_Point" column of supplied task id and split it by "," separator**/
			String desiredDataForAction = jsonTestData.get("End_Point");
			String[] instances = desiredDataForAction.split(",");

			for(int i=0; i<instances.length;i++)
			{
				/** re-assigning serveURL before starting loop */
				serveURL = defaultServeURL;

				String instance = "";
				if(instances[i].equalsIgnoreCase("[vanilla]"))
				{
					instance = MobileTestClass_Methods.propertyConfigFile.getString("[vanilla]");
					serveURL = serveURL.replace("[instance]", instance);
				}
				else if(instances[i].equalsIgnoreCase("[chocolate]"))
				{
					instance = MobileTestClass_Methods.propertyConfigFile.getString("[chocolate]");
					serveURL = serveURL.replace("[instance]", instance);
				}

				/** Perform test and do validations  */
				synchronized("synchronized")
				{					
					String validationMethod = jsonTestData.get("Validation");

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+": --ANKUR-- "+finalBidderTestData.get(taskID).get("[BidderID]"));

					/** Again check the health of the chocolate related servers before starting the validation */
					if(new ValidationHandler().chocolateSystemHealthCheck())
					{
						/** execute memcamp before validation for strawberry -- DON'T CHNAGE THIS AGAIN */
						Thread.sleep(IntegerLib.GetRandomNumber(3000, 1000));
						new SystemHealthCheck().memcampCron(sessionServe);

						/** perform validation using reflection */
						result =  result + " instance: "+ instance + "\n" + new LaunchValidationModules().launchValidationModule(validationMethod, serveURL, taskID, 
								driverFile, mapAllTasksFromDriverSheet, finalChannelTestData, finalCampaignTestData, finalBidderTestData, finalPackageTestData, 
								finalDealTestData, connection, sessionServe, sessionBidder, bigQueryConnection, bqProjectId);	
					}
					else
					{
						result = result + "\n SKIP: All servers may not be working properly so halting validation.";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" All servers may not be working properly so halting validation.");
					}
				}
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + ": "+e.getMessage(), e);
		}

		return result;
	}

	/** This is a crucial method, it applies rules to create url and then call validations based on defined instances.
	 * 
	 * @param tag
	 * @param taskID
	 * @param mapAllTasksFromDriverSheet
	 * @param finalCampaignTestData
	 * @param finalChannelTestData
	 * @param finalBidderTestData
	 * @param finalPackageTestData
	 * @param finalDealTestData
	 * @param connection
	 * @param sessionServe
	 * @param driverFile
	 * @param result
	 * @param serveURL
	 * @return
	 */
	public String performValidation_AfterApplyingURLRules(String taskID, TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet, TreeMap<String, 
			TreeMap<String, String>> finalCampaignTestData, TreeMap<String, TreeMap<String, String>> finalChannelTestData, 
			TreeMap<String, TreeMap<String, String>> finalBidderTestData, TreeMap<String, TreeMap<String, String>> finalPackageTestData, 
			TreeMap<String, TreeMap<String, String>> finalDealTestData, Connection connection, Session sessionServe, Session sessionBidder, 
			String driverFile, String serveURL, Bigquery bigQueryConnection, String bqProjectId)
	{
		String result = "";

		try
		{
			/** get url object and then check if this is a josn object or json array */
			Object objURLs = new RulesForURL().getURLsFromDriverSheet(taskID, mapAllTasksFromDriverSheet);

			if(objURLs instanceof JSONObject)
			{
				/** get the URL jsonObject from driver sheet -- usually it will be a json array, considering it as jsonobject for
				 * backward compatibility */
				JSONObject urls = (JSONObject) objURLs;
				serveURL = new RulesForURL().applyRuleToFormTag(serveURL, taskID, mapAllTasksFromDriverSheet, finalCampaignTestData, finalChannelTestData, 
						finalBidderTestData, finalPackageTestData, finalDealTestData, connection, urls);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": " + "Final Serve URL After Applying Rules: "+serveURL);

				/** use formatted serveURl and perform validation for all specified instances */
				result = result + "\n" + new ValidationHandler().perform_InstanceWiseValidations(sessionServe, sessionBidder, connection, serveURL, 
						mapAllTasksFromDriverSheet, taskID, driverFile, finalChannelTestData, finalCampaignTestData, finalBidderTestData, 
						finalPackageTestData, finalDealTestData, bigQueryConnection, bqProjectId);
			}
			else if(objURLs instanceof org.json.JSONArray)
			{
				JSONArray urls = (JSONArray) objURLs;

				/** in case of json array -- iterate all the url jsonObject and then perform validations */
				for(int i=0; i<urls.length(); i++)
				{
					JSONObject urlJsonObject = urls.getJSONObject(i);

					/** format serveURL before using it for further validation */
					serveURL = new RulesForURL().applyRuleToFormTag(serveURL, taskID, mapAllTasksFromDriverSheet, finalCampaignTestData, finalChannelTestData, 
							finalBidderTestData, finalPackageTestData, finalDealTestData, connection, urlJsonObject);

					/** use formatted serveURl and perform validation for all specified instances */
					result = result + "  Result Of URL: "+serveURL +"\n" + new ValidationHandler().perform_InstanceWiseValidations(sessionServe, 
							sessionBidder, connection, serveURL, mapAllTasksFromDriverSheet, taskID, driverFile, finalChannelTestData, 
							finalCampaignTestData, finalBidderTestData, finalPackageTestData, finalDealTestData, bigQueryConnection, bqProjectId);
				}
			}

		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+e.getMessage(), e);
		}

		return result;
	}

	/**
	 * This method will parse the chocolate xml response and return the moat details into map 
	 * @param chocolateResponse
	 * @return
	 */
	public static TreeMap<String, String> XmlParserForMoat(String chocolateResponse, String output)
	{
		TreeMap<String, String> moatMap = new TreeMap<>();
		try
		{
			/** writing response in a file - to parse further */
			String tmpLocation = System.getProperty("java.io.tmpdir").toString().concat(String.valueOf(new Date().getTime()));
			FileLib.WriteTextInFile(tmpLocation, chocolateResponse);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new File(tmpLocation));
			doc.getDocumentElement().normalize();

			System.out.println(doc.getFirstChild().getNodeName());

			if(output.equalsIgnoreCase("vast"))	
			{
				moatMap = parseMoatDetailsForVpaid(doc);
			}
			else if(output.equalsIgnoreCase("sdkvast"))
			{
				moatMap = new ValidationHandler().parseMoatDetailsForVast(doc);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ":  " + e.getMessage(), e);
		}
		return moatMap;
	}

	/**
	 * This method will return the map of actual moat details for VPAID(output = vast and apiframwork = 2)
	 * @param doc
	 * @return
	 */
	public static TreeMap<String, String> parseMoatDetailsForVpaid(Document doc)
	{
		TreeMap<String, String> moatMap = new TreeMap<>();
		String moatParametersJson = null;
		String result = null;
		moatParametersJson = doc.getElementsByTagName("AdParameters").item(0).getTextContent();
		JSONObject moatJson;
		JSONObject moatJsonObject = null;
		try{
			moatJson = new JSONObject(moatParametersJson);
			moatJsonObject = moatJson.getJSONObject("Moat");
			moatMap.put("moatStatus", "yes");
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Moat details are not available in response");
			moatMap.put("result", "Moat details are not available in response");
			moatMap.put("moatStatus", "no");
		}

		if(moatJsonObject != null)
		{
			HashMap<String, String> moatMapping = new ValidationHandler().moatParamMapping();
			for(String map : moatMapping.keySet())
			{
				String elementName = moatMapping.get(map);
				try{
					String elementValue = (String) moatJsonObject.get(elementName);
					moatMap.put(map, elementValue);
				}catch(NullPointerException | JSONException n){
					result = result + "Node : " + elementName + " is not present in response";
					moatMap.put("result", result);
				}
			}
		}
		return moatMap;
	}

	/**
	 * This method will return the map of actual moat details for vast(output = sdkvast)
	 * @param doc
	 * @return
	 */
	public TreeMap<String, String> parseMoatDetailsForVast(Document doc)
	{
		TreeMap<String, String> moatMap = new TreeMap<>();
		Node moatParameters = null;
		moatParameters = doc.getElementsByTagName("Moat").item(0);

		if(moatParameters != null)
		{
			moatMap.put("moatStatus", "yes");
		}
		else
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Moat details are not available in response");
			moatMap.put("result", "Moat details are not available in response");
			moatMap.put("moatStatus", "no");
		}
		if(moatParameters != null)
		{
			HashMap<String, String> moatMapping = new ValidationHandler().moatParamMapping();
			for(String key : moatMapping.keySet())
			{
				String elementName = moatMapping.get(key);
				String elementValue = getNodeText(moatParameters, elementName);
				if(!elementValue.contains("is not present"))
				{
					moatMap.put(key, elementValue);
				}
				else
				{
					moatMap.put("result", elementValue);
				}
			}
		}
		return moatMap;
	}


	/** This is a generic method to return the node text of supplied node 
	 * 
	 * @param node
	 * @param nodeName
	 * @return
	 */
	public String getNodeText(Node node, String nodeName)
	{
		String nodeText = null;
		NodeList nodelIst = node.getChildNodes();
		for(int i=0; i<nodelIst.getLength(); i++)
		{
			Node n = nodelIst.item(i);
			if(n.getNodeName().equalsIgnoreCase(nodeName))
			{
				nodeText = n.getTextContent();
			}
		}
		if(nodeText == null)
		{
			nodeText = "Node : "+nodeName + "is not present in response";
		}

		return nodeText;
	}


	/** Check if moat details are received in chocolate final response. 
	 * 
	 * @param chocolateResponse
	 * @param output
	 * @return
	 */
	public boolean ifMOATReceivedChocolateResponse(String chocolateResponse, String output)
	{
		NodeList nList = null;

		if(output.equalsIgnoreCase("sdkvast") || output.equalsIgnoreCase("vast") || output.equalsIgnoreCase("xhtml") || output.equalsIgnoreCase("javascript"))
		{
			try{
				File inputFile = new File(chocolateResponse);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(inputFile);
				doc.getDocumentElement().normalize();
				nList = doc.getElementsByTagName("AdParameters");
				if(nList == null)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
			catch(Exception e){
				return false;
			}
		}

		else{
			Pattern p= Pattern.compile("certifications\":");
			String [] s=p.split(chocolateResponse);
			String s2 = s[1];
			Pattern p2= Pattern.compile("\\,\"dw\"");
			String [] s3=p2.split(s2);
			String moatParametersJson = s3[0];

			JSONObject moatJson;
			JSONObject moatJsonObject = null;
			try {
				moatJson = new JSONObject(moatParametersJson);
				moatJsonObject = moatJson.getJSONObject("moat");
				if(moatJsonObject == null)
				{
					return false;
				}
				else
				{
					return true;
				}
			} catch (JSONException e) {
				return false;
			}
		}
	}

	/**
	 * This method will parse the chocolate json response and return the moat details into map 
	 * @param chocolateResponse
	 * @return
	 */
	public static TreeMap<String, String> jsonParserForMoat(String chocolateResponse)
	{
		TreeMap<String, String> moatMap = new TreeMap<>();
		try
		{
			Pattern p= Pattern.compile("certifications\":\"");
			String [] s=p.split(chocolateResponse);
			String s2 = s[1];
			Pattern p2= Pattern.compile("}}\"");
			String [] s3=p2.split(s2);
			String moatParametersJson = s3[0];
			moatParametersJson = moatParametersJson + "}}";
			moatParametersJson = moatParametersJson.replace("\\", "");
			//System.out.println(moatParametersJson);
			JSONObject moatJson;
			JSONObject moatJsonObject = null;
			try{
				moatJson = new JSONObject(moatParametersJson);
				moatJsonObject = moatJson.getJSONObject("moat");
				moatMap.put("moatStatus", "yes");
			}
			catch(Exception e)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Moat details are not available in response");
				moatMap.put("result", "Moat details are not available in response");
				moatMap.put("moatStatus", "no");
			}

			if(moatJsonObject != null)
			{
				try
				{
					@SuppressWarnings("unchecked")
					Iterator<String> jsonIterator = moatJsonObject.keys();
					while(jsonIterator.hasNext())
					{
						String key = jsonIterator.next();
						moatMap.put(key, moatJsonObject.getString(key));
					}
				}
				catch(Exception e)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Any moat node is not available in response", e);
					moatMap.put("result", "Some moat node is not available in response");
				}
			}
		} catch (Exception e) {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ":  " + e.getMessage(), e);
		}
		return moatMap;		
	}

	/**
	 * This method will return the expected moat partner code
	 * @param bidderTestData
	 * @param campaignTestData
	 * @param output
	 * @param caller
	 * @param adFormat
	 * @return
	 */
	public static String getExpectedMoatPartenerCode(TreeMap<String, String> bidderTestData, TreeMap<String, String> campaignTestData, TreeMap<String, String> packageTestData,String output,String caller, String adFormat)
	{
		String partnerCode = "";
		if(output.equalsIgnoreCase("sdkvast") && caller.equalsIgnoreCase("mpsdk") && adFormat.equalsIgnoreCase("preroll"))
		{
			if(new ValidationHandler().ifMoatEnabledAtStrawberry(campaignTestData, bidderTestData))
			{
				partnerCode =  "vdopianativevideo472658393564";
			}
			else if(new ValidationHandler().ifMoatEnabledAtChocolate(bidderTestData, packageTestData))
			{
				partnerCode =  "vdopianativevideortb390744284218";
			}
		}
		else
		{
			if(new ValidationHandler().ifMoatEnabledAtStrawberry(campaignTestData, bidderTestData))
			{
				partnerCode =  "vdopia209fjlk23r0wdkf23";
			}
			else if(new ValidationHandler().ifMoatEnabledAtChocolate(bidderTestData, packageTestData))
			{
				partnerCode =  "vdopiartb9482390456";
			}
		}
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"partnerCode: "+partnerCode);
		return partnerCode;
	}

	/**
	 * This method will return the status that expected bidder is picked or not
	 * @param tag
	 * @param connectionType
	 * @param bidderTestData
	 * @param taskID
	 * @param con
	 * @param sessionBidder
	 * @return
	 */
	public TreeMap<Object, Object> isBidderPicked(String tag,String connectionType,TreeMap<String,String> bidderTestDataMapOfTaskID, 
			String taskID, Connection con, Session sessionBidder )
	{
		TreeMap<Object, Object> finalResult = new TreeMap<>();
		String result = "";
		boolean status = false;
		String viewabilityMeasurable = bidderTestDataMapOfTaskID.get("[Viewability Measurable]");
		String enableMoatViewabilityMeasurement = bidderTestDataMapOfTaskID.get("[EnableMoatViewabilityMeasurement]");
		if(isVpaidEnabledSupply(tag))
		{
			if(connectionType.contains("vpaid") || (viewabilityMeasurable.equalsIgnoreCase("yes") && enableMoatViewabilityMeasurement.equalsIgnoreCase("yes")))
			{
				if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataMapOfTaskID, con, sessionBidder))
				{

					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"PASSED : Bidder is picked up as request is vpaid enabled and either bidder is vpaid or moat enabled");
					result = result + "PASSED : Bidder is picked up as request is vpaid enabled and either bidder is vpaid or moat enabled";
					status = true;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"FAILED : Bidder is not picked up but request is vpaid enabled and either bidder is vpaid or moat enabled");
					result = result + "FAILED : Bidder is not picked up but request is vpaid enabled and either bidder is vpaid or moat enabled";
				}
			}
			else
			{
				if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataMapOfTaskID, con, sessionBidder))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"FAILED : Bidder should not picked up as request is vpaid enabled but nither bidder is vpaid nor moat enabled");
					result = result + "FAILED : Bidder should not picked up as request is vpaid enabled but nither bidder is vpaid nor moat enabled";
					status = true;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"PASSED : Bidder is not picked up as request is vpaid enabled but nither bidder is vpaid nor moat enabled");
					result = result + "PASSED : Bidder is not picked up as request is vpaid enabled but nither bidder is vpaid nor moat enabled";
				}
			}
		}
		else
		{
			if(new BidderHandler().checkIfBidderWasPickedUp(bidderTestDataMapOfTaskID, con, sessionBidder))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"PASSED : Bidder is picked up");
				result = result + "PASSED : Bidder is picked up";
				status = true;
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"FAILED : Bidder is not picked up");
				result = result + "FAILED : Bidder is not picked up";
			}
		}
		finalResult.put("status", status);
		finalResult.put("result", result);

		return finalResult;
	}

	/**
	 * This method will verify the moat status on chocolate side (Bidder or package) -- to be used later on while
	 * checking MOAT status codes - whether MOAT code should be of chocolate or strawberry 
	 * @param bidderTestData
	 * @param packageTestData
	 * @return
	 */
	public boolean ifMoatEnabledAtChocolate(TreeMap<String, String> bidderTestData, TreeMap<String, String> packageTestData)
	{
		boolean status = false;
		if(!isMoatEnabledBidder(bidderTestData))
		{
			if(!isMoatEnabledPackage(packageTestData))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" Response should be without moat details");
			}
			else
			{
				status = true;
			}
		}
		else
		{
			status = true;
		}
		return status;
	}

	/**
	 * This method will verify if moat is enabled at strawberry campaign or not
	 * @param campaignTestData
	 * @param bidderTestData
	 * @return
	 */
	public boolean ifMoatEnabledAtStrawberry(TreeMap<String, String> campaignTestData, TreeMap<String, String> bidderTestData)
	{
		boolean status = false;
		if(isVdopiaBidder(bidderTestData))
		{
			if(!isMoatEnabledCampaign(campaignTestData))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"Response should be without moat details");
			}
			else
			{
				status = true;	
			}
		}
		return status;
	}

	/** Creating map containing the mapping of MOAT param name found in chocolate response and bidder response 
	supported params = {"MoatOnOff", "MoatPartnerCode", "Advertiser", "Campaign", "LineItem", "Creative", "SiteApp", "Placement"};
	 */
	public HashMap<String, String> moatParamMapping()
	{
		HashMap<String, String> moatMapping = new HashMap<>();
		moatMapping.put("moat_on_off", "MoatOnOff");
		moatMapping.put("site", "SiteApp");
		moatMapping.put("partner_id", "MoatPartnerCode");
		moatMapping.put("adv_nm", "Advertiser");
		moatMapping.put("cid", "Campaign");
		moatMapping.put("line_item", "LineItem");
		moatMapping.put("crid", "Creative");
		moatMapping.put("placement", "Placement");

		return moatMapping;
	}

	/**
	 * This method is for getting the ad id form the response of vast bidder
	 * @param response
	 * @return
	 */
	public static String getAdIDfromBidderResponse(String response)
	{
		String expectedAdId = null;
		String regularExpression = "(?<=<Ad id=\")[0-9]+(?=\">)";
		Pattern pattern = Pattern.compile(regularExpression);
		Matcher match = pattern.matcher(response);

		if(match.find())
		{
			expectedAdId = match.group();
		}

		return expectedAdId;
	}

	/** get expected moat parameters
	 * 
	 * @param connection
	 * @param bidderTestData
	 * @param campaignTestData
	 * @param packageTestData
	 * @param output
	 * @param caller
	 * @param adFormat
	 * @return
	 */
	public static TreeMap<String, String> getExpectedmoatDetails(Connection connection, TreeMap<String, String> bidderTestDataMapOfTaskID, TreeMap<String,
			String> campaignTestData,TreeMap<String,String>packageTestData, String output, String caller, String adFormat, Session sessionBidder,String taskID)
	{
		TreeMap<String, String> expectedMoatInformation =  new TreeMap<>(); 
		String bidderType = bidderTestDataMapOfTaskID.get("[Connection Type]");
		String ChannelName = bidderTestDataMapOfTaskID.get("[ChannelName]");
		String cid = campaignTestData.get("[CampaignID]");
		String adid = null;
		String moatPartnerCode = getExpectedMoatPartenerCode(bidderTestDataMapOfTaskID, campaignTestData, packageTestData, output, caller, adFormat);
		String bidderResponse = new BidderHandler().getBidderResponse(bidderTestDataMapOfTaskID, connection, sessionBidder);
		bidderResponse = bidderResponse.replace("\\", "");
		adid = getAdIDfromBidderResponse(bidderResponse);
		expectedMoatInformation = DBLib.getMoatInformation(connection, bidderType, ChannelName, adid, moatPartnerCode,cid);
		return expectedMoatInformation;
	}

	/**
	 * This method is for getting the expected moat details as per moat enabled/disabled condition.
	 * @param hashmap
	 * @return
	 */
	public static TreeMap<String, String> applyRules(TreeMap<String, String> TreeMap, String moatPartnerCode)
	{

		if(TreeMap.containsKey("customdetails"))
		{
			String moatEnabled = "0";

			try{
				moatEnabled = new JSONObject(TreeMap.get("customdetails")).getString("moatEnabled");
			}catch(JSONException j){}

			/** change values of received map, in case campaign is not moat enabled */
			if(moatEnabled.equalsIgnoreCase("0"))
			{
				TreeMap.put("partner_id", moatPartnerCode);
				TreeMap.put("line_item", "");
				TreeMap.put("adv_nm", "");
				TreeMap.put("placement", "");

			}

			/** removing customedetails key, as its not being used */
			TreeMap.remove("customdetails");

		}

		return TreeMap;
	}

	/**
	 * This method will return the actual moat details into map
	 * @param chocolateResponse
	 * @param output
	 * @return
	 */
	public TreeMap<String, String> getActaulMoatDetailsMap(String chocolateResponse, String output)
	{
		TreeMap<String, String> moatDetailsmap = new TreeMap<>();
		if(output.equalsIgnoreCase("sdkvast") || output.equalsIgnoreCase("vast"))
		{
			moatDetailsmap = XmlParserForMoat(chocolateResponse, output);
		}
		else if(output.equalsIgnoreCase("js") || output.equalsIgnoreCase("html") || output.equalsIgnoreCase("xhtml") || output.equalsIgnoreCase("javascript"))
		{
			moatDetailsmap = jsonParserForMoat(chocolateResponse);
		}
		return moatDetailsmap;
	}

	/**
	 * This method will validate the moat details
	 * @param chocolateResponse
	 * @param connection
	 * @param bidderTestData
	 * @param campaignTestData
	 * @param output
	 * @param caller
	 * @param adFormat
	 * @return
	 */
	public TreeMap<String, Object> validateMoatDetails(String chocolateResponse,Connection connection,TreeMap<String, String> bidderTestData,TreeMap<String,
			String> campaignTestData,TreeMap<String,String> packageTestData, String output, String caller, String adFormat, Session sessionBidder,String taskID)
	{
		TreeMap<String, Object> completeResult = new TreeMap<>();
		boolean status = true;
		String result = "";

		TreeMap<String, String> expectedMoatDetailsMap =  getExpectedmoatDetails(connection, bidderTestData, campaignTestData,packageTestData, output, caller, adFormat,sessionBidder,taskID);
		TreeMap<String, String> actualMoatDetailMap = getActaulMoatDetailsMap(chocolateResponse, output);
		/** in case expected map is empty then there shouldn't be any moat on any side. */
		if(expectedMoatDetailsMap.isEmpty())
		{
			result = result + " There is no expected MOAT details, so moat details should not be display in response";
			if(actualMoatDetailMap.get("moatStatus").equalsIgnoreCase("no"))
			{
				result = result + "PASS : Moat is not available is response as expected.";
			}
			else
			{
				result = result + "FAIL : Moat should not available is response as expected.";
				status = false;
			}	
		}
		else if(actualMoatDetailMap.get("moatStatus").equalsIgnoreCase("yes"))
		{
			for(Entry<String, String> map : expectedMoatDetailsMap.entrySet())
			{
				String expectedKey = map.getKey();
				String expectedValue = map.getValue();

				try{

					String actualMoatValue = actualMoatDetailMap.get(expectedKey);
					if(!actualMoatValue.trim().equalsIgnoreCase(expectedValue))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"  FAIL:" + expectedKey + " has expected value = " + expectedValue + " whereas actual = "+actualMoatValue);
						result = result + "  FAIL: " + expectedKey + " has expected value = " + expectedValue + " whereas actual = "+actualMoatValue+ "\n";
						status = false;
					}
					else
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" PASS:" + expectedKey + " has correct expected value. ");  
						result = result + "  PASS: " + expectedKey + " has correct value: "+actualMoatValue+ "\n";
					}
				}
				catch(Exception e)
				{
					result = result + actualMoatDetailMap.get("result") + " FAIL : Expected Key : " + expectedKey + " is not available in response"+ "\n";
					status = false;
				}
			}
		}
		else
		{
			result = result + "FAIL : "+actualMoatDetailMap.get("result");
			status = false;
		}

		completeResult.put("result", result);
		completeResult.put("status", status);

		return completeResult;
	}

	/** This method will parse the supplied xml.
	 * 
	 * @param xmlString
	 * @param nodeName
	 * @param elementName
	 * @return
	 */
	public static String parseXMLString(String xmlString, String nodeName, String elementName) 
	{
		String elementValue = null;
		try 
		{			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new ByteArrayInputStream(xmlString.getBytes()));

			doc.getDocumentElement().normalize();

			//NodeList nList = doc.getElementsByTagName("Moat");
			NodeList nList = doc.getElementsByTagName(nodeName);

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					try{
						elementValue = eElement.getElementsByTagName(elementName).item(0).getTextContent();
					}catch(NullPointerException n){}
				}
			}
		} catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received XMl: "+xmlString);
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while parsing supplied xml.", e);
		}

		return elementValue;
	}

	/** This method will save the chocolate response in a file.  
	 * 
	 * @param taskID
	 * @param tag
	 * @return
	 */
	public String saveChocolateResponse(String taskID, String tag, HashMap<Object, Object> responseMap)
	{
		try
		{
			String location = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/"+taskID+"/"+taskID);

			/** write the whole response map in file --> which is response, status code, response headers etc ..*/
			/** first create string out of map and then write it */

			String finalContent = "";
			for(Entry<Object, Object> en : responseMap.entrySet())
			{
				finalContent = finalContent + en.getKey() + " --- " + en.getValue() + "\n";
			}
			/** append all the response */
			FileLib.WriteFile(tag + "\n\n\n" + finalContent + "\n\n\n", TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/"+taskID), taskID, true);	
			//FileLib.WriteTextInFile(location, tag + "\n\n\n" + finalContent);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " saving chocolate response at: "+location);
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+e.getMessage(), e);
		}
		return (String) responseMap.get("response");
	}

	/**
	 * This method will validate the bidder categories saved in database
	 * @param testDataOfTaskID
	 * @return
	 */
	public String validateBidderCategoryExpression(TreeMap<String,String> bidderTestDataOfTaskID, Connection con)
	{
		String result = "";
		String categoryId = bidderTestDataOfTaskID.get("[CategoryId]");
		logger.info("Category id: "+ categoryId);
		categoryId = sortedCategories(categoryId);
		String categoryByDB = bidderCategoryFromDB(bidderTestDataOfTaskID, con);
		if(categoryId.equalsIgnoreCase(categoryByDB))
		{
			result = result + "Pass : Supplied Bidder Category: "+categoryId+" and Saved Bidder Category: "+categoryByDB+" are matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Pass : Supplied Bidder Category: "+categoryId+" and Saved Bidder Category: "+categoryByDB+" are matching");
		}
		else
		{
			result = result + "Fail : Supplied Bidder Category: "+categoryId+" and Saved Bidder Category: "+categoryByDB+" are not matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Fail : Supplied Bidder Category: "+categoryId+" and Saved Bidder Category: "+categoryByDB+" are not matching");
		}
		return result;
	}

	/**
	 * This method will validate the package categories saved in database
	 * @param testDataOfTaskID
	 * @return
	 */
	public String validatePackageCategoryExpression(TreeMap<String,String> packageTestDataOfTaskID, Connection con)
	{
		String result = "";
		String categoryId = packageTestDataOfTaskID.get("[CategoryId]");
		logger.info("Category id: "+ categoryId);
		categoryId = sortedCategories(categoryId);
		String categoryByDB = packageCategoryFromDB(packageTestDataOfTaskID, con);
		if(categoryId.equalsIgnoreCase(categoryByDB))
		{
			result = result + "Pass : Supplied Package Category: "+categoryId+" and Saved Package Category: "+categoryByDB+" are matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Pass : Supplied Package Category: "+categoryId+" and Saved Package Category: "+categoryByDB+" are matching");
		}
		else
		{
			result = result + "Fail : Supplied Package Category: "+categoryId+" and Saved Package Category: "+categoryByDB+" are not matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Fail : Supplied Package Category: "+categoryId+" and Saved Package Category: "+categoryByDB+" are not matching");
		}
		return result;
	}

	/**
	 * This method will validate the campaign categories saved in database
	 * @param testDataOfTaskID
	 * @return
	 */
	public String validateCampaignCategoryExpression(TreeMap<String,String> campaignTestDataOfTaskID, Connection con)
	{
		String result = "";
		String categoryId = campaignTestDataOfTaskID.get("[CategoryId]");
		logger.info("Category id: "+ categoryId);
		categoryId = sortedCategories(categoryId);
		String categoryByDB = campaignCategoryFromDB(campaignTestDataOfTaskID, con);
		if(categoryId.equalsIgnoreCase(categoryByDB))
		{
			result = result + "Pass : Supplied Campaign Category: "+categoryId+" and Saved Campaign Category: "+categoryByDB+" are matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Pass : Supplied Campaign Category: "+categoryId+" and Saved Campaign Category: "+categoryByDB+" are matching");
		}
		else
		{
			result = result + "Fail : Supplied Campaign Category: "+categoryId+" and Saved Campaign Category: "+categoryByDB+" are not matching";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": Fail : Supplied Campaign Category: "+categoryId+" and Saved Campaign Category: "+categoryByDB+" are not matching");
		}
		return result;
	}

	/**
	 * This method will short the LR and BK categories
	 * @param category
	 * @return
	 */
	public String sortedCategories(String category)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + "Suplied category is: "+category);
		List<String> sortedORCategory = new LinkedList<>();
		String sortedCategory = null;
		try
		{
			List<String> categoryAndList = Arrays.asList(category.split("&"));
			for(int i=0;i<categoryAndList.size();i++)
			{
				List<String> categoryOrList = Arrays.asList(categoryAndList.get(i).split("\\|"));
				List<String> categoryOrListBK = new LinkedList<>();
				List<String> categoryOrListLR = new LinkedList<>();
				for(int j=0;j<categoryOrList.size();j++)
				{
					if(categoryOrList.get(j).contains("bk"))
					{
						categoryOrListBK.add(categoryOrList.get(j));
					}
					else if(categoryOrList.get(j).contains("lr"))
					{
						categoryOrListLR.add(categoryOrList.get(j));
					}

				}
				categoryOrListBK.sort(Comparator.comparing(String::length).thenComparing(String::compareTo));	
				String categoryOrBKList = String.join("|", categoryOrListBK);

				categoryOrListLR.sort(Comparator.comparing(String::length).thenComparing(String::compareTo));	
				String categoryOrLRList = String.join("|", categoryOrListLR);

				if(categoryOrBKList.isEmpty() && !categoryOrLRList.isEmpty())
				{
					sortedORCategory.add(categoryOrLRList);
				}
				else if(!categoryOrBKList.isEmpty() && categoryOrLRList.isEmpty())
				{
					sortedORCategory.add(categoryOrBKList);
				}
				else if(!categoryOrBKList.isEmpty() && !categoryOrLRList.isEmpty())
				{
					sortedORCategory.add(categoryOrBKList + "|" + categoryOrLRList);
				}

				categoryOrListBK.clear();
				categoryOrListLR.clear();
			}
			sortedCategory = String.join("&", sortedORCategory);
			sortedCategory = sortedCategory.toUpperCase();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + "Sorted category is: "+sortedCategory);
			sortedCategory = "("+sortedCategory+")VDO_&-1VDO_&-1";
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " :Exception occured when sorting category ",e);
		}
		return sortedCategory;
	}

	/**
	 * This method will get the bidder category of provided bidder from DB
	 * @param bidderTestDataOfTaskID
	 * @param con
	 * @return
	 */
	public String bidderCategoryFromDB(TreeMap<String,String> bidderTestDataOfTaskID, Connection con)
	{
		String category = null;
		String bidderID = bidderTestDataOfTaskID.get("[BidderID]");
		category = new DBLib().getBidderCategoryExpression(bidderID, con);
		return category;
	}

	/**
	 * This method will get the package category of provided package from DB
	 * @param bidderTestDataOfTaskID
	 * @param con
	 * @return
	 */
	public String packageCategoryFromDB(TreeMap<String,String> packageTestDataOfTaskID, Connection con)
	{
		String category = null;
		String packageID = packageTestDataOfTaskID.get("[PackageID]");
		category = new DBLib().getPackageCategoryExpression(packageID, con);
		return category;
	}

	/**
	 * This method will get the campaign category of provided campaign from DB
	 * @param bidderTestDataOfTaskID
	 * @param con
	 * @return
	 */
	public String campaignCategoryFromDB(TreeMap<String,String> campaignTestDataOfTaskID, Connection con)
	{
		String category = null;
		String campaignID = campaignTestDataOfTaskID.get("[CampaignID]");
		category = new DBLib().getCampaignCategoryExpression(campaignID, con);
		return category;
	}

	/**
	 * This method will validate the expression of package/bidder/campaign category 
	 * @param bidderTestDataOfTaskID
	 * @param packageTestDataOfTaskID
	 * @param campaignTestDataOfTaskID
	 * @param con
	 * @return
	 */
	public String validateCategoryExpression(TreeMap<String,String> bidderTestDataOfTaskID, TreeMap<String,String> packageTestDataOfTaskID, 
			TreeMap<String,String> campaignTestDataOfTaskID, Connection con,String packageCategoryId,String bidderCategoryId,String campaignCategoryId)
	{
		String result = "";
		if(!packageCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			result = result + validatePackageCategoryExpression(packageTestDataOfTaskID, con);
		}
		else if(!bidderCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			result = result + validateBidderCategoryExpression(bidderTestDataOfTaskID, con);
		}
		else if(!campaignCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			result = result + validateCampaignCategoryExpression(campaignTestDataOfTaskID, con);
		}
		return result;
	}

	/**
	 * This method is to validate the category in BQ
	 * @param bidderTestDataOfTaskID
	 * @param dealTestDataOfTaskID
	 * @param con
	 * @param sessionBidder
	 * @param packageCategoryId
	 * @param bidderCategoryId
	 * @param campaignCategoryId
	 * @param bigQueryConnection
	 * @param bqProjectId
	 * @return
	 */
	public String validateCategoryInBQ(TreeMap<String,String>bidderTestDataOfTaskID, TreeMap<String,String>dealTestDataOfTaskID,Connection con, Session 
			sessionBidder,String packageCategoryId,String bidderCategoryId,String campaignCategoryId, Bigquery bigQueryConnection, String bqProjectId)
	{	
		String result = ""; 
		if(!packageCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			/** Check if bidder requested with deal */
			if(new BidderHandler().checkIfBidderWasPostedCorrectDealID(bidderTestDataOfTaskID, dealTestDataOfTaskID,con, sessionBidder))
			{
				/** Check if bidder response with deal */
				if(new BidderHandler().checkIfBidderResponseWithCorrectDealID(bidderTestDataOfTaskID, dealTestDataOfTaskID, con, sessionBidder))
				{
					compareCategoryDeatils(packageCategoryId, con, bigQueryConnection, bqProjectId);
				}
				else
				{
					result = result + "SKIP : Bidder responded with wrong deal id";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Bidder responded with wrong deal id");
				}
			}
			else
			{
				result = result + "SKIP : Bidder requested with wrong deal id";
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Bidder requested with wrong deal id");
			}
		}
		else if(!bidderCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			compareCategoryDeatils(bidderCategoryId, con, bigQueryConnection, bqProjectId);
		}
		else if(!campaignCategoryId.equalsIgnoreCase("skipTestStep"))
		{
			compareCategoryDeatils(campaignCategoryId, con, bigQueryConnection, bqProjectId);
		}
		else
		{
			result = result + "SKIP : Category id was not provided in test data";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+"SKIP : Category id was not provided in test data");
		}
		return result;
	}

	/**
	 * This method will return the actual price of category expression from BQ
	 * @param AutionID
	 * @param partnerName
	 * @return
	 */
	public String getActualExpressionPrice(int partnerID, Bigquery bigQueryConnection, String projectID)
	{
		String price = "0.0";
		String query = BQQueriesLib.queryToGetWinningCategoryPrice(partnerID);
		GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection,projectID,query);
		String [] result = new BQHandler().get1DArrayFromBQResults(queryResult);
		for(int i = 0; i<result.length;i++)
		{
			price = result[0];
		}
		return price;
	}

	/**
	 * This method will return the expected price of the category expression from mysql
	 * @param categoryExpression
	 * @param con
	 * @return
	 */
	public String getExpectedExpressionPrice(String categoryExpression, Connection con)
	{
		double categoryPrice = 0.0;
		String category = "";
		String finalCategory = "";
		double finalCategoryPrice = 0.0;
		List<String> categoryAndList = Arrays.asList(categoryExpression.split("&"));
		for(int i=0;i<categoryAndList.size();i++)
		{
			List<String> categoryOrList = Arrays.asList(categoryAndList.get(i).split("\\|"));
			for(int j=0;j<categoryOrList.size();j++)
			{	
				double ORprice = new DBLib().getCategoryPrice(categoryOrList.get(j), con);
				if(j==0)
				{
					categoryPrice = ORprice;
					category = categoryOrList.get(j);
				}	
				if(ORprice<categoryPrice)
				{
					categoryPrice = ORprice;
					category = categoryOrList.get(j);
				}
			}
			if(i==0)
			{
				finalCategoryPrice = categoryPrice;
				finalCategory = category;
			}
			if(finalCategoryPrice<categoryPrice)
			{
				finalCategoryPrice = categoryPrice;
				finalCategory = category;
			}

		}
		return finalCategory+":"+finalCategoryPrice;
	}

	/** This method returns true if 200 status code is received else false. 
	 * 
	 * @param url
	 * @return
	 */
	public boolean if200OK(String url)
	{
		/** sent request to version.txt for vanilla and version for chocolate */
		HashMap<Object, Object> responseMap = httpClientWrap.sendGetRequest_GetStatusLine(url);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" : URL "+ url +" has status code: " + responseMap.get("statuscode"));

		/** proceed only if status code received is 200 */
		if((int)responseMap.get("statuscode") == 200){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * This method will check the health of all the sever involved in automation before start the execution
	 * bidder, portal, config server, chocolate, vanilla
	 * @param sessionaerospike
	 * @return
	 */
	public boolean systemhealthCheck()
	{
		boolean configServerHealthCheck = configServerHealthCheck();

		/** if config server is not up then exit */
		if(configServerHealthCheck)
		{
			String vanilla = "http://"+MobileTestClass_Methods.propertyConfigFile.getProperty("[vanilla]").toString().trim().concat("/version.txt");
			String portal = "http://"+MobileTestClass_Methods.propertyConfigFile.getProperty("[portal]").toString().trim().concat("/version.txt");

			/** restart aerospike if required */
			String aerospikeStatus = ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(LaunchE2ETest.sessionaerospike, "sh ankur/aerospike_status_script.sh");

			boolean bidderHealthCheck = bidderHealthCheck(); 
			boolean chocolateHealthCheck = chocolateServerHealthCheck();

			/** check if 200 okay is received for all end points if not, then Assert.Fail and exit the test */
			if(new ValidationHandler().if200OK(vanilla) 
					&& new ValidationHandler().if200OK(portal) 
					&& chocolateHealthCheck 
					&& bidderHealthCheck 
					&& aerospikeStatus.contains("is running"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			logger.info("Config server is not up yet, all attempts failed, no point of attempting chocolate ... halting execution. ");
			return configServerHealthCheck;
		}
	}


	/** This method is to be used by all thread before proceeding the chocolate validation, its a synchronized method so 
	 * thread violation will not be there. Checking -- bidder, config server and chocolate server
	 * 
	 * @return
	 */
	public synchronized boolean chocolateSystemHealthCheck()
	{
		/** Pankaj --> I am not sure why I am putting this block here though the metow itself is synchronized */
		synchronized("block")
		{
			String vanilla = "http://"+MobileTestClass_Methods.propertyConfigFile.getProperty("[vanilla]").toString().trim().concat("/version.txt");
			boolean bidderHealthCheck = bidderHealthCheck(); 

			boolean chocolateServerHealthCheck = chocolateServerHealthCheck();
			boolean configServerHealthCheck = configServerHealthCheck();

			/** check if 200 okay is received for all end points if not, then Assert.Fail and exit the test */
			if(new ValidationHandler().if200OK(vanilla) 
					&& chocolateServerHealthCheck
					&& configServerHealthCheck
					&& bidderHealthCheck)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" WOW ... All are servers up, starting validation.");
				return true;
			}
			else
			{
				return false;
			}
		}
	}


	/** Handle chocolate service only
	 * 
	 * @return
	 */
	public boolean chocolateServerHealthCheck()
	{
		/** if chocolate is not running then restart this */
		String chocolate = "http://"+MobileTestClass_Methods.propertyConfigFile.getProperty("[chocolate]").toString().trim().concat("/healthcheckuphudson");

		/** run this code, if chocolate service needs to be healthy -- if yes the service will be restarted if found dead */
		if(MobileTestClass_Methods.propertyConfigFile.getProperty("maintainChocolateServiceHealthy").toString()
				.equalsIgnoreCase("yes"))
		{
			if(!new ValidationHandler().if200OK(chocolate))
			{
				ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(LaunchE2ETest.sessionChocolateServer, "sudo service hudson start");

				int i=0;
				while( i < 20)
				{
					if(!new ValidationHandler().if200OK(chocolate))
					{
						try {Thread.sleep(3000);} catch (InterruptedException e) {}
						logger.info("chocolate was dead, restarted, now waiting for warm up, attempt: "+i);
						i++;
						continue;
					}
					else{
						logger.info("chocolate was dead, restarted, now warmed up, attempt: "+i);
						break;
					}
				}
			}
		}

		return new ValidationHandler().if200OK(chocolate);
	}


	/** This method will start config server if stopped
	 * 
	 * @return
	 */
	public boolean configServerHealthCheck()
	{
		String configserver = "http://"+MobileTestClass_Methods.propertyConfigFile.getProperty("[chocolate]").toString().trim().concat("/healthcheck");

		/** if chocolate is not running then restart this */
		if(!new ValidationHandler().if200OK(configserver))
		{
			ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(LaunchE2ETest.sessionConfigServer, "sudo service objectserver start");

			int i=0;
			while( i < 10)
			{
				if(!new ValidationHandler().if200OK(configserver))
				{
					try {Thread.sleep(3000);} catch (InterruptedException e) {}
					logger.info("config server was dead, restarted, now waiting for warm up, attempt: "+i);
					i++;

					continue;
				}
				else{
					logger.info("config server was dead, restarted, now warmed up, attempt: "+i);
					break;
				}
			}
		}

		return new ValidationHandler().if200OK(configserver);
	}



	/** This method is to check the bidder url 
	 * 
	 * @return
	 */
	public boolean bidderHealthCheck()
	{
		/** check bidder end point also */
		WebDriver driver = MobileTestClass_Methods.WebDriverSetUp("chrome", null);
		String bidder = "https://ankur.serve.qa.vdopia.com/test.html";
		driver.get(bidder);

		boolean flag = false;
		if(driver.getPageSource().contains("Test Site - Ankur Ke Liye :)"))
		{
			flag = true;
		}
		driver.quit();

		return flag;
	}

	/**
	 * This method is for compare the category details of mysql and bq
	 * @param categoryExpression
	 * @param con
	 * @param AutionID
	 * @param bigQueryConnection
	 * @param projectID
	 * @return
	 */
	public boolean compareCategoryDeatils(String categoryExpression, Connection con,Bigquery bigQueryConnection, String projectID)
	{
		String expected = getExpectedExpressionPrice(categoryExpression, con);
		String partnerName = expected.split(":")[0].split("_")[0];
		int partnerID = getPartnerID(partnerName);
		String expectedPrice = expected.split(":")[1];
		String actualPrice = getActualExpressionPrice(partnerID, bigQueryConnection, projectID);
		if(expectedPrice.equalsIgnoreCase(actualPrice))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * This method will return partner id after get partner name as input
	 * @param partnerName
	 * @return
	 */
	public int getPartnerID(String partnerName)
	{
		if(partnerName.equalsIgnoreCase("bk"))
		{
			return 1;
		}
		if(partnerName.equalsIgnoreCase("fa"))
		{
			return 2;
		}
		if(partnerName.equalsIgnoreCase("lr"))
		{
			return 3;
		}
		else
		{
			return 0;
		}

	}

	/**
	 * This method will return aution id by parsing the bidder request 
	 * @param bidderRequest
	 * @param bidderType
	 * @return
	 */
	public String getAuctionID(String bidderRequest, String bidderType)
	{
		String autionID = "";
		try{
			if(bidderType.contains("rtb"))
			{
				JSONObject jsonBidderRequest = new JSONObject(bidderRequest);
				autionID = jsonBidderRequest.getString("id");
			}
			else
			{
				TreeMap<String, String> urlMap = getURLParam(bidderRequest);
				autionID = urlMap.get("auction_id");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " Exception occured when try to get the Aution ID from bidder request", e);
		}
		return autionID;
	}


	/** This method will send request to chocolate max 5 times to get response.
	 * 
	 * @param taskID
	 * @param tag
	 * @return
	 */
	public HashMap<Object, Object> getChocolateResponse(String taskID, String tag)
	{
		/** send request */
		HashMap<Object, Object> responseMap = new HashMap<>(); 

		try
		{
			/** random sleep */
			int delay = IntegerLib.GetRandomNumber(6000, 2000);
			Thread.sleep(delay);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " random delay before sending first request to chocolate: "+delay);

			/** Send request again to resolve the bidder timeout issue */
			responseMap = httpClientWrap.sendGetRequest_GetStatusLine(tag);

			/** get chocolate response and save it in a file at xxx/results/e2e/<TASK_ID/> for further analysis */
			String chocolateResponse = new ValidationHandler().saveChocolateResponse(taskID, tag, responseMap);
			int i = 0;

			while(i<=5)
			{
				if(chocolateResponse.contains("No ad found") 
						|| chocolateResponse.toLowerCase().contains("invalid api") 
						|| chocolateResponse.toLowerCase().contains("unavailable"))
				{
					/** random sleep */
					Thread.sleep(delay);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " random delay before sending request to chocolate: "+delay);

					/** Send request again to resolve the bidder timeout issue */
					responseMap = httpClientWrap.sendGetRequest_GetStatusLine(tag);

					/** get chocolate response and save it in a file at xxx/results/e2e/<TASK_ID/> for further analysis */
					chocolateResponse = new ValidationHandler().saveChocolateResponse(taskID, tag, responseMap);

					i++;
				}
				else
				{
					break;
				}
			}
		}catch( Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : ", e);
		}
		return responseMap;
	}

	/**
	 * This method will compare the adID send be bidder with displaying by chocolate in response
	 * @param BidderResponse
	 * @param chocolateResponse
	 * @return
	 */
	public boolean validateAdId(String bidderResponse, String chocolateResponse)
	{
		boolean status = false;
		try
		{
			String expectedAdID = getAdIDfromBidderResponse(bidderResponse);
			String actualAdID = getAdIDfromBidderResponse(chocolateResponse);
			if(expectedAdID.equalsIgnoreCase(actualAdID))
			{
				status = true;
			}
			else
			{
				status = false;
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" : Exception occured when validating Ad ID", e);
		}
		return status;
	}

	public String adServing(HashMap<Object, Object> responseMap, WebDriver driver, String taskID, String output, Session bidderSession)
	{
		String result = "";
		String fileName = new ValidationHandler().saveChocolateResponseForServing(responseMap, taskID, bidderSession);
		String playerUrl = getIntegratedPageURLOfSuppliedTag(fileName, taskID, output);

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Player url to be browsed: " + playerUrl);

		if(output.equalsIgnoreCase("vast"))
		{
			result = VastHandlerLib.playVastXMLbyVastPlayer(playerUrl, driver);
		}
		else if(output.equalsIgnoreCase("js"))
		{

		}

		return result;
	}

	/** Create files on server using writeTag api
	 * 
	 * @param tag
	 * @return
	 */
	public static String getIntegratedPageURLOfSuppliedTag(String fileName, String taskID, String output)
	{
		String writeTagApi = "";
		String finalURLForBrowser = "";

		if(output.equalsIgnoreCase("vast"))
		{
			writeTagApi = "http://bidders.qa.vdopia.com/integrateVastTagApi.php";
		}
		/*else if(output.equalsIgnoreCase("js"))
		{
			writeTagApi = "http://bidders.qa.vdopia.com/writeJsTagApi.php";
		}
*/
		try
		{
			JSONObject jsonRequest = new JSONObject();
			jsonRequest.put("id", taskID);
			jsonRequest.put("tag", fileName);

			/** send post request to api to create file with the supplied tags */ 
			finalURLForBrowser = httpClientWrap.sendPostRequest(writeTagApi, jsonRequest.toString());
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID + " Exception: ", e);
		}

		return finalURLForBrowser;
	}

	/**
	 * This is the method to save the chocolate response in a file
	 * @param responseMap
	 * @param taskID
	 * @return
	 */
	public String saveChocolateResponseForServing(HashMap<Object, Object> responseMap, String taskID, Session bidderSession)
	{
		String filename = "";
		String chocolateResponse = (String) responseMap.get("response");
		try
		{
			if(chocolateResponse.contains("No ad found") 
					|| chocolateResponse.toLowerCase().contains("invalid api") 
					|| chocolateResponse.toLowerCase().contains("unavailable"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " There is no valid ad");
			}
			else
			{
				String location = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/"+taskID+"/");
				filename = taskID+".serve";
				FileLib.WriteFile(chocolateResponse, location, filename, false);	
				location = location+"/"+taskID+".serve";
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+ " saving chocolate response locally for serving at: "+location);

				ExecuteCommands.ExecuteCommandUsingJsch_CopyFileFromLocalToRemote(bidderSession, location, "/tmp");

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " + " Serving file is copied from :"+location);
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ ": "+e.getMessage(), e);
		}

		return filename;

	}
}
