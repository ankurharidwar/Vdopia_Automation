package projects.e2etest;


import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger; 
import org.testng.annotations.Test;

import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import projects.TestSuiteClass;
import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.MobileTestClass_Methods;


public class SystemHealthCheck 
{
	Logger logger = Logger.getLogger(SystemHealthCheck.class.getName());


	@Test
	public void main() throws InterruptedException  
	{
		ExecutorService ex = Executors.newCachedThreadPool();
		ex.submit(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				int i=2;
				while(i< 10)
				{
					System.out.println(i);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					i++;
				}

			}
		});

		int x =0;
		while(x < 5)
		{
			System.out.println("Print My Task ");
			x++;
		}

	}


	/**
	 * execute rtFeedConsumer.php to update memcamp every time.
	 * 
	 * @return
	 */
	public synchronized void memcampCron(Session sessionServe)
	{		
		try
		{
			String vanillaInstance = MobileTestClass_Methods.propertyConfigFile.getProperty("[vanilla]").toString().trim();
			vanillaInstance = vanillaInstance.substring(0, vanillaInstance.indexOf(".serve"));

			String command = "sudo /usr/bin/php /var/"+vanillaInstance+"/ads/cliTools/rtFeedConsumer.php";

			/** execute rtFeed consumer cron in serve machine */
			ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionServe, command);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executed Cron for memcamp update ... ");

		}catch(Exception e){
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" : "+e.getMessage(), e);
		}
	}

	
	/** Restore converted ads from adplatform to qaautomation db 
	 * 
	 * @return
	 */
	public Callable<Object> restoreConvertedAds(Session sessionServe)
	{
		Callable<Object> cal = new Callable<Object>() {

			@Override
			public Object call() throws Exception {
				return ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionServe, "sudo sh /var/ankur/ads/bidders/adConvertedDBBackup.sh");
			}
		};

		return cal;
	}


	/** update rt_checkpoints table to have serving going on.
	 * select TIMESTAMPDIFF(SECOND,last_aggregation_update_time,now() ) as aggregation_update_delay, TIMESTAMPDIFF(SECOND,last_memcamp_update_time,now()) as memcamp_update_delay, if(TIMESTAMPDIFF(SECOND,last_aggregation_update_time,now() ) > aggregation_update_delay_limit, 'AGGREGATION_DELAY_LIMIT_EXCEEDED', if(TIMESTAMPDIFF(SECOND,last_memcamp_update_time,now()) > memcamp_update_delay_limit, 'MEMCAMP_DELAY_LIMIT_EXCEEDED', 'OK' ) ) as status,last_aggregation_update_time,aggregation_update_delay_limit,last_memcamp_update_time,memcamp_update_delay_limit from rt_checkpoints;
	 * @param connection
	 * @return
	 */
	public Runnable aggregationHealthCheck(final Connection connectionServe)
	{
		Runnable runnable = new  Runnable() {

			@Override
			public void run() {

				/** updating rt_checkpoint table to maintain the serving */
				String aggregationUpdateSQL = "update rt_checkpoints set last_aggregation_update_time = now(), last_memcamp_update_time = now();";

				while(true)
				{
					try
					{
						/** execute query only if received connection is not null */
						if(connectionServe != null)
						{
							new DBLib().executeUpdateInsertQuery(connectionServe, aggregationUpdateSQL);
						}
						else
						{
							logger.error(" ######## Alert !! RECEIVED DB CONNECTION IS NULL WHILE EXECUTING AGGREGATION UPDATE CRON !! ######## ");
						}

						Thread.sleep(120000);

					}catch(Exception e)
					{
						logger.error(e.getMessage());
					}
				}
			}
		};

		return runnable;
	}


	/** Restart object server, aerospike every two min
	 * 
	 * @param objectServerSession
	 * @return
	 */
	public Runnable chocolateDependenciesHealthCheck(final Session sessionObjectServer, final Session sessionAerospike)
	{
		Runnable runnable = new  Runnable() {

			@Override
			public void run() {

				while(true)
				{
					try
					{
						/** restart object server only if received session is not null */
						if(sessionObjectServer != null)
						{
							ExecuteCommands.ExecuteCommandUsingJsch(sessionObjectServer, "sudo service objectserver restart");
							logger.info("restarting objectserver to have the updated data ... ");
						}

						if(sessionAerospike != null && !ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionAerospike, "sh /etc/init.d/aerospike status").contains("is running"))
						{
							logger.info("restarting dead aerospike: "+ExecuteCommands.ExecuteCommandUsingJschReturnsOutput(sessionAerospike, "/etc/init.d/aerospike start"));
						}

						Thread.sleep(180000);
					}
					catch(Exception e)
					{
						logger.error(e.getMessage());
					}
				}
			}
		};

		return runnable;		
	}
}
