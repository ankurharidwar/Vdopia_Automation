package projects.e2etest;


import projects.bq.BQHandler;
import projects.chocolate.LaunchChocolateTests;
import projects.grid.HubSetupLib;

import java.awt.Robot;
import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.FileUtils;
import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

import projects.portal.GetObjectRepoAsJson;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import vlib.CaptureScreenShotLib;
import vlib.ExecuteCommands;
import vlib.FileLib;
import vlib.KeyBoardActionsUsingRobotLib;
import vlib.MobileTestClass_Methods;


public class LaunchE2ETest 
{
	static String suiteName = ""; 

	Logger logger = Logger.getLogger(LaunchE2ETest.class.getName());

	static String driverFileLocation;
	static String testdataFileLocation;
	static String channelTag;

	static Session sessionServe;
	static Session sessionaerospike;
	static Session sessionBidder;
	static Session sessionObjectServer;
	static Session sessionChocolateServer;
	static Session sessionConfigServer;

	static public Connection connectionServe;
	static HashMap<String, String> taskResult = new HashMap<String, String>();

	/** creating an executor service to execute the portal, chocolate tasks and system health check  */
	static ExecutorService portalTaskExecutor = Executors.newFixedThreadPool(8);;
	static ExecutorService chocolateTaskExecutor = Executors.newCachedThreadPool();

	static public ExecutorService systemHealthCheckExecutor = Executors.newCachedThreadPool();

	/** this is a global map which is monitored for task status, similarly creating one more 
	 * global map - mapAllTasksForChocolate which will contain the requisite data for chocolate tasks and 
	 * chocolate executor will get data from that map and update the status in mapAllTasksFromDriverSheet map */
	static TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet = new TreeMap<>();
	static TreeMap<String, TaskObjects> mapAllTasksForChocolate = new TreeMap<>();

	static TreeMap<String, HashMap<String, String>> jsonTestDataMap;

	static JSONObject jsonObjectRepo = new JSONObject();

	static String suiteBQStartTime;
	static Bigquery bigQueryConnection;
	static String bqProjectId; 

	static String chocolateTag;
	static String buildNumber;


	@SuppressWarnings("static-access")
	@Parameters({"chocolateTag", "buildNumber"})
	@BeforeClass
	public void beforeClass(String chocolateTag, String buildNumber) 
	{
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			suiteName = "endToEndFlow";

			/** Get session with serve db */
			connectionServe = MobileTestClass_Methods.CreateServeSQLConnection();

			/** save build number and chocolate tag */
			LaunchE2ETest.chocolateTag = chocolateTag; 
			LaunchE2ETest.buildNumber = buildNumber;

			String aerospike = MobileTestClass_Methods.propertyConfigFile.getProperty("[aerospike]").toString().trim();
			String objectServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[objectserver]").toString().trim();
			String configServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[configserver]").toString().trim();
			String chocolateServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[chocolateIP]").toString().trim();
			String bidderServer = MobileTestClass_Methods.propertyConfigFile.getProperty("[bidderserver]").toString().trim();

			String pemFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/qa_key.pem");
			String automationPemFile = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tpt/qa-automation.pem");

			sessionObjectServer = ExecuteCommands.createSessionWithPrivateKey("ubuntu", automationPemFile, objectServer);
			sessionConfigServer = ExecuteCommands.createSessionWithPrivateKey("ubuntu", automationPemFile, configServer);
			sessionChocolateServer = ExecuteCommands.createSessionWithPrivateKey("ubuntu", automationPemFile, chocolateServer);
			sessionaerospike = ExecuteCommands.createSessionWithPrivateKey("ec2-user", automationPemFile, aerospike);
			sessionBidder = ExecuteCommands.createSessionWithPrivateKey("ec2-user", automationPemFile, bidderServer);
			sessionServe = ExecuteCommands.createSessionWithPrivateKey("ec2-user", pemFile, "serve.qa.vdopia.com");

			logger.info("################### FIRST CHECKING IF ALL THE REQUIRED END POINTS ARE UP AND RUNNING ###################");

			if(new ValidationHandler().systemhealthCheck()){
				logger.info("All servers are up and running.");
			}
			else{
				Assert.fail("All system end points (vanilla, chocolate, config server, portal, aerospike) are not up and running, exiting tests.");
			}

			/** Initializing constructor of KeyBoardActionsUsingRobotLib and CaptureScreenShotLib here, so that focus on chrome browser is not disturbed. */
			/** initializing robot object headless to make it run in jenkins */
			System.setProperty("java.awt.headless", "false");
			Robot rt = new Robot();
			new KeyBoardActionsUsingRobotLib(rt);
			new CaptureScreenShotLib(rt);

			/** get object repository as json object */
			String objectRepo = TestSuiteClass.AUTOMATION_HOME.concat("/object_repository/portalObjectRepository/transformerPortal_ObjectRepository.xls");
			jsonObjectRepo = new GetObjectRepoAsJson().getObjectRepoAsJson(objectRepo);

			/** Execute Channel Tag generation test case and save the tag in a file and get the content to be referenced later on */
			//channelTag = new TestSetup().channelTagSetup();
			channelTag = FileLib.ReadContentOfFile(TestSuiteClass.AUTOMATION_HOME.concat("/tpt/tag.txt"));

			/** Copy the driver sheet and in copied file add columns - URL, Task_Status and Results and pass this location in below code*/
			driverFileLocation = new TestSetup().addLabels_DriverSheet();

			/** Get the driver sheet in a map, get all the tasks for which Execute is set to Yes, now there will a atomic boolean status = false will also be set */ 
			mapAllTasksFromDriverSheet = new E2EGenericMethods().readDriverSheet(driverFileLocation);

			/** Generate the json data*/
			if(!MobileTestClass_Methods.propertyConfigFile.getProperty("[debugMode]").toString().equalsIgnoreCase("yes"))
			{
				new TestSetup().createJsonData(connectionServe, mapAllTasksFromDriverSheet.size()+5);
			}
			/** get json input data as map with atomic boolean set as false */
			jsonTestDataMap = new E2EGenericMethods().getInputJsonData();

			/** copy the original test data file and use it everywhere */
			String testDataFile_raw = TestSuiteClass.AUTOMATION_HOME.toString().concat("/tc_data/e2e/E2E_Test_Data.xls");
			testdataFileLocation = TestSuiteClass.AUTOMATION_HOME.toString().concat("/results/e2e/Test_Data/").concat("Test_Data.xls");
			FileUtils.copyFile(new File(testDataFile_raw), new File(testdataFileLocation));

			/** creating big query connection */
			bigQueryConnection = new BQHandler().createBqConnection();
			bqProjectId = MobileTestClass_Methods.propertyConfigFile.getProperty("qaBigQueryProjectId").toString();
			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection, bqProjectId, "select current_timestamp();");

			suiteBQStartTime = new BQHandler().get1DArrayFromBQResults(queryResult)[0];
			logger.info("BQ Start Time : "+suiteBQStartTime);
		}
		catch (Exception e)
		{
			logger.error("Error occurred before starting the EndToEndFlow test", e);
		}
	}


	/** running tests */
	@Test(priority=0)
	public void launchTest()
	{
		/** running a system health check and prerequisites in a separate thread */
		systemHealthCheckExecutor.submit(new SystemHealthCheck().restoreConvertedAds(sessionServe));
		systemHealthCheckExecutor.submit(new SystemHealthCheck().aggregationHealthCheck(connectionServe));
		systemHealthCheckExecutor.submit(new SystemHealthCheck().chocolateDependenciesHealthCheck(sessionObjectServer, sessionaerospike));

		logger.info(" RunningTest ...");

		/** get all test data --> campaign, channel, bidder in a map and pass it to all the callables. coz test data remains constant throughout the execution 
		 */
		TreeMap<String, TreeMap<String,String>> channelTestData = new E2EGenericMethods().getCompleteDataFromExcelSheet(testdataFileLocation, "Channel_Data");
		TreeMap<String, TreeMap<String,String>> campaignTestData = new E2EGenericMethods().getCompleteDataFromExcelSheet(testdataFileLocation, "Campaign_Data");
		TreeMap<String, TreeMap<String,String>> bidderTestData = new E2EGenericMethods().getCompleteDataFromExcelSheet(testdataFileLocation, "Bidder_Data");
		TreeMap<String, TreeMap<String,String>> packageTestData = new E2EGenericMethods().getCompleteDataFromExcelSheet(testdataFileLocation, "Package_Data");
		TreeMap<String, TreeMap<String,String>> dealTestData = new E2EGenericMethods().getCompleteDataFromExcelSheet(testdataFileLocation, "Deal_Data");

		/** apply data parser for bidder map -- in case there is any macro provided */
		packageTestData = new TestSetup().createDynamicTestData(packageTestData, connectionServe);

		/** setup bidder end point */
		bidderTestData = new TestSetup().updateBidderEndPoint(mapAllTasksFromDriverSheet, bidderTestData, sessionBidder);

		final TreeMap<String, TreeMap<String,String>> packageData = packageTestData;

		try{

			/** wait until all free task are completed --> Need to write code like check the drivermap where we can keep
			 * a status like in progress or completed, and then keep on waiting until there is any in progress status 
			 *  execute portal and chocolate tasks */
			new TaskHandler().assignTasks(channelTestData, campaignTestData, bidderTestData, packageData, dealTestData);

			logger.info(" ******* All Tasks Completed ******** ");

		}catch(Exception e)
		{	
			logger.error(e.getMessage(), e);
		}
	}


	/**
	 * Setting up SSP Suite Name to decide which OR needs to be loaded.
	 * @return
	 */
	public static String getSuiteName()
	{
		return suiteName; 
	}


	/** This is a getter method which returns the channel tag.
	 * 
	 * @return
	 */
	public static String getChannelTag()
	{
		return channelTag;
	}


	@AfterClass
	public void afterTest() 
	{
		try
		{
			/** Mail the data for debugging */
			E2EGenericMethods.mailDataForDebug(sessionChocolateServer, sessionBidder, chocolateTag, buildNumber);

			/** shut down system health check */
			new HubSetupLib().shutdownSeleniumGridHub(connectionServe);
			sessionServe.disconnect();
			sessionaerospike.disconnect();
			sessionObjectServer.disconnect();
			systemHealthCheckExecutor.shutdownNow();
			sessionChocolateServer.disconnect();
			sessionBidder.disconnect();

			/** shut down executor after finishing tasks */
			portalTaskExecutor.shutdownNow();

			/** close serve connection */
			connectionServe.close();


		}catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		finally
		{
			/** write result in driver sheet */
			new E2EGenericMethods().writeTaskResults(driverFileLocation, taskResult);

			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection, bqProjectId, "select current_timestamp();");
			String suiteBQEndTime = new BQHandler().get1DArrayFromBQResults(queryResult)[0];
			String tableDate = new SimpleDateFormat("yyyyMMdd").format(new Date());

			String sql = "SELECT device.ifa, UNIQUE(bidResponses.bidderName) AS bidderName, bidResponses.responseStatus, id, timestamp "
					+ " FROM ( TABLE_QUERY(chocolate_raw, \"table_id CONTAINS 'auctions_' AND table_id CONTAINS '"+tableDate+"' \")) "
					+ " WHERE timestamp > '"+ suiteBQStartTime +"' AND timestamp < '"+ suiteBQEndTime +"' AND device.ifa LIKE '%TASK%' "
					+ " GROUP BY device.ifa, bidResponses.responseStatus, id, timestamp ORDER BY timestamp "; 

			/** Dump data from BQ for all active task ids */
			logger.info(" ----- -----  ----- For BQ Results ----- ----- -----  "+ sql);
			logger.info("################### EndToEndFlow Ended At: "+ new SimpleDateFormat("MM/dd/yyyy hh:mm:ss").format(new Date()) +" ########################");
		}
	}


	/** This will act as a data provider and other test- chocolateTest
	 * 
	 * @return
	 */
	@DataProvider(name="taskResults")
	public static String [][] getResultMap()
	{
		String [][] result = new String[taskResult.size()][2];

		int count = 0;
		for(Map.Entry<String, String> map : taskResult.entrySet())
		{
			String key = map.getKey();
			String value = map.getValue();

			result[count][0] = key;
			result[count][1] = value;

			count++;
		}

		return result;
	}


	/** This test will parse the result map and supply testNg results to jenkins
	 * 
	 * @param taskId
	 * @param result
	 */
	@Test(priority=1, dataProvider="taskResults")
	public void chocolateTest(String taskId, String result)
	{
		logger.info("*********** Now Writing Results ***********  ");
		new LaunchChocolateTests().getTestNGResults(result);
	}

}

