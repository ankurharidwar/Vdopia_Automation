package projects.e2etest;


import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;

import com.google.api.services.bigquery.Bigquery;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;

public class TaskObjects {


	private TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet; 
	private String taskID;
	private Session sessionServe; 
	private Session sessionBidder; 
	private Connection connection;
	private TreeMap<String, TreeMap<String, String>> finalChannelTestData;
	private TreeMap<String, TreeMap<String, String>> finalCampaignTestData;
	private TreeMap<String, TreeMap<String, String>> finalBidderTestData;
	private TreeMap<String, TreeMap<String, String>> finalPackageTestData; 
	private TreeMap<String, TreeMap<String, String>> finalDealTestData;
	private Bigquery bigQueryConnection;
	private String bqProjectId;
	private String driverFile;
	private String result;
	private AtomicBoolean ifProceedChocolateTask;
	private long portalTaskEndTime;
	private AtomicBoolean retrychocolatetest;

	public TreeMap<String, TreeMap<String, String>> getMapAllTasksFromDriverSheet() {
		return mapAllTasksFromDriverSheet;
	}
	public void setMapAllTasksFromDriverSheet(TreeMap<String, TreeMap<String, String>> mapAllTasksFromDriverSheet) {
		this.mapAllTasksFromDriverSheet = mapAllTasksFromDriverSheet;
	}
	public String getTaskID() {
		return taskID;
	}
	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}
	public Session getSessionServe() {
		return sessionServe;
	}
	public void setSessionServe(Session sessionServe) {
		this.sessionServe = sessionServe;
	}
	public Session getSessionBidder() {
		return sessionBidder;
	}
	public void setSessionBidder(Session sessionBidder) {
		this.sessionBidder = sessionBidder;
	}
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public TreeMap<String, TreeMap<String, String>> getFinalChannelTestData() {
		return finalChannelTestData;
	}
	public void setFinalChannelTestData(TreeMap<String, TreeMap<String, String>> finalChannelTestData) {
		this.finalChannelTestData = finalChannelTestData;
	}
	public TreeMap<String, TreeMap<String, String>> getFinalCampaignTestData() {
		return finalCampaignTestData;
	}
	public void setFinalCampaignTestData(TreeMap<String, TreeMap<String, String>> finalCampaignTestData) {
		this.finalCampaignTestData = finalCampaignTestData;
	}
	public TreeMap<String, TreeMap<String, String>> getFinalBidderTestData() {
		return finalBidderTestData;
	}
	public void setFinalBidderTestData(TreeMap<String, TreeMap<String, String>> finalBidderTestData) {
		this.finalBidderTestData = finalBidderTestData;
	}
	public TreeMap<String, TreeMap<String, String>> getFinalPackageTestData() {
		return finalPackageTestData;
	}
	public void setFinalPackageTestData(TreeMap<String, TreeMap<String, String>> finalPackageTestData) {
		this.finalPackageTestData = finalPackageTestData;
	}
	public TreeMap<String, TreeMap<String, String>> getFinalDealTestData() {
		return finalDealTestData;
	}
	public void setFinalDealTestData(TreeMap<String, TreeMap<String, String>> finalDealTestData) {
		this.finalDealTestData = finalDealTestData;
	}
	public Bigquery getBigQueryConnection() {
		return bigQueryConnection;
	}
	public void setBigQueryConnection(Bigquery bigQueryConnection) {
		this.bigQueryConnection = bigQueryConnection;
	}
	public String getBqProjectId() {
		return bqProjectId;
	}
	public void setBqProjectId(String bqProjectId) {
		this.bqProjectId = bqProjectId;
	}
	public String getDriverFile() {
		return driverFile;
	}
	public void setDriverFile(String driverFile) {
		this.driverFile = driverFile;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public AtomicBoolean getIfProceedChocolateTask() {
		return ifProceedChocolateTask;
	}
	public void setIfProceedChocolateTask(AtomicBoolean ifProceedChocolateTask) {
		this.ifProceedChocolateTask = ifProceedChocolateTask;
	}
	public long getPortalTaskEndTime() {
		return portalTaskEndTime;
	}
	public void setPortalTaskEndTime(long portalTaskEndTime) {
		this.portalTaskEndTime = portalTaskEndTime;
	}
	public AtomicBoolean getRetrychocolatetest() {
		return retrychocolatetest;
	}
	public void setRetrychocolatetest(AtomicBoolean retrychocolatetest) {
		this.retrychocolatetest = retrychocolatetest;
	}
	
}
