/**
 * Last Changes Done on 27 May, 2015 3:08:45 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class contains all the methods which are executing the BQ queries.
 */

package projects.bq;



import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.List;
import java.util.TreeMap;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 


import vlib.MobileTestClass_Methods;



import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.TableRow;


public class BQQueriesLib 
{

	static Logger logger = Logger.getLogger(BQQueriesLib.class.getName());
	public static String adFormat = "";
	public static boolean isDeviceConnected = false;
	public static String configFlag = "desktop";

	public static String hudsonFlag = "nonHudson";
	public static int expectedaiTracker_Hudson = 0;
	public static int expectedrtbbpTracker_Hudson = 0;


	/** This constructor will be used by webservice 
	 * 
	 * @param configFlag
	 */
	public BQQueriesLib(String configFlag)
	{
		BQQueriesLib.configFlag = configFlag;
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : initializing constructor ServingBQLib: "+ " configFlag: "+configFlag);
	}


	/** This constructor is being used by MobileAdServingTests
	 * @param adFormat
	 */
	public BQQueriesLib(Object adFormat)
	{
		MobileTestClass_Methods.adFormat = (String) adFormat;
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : initializing constructor BQQueriesLib: "+ " adFormat: "+adFormat);
	}


	/** Used in MobileAdServingTests
	 * @param isDeviceConnected
	 */
	public BQQueriesLib(boolean isDeviceConnected)
	{
		MobileTestClass_Methods.isDeviceConnected = isDeviceConnected;
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : initializing constructor ServingBQLib: "+ " isDeviceConnected: "+isDeviceConnected);
	}


	/** Used in chocolate to check extra rtb_win and rtb_bp trackers for chocolate
	 * 
	 * @param hudsonFlag
	 * @param expectedaiTracker_Hudson
	 * @param expectedrtbbpTracker_Hudson
	 */
	public BQQueriesLib(String hudsonFlag, int expectedaiTracker_Hudson, int expectedrtbbpTracker_Hudson)
	{
		BQQueriesLib.hudsonFlag = hudsonFlag;
		BQQueriesLib.expectedaiTracker_Hudson = expectedaiTracker_Hudson;
		BQQueriesLib.expectedrtbbpTracker_Hudson = expectedrtbbpTracker_Hudson;
		logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : initializing constructor ServingBQLib: "+ "hudsonFlag: "+hudsonFlag + ", expectedaiTracker_Hudson: "+expectedaiTracker_Hudson + ", expectedrtbbpTracker_Hudson: "+expectedrtbbpTracker_Hudson);
	}


	/**
	 * This method will get the current db time.
	 * current_timestamp() returns Unix Time Stamp in ms --> use this select TIMESTAMP('1.450076092528053E9')
	 * to get output in readable format.
	 * 
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static String getCurrentDBTime (Bigquery bqConnection, String bqProjectID) 
	{	
		String currentTime = "";
		try
		{
			String sqlQuery = "select current_timestamp() as CurrentDateTime;";
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Getting current database time by executing query: "+sqlQuery);

			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQuery);

			currentTime = new BQHandler().get1DArrayFromBQResults(queryResult)[0];
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Current BQ Database time is:  "+currentTime);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting current bq database time: ", e);
		}
		return currentTime;
	}


	/**
	 * This method will wait until it finds the ui tracker.
	 * 
	 * @param channelID
	 * @param trackerStartTime
	 * @param testDuration
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static boolean waitForUiTracker(String channelID, String trackerStartTime, int attempt, Bigquery bqConnection, String bqProjectID) 
	{
		boolean flag = false;

		try
		{
			String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

			String sqlQueryForuiTracker = " SELECT measure FROM  [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"]  " +
					" WHERE channel_id = "+ channelID + 
					" AND measure = 'ui' " + 
					" AND tstamp >= '"+trackerStartTime + "'" + 
					" order by tstamp desc LIMIT 1 ";

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print query to check ui tracker: " +sqlQueryForuiTracker);

			for (int i=0; i<attempt; i++)
			{
				GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForuiTracker);
				List<TableRow> tableRow = queryResult.getRows();

				if(tableRow != null)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found tracker: " + tableRow.toString() + ", exiting this iteration.");
					flag = true;

					break;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : checking if ui tracker is fired yet, attempt# " +i);
					Thread.sleep(45000);

					continue;
				}
			}
		}catch(Exception t)
		{	
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while waiting for ui tracker.", t);
		}
		return flag;
	}


	/**
	 * This method will return true if supplied campaign tracker is found else
	 * false.
	 * 
	 * @param campaignTracker
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static boolean getCampaignTracker(String campaignTracker, String campaignID, String channelID, String trackerStartTime, 
			Bigquery bqConnection, String bqProjectID) 
	{
		boolean flag = false;

		/** Adding sub query to put condition on campaignID so that specific campaign tracker can be retrieved 
		 *  even without campaignID and with Only channelID
		 */
		String subQuery = "";

		if(campaignID == null)
		{
			subQuery = "";
		}
		else if(campaignID.trim().isEmpty())
		{
			subQuery = "";
		}
		else
		{
			subQuery = " campaign_id = " + campaignID + " AND ";
		}

		try
		{	
			String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

			String sqlQueryForCampaignTracker = " SELECT measure FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " +
					" WHERE " + subQuery + 
					" channel_id = "+channelID +
					" AND measure = '"+ campaignTracker +"' " +
					" AND tstamp >= '"+ trackerStartTime +"' order by tstamp desc LIMIT 1; " ;

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking campaign side tracker by executing query: " +sqlQueryForCampaignTracker);

			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForCampaignTracker);
			List<TableRow> tableRow = queryResult.getRows();

			if(tableRow != null)
			{
				flag = true;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found tracker: " + tableRow.toString());
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker: "+campaignTracker +" isn't fired yet. ");
			}
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking campaign side tracker: "+campaignTracker, e);
		}
		finally
		{
			return flag;			
		}
	}


	/** This method will return true if supplied channel tracker is found else false.
	 * 
	 * @param channelTracker
	 * @param channelID
	 * @param trackerStartTime
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static boolean getChannelTracker(String channelTracker, String channelID, String trackerStartTime, Bigquery bqConnection, String bqProjectID) 
	{
		boolean flag = false;
		try
		{
			String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

			String sqlQueryForChannelTracker = " SELECT measure FROM  [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " +
					" WHERE channel_id = "+channelID + 
					" AND measure = '"+channelTracker+"' " +
					" AND tstamp >= '"+trackerStartTime+"' "+ 
					" order by tstamp desc LIMIT 1; ";

			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Executing query to check channel tracker: " +sqlQueryForChannelTracker);

			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForChannelTracker);
			List<TableRow> tableRow = queryResult.getRows();

			if(tableRow != null)
			{
				flag = true;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found tracker: " + tableRow.toString());
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Tracker: "+channelTracker +" isn't fired yet. ");
			}
		}
		catch (Exception e) 
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking channel side tracker: "+channelTracker, e);
		}
		finally
		{
			return flag;
		}
	}	


	/** This method will build query (on big query ) without using unique parameter of test url to get channel tracker
	 * 
	 * @param channelID
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @return
	 */
	public static String queryWithOutUniqueParamForChannelTracker(String directMarketplaceFlag, String channelID, String trackerStartTime, String trackerEndTime)
	{
		/** adding a sub query to distinguish between chocolate and vdopia trackers ... */
		String subQuery= "";
		if(directMarketplaceFlag.equalsIgnoreCase("marketplace"))
		{
			subQuery = " AND source = 'marketplace' ";
		}
		else
		{
			subQuery = " AND source = 'direct' ";
		}

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQueryForChannelTracker = " SELECT  IFNULL(campaign_id, 0) AS Campaign_ID, IFNULL(Channel_ID,0) AS Channel_ID, " +
				" measure AS Tracker_Name, count(measure) AS Tracker_Count " +
				" FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE channel_id = "+channelID +
				" AND (tstamp >= '"+trackerStartTime+"' AND tstamp <= '"+trackerEndTime+"') " +
				subQuery +
				" group by Campaign_ID, Channel_ID, Tracker_Name; " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print SQL For Channel Tracker Validation: " +sqlQueryForChannelTracker);

		return sqlQueryForChannelTracker;
	}


	/** This query will get all the trackers recorded for a transaction.
	 * 
	 * @param channelID
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @return
	 */
	public static String queryToGetVdopiaTrackers(String channelID, String trackerStartTime, String trackerEndTime)
	{
		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQuery = " SELECT  IFNULL(campaign_id, 0) AS Campaign_ID, IFNULL(Channel_ID,0) AS Channel_ID, " +
				" measure AS Tracker_Name, count(measure) AS Tracker_Count " +
				" FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE channel_id = "+channelID +
				" AND (tstamp >= '"+trackerStartTime+"' AND tstamp <= '"+trackerEndTime+"') " +
				" group by Campaign_ID, Channel_ID, Tracker_Name; " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : BQ Query to get all trackers: " +sqlQuery);

		return sqlQuery;
	}


	/** This method will build query (on big query ) without using unique parameter of test url to get campaign tracker
	 * 
	 * @param channelID
	 * @param campaignID
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @return
	 */
	public static String queryWithOutUniqueParamForCampaignTracker(String directMarketplaceFlag, String channelID, String campaignID, String trackerStartTime, String trackerEndTime)
	{
		/** adding a sub query to distinguish between chocolate and vdopia trackers ... */
		String subQuery= "";
		if(directMarketplaceFlag.equalsIgnoreCase("marketplace"))
		{
			subQuery = " AND source = 'marketplace' ";
		}
		else
		{
			subQuery = " AND source = 'direct' ";
		}

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQueryForCampaignTracker = " SELECT IFNULL(campaign_id, 0) AS Campaign_ID, IFNULL(Channel_ID,0) AS Channel_ID, measure AS Tracker_Name, "+ 
				" count(measure) AS Tracker_Count FROM  [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " +
				" WHERE campaign_id = "+ campaignID +
				" AND channel_id = "+ channelID + 
				" AND (tstamp >= '"+trackerStartTime+"' AND tstamp <= '"+trackerEndTime+"') " +
				subQuery +
				" group by Campaign_ID, Channel_ID, Tracker_Name; ";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print SQL For Campaign Tracker Validation: " +sqlQueryForCampaignTracker);

		return sqlQueryForCampaignTracker;
	}


	/**This method will build query (on big query ) using unique parameter of test url to get channel tracker
	 * 
	 * @param trackerStartTime
	 * @param uniqueRequestParam
	 * @return
	 */
	public static String queryWithUniqueParamForChannelTracker(String trackerStartTime, String uniqueRequestParam)
	{
		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQueryForChannelTracker = " SELECT  IFNULL(campaign_id, 0) AS Campaign_ID, IFNULL(Channel_ID,0) AS Channel_ID, " +
				" measure AS Tracker_Name, count(measure) AS Tracker_Count " +
				" FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE uniq_id = '" + uniqueRequestParam + "'" +
				" AND tstamp >= '"+trackerStartTime +"'" +
				" group by Campaign_ID, Channel_ID, Tracker_Name; " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print SQL For Channel Tracker Validation: " +sqlQueryForChannelTracker);

		return sqlQueryForChannelTracker;
	}


	/** This method will build query (on big query ) using unique parameter of test url to get campaign tracker
	 * 
	 * @param channelID
	 * @param trackerStartTime
	 * @param uniqueRequestParam
	 * @return
	 */
	public static String queryWithUniqueParamForCampaignTracker(String channelID, String trackerStartTime, String uniqueRequestParam)
	{
		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQueryForCampaignTracker = " SELECT  IFNULL(campaign_id, 0) AS Campaign_ID, IFNULL(Channel_ID,0) AS Channel_ID, " +
				" measure AS Tracker_Name, count(measure) AS Tracker_Count " +
				" FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE uniq_id = '" + uniqueRequestParam + "'" +
				" AND channel_id = '"+ channelID +"' " +
				" AND tstamp >= '"+trackerStartTime +"'" +
				" group by Campaign_ID, Channel_ID, Tracker_Name; " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print SQL For Channel Tracker Validation: " +sqlQueryForCampaignTracker);

		return sqlQueryForCampaignTracker;
	}


	/** This method will return a list containing queries for channel and campaign side trackers.
	 * 
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param uniqueRequestParam
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static TreeMap<String, String> getQueriesForTrackerCalculation(String directMarketplaceFlag, String campaignID, String channelID, String trackerStartTime, String trackerEndTime, 
			String uniqueRequestParam, Bigquery bqConnection, String bqProjectID)
			{

		TreeMap<String, String> hashmap = new TreeMap<>();

		/** Getting query to find out the number of channel and campaign tracker
		 */
		String sqlQueryForChannelTracker;
		String sqlQueryForCampaignTracker;

		/** Build query for ad serving on webservice
		 */
		if(configFlag.equalsIgnoreCase("webservice"))
		{
			sqlQueryForChannelTracker = queryWithUniqueParamForChannelTracker(trackerStartTime, uniqueRequestParam);
			sqlQueryForCampaignTracker = queryWithUniqueParamForCampaignTracker(channelID, trackerStartTime, uniqueRequestParam);
		}

		/** Build query for ad serving other than webservice
		 */
		else
		{
			sqlQueryForChannelTracker = queryWithOutUniqueParamForChannelTracker(directMarketplaceFlag, channelID, trackerStartTime, trackerEndTime);
			sqlQueryForCampaignTracker = queryWithOutUniqueParamForCampaignTracker(directMarketplaceFlag, channelID, campaignID, trackerStartTime, trackerEndTime);
		}


		/** Adding queries in a list
		 */
		hashmap.put("sqlqueryforchanneltracker", sqlQueryForChannelTracker);
		hashmap.put("sqlqueryforcampaigntracker", sqlQueryForCampaignTracker);

		return hashmap;
			}


	/**
	 * This method will wait until it finds the supplied tracker.
	 * 
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param testDuration
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static boolean waitForCampaignTracker(String measure, String campaignID, String channelID, String trackerStartTime, int attempt, Bigquery bqConnection, String bqProjectID)
	{
		boolean flag = false;

		try
		{
			String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

			String sqlQueryForAeTracker = " SELECT measure AS Tracker_Name FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " +
					" WHERE campaign_id = "+ campaignID +" " +
					" AND channel_id = "+ channelID +" " +
					" AND measure = '"+ measure +"' " +
					" AND tstamp >= '" + trackerStartTime + "' " +
					" order by tstamp desc LIMIT 1 "; 

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print query for checking ae tracker: " +sqlQueryForAeTracker);

			for (int i=0; i<attempt; i++)
			{
				GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForAeTracker);
				List<TableRow> tableRow = queryResult.getRows();

				if(tableRow != null)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found tracker: " + tableRow.toString() + ", exiting this iteration.");
					flag = true;

					break;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : checking if "+measure+" tracker is fired yet, attempt# " +i +" sleeping thread for 45 sec... ");
					Thread.sleep(45000);
				}

				if(i==attempt-1)
				{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* NO DATA FOUND FOR THE ABOVE QUERY IN BQ EVEN AFTER "+attempt +" ATTEMPT OF 45 SEC. *********");
				}
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while waiting for "+measure+" tracker.", t);
		}
		return flag;
	}


	/** Wait for supplied vdopia tracker, only channel id is used in query.
	 * 
	 * @param measure
	 * @param channelID
	 * @param trackerStartTime
	 * @param attempt
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static boolean waitForVdopiaTracker(String measure, String channelID, String trackerStartTime, String trackerEndTime, int attempt, Bigquery bqConnection, String bqProjectID)
	{
		boolean flag = false;

		try
		{
			String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

			String sqlQuery = " SELECT measure AS Tracker_Name FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " +
					" WHERE channel_id = "+ channelID +" " +
					" AND measure = '"+ measure +"' " +
					" AND tstamp >= '" + trackerStartTime + "' AND tstamp<= '" + trackerEndTime + "' " +
					" order by tstamp desc LIMIT 1 "; 

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print query for checking "+measure +" tracker: " +sqlQuery);

			for (int i=0; i<attempt; i++)
			{
				GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQuery);
				List<TableRow> tableRow = queryResult.getRows();

				if(tableRow != null)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found tracker: " + tableRow.toString() + ", exiting this iteration.");
					flag = true;

					break;
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : checking if "+measure+" tracker is fired yet, attempt# " +i +" sleeping thread for 45 sec... ");
					Thread.sleep(45000);
				}

				if(i==attempt-1)
				{
					logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ********* NO DATA FOUND FOR THE ABOVE QUERY IN BQ EVEN AFTER "+attempt +" ATTEMPT OF 45 SEC. *********");
				}
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while waiting for "+measure+" tracker.", t);
		}
		return flag;

	}


	/**
	 * Mobile Tracker Validation Upon Browsing The Test URLs in mobile device/browser, this will check the Click, Pause / Unpause, Mute/UnmUte etc.. 
	 * This method is very crucial for ad serving validation as it is being used by Desktop, Mobile Device, Mobile App Ad Serving Validation.
	 * All trackers are validated in big query.
	 * 
	 * @param data
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static String mobileAds_VdopiaTrackerValidationForUIOperations(TreeMap<String, String> data, Bigquery bqConnection, String bqProjectID) 
	{
		String resultForTracker = "";

		try
		{
			/** Getting queries for getting channel and campaign side trackers 
			 */
			String sqlQueryForChannelTracker = data.get("sqlqueryforchanneltracker");
			String sqlQueryForCampaignTracker = data.get("sqlqueryforcampaigntracker");
			String adFormat = data.get("adformat");

			/** Getting tracker data */
			resultForTracker = mobileAds_VdopiaTrackerValidationForUIOperations(sqlQueryForChannelTracker, sqlQueryForCampaignTracker, adFormat, bqConnection, bqProjectID);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by Method : MobileAdsTrackerValidationForUIOperations: ",e);
		}
		return resultForTracker;
	}


	/**
	 * Mobile Tracker Validation Upon Browsing The Test URLs in mobile device/browser, this will check the Click, Pause / Unpause, Mute/UnmUte etc.. 
	 * This method is very crucial for ad serving validation as it is being used by Desktop, Mobile Device, Mobile App Ad Serving Validation.
	 * All trackers are validated in big query.
	 * 
	 * @param sqlQueryForChannelTracker
	 * @param sqlQueryForCampaignTracker
	 * @param adFormat
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static String mobileAds_VdopiaTrackerValidationForUIOperations(String sqlQueryForChannelTracker, String sqlQueryForCampaignTracker, 
			String adFormat, Bigquery bqConnection, String bqProjectID) 
	{
		String failResult = "FAIL:";
		String finalResult = "";
		String resultForTracker = "";

		try
		{	
			/** Proceed further both campaign and channel side query were received */
			if(sqlQueryForCampaignTracker != null && sqlQueryForChannelTracker != null)
			{
				/** Getting Channel Trackers In 2 D Array from bq 
				 */
				GetQueryResultsResponse channelQueryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForChannelTracker);
				String [][] validationDataForChannelTracker = new BQHandler().get2DArrayFromBQResults(channelQueryResult);

				/** get ai tracker */
				int aiTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForChannelTracker, "ai");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print Channel Tracker ai : " +aiTrackerCount);
				finalResult =  finalResult.concat(adFormat).concat(":").concat("ai").concat(":").concat(String.valueOf(aiTrackerCount));

				/** get ui tracker */
				int uiTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForChannelTracker, "ui");	
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Print Channel Tracker ui : " +uiTrackerCount);
				finalResult =  finalResult.concat(":").concat("ui").concat(":").concat(String.valueOf(uiTrackerCount));

				/** Getting Campaign Trackers In 2 D Array from bq. */ 
				GetQueryResultsResponse campaignQueryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForCampaignTracker);
				String [][] validationDataForCampaignTracker = new BQHandler().get2DArrayFromBQResults(campaignQueryResult);

				/** get vi tracker */
				int viTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForCampaignTracker, "vi");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : vi tracker for " + adFormat + ": " +viTrackerCount);

				/** Constructor hudsonFlag = hudson, will instruct not to check si tracker, else check it.
				 * rtb_bp and rtb_win trackers are required to check in case of hudson requests.
				 * adding cst tracker in case chocolate serves a video ad in a container like ad is integrated in tag <div> </div> 
				 */
				int siTrackerCount = 0;
				int rtbbpTrackerCount = 0;
				int rtbwinTrackerCount = 0;
				int cstTrackerCount = 0;
				if(hudsonFlag.contains("hudson"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : si tracker will not be checked for hudson requests, checking rtb_win, rtb_bp trackers... ");

					rtbbpTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForCampaignTracker, "rtb_bp");
					finalResult = finalResult.concat(":").concat("rtb_bp:").concat(String.valueOf(rtbbpTrackerCount));

					rtbwinTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForCampaignTracker, "rtb_win");
					finalResult = finalResult.concat(":").concat("rtb_win:").concat(String.valueOf(rtbwinTrackerCount));

					/** get cst tracker only in case when video ad played by chocolate 
					 */
					if(adFormat.equalsIgnoreCase("video"))
					{
						cstTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForCampaignTracker, "cst");
						finalResult = finalResult.concat(":").concat("cst:").concat(String.valueOf(cstTrackerCount));
					}
				}
				else
				{
					siTrackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForCampaignTracker, "si");
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : si tracker for " + adFormat + ": " +siTrackerCount);
					finalResult = finalResult.concat(":").concat("si:").concat(String.valueOf(siTrackerCount));
				}


				if (adFormat.equalsIgnoreCase("html") || adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("jsbanner") )
				{
					resultForTracker = MobileTestClass_Methods.MobileAdsTrackerforBanner(adFormat, validationDataForCampaignTracker, finalResult);
				}
				else if(adFormat.equalsIgnoreCase("appinterstitial") || adFormat.equalsIgnoreCase("htmlinter"))
				{
					resultForTracker = MobileTestClass_Methods.MobileAdsTrackerforInterstitial(adFormat,validationDataForCampaignTracker,finalResult);
				}
				else if(adFormat.equalsIgnoreCase("video") || adFormat.equalsIgnoreCase("vastfeed") 
						|| adFormat.equalsIgnoreCase("inview") || adFormat.equalsIgnoreCase("leadervdo") || adFormat.equalsIgnoreCase("vdobanner"))
				{
					/** flagForCloseButtonTestForVideo - is not used in the below method any more. */
					resultForTracker = MobileTestClass_Methods.MobileAdsTrackerforVideo(adFormat,validationDataForCampaignTracker,finalResult);	
				}
				else
				{
					resultForTracker = "SKIP: THIS AD FORMAT: "+adFormat+" IS NOT CODED YET, PLEASE INFORM QA AUTOMATION TEAM.";
				}

				if(configFlag.equalsIgnoreCase("webservice"))
				{
					/** Server side trackers validation excluding for Jaadoo - Ad Serving */
					if(uiTrackerCount>0 || siTrackerCount<1 || siTrackerCount >1)
					{
						if(!(resultForTracker.startsWith("FAIL:")))
						{
							/** in case campaign side tracker result is pass and server side tracker is fail then replace PASS in campaign side results.*/
							resultForTracker = resultForTracker.replace("PASS:", failResult);
						}
					}
				}
				else
				{
					/** Server side trackers validation for non Jaadoo - Ad Serving 
					 * 
					 * In case of hudson requests, do not validate si trackers rather validate rtb_bp and rtbwin trackers.
					 * in case of hudson, count of ai = number of rtb vdopia bidders picked up for bidding
					 * and count of rtb_bp = number of vdopia rtb bidders responded with correct response
					 * 
					 *  removing condition on ui tracker in case of hudson
					 */
					if(hudsonFlag.equalsIgnoreCase("hudson"))
					{
						boolean checkFlag1 = false;
						boolean checkFlag2 = false;
						boolean checkFlag3 = false;

						if(aiTrackerCount!=expectedaiTracker_Hudson)
						{
							checkFlag1 = true;
							resultForTracker = resultForTracker+"\nExpected ai="+expectedaiTracker_Hudson + ", Actual ai="+aiTrackerCount;
						}
						if(rtbbpTrackerCount!=expectedrtbbpTracker_Hudson)
						{
							checkFlag2 = true;
							resultForTracker = resultForTracker+"\nExpected rtb_bp="+expectedrtbbpTracker_Hudson + ", Actual rtb_bp="+rtbbpTrackerCount;
						}
						if(rtbwinTrackerCount!=1)
						{
							checkFlag3 = true;
						}

						if(checkFlag1 || checkFlag2 || checkFlag3)
						{
							if(!(resultForTracker.startsWith("FAIL:")))
							{
								/** in case campaign side tracker result is pass and server side tracker result is fail 
								 * then replace PASS in final results with FAIL.
								 */
								resultForTracker = resultForTracker.replace("PASS:", failResult);
							}
						}
					}
					else
					{
						/**
						 * Normal ad serving - non jaadoo serving
						 */
						if(aiTrackerCount<1 || aiTrackerCount>1 || uiTrackerCount>0 || siTrackerCount<1 || siTrackerCount >1)
						{
							if(!(resultForTracker.startsWith("FAIL:")))
							{
								/** in case campaign side tracker result is pass and server side tracker result is fail 
								 * then replace PASS in final results with FAIL.
								 */
								resultForTracker = resultForTracker.replace("PASS:", failResult);
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by Method : MobileAdsTrackerValidationForUIOperations: ",e);
		}
		return resultForTracker;
	}


	/** Third party click trackers are not applicable to adformats: appinterstitial, htmlinter and jsbanner, therefore these will be excluded
	 * in validation part.
	 * 
	 * @param channelID
	 * @param trackerStartTime
	 * @param expectedImpressionTracker
	 * @param expectedClickTracker
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String MobileAds_ThirdPartyTrackerValidation(TreeMap<String, String> secondChildMap, Bigquery bqConnection, String bqProjectID)
	{
		String finalResult = "";
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Third Party Tracker Validation Started At Time: "+ MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss"));

		try
		{	
			boolean proceedTest = Boolean.parseBoolean(secondChildMap.get("proceedtest"));

			/** Proceed for third party trackers only if proceedTest is true */
			if(proceedTest)
			{
				/** Getting parameters from secondchildmap */
				String expectedImpressionTracker = secondChildMap.get("expectedthirdpartyimpressiontracker");
				String expectedClickTracker = secondChildMap.get("expectedthirdpartyclicktracker");
				String sqlQueryForUniqID = secondChildMap.get("sqlqueryforuniqid");
				String trackerStartTime = secondChildMap.get("trackerstarttime");
				String trackerEndTime = secondChildMap.get("trackerendtime");
				String adFormat = secondChildMap.get("adformat");

				if(	(expectedImpressionTracker.equalsIgnoreCase("") || expectedImpressionTracker.equalsIgnoreCase("0")	)
						&&
						(	expectedClickTracker.equalsIgnoreCase("") || expectedClickTracker.equalsIgnoreCase("0")	)	
						)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no third party tracker associated with this campaign.");
				}
				else
				{
					/** Remove [timestamp] param from tracker url, as its a dynamic field. */
					expectedImpressionTracker = expectedImpressionTracker.replace("[timestamp]", "").trim();
					expectedClickTracker = expectedClickTracker.replace("[timestamp]", "").trim();

					/**Get Uniq ID*/
					String [][] uniqID = null;
					try
					{
						/** Getting DATA In 2 D Array. */ 
						GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForUniqID);					
						uniqID = new BQHandler().get2DArrayFromBQResults(queryResult);

					}catch(Exception e)
					{
						uniqID = null;
					}

					if(uniqID.length > 0)
					{
						/********** VALIDATE IMPRESSION TRACKER ****************/ 
						if(	expectedImpressionTracker.equalsIgnoreCase("") || expectedImpressionTracker.equalsIgnoreCase("0"))
						{
							finalResult = "There is no third party impression tracker associated with this campaign.";
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no third party impression tracker associated with this campaign.");
						}
						else
						{
							/** get third party impression tracker data */
							String queryForThirdPartyImpressionTracker = queryForThirdPartyImpressionTracker(trackerStartTime, trackerEndTime, uniqID[0][0]);
							String actualthirdpartyImpressionTracker[][] = BQQueriesLib.getThirdPartyTrackerData(queryForThirdPartyImpressionTracker, bqConnection, bqProjectID);

							finalResult = finalResult + MobileTestClass_Methods.getThirdPartyTrackerResults(expectedImpressionTracker, actualthirdpartyImpressionTracker, "Impression");
						}

						/********** VALIDATE CLICK TRACKER ****************/
						if((expectedClickTracker.equalsIgnoreCase("") || expectedClickTracker.equalsIgnoreCase("0")))
						{
							finalResult = "There is no destination url associated with this campaign.";
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There is no destination url associated with this campaign.");
						}
						else
						{
							/** get third party click tracker data */
							String queryForThirdPartyClickTracker = queryForThirdPartyClickTracker(trackerStartTime, trackerEndTime, uniqID[0][0]);
							String actualthirdpartyClickTracker[][] = BQQueriesLib.getThirdPartyTrackerData(queryForThirdPartyClickTracker, bqConnection, bqProjectID);

							/** for ad format: jsbanner, htmlinter and appinterstitial, click tracker will not fired. 
							 */
							if(adFormat.equalsIgnoreCase("jsbanner") || adFormat.equalsIgnoreCase("htmlinter") || adFormat.equalsIgnoreCase("appinterstitial"))
							{
								finalResult = finalResult + "Click tracker is not applicable for ad format: "+adFormat +" therefore wasn't checked.";
							}
							else if(adFormat.equalsIgnoreCase("vdobanner") || adFormat.equalsIgnoreCase("leadervdo"))
							{
								finalResult = finalResult + "Automation doesn't perform click on "+ adFormat +" therefore click tracker wasn't checked.";
							}
							else
							{
								finalResult = finalResult + MobileTestClass_Methods.getThirdPartyTrackerResults(expectedClickTracker, actualthirdpartyClickTracker, "Click");
							}
						}

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Third Party Tracker Result:  "+finalResult);
					}
					else
					{
						finalResult = "SKIP: Couldn't Find Uniq ID, Hence Skipping Third Party Tracker Validation For This Iteration. ";
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Couldn't Find Uniq ID, Hence Skipping Third Party Tracker Validation For This Iteration. ");
					}
				}
			}
		}
		catch(Exception e)
		{
			finalResult = "FAIL: Exception occurred while checking Third Party Tracker for this iteration. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by Method : MobileAds_ThirdPartyTrackerValidation: ",e);
		}
		finally
		{
			if(!finalResult.isEmpty())
			{
				finalResult = "Third Party Trackers: \n" + finalResult;
				logger.debug(finalResult);
			}
			return finalResult;
		}

	}


	/** This method will form query to get third party tracker
	 * 
	 * @param sqlQueryForThirdPartyTracker
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String[][] getThirdPartyTrackerData(String sqlQueryForThirdPartyTracker, Bigquery bqConnection, String bqProjectID)
	{
		String thirdpartyTracker[][] = null;
		try
		{
			GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bqConnection, bqProjectID, sqlQueryForThirdPartyTracker);					
			thirdpartyTracker = new BQHandler().get2DArrayFromBQResults(queryResult);
		}
		catch(Exception e)
		{
			thirdpartyTracker = null;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while getting data from event log tables for third party trackers.", e);
		}
		finally
		{
			return thirdpartyTracker;
		}
	}


	/**
	 * big query to get unique id to be used to get third party trackers
	 * @param channelID
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @return
	 */
	public static String queryForUniqID(String channelID, String trackerStartTime, String trackerEndTime)

	{

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Time End For Third Party Tracker Calculation: " +trackerEndTime);

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String sqlQueryForUniqID = " SELECT uniq_id FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE channel_id = "+ channelID +" AND measure = 'ai' AND " +
				" (tstamp >= '"+ trackerStartTime +"' AND tstamp <= '"+ trackerEndTime +"') " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SQL Query To Get Uniq ID For Third Party Tracker Calculation: " +sqlQueryForUniqID);

		return sqlQueryForUniqID;

	}


	/** This method will return the query to get third party click tracker.
	 * 
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param uniq_id
	 * @return
	 */
	public static String queryForThirdPartyClickTracker(String trackerStartTime, String trackerEndTime, String uniq_id)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Time End For Third Party Tracker Calculation: " +trackerEndTime);

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String QueryForThirdPartyClickTracker = 	" SELECT IFNULL(event_info, '0'), IFNULL(ref_url, '0') " +
				" FROM [bigquery_processed.event_log_daily_"+timeStamp+"] " +
				" WHERE event_type = 'rdu' AND uniq_id = '"+ uniq_id +"' AND " + 
				" (tstamp >= '"+ trackerStartTime +"' AND tstamp <= '"+ trackerEndTime +"') " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SQL Query For Third Party Tracker Validation: " +QueryForThirdPartyClickTracker);
		return QueryForThirdPartyClickTracker;
	}


	/** This method will return the query to get third party impression tracker.
	 * 
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param uniq_id
	 * @return
	 */
	public static String queryForThirdPartyImpressionTracker(String trackerStartTime, String trackerEndTime, String uniq_id)
	{

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Time End For Third Party Tracker Calculation: " +trackerEndTime);

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String QueryForThirdPartyImpressionTracker = 	" SELECT IFNULL(event_info,'0'), IFNULL(ref_url, '0') " +
				" FROM [bigquery_processed.event_log_daily_"+timeStamp+"] " +
				" WHERE event_type = 'ttu' AND uniq_id = '"+ uniq_id +"' AND " + 
				" (tstamp >= '"+ trackerStartTime +"' AND tstamp <= '"+ trackerEndTime +"') " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SQL Query For Third Party Tracker Validation: " +QueryForThirdPartyImpressionTracker);
		return QueryForThirdPartyImpressionTracker;
	}


	/** Query to get source from big query table: ad_log_5_minute_files_batch_daily_<> 
	 * 
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param channelID
	 * @param campaignID
	 * @return
	 */
	public static String queryToGetSource(String trackerStartTime, String trackerEndTime, String channelID, String campaignID)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Time End For source Calculation: " +trackerEndTime);

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String subQuery = "";

		if(campaignID == null)
		{
			subQuery = "";
		}
		else if(campaignID.trim().isEmpty())
		{
			subQuery = "";
		}
		else
		{
			subQuery = " campaign_id = " + campaignID + " AND ";
		}

		String bqQueryForSource = " SELECT source FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE "+ subQuery + " (tstamp >= '"+ trackerStartTime +"' AND tstamp <= '"+ trackerEndTime +"')  " +
				" AND channel_id = "+channelID +" LIMIT 1; " ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SQL Query To Get Source " +bqQueryForSource);

		return bqQueryForSource;
	}


	/**
	 * Query to get container size from big query table: ad_log_5_minute_files_batch_daily_<>
	 * @param trackerStartTime
	 * @param trackerEndTime
	 * @param channelID
	 * @param campaignID
	 * @return
	 */
	public static String queryToGetContainer_size(String trackerStartTime, String trackerEndTime, String channelID, String campaignID)
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Time End For container_size Calculation: " +trackerEndTime);

		String timeStamp = MobileTestClass_Methods.DateTimeStamp("yyyyMMdd");

		String subQuery = "";

		if(campaignID == null)
		{
			subQuery = "";
		}
		else if(campaignID.trim().isEmpty())
		{
			subQuery = "";
		}
		else
		{
			subQuery = " campaign_id = " + campaignID + " AND ";
		}

		String bqQueryForSource = " SELECT container_size FROM [bigquery_processed.ad_log_5_minute_files_batch_daily_"+timeStamp+"] " + 
				" WHERE "+ subQuery + " (tstamp >= '"+ trackerStartTime +"' AND tstamp <= '"+ trackerEndTime +"')  " +
				" AND channel_id = "+channelID +" AND measure = 'cst' and source = 'marketplace'" ;

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : SQL Query To get container size " +bqQueryForSource);

		return bqQueryForSource;
	}
	
	/**
	 * This method will return the BQ query to get the price of winning category    
	 * @param partnerID
	 * @return
	 */
	public static String queryToGetWinningCategoryPrice(int partnerID)
	{
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String strDate = sdfDate.format(date);
	    
	    String query =  "SELECT (sum(qualifiedcategorycost)/sum(impressions))*1000 AS category_cost FROM " 
	    + "[qa-bigquery:reporting_audience_views.stats_aggregated_"+strDate+"] WHERE category = qualified_category and provider_id="+partnerID;
	    
		return query;
	}
}
