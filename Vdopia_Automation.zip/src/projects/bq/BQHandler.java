/**
 * Last Changes Done on 27 May, 2015 2:46:12 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: This class will handle all the big query actions
 */
package projects.bq;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson.JacksonFactory;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.BigqueryScopes;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.Job;
import com.google.api.services.bigquery.model.JobConfiguration;
import com.google.api.services.bigquery.model.JobConfigurationQuery;
import com.google.api.services.bigquery.model.JobReference;
import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import java.io.File;
import java.util.Arrays;
import java.util.List;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import vlib.MobileTestClass_Methods;




// TODO: Auto-generated Javadoc
public class BQHandler 
{

	Logger logger = Logger.getLogger(BQHandler.class.getName());


	/** This is a sample test for bq methods
	 */
	@Test
	public static void TestBq() 
	{
		MobileTestClass_Methods.InitializeConfiguration();
		String projectID = MobileTestClass_Methods.propertyConfigFile.getProperty("prodBigQueryProjectId").toString();

		Bigquery bigQueryConnection = new BQHandler().createBqConnection();

		//Datasets.List datasetRequest = bigquery.datasets().list("qa-bigquery");
		//DatasetList datasetList = datasetRequest.execute();
		//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : %s\n", datasetList.toPrettyString());

		//Start a Query Job
		//String querySql = "SELECT id FROM [Hudson_Live.hudson_bidder_log_20150415] LIMIT 1;";

		//String querySql = "SELECT id, timestamp FROM [Hudson_Live.hudson_bidder_log_20150415] where timestamp < (Select NOW()) LIMIT 10;";

		String querySql = "Select NOW() as CurrentDateTime, 'Test' ;";

		//Poll for Query Results, return result output
		GetQueryResultsResponse queryResult = new BQHandler().getBQResults(bigQueryConnection, projectID, querySql);

		//Return and display the results of the Query Job
		new BQHandler().displayBQResults(bigQueryConnection, queryResult);
		new BQHandler().get1DArrayFromBQResults(queryResult);
	}


	/** This method returns the big query connection.
	 * 
	 * @return
	 */
	public Bigquery createBqConnection()
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Creating big query connection..");

		GoogleCredential credential;
		Bigquery bqConnection = null;
		HttpTransport TRANSPORT = new NetHttpTransport();
		JsonFactory JSON_FACTORY = new JacksonFactory();
		List<String> SCOPES = Arrays.asList(BigqueryScopes.BIGQUERY);

		try 
		{
			/** Getting current test environment */
			String currentEnv = MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString().trim();

			/** Get .p12 file from tpt
			 * service account id for qa = 772198872067-s9ic0ifunckb1kblg66r260s9is5vahm@developer.gserviceaccount.com
			 */
			String p12File;
			String serviceAccountId;
			if(currentEnv.equalsIgnoreCase("qa"))
			{
				p12File = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/bq/qa/qa-bigquery-a2af0988a50b.p12");
				serviceAccountId = MobileTestClass_Methods.propertyConfigFile.getProperty("qaBigQueryServiceAccountId").toString().trim();
			}
			else
			{
				p12File = TestSuiteClass.AUTOMATION_HOME.concat("/tpt/bq/prod/Reporting-d7b4a85dc2e7.p12");
				serviceAccountId = MobileTestClass_Methods.propertyConfigFile.getProperty("prodBigQueryServiceAccountId").toString().trim();
			}

			credential = new GoogleCredential.Builder().setTransport(TRANSPORT)
					.setJsonFactory(JSON_FACTORY)
					.setServiceAccountId(serviceAccountId)
					.setServiceAccountScopes(SCOPES)
					.setServiceAccountPrivateKeyFromP12File(new File(p12File))
					.build();

			/** Creating the Big query Connection Object, .setApplicationName("executeBiqQuery") was .setApplicationName("qa-bigquery")  
			 */
			bqConnection = new Bigquery.Builder(TRANSPORT, JSON_FACTORY, credential)
			.setApplicationName("executeBiqQuery")
			.setHttpRequestInitializer(credential).build();

		} 
		catch (Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while creating big query connection. ", e);
		}
		return bqConnection;
	}


	/**
	 * Polls the status of a BigQuery job, returns Job reference if "Done".
	 * 
	 * @param bqConnection
	 * @param bqProjectID
	 * @param sqlQuery
	 * @return
	 */
	public GetQueryResultsResponse getBQResults(Bigquery bqConnection, String bqProjectID, String sqlQuery)
	{
		Job pollJob = null;
		GetQueryResultsResponse queryResult = null;
		try
		{
			// Variables to keep track of total query time
			long startTime = System.currentTimeMillis();
			long elapsedTime;
			JobReference jobId = executeBigQuery(bqConnection, bqProjectID, sqlQuery);

			while (true) 
			{
				pollJob = bqConnection.jobs().get(bqProjectID, jobId.getJobId()).execute();
				elapsedTime = System.currentTimeMillis() - startTime;
				String status = pollJob.getStatus().getState();

				logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Job status: " + elapsedTime + ", " +jobId.getJobId() + ", " + status);

				if (status.equalsIgnoreCase("DONE")) 
				{	
					queryResult = bqConnection.jobs()
							.getQueryResults(
									bqProjectID, pollJob
									.getJobReference()
									.getJobId()
									).execute();

					return queryResult;
				}

				/** Pause execution for one second before polling job status again, 
				 * to reduce unnecessary calls to the BigQUery API and lower overall 
				 * application bandwidth.
				 */
				Thread.sleep(500);
			}
		}
		catch(GoogleJsonResponseException g)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Check the supplied query. ");
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while checking query results. ", e);
		}
		return queryResult;
	}


	/**
	 * Creates a Query Job for a particular query on a data set.
	 * 
	 * @param bigquery
	 * @param projectId
	 * @param querySql
	 * @return a reference to the inserted query job
	 */
	public JobReference executeBigQuery(Bigquery bigquery, String projectId, String querySql)
	{
		JobReference jobId = null;
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Inserting Query Job: "+ querySql);

			Job job = new Job();
			JobConfiguration config = new JobConfiguration();
			JobConfigurationQuery queryConfig = new JobConfigurationQuery();
			config.setQuery(queryConfig);

			job.setConfiguration(config);
			queryConfig.setQuery(querySql);

			com.google.api.services.bigquery.Bigquery.Jobs.Insert insert = bigquery.jobs().insert(projectId, job);
			insert.setProjectId(projectId);
			jobId = insert.execute().getJobReference();

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Job ID of Query Job is: " + jobId.getJobId());
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while starting the query. ", e);
		}
		return jobId;
	}


	/**
	 * Print query results to console.
	 * 
	 * @param bigquery
	 * @param queryResult
	 */
	private void displayBQResults(Bigquery bigquery, GetQueryResultsResponse queryResult)  
	{

		String [][] records = null;

		try
		{
			List<TableFieldSchema> columns  = queryResult.getSchema().getFields();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Table Field Schema: "+columns.toString());

			java.util.List<TableRow> rows = queryResult.getRows();

			/** size of List<TableFieldSchema> list is number of columns in result
			 * size of List<TableRow> rows is number of rows in result
			 */
			records = new String[rows.size()][columns.size()];


			if (rows != null) 
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Query Results Rows: "+rows.size());
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Total Records List: "+rows.toString());

				/** Iterating each row of query result  */
				for (int i=0; i<=rows.size()-1; i++) 
				{

					/** each row is in json format, get the string 
					 * and create the json object of that string and get json array of element f 
					 */
					String strRow = rows.get(i).toString();
					JSONObject jsonObj = new JSONObject(strRow);
					JSONArray jsonArray = jsonObj.getJSONArray("f");


					/** Iterating each column of query result ~~~ equivalent to iterating above json array 
					 */
					for(int j=0; j<jsonArray.length(); j++)
					{
						/** value is again a json */
						String jsonArrayValue = jsonArray.getString(j);

						JSONObject jsonValue = new JSONObject(jsonArrayValue);

						String value = jsonValue.getString("v");

						records[i][j] = value;

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : JSON Array: "+value);
					}

				}


				//				for (TableRow row : rows) 
				//				{
				//					for (TableCell field : row.getF()) 
				//					{
				//						logger.info(field.getV());
				//					}
				//				}
			}
		}
		catch(NullPointerException n)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : No record found. ");
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
	}


	/**
	 * This method will convert the GetQueryResultsResponse into 2D array.
	 * 
	 * @param queryResult
	 * @return
	 */
	public String[][] get2DArrayFromBQResults(GetQueryResultsResponse queryResult)
	{
		String [][] records = null;

		try
		{
			List<TableFieldSchema> columns  = queryResult.getSchema().getFields();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received Table Field Schema: "+columns.toString());

			java.util.List<TableRow> rows = queryResult.getRows();

			if (rows != null) 
			{
				/** size of List<TableFieldSchema> list is number of columns in result
				 * size of List<TableRow> rows is number of rows in result
				 */
				records = new String[rows.size()][columns.size()];

				/** Iterating each row of query result  */
				for (int i=0; i<=rows.size()-1; i++) 
				{
					/** each row is in json format, get the string 
					 * and create the json object of that string and get json array of element f 
					 */
					String strRow = rows.get(i).toString();
					JSONObject jsonObj = new JSONObject(strRow);
					JSONArray jsonArray = jsonObj.getJSONArray("f");

					/** Iterating each column of query result ~~~ equivalent to iterating above json array 
					 */
					for(int j=0; j<jsonArray.length(); j++)
					{
						/** json array contains each element as json string therefore each json element
						 * also needs to be parsed as json object and get the actual value of node v
						 */
						String jsonArrayValue = jsonArray.getString(j);
						JSONObject jsonValue = new JSONObject(jsonArrayValue);

						String value = jsonValue.getString("v");
						records[i][j] = value;
					}
				}
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while converting big query results into 2D array. ", t);
		}

		return records;
	}


	/**
	 * This method will convert the GetQueryResultsResponse into 1D array.
	 * 
	 * @param queryResult
	 * @return
	 */
	public String[] get1DArrayFromBQResults(GetQueryResultsResponse queryResult)
	{
		String [] records = null;

		try
		{
			List<TableFieldSchema> columns  = queryResult.getSchema().getFields();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received Table Field Schema: "+columns.toString());

			java.util.List<TableRow> rows = queryResult.getRows();

			/** size of List<TableFieldSchema> list is number of columns in result
			 */
			records = new String[columns.size()];

			if (rows != null) 
			{
				/** each row is in json format, get the string 
				 * and create the json object of that string and get json array of element f 
				 */
				String strRow = rows.get(0).toString();
				JSONObject jsonObj = new JSONObject(strRow);
				JSONArray jsonArray = jsonObj.getJSONArray("f");

				/** Iterating each column of query result ~~~ equivalent to iterating above json array 
				 */
				for(int j=0; j<jsonArray.length(); j++)
				{
					/** json array contains each element as json string therefore each json element
					 * also needs to be parsed as json object and get the actual value of node v
					 */
					String jsonArrayValue = jsonArray.getString(j);
					JSONObject jsonValue = new JSONObject(jsonArrayValue);

					String value = jsonValue.getString("v");
					records[j] = value;
				}
			}
		}
		catch(Exception t)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while converting big query results into 2D array. ", t);
		}

		return records;
	}

} 