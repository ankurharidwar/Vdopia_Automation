
package projects.grid;

import java.net.URL;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.mysql.jdbc.Connection;

import projects.TestSuiteClass;
import vlib.ExecuteCommands;
import vlib.IntegerLib;
import vlib.MobileTestClass_Methods;


public class GridLib {

	Logger logger = Logger.getLogger(GridLib.class.getName());


	public static void main(String [] args)
	{

	}


	/** if both hub and node are running then only distribute traffic  
	 * 
	 * @param connection
	 * @return
	 */
	public boolean ifForwardTraffic(Connection connection)
	{
		return new HubSetupLib().ifHubRunning_CheckInHubMachine() && new NodeSetupLib().ifNodeRunning(connection);
	}


	/** Return Grid Driver
	 * 
	 * @return
	 */
	public WebDriver setupGridChromeBrowser() 
	{
		WebDriver driver = null;
		try
		{
			Thread.sleep(IntegerLib.GetRandomNumber(3000, 1000));

			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setBrowserName("chrome");

			String hubIpAddress = ExecuteCommands.ExecuteMacCommand_ReturnsOutput("ipconfig getifaddr en1");
			driver = new RemoteWebDriver(new URL("http://"+hubIpAddress+":4444/wd/hub"), cap);

			/** setting up implicit driver delay */
			int driverImplicitDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("driverImplicitDelay").toString());
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(driverImplicitDelay, TimeUnit.SECONDS);

			/** trial page */
			driver.get("http://www.google.com?"+new Date().getTime());
			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+ " : " + " Grid Browser Launched ... ");
		}catch(Exception e)
		{
			driver = null;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " +e.getMessage(), e);
		}

		return driver;
	}



}


