package projects.grid;

import java.net.InetAddress;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import com.mysql.jdbc.Connection;

import projects.TestSuiteClass;
import vlib.DBLib;
import vlib.ExecuteCommands;
import vlib.MobileTestClass_Methods;
import vlib.httpClientWrap;

public class HubSetupLib {

	Logger logger = Logger.getLogger(HubSetupLib.class.getName());


	@Test
	public void launchConfig()
	{
		MobileTestClass_Methods.InitializeConfiguration();
		startSeleniumGridHub(MobileTestClass_Methods.CreateServeSQLConnection());
	}


	/** Kill hub 
	 * 
	 * @return
	 */
	public boolean shutdownSeleniumGridHub(Connection connection)
	{
		if(!System.getProperty("os.name").matches("^Windows.*"))
		{
			ExecuteCommands.ExecuteMacCommand_ReturnsExitStatus("lsof -t -i :4444 | xargs kill");
			new DBLib().executeUpdateInsertQuery(connection, "truncate table gridstatus");
		}
		return true;
	}


	/** start selenium grid - remember to start with & background and find a parameter for timeout
	 * @param connection
	 * @return
	 */
	public boolean startSeleniumGridHub(Connection connection)
	{		
		try
		{
			/** run selenium grid only if config is set to yes */
			if(MobileTestClass_Methods.propertyConfigFile.getProperty("useGridConfiguration").toString().trim().equalsIgnoreCase("yes"))
			{
				boolean flagStarted = false;

				/** get ipadress of mac - using command java is giving machine name not ip - which will always be mac */
				String ipAddressHub = ExecuteCommands.ExecuteMacCommand_ReturnsOutput("ipconfig getifaddr en1");

				ipAddressHub = InetAddress.getLocalHost().getHostAddress();
				logger.info("Mac - hub address: "+ipAddressHub);

				if(ifHubRunning_CheckInHubMachine())
				{
					flagStarted = true;
					logger.info(" Grid Hub Was Already Running ... ");
				}
				else
				{
					/** truncate table */
					new DBLib().executeUpdateInsertQuery(connection, "truncate table gridstatus");

					/** first kill any running server */
					shutdownSeleniumGridHub(connection);

					/** start hub */
					String command ="java -jar "+ TestSuiteClass.AUTOMATION_HOME + "/tpt/selenium-server/selenium-server-standalone-2.53.0.jar -role hub "
							+ " -hubConfig "+ TestSuiteClass.AUTOMATION_HOME + "/tpt/selenium-server/hubConfig.json &";
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID + " : " + " Running command for hub: "+command);

					ExecuteCommands.ExecuteMacCommand_ReturnsExitStatus(command);

					int maxAttempt = 0;
					int httpStatusCode = 0;
					while(httpStatusCode != 200 && maxAttempt < 10)
					{
						Thread.sleep(3000);
						try{httpStatusCode = ((int)httpClientWrap.sendGetRequest_GetStatusLine("http://"+ipAddressHub+":4444/grid/console?config=true&configDebug=true#").get("statuscode"));}
						catch(Exception e){}

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : Starting Grid Hub --- status code: "+httpStatusCode);

						maxAttempt ++;
					}

					if(httpStatusCode == 200){
						flagStarted = true;
					}
				}

				/** update db */
				updateDB_HubStatus(connection, flagStarted);
				return true;
			}
			else
			{
				logger.info(" Grid Hub not starting as directed by config .... ");
				return false;
			}
		}catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : " +e.getMessage(), e);
			return false;
		}
	}


	/** Check if hub is running -- considering hub will always run on mac machine 
	 * 
	 * @param connection
	 * @return
	 */
	public boolean ifHubRunning_CheckInHubMachine()
	{
		try
		{
			String ipAddressHub = InetAddress.getLocalHost().getHostAddress();
			//ExecuteCommands.ExecuteMacCommand_ReturnsOutput("ipconfig getifaddr en1");

			String hubUrl = "http://"+ipAddressHub+":4444/grid/console?config=true&configDebug=true#";

			int httpStatusCode = ((Integer)httpClientWrap.sendGetRequest_GetStatusLine(hubUrl).get("statuscode"));

			if(httpStatusCode == 200)
			{
				return true;	
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+":"+" hub is not running, hub url: "+hubUrl + " and status code: "+httpStatusCode);
				return false;	
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : "+e.getMessage(), e);
			return false;
		}
	}


	/** Check if hub is running -- considering hub will always run on mac machine 
	 * 
	 * @param connection
	 * @return
	 */
	public boolean ifHubRunning_CheckInNodeMachine(Connection connection)
	{
		try
		{
			String sql = "select IFNULL(hub_url,'') AS hub_url, IFNULL(node_url,'') AS node_url "
					+ " from gridstatus where hub_status = 'active' order by date desc limit 1; ";
			HashMap<String, String> dbMap = new DBLib().getDBInformationMap(connection, sql);

			/** in case of no entry in db for any active hub */
			if(dbMap.isEmpty())
			{
				return false;
			}
			else
			{
				String ipAddressHub = dbMap.get("hub_url");
				String hubUrl = ipAddressHub+"/grid/console?config=true&configDebug=true#";

				int httpStatusCode = ((Integer)httpClientWrap.sendGetRequest_GetStatusLine(hubUrl).get("statuscode"));

				if(httpStatusCode == 200)
				{
					return true;	
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID+":"+" hub is not running, hub url: "+hubUrl + " and status code: "+httpStatusCode);
					return false;	
				}
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID+" : "+e.getMessage(), e);
			return false;
		}
	}


	/**
	 * update db with hub values 
	 * 
	 * @param connection
	 * @return
	 */
	public boolean updateDB_HubStatus(Connection connection, boolean flagStarted)
	{
		boolean flag = false;

		try
		{
			/** get ipadress of mac - using command java is giving machine name not ip - which will always be mac */
			String ipAddressHub  = InetAddress.getLocalHost().getHostAddress();
			//ExecuteCommands.ExecuteMacCommand_ReturnsOutput("ipconfig getifaddr en1");

			/** set status in gridstatus table; - truncate table if hub is not up */
			if(!flagStarted){
				new DBLib().executeUpdateInsertQuery(connection, "truncate table gridstatus");
			}else{
				/** running insert and update both - in case for the first there won't be any entry */
				new DBLib().executeUpdateInsertQuery(connection, "insert into gridstatus (hub_url, node_register_url, hub_status) "
						+ " values ('http://"+ipAddressHub+":4444', 'http://"+ipAddressHub+":4444/grid/register/','active');");

				new DBLib().executeUpdateInsertQuery(connection, "update gridstatus set hub_url = 'http://"+ipAddressHub+":4444', node_register_url= 'http://"+ipAddressHub+":4444/grid/register/', hub_status='active' ");
			}

			flag = true;
		}catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}

		return flag;
	}


}
