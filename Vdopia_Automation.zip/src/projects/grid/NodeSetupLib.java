package projects.grid;

import java.net.Inet4Address;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import com.mysql.jdbc.Connection;

import projects.TestSuiteClass;
import vlib.DBLib;
import vlib.FileLib;
import vlib.MobileTestClass_Methods;
import vlib.httpClientWrap;


public class NodeSetupLib {

	Logger logger = Logger.getLogger(NodeSetupLib.class.getName());


	@Test
	public void launchConfig()
	{
		MobileTestClass_Methods.InitializeConfiguration();
		setupSeleniumGridNode(MobileTestClass_Methods.CreateServeSQLConnection());
	}


	/** Start selenium grid node
	 * 
	 * @param connection
	 * @return
	 */
	public boolean setupSeleniumGridNode(Connection connection)
	{
		try
		{
			String sql = "select id, IFNULL(hub_url,'') AS hub_url, IFNULL(node_url,'') AS node_url, IFNULL(node_register_url, '') AS node_register_url "
					+ " from gridstatus where hub_status = 'active' order by date desc limit 1; ";

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : running sql -- "+sql);

			HashMap<String, String> dbMap = new DBLib().getDBInformationMap(connection, sql);

			/** set up node when there is an active hub and no node_url in db */
			if(new HubSetupLib().ifHubRunning_CheckInNodeMachine(connection)){
				String node_register_url = dbMap.get("node_register_url");

				/** creating bat to be executed on windows to start node  */
				cmd_startSeleniumNode(node_register_url);

				String ipAddressNode = Inet4Address.getLocalHost().getHostAddress();
				String node_url = "http://"+ipAddressNode+":5555";

				/** update table with node url */
				new DBLib().executeUpdateInsertQuery(connection, "update gridstatus set node_url ='"+node_url+"' ;");
				TestSuiteClass.ifNodeRunning = true;
				return true;
			}else{

				/** if node is not running then shutdown node */
				cmd_shutdownSeleniumGridNode();

				return false;
			} 
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +  ":" + e.getMessage(), e);
			return false;
		}
	}


	/** return command to start node server
	 * 
	 * @param node_register_url
	 * @return
	 */
	public boolean cmd_startSeleniumNode(String node_register_url)
	{
		try
		{
			/** to be executed on windows */
			String command = "java -jar "+ TestSuiteClass.AUTOMATION_HOME.replace("/D", "D") + "\\tpt\\selenium-server\\selenium-server-standalone-2.53.0.jar "
					+ " -role node -hub "+ node_register_url + " -nodeConfig " + TestSuiteClass.AUTOMATION_HOME.replace("/D", "D") + "\\tpt\\selenium-server\\nodeConfig.json "
					+ " -Dwebdriver.chrome.driver="+TestSuiteClass.AUTOMATION_HOME.replace("/D", "D")+"\\tpt\\chromedriver.exe ";

			FileLib.WriteTextInFile(TestSuiteClass.AUTOMATION_HOME.replace("/D", "D")+"\\tpt\\selenium-server\\node-server-setup.bat", command);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() + " : "+ " Starting node via - "+command);
			return true;
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
			return false;
		}
	}

	/** Shut down node server
	 * 
	 * @param connection
	 * @return
	 */
	public boolean cmd_shutdownSeleniumGridNode()
	{
		try
		{			
			String command = " FOR /F \"tokens=5 delims= \" %P IN ('netstat -a -n -o ^| findstr :5555') DO TaskKill.exe /F /PID %P ";
			FileLib.WriteTextInFile(TestSuiteClass.AUTOMATION_HOME.replace("/D", "D")+"\\tpt\\selenium-server\\node-server-setup.bat", command);

			return true;
		}catch(Exception e)
		{
			return false;
		}
	}


	/** this method checks if any node is registered to hub and running  
	 * Sample URL: http://192.168.1.3:4444/grid/api/proxy?id=http://192.168.1.3:5555
	 * @param connection
	 * @return
	 */
	public boolean ifNodeRunning(Connection connection)
	{
		try
		{
			String sql = "select IFNULL(hub_url,'') AS hub_url, IFNULL(node_url,'') AS node_url "
					+ " from gridstatus where hub_status = 'active' order by date desc limit 1; ";
			HashMap<String, String> dbMap = new DBLib().getDBInformationMap(connection, sql);

			if(!dbMap.isEmpty())
			{
				String nodeURL = dbMap.get("node_url");

				if(!nodeURL.isEmpty())
				{
					int statuscode = 0;
					try{statuscode = (int) httpClientWrap.sendGetRequest_GetStatusLine(nodeURL).get("statuscode");}catch(Exception e){}

					if(statuscode == 403)
					{
						return true;
					}
					else
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +":"+" node: " + nodeURL+ " not running ... ");
						return false;	
					}
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +":"+" no node url found in gridstatus table ... ");
					return false;
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get() +":"+" no active hub entry found in gridstatus table ... ");
				return false;
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get() +" : "+e.getMessage(), e);
			return false;
		}
	}

}
