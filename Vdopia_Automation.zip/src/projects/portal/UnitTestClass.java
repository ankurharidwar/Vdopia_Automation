package projects.portal;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.testng.annotations.Test;

public class UnitTestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	public void test1()
	{
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");//dd/MM/yyyy
		Date date = new Date();
		String strDate = sdfDate.format(date);
		System.out.println(strDate);
	}

	@Test
	public void test2()
	{
		try
		{
			List<TestCaseObjects> list = new ReadTestCases()
					.getRunnableTestCaseObjects("/Users/Pankaj/Desktop/qaAutomation/qascripting/Vdopia_Automation/tc_cases/transformerportal/Test_Cases_Transformer_main.xls");

			for(TestCaseObjects x : list)
			{
				
				System.out.println(x.getTestCaseId() + "=" + x.getIfTestCaseQueued());
				
				List<TestStepObjects> xy = x.gettestStepObjectsList();
				for (TestStepObjects ts : xy)
				{
					System.out.println(ts.getTestCaseId() + "-"+ts.getTestStepId()+"-"+ts.getKeyword()+"-"+ts.getObjectName()+"-"+ts.getData());
				}
			}
			

			//			for(new LoadTestStepObjects() : map)
			//			{
			//				System.out.println(m.getKey());
			//
			//				List<LoadTestStepObjects> list = m.getValue();
			//
			//				for(int i=0; i<list.size(); i++)
			//				{
			//					LoadTestStepObjects g = list.get(i);
			//
			//					System.out.println(g.getTestCaseId() + "--" + g.getTestStepId()+ "--"+ g.getKeyword()+"--"+g.getObjectName()+"--"+g.getData());
			//				}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


}
