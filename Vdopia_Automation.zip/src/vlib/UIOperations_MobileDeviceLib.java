/**
 * Last Changes Done on Feb 5, 2015 12:46:36 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;


//import io.selendroid.SelendroidCapabilities;
//import io.selendroid.SelendroidConfiguration;
//import io.selendroid.SelendroidDriver;
//import io.selendroid.SelendroidLauncher;
//import io.selendroid.exceptions.TimeoutException;

import io.selendroid.client.*;
import io.selendroid.common.*;
import io.selendroid.standalone.SelendroidConfiguration;
import io.selendroid.standalone.SelendroidLauncher;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Point;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.UnsupportedCommandException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;





import com.google.api.services.bigquery.Bigquery;


// TODO: Auto-generated Javadoc
public class UIOperations_MobileDeviceLib 
{

	static Logger logger = Logger.getLogger(UIOperations_MobileDeviceLib.class.getName());

	static String adFormat;

	static int bannerDelay;
	static int nonBannerDelay;
	static int adWait;
	static String campaignID;
	static String channelID;
	static String trackerStartTime; 
	static int testDuration;
	static String adsByText;
	static String learnMoreText;


	/**
	 * 
	 * 
	 * @param adFormat
	 * @param adWait
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 */
	public UIOperations_MobileDeviceLib(String adFormat, int adWait, String campaignID, String channelID, String trackerStartTime)
	{
		UIOperations_MobileDeviceLib.adFormat = adFormat;
		UIOperations_MobileDeviceLib.adWait = adWait;
		UIOperations_MobileDeviceLib.campaignID = campaignID;
		UIOperations_MobileDeviceLib.channelID = channelID;
		UIOperations_MobileDeviceLib.trackerStartTime = trackerStartTime;

		testDuration = 30;

		//initializing configuration to get the variables from Config File
		MobileTestClass_Methods.InitializeConfiguration();

		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
	}


	/**
	 * 
	 * 
	 * @param adFormat
	 * @param adWait
	 * @param campaignID
	 * @param channelID
	 * @param trackerStartTime
	 * @param adsByText
	 * @param learnMoreText
	 */
	public UIOperations_MobileDeviceLib(String adFormat, int adWait, String campaignID, String channelID, String trackerStartTime, String adsByText, String learnMoreText)
	{
		UIOperations_MobileDeviceLib.adsByText = adsByText;
		UIOperations_MobileDeviceLib.learnMoreText = learnMoreText;
		UIOperations_MobileDeviceLib.adFormat = adFormat;
		UIOperations_MobileDeviceLib.adWait = adWait;
		UIOperations_MobileDeviceLib.campaignID = campaignID;
		UIOperations_MobileDeviceLib.channelID = channelID;
		UIOperations_MobileDeviceLib.trackerStartTime = trackerStartTime;

		testDuration = 30;

		/** initializing configuration to get the variables from Config File */
		MobileTestClass_Methods.InitializeConfiguration();

		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
	}


	/**
	 * Checking if connection can be established with the supplied comma separated iphone ip(s).
	 * 
	 * @param iphoneIPs
	 * @return
	 */
	public static boolean ifiPhoneConnected(String iphoneIPs)
	{
		boolean iphoneDeviceConnected = false;

		try
		{
			if(iphoneIPs.equalsIgnoreCase("")) 
			{
				iphoneDeviceConnected = false;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Please Enter iphoneIPPort. ");

				return iphoneDeviceConnected;
			}
			String[] iphoneIPCollection = StringLib.StrSplit(iphoneIPs,",");
			for (String iphoneIPPort : iphoneIPCollection) 
			{
				//if Device IP is not blank then check If IP is valid or not
				if(UIOperations_MobileDeviceLib.getiPhoneDriver(iphoneIPPort) != null)
				{
					iphoneDeviceConnected = true;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : iphone device is found having iphone IP&Port: " +iphoneIPPort);
					return iphoneDeviceConnected;
				}
			}
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : no iphone connectivity found. ");
			iphoneDeviceConnected = false;
		}
		return iphoneDeviceConnected;
	}


	/** Check if there is any ipad connected to desktop.
	 * 
	 * @return
	 */
	public static boolean ifiPadConnected()
	{
		if(getUDID_iPad().isEmpty())
		{
			return false;
		}
		else
		{
			return true;
		}
	}


	/** Check if there is any iphone connected to desktop.
	 * 
	 * @return
	 */
	public static boolean ifiPhoneConnected()
	{
		if(getUDID_iPhone().isEmpty())
		{
			return false;
		}
		else
		{
			return true;
		}
	}


	/**
	 * Checking if any connected Android device.
	 * 
	 * @return
	 */
	public static boolean ifAndroidDeviceConnected()
	{
		try
		{
			List<String> androidDeviceList = UIOperations_MobileDeviceLib.getAndroidDeviceList();
			boolean androidDeviceConnected;

			if(!(androidDeviceList.size()==0))
			{
				androidDeviceConnected = true;
			}
			else
			{
				androidDeviceConnected = false;
			}

			return androidDeviceConnected;
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: CheckIfAndroidConnected. ", e);
			return false;
		}

	}


	/** This method will execute terminal command and find out UDID of attached iphone.
	 * 
	 * @return
	 */
	public static List<String> getUDID_iPhone() 
	{
		List<String> udid = new ArrayList<>();
		try
		{
			String commandToGetUDID = "system_profiler SPUSBDataType | sed -n '/iPhone/,/Serial/p' | grep \"Serial Number:\" | awk -F \": \" '{print $2}'";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Command to get UDID of an attached iPhone: " +commandToGetUDID);

			String output = ExecuteCommands.ExecuteMacCommand_ReturnsOutput(commandToGetUDID);

			if(!(output.equalsIgnoreCase("")))
			{
				udid = Arrays.asList(output.trim().split("\n")); 
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Obtained UDID of attached iPhone(s): " +udid.toString());
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Couldn't obtained UDID of attached iPhone, Plz see if there is actually any device attached to this MAC. ");
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: GetUDID_iPhone", e);
		}
		return udid;
	}


	/**
	 * This method will execute terminal command and find out UDID of attached ipad.
	 * 
	 * @return
	 */
	public static List<String> getUDID_iPad() 
	{
		List<String> udid = new ArrayList<String>();

		try
		{
			String commandToGetUDID = "system_profiler SPUSBDataType | sed -n '/iPad/,/Serial/p' | grep \"Serial Number:\" | awk -F \": \" '{print $2}'";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Command to get UDID of an attached iPad: " +commandToGetUDID);

			String output = ExecuteCommands.ExecuteMacCommand_ReturnsOutput(commandToGetUDID).trim();

			if(output.equalsIgnoreCase(""))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Couldn't obtained UDID of attached iPad, Plz see if there is actually any device attached to this MAC. ");
			}
			else
			{
				udid = Arrays.asList(output.trim().split("\n"));
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Obtained UDID of attached iPad: " +udid.toString());
			}
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking connected ipad", e);
		}
		return udid;
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @throws InterruptedException
	 */
	public static void clickOnMobileVideoScreen(WebDriver driver) throws InterruptedException 
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operaton will be performed on video screen.");

		String winHandleBefore;
		String initialUrl = null;

		//Click on running video to pause it.
		try
		{
			WebElement vdoRunning = driver.findElement(By.id("vdoPreloaded"));
			//WebElement vdoRunning = driver.findElement(By.xpath("//video[@id='vdoSnd']"));

			//Store the current window handle
			winHandleBefore = driver.getWindowHandle();

			initialUrl = driver.getCurrentUrl();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);

			vdoRunning.click();		//Perform the click operation that opens new window
			Thread.sleep(2000);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Driver Type: " +driver.toString() );

			if(driver.toString().toLowerCase().contains("android"))
			{
				//				for(String winHandle : driver.getWindowHandles())
				//				{
				//					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Going to Window handle: " + winHandle);
				//					//if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
				//					//{
				//					driver.switchTo().window(winHandle);
				//					Thread.sleep(2000);
				//					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
				//					driver.close();
				//					driver.switchTo().window(winHandleBefore);
				//					//break;
				//					//}
				//				}
			}
			else if (driver.toString().toLowerCase().contains("iphone"))
			{
				if (!(driver.getCurrentUrl().matches(initialUrl)))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url opened is: " + driver.getCurrentUrl());

					driver.switchTo().window(winHandleBefore);
					//driver.navigate().to(initialUrl);
				}
			}			
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Undefined Driver, Need to be implemented");
			}

		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickOnMobileVideoScreen. Click operation on video is unsuccessful. Error message is: " + e.getMessage());		
		}
	}


	/**
	 * 
	 * 
	 * @param driver
	 */
	public static void muteUnmuteVideoOnMobileScreen(WebDriver driver) 
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("soundimg")));

			WebElement btnMute = driver.findElement(By.id("soundimg"));

			boolean stat = btnMute.isDisplayed();

			if(stat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Ad Mute / Unmute button is displayed");

				/** If unmute button is displayed then touch it */
				if(btnMute.getAttribute("style").contains("left: 0px;"))
				{
					/** Use touch in case of android, in case of iphone: execute js to simulate touch */
					if(driver.toString().contains("selendroid"))
					{
						Thread.sleep(2000);
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Touch to unmute ... ");
						TouchActions flick = new TouchActions(driver).flick(btnMute, -100, 0, 0);
						flick.perform();
					}
					else
					{
						((JavascriptExecutor)driver).executeScript(getMuteUnmuteJsForiPhone("video", ""));
					}
				}

				Thread.sleep(3000);

				/** If mute button is displayed then touch that */
				if(btnMute.getAttribute("style").contains("left: -20.4pt;"))
				{					
					/** Use touch in case of android, in case of iphone launch js to simuate touch */
					if(driver.toString().contains("selendroid"))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Touch to mute ... ");
						TouchActions flick = new TouchActions(driver).flick(btnMute, -100, 0, 0);
						flick.perform();
					}
					else
					{
						((JavascriptExecutor)driver).executeScript(getMuteUnmuteJsForiPhone("video", ""));
					}
				}
			}
			else
			{
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Ad Mute/Unmute wasn't displayed");
			}
		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteVideoOnMobileScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (Exception e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while performing mute/unmute operation. ", e);
		}

	}


	/* =======================================================================================================
	Function to Verify Text 'Ads By ...' On the Mobile Screen
	=======================================================================================================*/
	/**
	 * 
	 * 
	 * @param driver
	 * @return
	 */
	public static String verifyAdsByTextOnMobileScreen(WebDriver driver)
	{
		String parseText = adsByText;
		boolean state;
		String result = "";
		try
		{
			if(parseText.isEmpty() || parseText == null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : received expected adsByText is empty, therefore will not be validated. ");
			}
			else
			{
				WebElement adsByVdopiaText = driver.findElement(By.id("vdoAdText"));
				state = verifyTextOnMobileScreen(adsByVdopiaText, parseText);
				if(state)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is displayed on the screen.");
					result = "PASS:" + " Expected Text '" + parseText + "' is displayed on the screen.";
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is not displayed on the screen.");
					result = "FAIL:" + " Expected Text '" + parseText + "' is not displayed on the screen.";
				}
			}
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking adsbytext.", e);
			result = "SKIP: Ads By text wasn't verified.";
		}
		return result;
	}


	/* =======================================================================================================
	Function to Verify Text 'Learn More' On the Mobile Screen
	=======================================================================================================*/
	/**
	 * 
	 * 
	 * @param driver
	 * @return
	 */
	public static String verifyLearnMoreTextOnMobileScreen(WebDriver driver)
	{
		String result = "";
		try
		{
			if(learnMoreText.isEmpty() || learnMoreText == null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : received expected learnMoreText is empty, therefore will not be validated. ");
			}
			else
			{
				WebElement learnMoreElement = driver.findElement(By.xpath("//div[@class='vdo_lm_bg']"));
				//state = verifyTextOnMobileScreen(learnMoreText, parseText);

				String actualText = learnMoreElement.getText().trim();
				if(learnMoreText.trim().equalsIgnoreCase(actualText))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + learnMoreText + "' is displayed on the screen.");
					result = "PASS:" + " Expected Text: " + learnMoreText + " is displayed on the screen.";
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text " + learnMoreText + " is not displayed on the screen.");
					result = "FAIL:" + " Expected Text: " + learnMoreText + " is not displayed on the screen whereas text = "+ actualText + " is displayed.";
				}
			}
		}
		catch(NoSuchElementException n)
		{
			result = "FAIL: Learn More text wasn't displayed on web.";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Learn More Text wasn't found. ", n);
		}
		catch(Exception e)
		{
			result = "SKIP: Learn More text wasn't verified.";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while checking learn more text.", e);
		}
		return result;
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @return
	 */
	public static boolean closeVideoOnMobileScreen(WebDriver driver)
	{
		boolean flag = false;

		// For Close Button
		try
		{
			WebElement closeButton = driver.findElement(By.id("closeBut"));

			WebDriverWait w = new WebDriverWait(driver, 45);
			w.until(ExpectedConditions.visibilityOf(closeButton));

			boolean state = closeButton.isDisplayed();
			if (state)
			{
				closeButton.click();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed, Now closing video.");
				flag = true;
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is not displayed");
				flag = false;
			}
		}
		catch(WebDriverException e)
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method CloseVideoOnMobileScreen. Video wasn't closed successfully. ");
			logger.info(e.getMessage());
		}
		catch (NullPointerException e) 
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method CloseVideoOnMobileScreen. Video wasn't closed successfully.");
			logger.info(e.getMessage());
		}
		return flag;
	}


	/**
	 * 
	 * 
	 * @param webelement
	 * @param text
	 * @return
	 */
	public static boolean verifyTextOnMobileScreen(WebElement webelement, String text)
	{
		boolean flag = false;
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Before Using This Method, Please Use The Appropriate Driver. For Mobile Device Use Android or iOS Driver.");

		try
		{
			if	(webelement.isDisplayed())
			{
				if(webelement.getText().toLowerCase().contains(text.toLowerCase()))
				{
					logger.info(text + " is displayed");
					flag = true;	
				}
				else
				{
					logger.info(text + " is not Displayed");
					flag = false;
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Unable to verify text on screen. " + webelement.toString() + " :Element is not displayed ");
				flag = true;
			}
		}
		catch(org.openqa.selenium.NoSuchElementException n)
		{
			logger.info(text + " is not displayed");
		}
		catch(WebDriverException e)
		{
			logger.info(text + " is not displayed. Error is: " + e.getMessage());
		}
		return flag;
	}


	/**
	 * 
	 * 
	 * @param proceedTest
	 * @param driver
	 * @param strUrl
	 * @param flagForCloseButtonTest
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	public static String uiTestsOnMobileScreen(boolean proceedTest, WebDriver driver, String strUrl, boolean flagForCloseButtonTest, 
			int adWait, Bigquery bqConnection, String bqProjectID) 
	{
		String result = "";

		try
		{
			if(driver != null)
			{
				driver.get(strUrl);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now browsing url: " +strUrl + " on device at time: "+MobileTestClass_Methods.DateTimeStamp());

				/** If proceedTest is true then serve ad else just wait for 1.5 sec to record ui tracker */
				if(proceedTest)
				{ 
					if (adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("jsbanner"))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");
						//Click on screen.
						UIOperations_MobileDeviceLib.clickOnMobileBannerScreen(driver, adFormat);
					}
					else if(adFormat.equalsIgnoreCase("html"))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");
						//Click on screen.
						UIOperations_MobileDeviceLib.clickOnMobileAnimatedBannerScreen(driver);
					}
					else if(adFormat.equalsIgnoreCase("vdobanner"))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + ", Mute / Unmute operation will be performed now.");

						//Mute/Unmute on vdoBanner
						UIOperations_MobileDeviceLib.muteUnmuteVdoBannerOnMobileScreen(driver);

					}
					else if(adFormat.equalsIgnoreCase("leadervdo"))
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Mute / Unmute operation will be performed now.");

						//Mute/Unmute on leader vdo
						UIOperations_MobileDeviceLib.muteUnmuteLeadervdoOnMobileScreen(driver);
					}
					else if(adFormat.equalsIgnoreCase("appinterstitial") || adFormat.equalsIgnoreCase("htmlinter"))
					{
						/** for interstitial ads, no click and skip trackers are recorded therefore skipping any operation on them */

						//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");
						//Click on screen.
						//UIOperations_MobileDeviceLib.ClickInterstitialOnMobileScreen(driver);

						/** Check Close Button on InterstitialScreen */
						//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Close button operation will be performed now.");
						//UIOperations_MobileDeviceLib.CloseInterstitialOnMobileScreen(driver);			
					}
					else if(adFormat.equalsIgnoreCase("video") || adFormat.equalsIgnoreCase("vastfeed"))
					{
						//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");

						//Click on screen.
						//UIOperations_MobileDeviceLib.ClickOnMobileVideoScreen(driver);

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Mute /Unmute operation will be performed now.");

						/** Mute/Unmute on video */
						UIOperations_MobileDeviceLib.muteUnmuteVideoOnMobileScreen(driver);

						// Verify Text 'Ads by Vdopia' on the mobile screen
						result = result + UIOperations_MobileDeviceLib.verifyAdsByTextOnMobileScreen(driver) + "\n";

						// Verify Text 'Learn More' on the mobile screen
						result = result + UIOperations_MobileDeviceLib.verifyLearnMoreTextOnMobileScreen(driver) + "\n";

						//Check Close Button on Video
						if(flagForCloseButtonTest)
						{
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " X button is being tried to click now.");
							UIOperations_MobileDeviceLib.closeVideoOnMobileScreen(driver);
						}
					}
					else if(adFormat.equalsIgnoreCase("inview"))
					{
						int numberOfFlick =100;
						int xcord = 1000;
						int ycord = 1000;
						UIOperations_MobileDeviceLib.scrollMobileScreen(driver,xcord,ycord,numberOfFlick);
						Thread.sleep(3000);
						UIOperations_MobileDeviceLib.scrollMobileScreen(driver,xcord,ycord,20);

						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Mute /Unmute operation will be performed now.");
						//Mute/Unmute on video
						UIOperations_MobileDeviceLib.muteUnmuteVideoOnMobileScreen(driver);

						Thread.sleep(2000);

						UIOperations_MobileDeviceLib.scrollMobileScreen(driver,-1000,-1000,20);

						Thread.sleep(2000);

						UIOperations_MobileDeviceLib.scrollMobileScreen(driver,1000,1000,20);
					}
					else
					{
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** Ad format : " +adFormat +" is not supported yet. *****************");
					}

					/** Sleeping thread for mobile ad completion
					 */
					int sleepDurationMS = adWait*1000;
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sleeping thread for duration = "+sleepDurationMS + " mili seconds. ");

					Thread.sleep(sleepDurationMS);
				}
				else
				{
					logger.info(String.valueOf(proceedTest) + " browsing for 2 secs ... just to record ui tracker. ");
					Thread.sleep(3000);
				}
			}
			else
			{
				result = "SKIP: Driver Wasn't Setup For This Iteration. ";
			}
		}
		catch(UnreachableBrowserException e)
		{
			logger.error(e.getMessage());
		}
		catch(Exception e)
		{
			result = "Error occurred while performing UI Tests On Mobile Device";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while performing UI Tests On MobileScreen. ", e);
		}

		return result;

	}


	/**
	 * 
	 * 
	 * @param driver
	 * @param xcord
	 * @param ycord
	 * @param numberOfFlick
	 */
	public static void scrollMobileScreen(WebDriver driver, int xcord, int ycord ,int numberOfFlick)
	{
		int i = 1;
		try
		{
			TouchActions touch = new TouchActions(driver);
			do
			{
				touch.flick(xcord, ycord);
				touch.perform();
				i++;
			}
			while(i < numberOfFlick);
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while scrolling down mobile screen in function UIOperations_MobileDeviceLib.ScrollMobileScreen");
			logger.info(e.getMessage());
		}
	}


	/**
	 * 
	 * 
	 * @return
	 */
	public static List<String> getAndroidDeviceList() 
	{
		String adbPath = null;
		List<String> devicelist= new ArrayList<String>();

		try{
			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb.exe");
			}
			else
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb");
			}
		}
		catch(NullPointerException n)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Check environment variable $ANDROID_HOME. ");
		}

		if(adbPath != null)
		{
			devicelist = ExecuteCommands.GetConnectedAndroidDeviceList(adbPath);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Number of attached and detected Android Devices: "+devicelist.size());
		}

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : attached and detected Android Devices: "+devicelist.toString());
		return devicelist;
	}


	//Uninstall app in android device
	/**
	 * 
	 * 
	 * @param packageName
	 * @param androidDeviceID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static boolean uninstallApp_AndroidDevices(String packageName, String androidDeviceID) 
	{
		boolean flag = false;
		try
		{
			String adbPath = null;

			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb.exe");
			}
			else
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb");
			}

			flag = ExecuteCommands.UninstallAppCommand_AndroidDevice(adbPath, packageName, androidDeviceID);

			if(flag)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : App package: "+packageName+ " is uninstalled successfully. ");
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : App package: "+packageName+ " is not uninstalled successfully. ");
			}
		}
		catch(Exception e)
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: UninstallApp_AndroidDevices. " +e.getMessage());
		}
		finally
		{
			return flag;
		}
	}


	/**
	 * 
	 * 
	 * @param proceedTest
	 * @param deviceId
	 * @param url
	 * @param flagForCloseButtonTest
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	@SuppressWarnings({ "finally" })
	public static String testRun_AndroidDevice(boolean proceedTest, String deviceId, String url, boolean flagForCloseButtonTest, int adWait, Bigquery bqConnection, String bqProjectID) 
	{
		String result = "";
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running Test on Android Device ID: " +deviceId  + " at time: "+MobileTestClass_Methods.DateTimeStamp());

		String adbPath = null;
		WebDriver androidDriver = null;
		try
		{
			if(System.getProperty("os.name").matches("^Windows.*"))
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb.exe");
			}
			else
			{
				adbPath = System.getenv("ANDROID_HOME").concat("/platform-tools/adb");
			}

			List<String> devicelist = ExecuteCommands.GetConnectedAndroidDeviceList(adbPath);

			if (devicelist.size() == 0)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** No Android device connected ********");
			}
			else
			{
				//				String portDirection = adbPath +  " -s " + deviceId + " forward tcp:8080 tcp:8080";
				//				String portDisconnection = adbPath + " forward --remove-all";

				androidDriver = launchSelendroidDriver(deviceId);

				if(androidDriver != null)
				{
					result = result + UIOperations_MobileDeviceLib.uiTestsOnMobileScreen(proceedTest, androidDriver, url, flagForCloseButtonTest, adWait, bqConnection, bqProjectID);
				}
			}
		}
		catch(io.selendroid.server.common.exceptions.SelendroidException s)
		{
			UIOperations_MobileDeviceLib.launchSelendroidServer();
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *************** Selendroid Server Might Have Died, Therefore Restarting Server ****************** ");
		}
		catch (Exception e) 
		{
			result = result + "There was some problem while setting up Android Driver";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : There was some problem while setting up Android Driver: ", e);
		}
		finally
		{

			if (androidDriver != null) 
			{
				androidDriver.quit();
			}

			return result;
		}

	}


	/**
	 * 
	 * 
	 * @param iphoneIp
	 * @param proxy
	 * @return
	 */
	@SuppressWarnings("finally")
	public static WebDriver getiPhoneDriver(String iphoneIp, Proxy proxy)
	{
		RemoteWebDriver iphoneDriver = null;
		try 
		{
			if(iphoneIp.contains("\""))
			{
				iphoneIp = iphoneIp.replaceAll("\"","");
			}

			DesiredCapabilities cap = new DesiredCapabilities();

			if(proxy != null)
			{
				cap.setCapability(CapabilityType.PROXY, proxy);
				cap.setCapability(CapabilityType.ForSeleniumServer.PROXY_PAC, proxy.getHttpProxy());
			}

			iphoneDriver = new RemoteWebDriver(new URL(iphoneIp), cap);
			try{
				iphoneDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}catch(UnsupportedCommandException c){

			}

			logger.info(iphoneDriver.toString() + " is set up.");
		} 
		catch (MalformedURLException e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : MalformedURLException handled by Method: CheckIphoneDevices. " +e.getMessage());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Either the given IP of iPhone in config file is not valid or iPhone is not detected. ");
		} 
		catch (Exception e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by Method: CheckIphoneDevices. ", e);
		}
		finally
		{
			return iphoneDriver;
		}
	}


	/**
	 * 
	 * 
	 * @param iphoneIp
	 * @return
	 */
	@SuppressWarnings("finally")
	public static WebDriver getiPhoneDriver(String iphoneIp)
	{
		WebDriver iphoneDriver = null;
		try 
		{
			if(iphoneIp.contains("\""))
			{
				iphoneIp = iphoneIp.replaceAll("\"","");
			}
			//iphoneDriver = new IPhoneDriver(new URL("http://172.16.1.195:3001/wd/hub"));

			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability(CapabilityType.PLATFORM, DesiredCapabilities.iphone());

			//iphoneDriver = new IPhoneDriver(new URL(iphoneIp));
			iphoneDriver = new RemoteWebDriver(new URL(iphoneIp), cap);

			logger.info(iphoneDriver.toString() + " is found.");
		} 
		catch (MalformedURLException e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Either the given IP of iPhone in config file is not valid or iPhone is not detected. ");
		} 
		catch (UnreachableBrowserException e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Check the iphone ip in qa config file, supplied ip is not correct. ");
		}
		catch (Exception e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by Method: CheckIphoneDevices. " +e.getMessage());
		}
		finally
		{
			return iphoneDriver;
		}
	}


	/**
	 * 
	 * 
	 * @param proceedTest
	 * @param iphoneIp
	 * @param proxy
	 * @param url
	 * @param flagForCloseButtonTest
	 * @param adWait
	 * @param bqConnection
	 * @param bqProjectID
	 * @return
	 */
	@SuppressWarnings("finally")
	public static String testRun_iPhoneDevice(boolean proceedTest, String iphoneIp, Proxy proxy, String url, boolean flagForCloseButtonTest, int adWait,
			Bigquery bqConnection, String bqProjectID)
	{
		String result = "";

		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ============  Running test for Iphone Device  =================================================================");
		try 
		{
			WebDriver iphoneDriver = getiPhoneDriver(iphoneIp, proxy);
			result = UIOperations_MobileDeviceLib.uiTestsOnMobileScreen(proceedTest, iphoneDriver, url, flagForCloseButtonTest, adWait, bqConnection, bqProjectID);
		} 
		catch (Exception e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error in Running Iphone Driver. ", e);
			result = result + "  Error in Running Iphone Driver. ";
		}
		finally
		{
			return result;
		}

	}

	/**
	 * 
	 * 
	 * @param adFormat
	 * @param xpath
	 * @return
	 */
	public static String getMuteUnmuteJsForiPhone(String adFormat, String xpath)
	{
		String js = "";
		if(adFormat.equalsIgnoreCase("video"))
		{
			js = "var targetElement = document.getElementById('soundimg');"+
					"var evt = document.createEvent('UIEvent');"
					+"evt.initUIEvent('touchstart', true, true);"
					+"targetElement.dispatchEvent(evt);";
		}
		else
		{
			js = "var targetElement = document.evaluate(\""+xpath+"\",document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;"+
					"var evt = document.createEvent('UIEvent');"
					+"evt.initUIEvent('touchstart', true, true);"
					+"targetElement.dispatchEvent(evt);";
		}

		return js;
	}


	/**
	 * 
	 * 
	 * @param driver
	 */
	public static void muteUnmuteVdoBannerOnMobileScreen(WebDriver driver) 
	{
		try
		{			
			String unMuteBtnXpath = "//div[contains(@style, 'sound.png')][contains(@style,'-18px 50%')]";			

			/** Wait unitl unmute button is displayed */
			WebDriverWait waitUnmute = new WebDriverWait(driver, 15);
			waitUnmute.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(unMuteBtnXpath)));

			WebElement btnMute = driver.findElement(By.xpath(unMuteBtnXpath));
			boolean stat = btnMute.isDisplayed();
			if	(stat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute / Unmute button is displayed");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner is not mute, Now clicking to mute the VdoBanner");

				//Clicking Mute Button
				try{
					TouchActions flick = new TouchActions(driver).flick(btnMute, -100, 0, 0);
					flick.perform();
				}catch(Exception e)
				{
					/** in case exception occurs while clicking on mute then execute js */
					String js = getMuteUnmuteJsForiPhone("vdobanner", unMuteBtnXpath);
					((JavascriptExecutor)driver).executeScript(js);
				}
			}

			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute/Unmute is not Displayed");
			}

			Thread.sleep(1500);

			String muteBtnXpath = "//div[contains(@style, 'sound.png')][contains(@style,'0px 50%')]";

			/** Wait unitl unmute button is displayed */
			WebDriverWait waitMute = new WebDriverWait(driver, 15);
			waitMute.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(muteBtnXpath)));

			WebElement btnUnMute = driver.findElement(By.xpath(muteBtnXpath));
			boolean unmutestat = btnUnMute.isDisplayed();
			if	(unmutestat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now VdoBanner is mute, clicking to unmute the VdoBanner");

				//Clicking Unmute Button
				try{
					TouchActions flick = new TouchActions(driver).flick(btnUnMute, -100, 0, 0);
					flick.perform();
				}catch(Exception e)
				{
					/** in case exception occurs while clicking on unmute then execute js */
					String js = getMuteUnmuteJsForiPhone("vdobanner", muteBtnXpath);
					((JavascriptExecutor)driver).executeScript(js);				
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute/Unmute is not Displayed after mute.");
			}
		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteVdoBannerOnMobileScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while peforming mute/unmute operation. ", e);
		}
	}


	/**
	 * 
	 * 
	 * @param driver
	 */
	public static void muteUnmuteLeadervdoOnMobileScreen(WebDriver driver) 
	{
		try
		{
			String unMuteXpath = "//div[contains(@style, 'sound.png')][contains(@style,'-18px 50%')]";			

			/** Wait until unmute button is displayed */
			WebDriverWait waitUnmute = new WebDriverWait(driver, 7);
			waitUnmute.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(unMuteXpath)));

			WebElement btnMute = driver.findElement(By.xpath(unMuteXpath));

			boolean muteStat = btnMute.isDisplayed();
			if(muteStat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Unmute button is displayed");

				//Clicking mute Button
				try{
					TouchActions flick = new TouchActions(driver).flick(btnMute, -100, 0, 0);
					flick.perform();
				}catch(Exception e)
				{
					/** in case exception occurs while clicking on unmute then execute js */
					String js = getMuteUnmuteJsForiPhone("leadervdo", unMuteXpath);
					((JavascriptExecutor)driver).executeScript(js);				
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Mute/Unmute is not Displayed");
			}

			Thread.sleep(2000);
			String muteXpath = "//div[contains(@style, 'sound.png')][contains(@style,'0px 50%')]";

			/** Wait until mute button is displayed */
			WebDriverWait waitMute = new WebDriverWait(driver, 7);
			waitMute.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(muteXpath)));


			WebElement btnUnMute = null;
			try{
				btnUnMute = driver.findElement(By.xpath(muteXpath));
			}catch(NoSuchElementException e){
				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****** Unmute button wasn't found on ad. ");
			}

			if(btnUnMute != null){
				boolean unmutestat = btnUnMute.isDisplayed();
				if(unmutestat)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now LeaderVdo is mute, clicking to unmute the LeaderVdo");

					//Clicking mute Button
					try{
						TouchActions flick = new TouchActions(driver).flick(btnUnMute, -100, 0, 0);
						flick.perform();
					}catch(Exception e)
					{
						/** in case exception occurs while clicking on unmute then execute js */
						String js = getMuteUnmuteJsForiPhone("leadervdo", muteXpath);
						((JavascriptExecutor)driver).executeScript(js);				
					}
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Mute/Unmute is not Displayed after mute.");
				}
			}
		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteleadervdoOnMobileScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (NullPointerException e) {
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method MuteUnmuteleadervdoOnMobileScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (Exception e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while performing mute/unmute operation. ", e);
		}
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @throws InterruptedException
	 */
	public static void clickInterstitialOnMobileScreen(WebDriver driver) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation will be performed for Interstitial ad on Mobile screen.");

		String winHandleBefore;
		String initialUrl = null;
		//String destUrl;

		//Click on running Interstitial to get Landing page url..
		try
		{
			WebElement intRunning = driver.findElement(By.id("vdoModalContent"));

			//Store the current window handle
			winHandleBefore = driver.getWindowHandle();

			initialUrl = driver.getCurrentUrl();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);
			intRunning.click();		//Perform the click operation that opens new window
			Thread.sleep(2000);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Driver Type: " +driver.toString());

			if(driver.toString().toLowerCase().contains("android"))
			{
				for(String winHandle : driver.getWindowHandles())
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Going to Window handle: " + winHandle);
					if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
					{
						driver.switchTo().window(winHandle);
						Thread.sleep(2000);
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
						driver.close();
						driver.switchTo().window(winHandleBefore);
						break;
					}
				}
			}
			else if (driver.toString().toLowerCase().contains("iphone"))
			{
				if (!(driver.getCurrentUrl().matches(initialUrl)))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url opened is: " + driver.getCurrentUrl());
					driver.navigate().to(initialUrl);
				}
			}			
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Undefined Driver, Need to be implemented");
			}

		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickInterstitialOnMobileScreen. Click operation on Interstitial is unsuccessful. Error message is: " + e.getMessage());		
		}
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @return
	 */
	public static boolean closeInterstitialOnMobileScreen(WebDriver driver)
	{
		boolean flag = false;

		// For Close Button
		try
		{
			WebElement closeButton = driver.findElement(By.id("closeBut"));

			WebDriverWait w = new WebDriverWait(driver, 45);
			w.until(ExpectedConditions.visibilityOf(closeButton));

			boolean state = closeButton.isDisplayed();
			if (state)
			{
				//closeButton.click();
				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed, Now closing Interstitial.");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed.");
				flag = true;
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is not displayed");
				flag = false;
			}
		}
		catch (org.openqa.selenium.NoSuchElementException e) 
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close button wasn't found on ad.", e);
		}
		catch(Exception e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method CloseInterstitialOnMobileScreen. Interstitial wasn't closed successfully. ", e);
		}
		return flag;
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @param adFormat
	 * @throws InterruptedException
	 */
	public static void clickOnMobileBannerScreen(WebDriver driver, String adFormat) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operaton will be performed on banner screen.");
		try
		{

			/** For js banner, vdopia click tracker is not fired */
			Thread.sleep(2000);

			if(!adFormat.equalsIgnoreCase("jsbanner"))
			{
				WebElement bannerImage = driver.findElement(By.xpath("//a/img[1]"));
				bannerImage.click();
			}

			/*
			//Code to click

			 //1.
			WebElement bannerImage = driver.findElement(By.xpath("//a/img[1]"));
			TouchActions flick = new TouchActions(driver).flick(bannerImage, -100, 0, 0);
			flick.perform();

			//2.
			String xpath = "//a/img[1]";
			String js = "var targetElement = document.evaluate(\""+xpath+"\",document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;"+
					"var evt = document.createEvent('UIEvent');"
					+"evt.initUIEvent('touchstart', true, true);"
					+"targetElement.dispatchEvent(evt);";
			((JavascriptExecutor)driver).executeScript(js);

			//3.
			String script = "var element = document.evaluate(\"//a/img[1]\" ,document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;" +
					"if (element != null) {" +
					"element.click();" +
					"};";
			((JavascriptExecutor)driver).executeScript(script);
			 */
		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickOnMobileBannerScreen. Click operation on banner is unsuccessful.", e);		
		}
	}


	/**
	 * 
	 * 
	 * @param driver
	 * @throws InterruptedException
	 */
	public static void clickOnMobileAnimatedBannerScreen(WebDriver driver) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operaton will be performed on Aniamted banner screen.");

		try
		{
			Thread.sleep(2000);
			//WebElement aniamtedBanner = driver.findElement(By.id("bannerDiv"));
			WebElement aniamtedBanner = driver.findElement(By.xpath("//a/img[3]"));

			aniamtedBanner.click();
		}
		catch(WebDriverException e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickOnMobileAnimatedBannerScreen. Click operation on Animated banner is unsuccessful. Error message is: " + e.getMessage(), e);		
		}
	}


	/**
	 * Launch selendroid server.
	 * 
	 * @return
	 */
	public static boolean launchSelendroidServer()
	{
		try
		{
			SelendroidConfiguration config = new SelendroidConfiguration();
			SelendroidLauncher selendroidServer = new SelendroidLauncher(config);
			selendroidServer.launchSelendroid();
			return true;
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while launching selendroid server.", e);
			return false;
		}
	}

	/**
	 * Launch selendroid driver.
	 * 
	 * @param deviceId
	 * @return
	 */
	public static WebDriver launchSelendroidDriver(String deviceId)
	{
		WebDriver driver = null;
		try
		{
			SelendroidCapabilities caps = new SelendroidCapabilities();
			caps.setBrowserName("android");
			caps.setPlatform(Platform.ANDROID);
			caps.setSerial(deviceId);
			caps.setCapability("newCommandTimeout", 90);

			driver = new SelendroidDriver (caps);
			Thread.sleep(2500);
		}
		catch (Exception e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error in running Selendroid driver on android: ", e);

		}
		return driver; 
	}


	/**
	 * 
	 * 
	 * @param driver
	 */
	public static void clickElement(WebDriver driver)
	{
		Point elementpointer = driver.findElement(By.xpath("//a/img[3]")).getLocation();
		TouchActions touch = new TouchActions(driver);
		touch.down(elementpointer.x, elementpointer.y);
		touch.up(elementpointer.x, elementpointer.y);
		touch.perform();
	}
}

