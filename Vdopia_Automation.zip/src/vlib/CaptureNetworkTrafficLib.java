/**
 * Last Changes Done on 5 Mar, 2015 12:07:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.io.FileOutputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.browsermob.core.har.Har;
import org.browsermob.proxy.ProxyServer;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;






public class CaptureNetworkTrafficLib 
{

	static Logger logger = Logger.getLogger(CaptureNetworkTrafficLib.class.getName());
	
	//This method will start the proxy server and return the instance of proxy server.
	@SuppressWarnings("finally")
	public static ProxyServer startProxyServer(int proxyServerPort)
	{
		ProxyServer ps = null;
		try
		{
			//Start Proxy Server at a port like 9090, 9092 etc..

			ps = new ProxyServer(proxyServerPort);
			ps.start();
			ps.setCaptureHeaders(true);
			ps.setCaptureContent(true);

			//Check current environment
			String environment = MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString();

			//In case of production environment
			if(environment.equalsIgnoreCase("prod") || environment.equalsIgnoreCase("production") || environment.matches("^prod.*"))
			{
				//Production Server IP
				String prodServerIP = MobileTestClass_Methods.propertyConfigFile.getProperty("prodServerIP").toString();

				//Remap -- to make sure host entry is read
				ps.remapHost("trk.vdopia.com", prodServerIP);
			}

			// create a new HAR with some label
			ps.newHar("test.com");

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Proxy server is started at port: "+proxyServerPort);
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled while starting proxy server. "+e.getMessage());
		}
		finally
		{
			return ps;
		}
	}


	//This method will stop the proxy server 
	@SuppressWarnings("finally")
	public static boolean stopProxyServer(ProxyServer ps)
	{
		boolean flag = false;
		try
		{
			ps.stop();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Proxy server is stopped. ");

			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled while stopping proxy server. "+e.getMessage());
		}
		finally
		{
			return flag;
		}
	}


	//This method will return the proxy setting from the proxy server which will be used as an capability to web driver
	@SuppressWarnings("finally")
	public static String getProxySettingFromProxyServer(ProxyServer ps)
	{
		String proxy = "";
		try
		{
			proxy = ps.seleniumProxy().getHttpProxy();
		}
		catch(Exception e)
		{	
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled while getting the proxy from Proxy Server. " +e.getMessage());
		}
		finally
		{
			return proxy;
		}

	}


	//This method will return the http log captured from the proxy server 
	@SuppressWarnings("finally")
	public static String getHttpLogAfterStoppingProxyServer(ProxyServer ps)
	{
		String httpLog = "";

		try
		{
			//Get the HAR data
			Har har = ps.getHar();
			String file = null;

			if (System.getProperty("os.name").matches("^Mac.*"))
			{
				file = "/tmp/NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
			}
			else
			{
				file = System.getProperty("java.io.tmpdir").toString()+"\\NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
			}

			//Write log to a file
			FileOutputStream fos = new FileOutputStream(file);
			har.writeTo(fos);
			fos.close();

			//Stopping Proxy Server
			ps.stop();

			//Read log from file
			httpLog = FileLib.ReadContentOfFile(file);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Captured Log is stored at: " +file);
		}
		catch(Exception e)
		{
			ps.stop();
			httpLog = "";

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: getHttpLogAfterStoppingProxyServer. " +e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			return httpLog;
		}

	}


	//This method will return the http log captured from the proxy server 
	@SuppressWarnings("finally")
	public static String getHttpLogWithoutStoppingProxyServer(ProxyServer ps)
	{
		String httpLog = "";

		try
		{
			//Get the HAR data
			Har har = ps.getHar();
			String file = null;

			if (System.getProperty("os.name").matches("^Mac.*"))
			{
				file = "/tmp/NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
			}
			else
			{
				file = System.getProperty("java.io.tmpdir").toString()+"\\NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
			}

			//Write log to a file
			FileOutputStream fos = new FileOutputStream(file);
			har.writeTo(fos);
			fos.close();

			//Stopping Proxy Server
			//ps.stop();

			//Read log from file
			httpLog = FileLib.ReadContentOfFile(file);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Captured Log is stored at: " +file);
		}
		catch(Exception e)
		{
//			ps.stop();
//			httpLog = "";
//
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: getHttpLogWithoutStoppingProxyServer. " +e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			return httpLog;
		}

	}


	//This method captures all the http traffic request and returns them 
	@SuppressWarnings("finally")
	public static String getHttpLogAfterStoppingProxyServer(String url, int proxyServerPort, String browser, int browserWaitSeconds)
	{
		String httpLog = "";
		ProxyServer ps = null;

		try
		{
			//Start Proxy Server at a port like 9090, 9092 etc..
			ps = new ProxyServer(proxyServerPort);
			ps.start();
			ps.setCaptureHeaders(true);
			ps.setCaptureContent(true);

			//Check current environment
			String environment = MobileTestClass_Methods.propertyConfigFile.getProperty("currentTestEnvironment").toString();

			//In case of production environment
			if(environment.equalsIgnoreCase("prod") || environment.equalsIgnoreCase("production") || environment.matches("^prod.*"))
			{
				//Production Server IP
				String prodServerIP = MobileTestClass_Methods.propertyConfigFile.getProperty("prodServerIP").toString();

				//Remap -- to make sure host entry is read
				ps.remapHost("trk.vdopia.com", prodServerIP);
			}

			//Setting up driver
			WebDriver driver = null;
			boolean flag = false;

			if(browser.equalsIgnoreCase("Firefox"))
			{
				//get the Selenium proxy object
				Proxy proxy = ps.seleniumProxy();

				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(CapabilityType.PROXY, proxy);
				driver = new FirefoxDriver(capabilities);

				flag = true;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up firefox driver ..... ");
			}
			else if(browser.equalsIgnoreCase("Chrome"))
			{
				//Setting up proxy switch to chrome driver
				String []capabilities = {"--proxy-server="+ps.seleniumProxy().getHttpProxy()};
				driver = MobileTestClass_Methods.WebDriverSetUp(browser, capabilities);

				flag = true;
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Setting up chrome driver ..... ");
			}
			else
			{
				flag = false;
				ps.stop();

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : *********** Only Firefox and Chrome Browsers are supported, not: "+browser+" ***************" );
			}

			if(flag)
			{
				//setting up implicit driver delay
				//driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);				

				// create a new HAR with some label
				ps.newHar("test.com");

				//Browse and Quit URL
				driver.get(url);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for duration: " +browserWaitSeconds*1000 + " ms ........ ");
				Thread.sleep(browserWaitSeconds*1000);
				driver.quit();

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Proxy server running at port: "+ps.getPort() + ", Selenium Http Proxy: "+ps.seleniumProxy().getHttpProxy());

				//Get the HAR data
				Har har = ps.getHar();
				String file = null;

				if (System.getProperty("os.name").matches("^Mac.*"))
				{
					file = "/tmp/NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
				}
				else
				{
					file = System.getProperty("java.io.tmpdir").toString()+"\\NetworkCapture"+ "_" + MobileTestClass_Methods.DateTimeStamp("MMddyy_hhmmss") +".txt";
				}

				//Write log to a file
				FileOutputStream fos = new FileOutputStream(file);
				har.writeTo(fos);
				fos.close();
				ps.stop();

				//Read log from file
				httpLog = FileLib.ReadContentOfFile(file);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Captured Log is stored at: " +file);
			}
		}
		catch(Exception e)
		{
			ps.stop();
			httpLog = "";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: getHttpLogAfterStoppingProxyServer. " +e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			return httpLog;
		}
	}


	//This method will find out the urls from http network log 
	@SuppressWarnings("finally")
	public static List<String> getURLsFromNetworkLog(String httpLog)
	{
		List<String> urlList = new ArrayList<String>();

		try
		{
			String regexString = "\"url\":.*?,";

			// Get Sub string
			Pattern pattern = Pattern.compile(regexString);
			Matcher m = pattern.matcher(httpLog);

			while (m.find()) 
			{
				String matchURL = m.group();

				//Removing characters==>  "url", : "" ,
				matchURL = matchURL.replace("\"url\":", "").replace("\"", "").replace(",", "").trim();
				urlList.add(matchURL);
			}
		}
		catch(Exception  e)
		{
			urlList = null;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: GetURLsFromNetworkLog. " +e.getMessage());
		}	
		finally
		{
			/*
			
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Printing url list from captured http log: ");

			for(int i=0; i<urlList.size(); i++)
			{
				logger.info(urlList.get(i));
			}
			 */
			return urlList;
		}
	}


	//This method will find the vastxml url list from the provided http log
	@SuppressWarnings("finally")
	public static List<String> getVastXMLURLsFromHttpLog(String httpLog)
	{
		List<String> vastXmlURL = new ArrayList<String>();
		try
		{
			//Getting URL list from http log
			List<String> url = getURLsFromNetworkLog(httpLog);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking VastXml URL From The Supplied Http Log: ");

			//Finding vastxml url from url list
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("/vastxml/"))
				{
					//Adding vast xml urls in a list 
					vastXmlURL.add(url.get(i));

					logger.info(url.get(i));

					//vastURL = URLEncoder.encode(vastURL, "UTF-8");
					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VastXml URL After Encoding: " +vastURL);
				}
			}

			if(vastXmlURL.size() < 1)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******* Vast XML url wasn't found in provided http log.  ********");
				logger.info(httpLog);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching vastxml url in provided http log. " ); 
			logger.info(e.getMessage());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
			logger.info(httpLog);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
		}
		finally
		{
			return vastXmlURL;
		}
	}


	//This method will find the midroll requests out of vastxml url list from the provided http log
	@SuppressWarnings("finally")
	public static List<String> getMidrollRequestsOnCuePointsFromHttpLog(String httpLog)
	{
		List<String> midrollVastXmlURL = new ArrayList<String>();
		try
		{
			//Getting URL list from http log
			List<String> url = getURLsFromNetworkLog(httpLog);

			//Getting the first occurrence of vast xml request
			String firstVastXMLRequest = getFirstOccuence_VastXMLURLFromHttpLog(httpLog);

			//remove first occurrence of vast xml request
			url.remove(firstVastXMLRequest);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking Midroll VastXml URLs From The Supplied Http Log: ");

			//Finding vastxml url from url list
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("vastxml") && url.get(i).toLowerCase().contains("/midroll/"))
				{
					//Adding midroll vast xml urls in a list 
					midrollVastXmlURL.add(url.get(i));

					logger.info(url.get(i));
				}
			}

			if(midrollVastXmlURL.size() < 1)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******* Midroll Vast XML url wasn't found in provided http log.  ********");
				logger.info(httpLog);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching midroll vastxml url in provided http log. " ); 
			logger.info(e.getMessage());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
			logger.info(httpLog);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
		}
		finally
		{
			return midrollVastXmlURL;
		}
	}


	//This method will find the overlay requests out of vastxml url list from the provided http log
	@SuppressWarnings("finally")
	public static List<String> getOverlayRequestsOnCuePointsFromHttpLog(String httpLog)
	{
		List<String> overlayVastXmlURL = new ArrayList<String>();
		try
		{
			//Getting URL list from http log
			List<String> url = getURLsFromNetworkLog(httpLog);

			//Getting the first occurrence of vast xml request
			String firstVastXMLRequest = getFirstOccuence_VastXMLURLFromHttpLog(httpLog);

			//remove first occurrence of vast xml request
			url.remove(firstVastXMLRequest);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking Overlay VastXml URLs From The Supplied Http Log: ");

			//Finding overlay vastxml url from url list
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("vastxml") && url.get(i).toLowerCase().contains("/overlay/"))
				{
					//Adding overlay vast xml urls in a list 
					overlayVastXmlURL.add(url.get(i));

					logger.info(url.get(i));
				}
			}

			if(overlayVastXmlURL.size() < 1)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******* Overlay Vast XML url wasn't found in provided http log.  ********");
				logger.info(httpLog);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching overlay vastxml url in provided http log. " ); 
			logger.info(e.getMessage());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
			logger.info(httpLog);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
		}
		finally
		{
			return overlayVastXmlURL;
		}
	}


	//This method will find the first occurrence of vastxml url from the provided http log
	@SuppressWarnings("finally")
	public static String getFirstOccuence_VastXMLURLFromHttpLog(String httpLog)
	{
		String vastURL = "";
		boolean flag = false;

		try
		{
			//Getting URL list from http log
			List<String> url = getURLsFromNetworkLog(httpLog);

			//Finding vastxml url from url list
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("vastxml"))
				{
					vastURL = url.get(i);

					
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found First Occurence Of VastXml URL: "+vastURL);

					//vastURL = URLEncoder.encode(vastURL, "UTF-8");
					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VastXml URL After Encoding: " +vastURL);

					flag = true;
					break;
				}
			}

			if(!flag)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vast XML url wasn't found in captured http log. ");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching vastxml url. " ); 
			logger.info(e.getMessage());
		}
		finally
		{
			return vastURL;
		}
	}


	//This method will find the first occurrence of vastxml url from the provided list of urls
	@SuppressWarnings("finally")
	public static String getFirstOccuence_VastXMLURLFromHttpLog(List<String> url)
	{
		String vastURL = "";
		boolean flag = false;

		try
		{
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("vastxml"))
				{
					vastURL = url.get(i);

					
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found First Occurence Of VastXml URL from The Supplied URLs: "+vastURL);

					//vastURL = URLEncoder.encode(vastURL, "UTF-8");
					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VastXml URL After Encoding: " +vastURL);

					flag = true;
					break;
				}
			}

			if(!flag)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vast XML url wasn't found in given list of urls. ");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching vastxml url. " ); 
			logger.info(e.getMessage());
		}
		finally
		{
			return vastURL;
		}
	}


	//This method will return the unique list containing vast xml url from the provided http log
	public static List<String> getUniqueVastXMLRequests(List<String> urls, String httpLog)
	{
		List<String> uniqueVastURLs = CaptureNetworkTrafficLib.getVastXMLURLsFromHttpLog(httpLog);

		uniqueVastURLs.removeAll(urls);

		return uniqueVastURLs;
	}


	//This method will find the vast xml requests from the provided http log for a specific ad format
	@SuppressWarnings("finally")
	public static List<String> getAllVastRequestsForSpecificOnlineAdFormatFromHttpLog(String httpLog, String adFormat)
	{
		List<String> vastXmlURL = new ArrayList<String>();
		try
		{
			//Getting URL list from http log
			List<String> url = getVastXMLURLsFromHttpLog(httpLog);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Checking VastXml URLs For Ad Format: "+adFormat + " From The Supplied Http Log: ");

			//Finding overlay vastxml url from url list
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains(adFormat.toLowerCase()))
				{
					//Adding vast xml urls in a list 
					vastXmlURL.add(url.get(i));

					logger.info(url.get(i));
				}
			}

			if(vastXmlURL.size() < 1)
			{
				
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******* Overlay Vast XML url wasn't found in provided http log.  ********");
				logger.info(httpLog);
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
				
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while searching overlay vastxml url in provided http log. " ); 
			logger.info(e.getMessage());
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
			logger.info(httpLog);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ****************************************************************");
		}
		finally
		{
			return vastXmlURL;
		}
	}


	//This method will split the url and return the number of midrolls and overlays
	@SuppressWarnings("finally")
	public static String getNumberOfMidrollsOverlays(String url)
	{
		String midrolls = "0";
		String overlays = "0";

		List<String> list1 = Arrays.asList(url.split("/"));
		try
		{
			for(int i=0; i<list1.size(); i++)
			{
				String str1 = list1.get(i).toLowerCase();

				if(str1.contains("numberof"))
				{
					List<String> list2 = Arrays.asList(str1.split(";"));

					for(int j=0; j<list2.size(); j++)
					{
						String str3 = list2.get(j).toLowerCase();

						if(str3.contains("numberOfMidrolls".toLowerCase()))
						{
							midrolls = str3.substring(str3.indexOf(":")+1, str3.length());
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Number of Midroll: "+midrolls);
						}

						if(str3.contains("numberOfOverlays".toLowerCase()))
						{
							overlays = str3.substring(str3.indexOf(":")+1, str3.length());
							logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Number of Overlay: "+overlays);
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while checking number of midrolls and overlays. "+e.getMessage());
		}	
		finally
		{
			return midrolls + ":" + overlays;
		}

	}


	//This method will split the url and return the number of midrolls and overlays
	@SuppressWarnings("finally")
	public static String getNumberOfMidrollsOverlays(List<String> url)
	{
		String midrollOverlays = "";
		String vastURL = "";
		boolean flag = false;

		try
		{
			for(int i=0; i<url.size(); i++)
			{
				if(url.get(i).toLowerCase().contains("vastxml"))
				{
					vastURL = url.get(i);

					
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Found VastXml URL: "+vastURL);

					//Decode URL before further processing
					vastURL = URLDecoder.decode(vastURL, "UTF-8");
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VastXml URL After Decoding: " +vastURL);

					//Getting number of midrolls, overlays
					midrollOverlays = CaptureNetworkTrafficLib.getNumberOfMidrollsOverlays(vastURL);

					flag = true;

					break;
				}
			}

			if(!flag)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Vast XML url wasn't found in given list of urls. ");
			}

		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while checking number of midrolls and overlays from the vastxml url. " +vastURL, e); 
		}
		finally
		{
			return midrollOverlays;
		}
	}


}
