/**
 * Last Changes Done on 5 Mar, 2015 12:07:44 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.net.MalformedURLException;
import java.sql.SQLException;

//import org.json.JSONArray;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

//import projects.rtb.lib.MopubRTBLib;

public class RTBLib 
{

	/*
	 * This function returns the ad-format information if ad_id information is avaialble.
	 * 
	 */
	
	public static String GetAd_format(String id) throws ClassNotFoundException, SQLException
	{
		String ad_format_value = null;
		String NewSqlQuery = "select ad_format from adplatform.ads where id = " + id + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		while(NewRs.next())
		{
			ad_format_value =  NewRs.getString("ad_format").toString();
		}

		NewCon.close();
		return ad_format_value;

	}

	/*
	 * 
	 * This function return the campaign ID if campaign name of the campaign is available.
	 * 
	 */

	public static String GetCampaignID(String campaignName) throws ClassNotFoundException, SQLException
	{
		String ID = null;
		String NewSqlQuery = "select id from adplatform.campaign where name like '" + campaignName + "%';";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		MobileTestClass_Methods.InitializeConfiguration();
		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		while(NewRs.next())
		{
			ID =  NewRs.getString("id").toString();

		}

		NewCon.close();
		return ID;

	}


	/*
	 * This function deletes the campaign entry from Server Memcamp table
	 * 
	 */

	public static void DeleteEntryFromServeMemcamp(String campaignID) throws ClassNotFoundException, SQLException
	{

		String NewSqlQuery = "delete from adplatform.memcamp where cid = " + campaignID + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();

		NewStmt.executeUpdate(NewSqlQuery);

		//ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		NewCon.close();

	}

	

	/*
	 * This function pause a campaign in serve DB
	 * 
	 */
	
	public static void PauseCampaignServe(String campaignName) throws ClassNotFoundException, SQLException
	{
		String CID = GetCampaignID(campaignName);
		String NewSqlQuery = "update campaign set status = 'paused' where id = " + CID + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		//ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);
		NewStmt.executeUpdate(NewSqlQuery);

		NewCon.close();

		DeleteEntryFromServeMemcamp(CID);

	}


	/*
	 * This function delete the entry of a campiagn from memcamp table.
	 * 
	 */
	public static void DeleteEntryFromQAMemcamp(String campaignID) throws ClassNotFoundException, SQLException
	{

		String NewSqlQuery = "delete from adplatform.memcamp where cid = " + campaignID + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();

		NewStmt.executeUpdate(NewSqlQuery);

		//ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		NewCon.close();

	}

	
	/*
	 * This function pause a campaign in portal DB
	 * 
	 */
	public static void PauseCampaignQA(String campaignName) throws ClassNotFoundException, SQLException
	{
		String CID = GetCampaignID(campaignName);
		String NewSqlQuery = "update campaign set status = 'paused' where id = " + CID + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		//ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);
		NewStmt.executeUpdate(NewSqlQuery);

		NewCon.close();

		DeleteEntryFromQAMemcamp(CID); 

	}
	
	/*
	 * This function can pause a campaign in portal & serve environment using database queries.
	 * 
	 */
	public static boolean PauseCampaign(String campaignName) throws ClassNotFoundException, SQLException
	{
		boolean flag = false;
		try
		{
			PauseCampaignQA(campaignName);
			PauseCampaignServe(campaignName);
			
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			System.out.println("Exception Occured While Trying To Pause Campaign: " +campaignName);
			System.out.println(e.getMessage());
		}
		return flag;

	}

	
	/*
	 * if channelname is available then this function can return the channel_id after quering Database
	 */
	
	public static String GetChannelID(String channelName) throws ClassNotFoundException, SQLException
	{
		String ID = null;
		String NewSqlQuery = "select id from adplatform.channels where name like '" + channelName + "%';";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		while(NewRs.next())
		{
			ID =  NewRs.getString("id").toString();

		}

		NewCon.close();
		return ID;

	}
	
	/*
	 * 
	 * This Function return the API key of the channel.
	 * 
	 */
	public static String GetChannelApiKey(String channelName) throws ClassNotFoundException, SQLException
	{
		String apiKey = null;
		String NewSqlQuery = "select apikey from adplatform.channels where name like '" + channelName + "%';";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		while(NewRs.next())
		{
			apiKey =  NewRs.getString("apikey").toString();

		}

		NewCon.close();
		return apiKey;

	}

	/*
	 * This function verify whether a campaign exist in memcamp table or not
	 * 
	 */
	public static boolean isCampaignExistInMemcamp(String campaignName) throws ClassNotFoundException, SQLException
	{
		String campaignID = GetCampaignID(campaignName);
		boolean exist = false;
		if (campaignID != null)
		{
			String sqlQuery = "Select count(*) as Exist from adplatform.memcamp where cid = '" + campaignID + "';";
			System.out.println("Running Query in DB : " + sqlQuery);
			//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
			Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);

			while(rs.next())
			{
				if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
				{
					System.out.println("Campaign with name  = " + campaignName + " does not exist in adplatform.mamcamp table");

				}
				else
				{
					System.out.println("Campaign with name  = " + campaignName + " exist in adplatform.rtb_memcamp table");
					exist = true;
				}

			}

			con.close();
		}
		else
		{
			System.out.println("GetCampaignID function is not able to be find Campaign ID of Campaign with name  = " + campaignName + ". Check Campaign manually in adplatform.channels table.");
		}
		return exist;

	}


	public static boolean isRTBChannelExist(String app_id) throws ClassNotFoundException, SQLException
	{
		String sqlQuery = "Select count(*) as Exist from adplatform.rtb_channels where app_id = '" + app_id + "';";
		System.out.println("Running Query in DB : " + sqlQuery);
		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("RTB channel with App_id  = " + app_id + " does not exist in adplatform.rtb_channels table");

			}
			else
			{
				System.out.println("RTB channel with App_id  = " + app_id + " exist in adplatform.rtb_channels table");
				exist = true;
			}

		}

		con.close();

		return exist;

	}

	/*
	 * 
	 * This return status of whether channel (with given channel Name ) is present in adplatform.channels table.
	 */
	
	public static boolean isChannelExist(String channelName) throws ClassNotFoundException, SQLException
	{
		
		String sqlQuery = "select count(*) as Exist from adplatform.channels where name like '" + channelName + "';";
		System.out.println("Running Query in DB : " + sqlQuery);

		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("Channel with name  = " + channelName + " does not exist in adplatform.channels table");

			}
			else
			{
				System.out.println("Channel with name  = " + channelName + " exist in adplatform.channels table");
				exist = true;
			}

		}

		con.close();

		return exist;

	}

	
	
	public static String getRTBAppFromChannelID(String channelID) throws ClassNotFoundException, SQLException
	{
		String app_id = null;
		String NewSqlQuery = "select app_id as app_id from rtb_channels where channel_id  = " + channelID + ";";
		System.out.println("Running Query in DB : " + NewSqlQuery);

		//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
		Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement NewStmt = (Statement) NewCon.createStatement();
		ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

		while(NewRs.next())
		{
			app_id =  NewRs.getString("app_id").toString();

		}

		NewCon.close();
		return app_id;

	}
	
	
	public static String RTBChannelName(String app_id) throws ClassNotFoundException, SQLException
	{
		/*
		 * This function will return channel name of the RTB channel with app_id. 
		 * If channel does not exist in the channels table, then this function will return NULL   
		 * 
		 */

		String ChannelName = null;


		String sqlQuery = "select count(*) as Exist from adplatform.channels where name like 'RTB - " + app_id + "%';";
		System.out.println("Running Query in DB : " + sqlQuery);

		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
//		while(rs.next())
//		{
//			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
//			{
//				System.out.println("RTB channel with App_id  = " + app_id + " does not exist in adplatform.channels table");
//
//			}
//			else if(Integer.parseInt( rs.getString("Exist").toString()) == 1)
//			{
//				System.out.println("RTB channel with App_id  = " + app_id + " exist in adplatform.channels table");
//				exist = true;
//			}
//			else
//			{
//				System.out.println("RTBChannelName Function retuned unexpected output on searching channnel in adplatform.channels table");
//
//			}
//
//		}
		
		
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("RTB channel with App_id  = " + app_id + " does not exist in adplatform.channels table");

			}
			else if(Integer.parseInt( rs.getString("Exist").toString()) >= 1)
			{
				System.out.println("RTB channel with App_id  = " + app_id + " exist in adplatform.channels table");
				exist = true;
			}
		}

		
		
		con.close();

		if(exist)
		{
			String NewSqlQuery = "select name from adplatform.channels where name like 'RTB - " + app_id + "%' LIMIT 1;";
			System.out.println("Running Query in DB : " + sqlQuery);

			//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
			Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
			Statement NewStmt = (Statement) NewCon.createStatement();
			ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

			while(NewRs.next())
			{
				ChannelName = NewRs.getString("name").toString();

			}

			NewCon.close();

		}

		return ChannelName;

	}


	/*
	 * This Function provide the return the channelName if id is RTB request is available.
	 * 
	 */
	public static String getRTBChannelName(String app_id) throws ClassNotFoundException, SQLException
	{
		String channelName = RTBChannelName(app_id);
		return channelName;
	}

	
	/*
	 * This function query adplatform.rtb_channels tables to verify whether channel with ID = app_id is created or not.
	 * 
	 */
	public static String checkRTBChannelTable(String app_id) throws ClassNotFoundException, SQLException, InterruptedException
	{
		for(int i = 0; i < 10;i++)
		{
			if(isRTBChannelExist(app_id))
			{
				System.out.println("Requested  RTB Channel : " + app_id + " is created successfully in adplatform.rtb_channels table. \n");
				return "Requested  RTB Channel : " + app_id + " is created successfully in adplatform.rtb_channels table. \n";

			}
			else
			{
				Thread.sleep(15000);
			}
		}

		if(isRTBChannelExist(app_id))
		{
			System.out.println("Requested  RTB Channel : " + app_id + " is created successfully in adplatform.rtb_channels table. \n");
			return "Requested  RTB Channel : " + app_id + " is created successfully in adplatform.rtb_channels table. \n";

		}
		else
		{
			System.out.println("FAIL - Requested RTB Channel : " + app_id + " is not created in adplatform.rtb_channels table. \n");
			return "FAIL - Requested RTB Channel : " + app_id + " is not created in DB table.\n";
		}
	}

	
	/*
	 * This function check whter a channel ID exist in adplatform.channels table.
	 * 
	 */
	public static String checkChannelTable(String app_id) throws ClassNotFoundException, SQLException, InterruptedException
	{
		String channelName = RTBChannelName(app_id);
		if( channelName != null)
		{
			System.out.println("Requested  RTB Channel : " + app_id + " exists in adplatform.channels table. \n");
			return "Requested  RTB Channel : " + app_id + " exists in adplatform.channels table. \n";

		}
		else
		{
			System.out.println("FAIL - Requested RTB Channel : " + app_id + " does not exist in adplatform.channels table. \n");
			return "FAIL - Requested RTB Channel : " + app_id + " does not exis in adplatform.channels table. \n";
		}
	}


	/*
	 * 
	 * This function checks whether campaign exist in memcamp table.
	 * 
	 */
	
	public static String checkMemcampTable(String Name) throws ClassNotFoundException, SQLException, InterruptedException
	{
		for(int i = 0; i < 15;i++)
		{
			if(isCampaignExistInMemcamp(Name))
			{
				System.out.println("Campaign with name : " + Name + " exist in adplatform.memcamp table. \n");
				return "Campaign with name : " + Name + " exist in adplatform.memcamp table. \n";

			}
			else
			{
				Thread.sleep(15000);
			}
		}

		if(isCampaignExistInMemcamp(Name))
		{
			System.out.println("Campaign with name : " + Name + " exist in adplatform.memcamp table. \n");
			return "Campaign with name : " + Name + " exist in adplatform.memcamp table. \n";

		}
		else
		{
			System.out.println("FAIL - Campaign with name : " + Name + " does not exist in adplatform.memcamp table. \n");
			return "FAIL - Campaign with name : " + Name + " does not exist in adplatform.memcamp table. \n";
		}
	}


	
	/*
	 * This function return the id value from RTB response
	 * 
	 */
	

	public static String getRTB_Response_id(String RTB_Response)
	{
		String id = "";
		
		JSONParser parser=new JSONParser();
		try{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject jsonObject = (JSONObject) obj;
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :jsonObject.keySet())
			{
				if(key.toString().equalsIgnoreCase("id"))
				{
					id = jsonObject.get(key).toString();	
				}
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		return id;
	}

	/*
	 * This function return the nbr value from RTB response
	 * 
	 */

	
	public static String getRTB_Response_nbr(String RTB_Response)
	{
		String nbr = "";
		
		if(processJSON.keyExist(RTB_Response, "nbr"))
		{
			JSONParser parser=new JSONParser();
			try{
				//  Parse MAIN JSON request for searching key value pairs
				Object obj = parser.parse(RTB_Response);
				JSONObject jsonObject = (JSONObject) obj;
				//  Traverse through all the possible keys in Main JSON request
				for (Object key :jsonObject.keySet())
				{
					if(key.toString().equalsIgnoreCase("nbr"))
					{
						nbr = jsonObject.get(key).toString();	
					}
					
				}
			}
			catch(ParseException pe)
			{
				System.out.println("position: " + pe.getPosition());
				System.out.println(pe);
			}	
		}
		else
		{
			nbr = "NBR KEY DOES NOT EXIST";
		}
		
		
		return nbr;
	}
	
	/*
	 * This function return the bidid value from RTB response
	 * 
	 */

	public static String getRTB_Response_bidid(String RTB_Response)
	{
		String bidid = "";
		
		JSONParser parser=new JSONParser();
		try{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject jsonObject = (JSONObject) obj;
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :jsonObject.keySet())
			{
				if(key.toString().equalsIgnoreCase("bidid"))
				{
					bidid = jsonObject.get(key).toString();	
				}
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		return bidid;
	}
	
	/*
	 * This validate whether win log of RTB has reached in adplatform.rtb_win_log1 or adplatform.rtb_win_log0 table. 
	 * 
	 */	
	public static String  ValidateRTBWinDB(String bidid) throws ClassNotFoundException, SQLException
	{
		String result = "";

		String sqlQuery = "select sum(Exist) as Exist from (Select count(*) as Exist from adplatform.rtb_win_log1 where bid_id = '" + bidid + "' union Select count(*) as Exist from adplatform.rtb_win_log0 where bid_id = '" + bidid + "') as Query ;";
		System.out.println("Running Query in DB : " + sqlQuery);
		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();

		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);

		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("RTB Win request for bid_id : " + bidid + " does not exist in adplatform.rtb_win_log1 & adplatform.rtb_win_log0 tables");
				result = "FAIL - RTB Win request for bid_id : " + bidid + " does not exist in adplatform.rtb_win_log1 & adplatform.rtb_win_log0 tables";
			}
			else if(Integer.parseInt( rs.getString("Exist").toString()) == 1)
			{
				System.out.println("RTB Win request for bid_id : " + bidid + " exist in adplatform.rtb_win_log1 & adplatform.rtb_win_log0 tables");
				result = "RTB Win request for bid_id : " + bidid + " exist in adplatform.rtb_win_log1 & adplatform.rtb_win_log0 tables";
			}
			else
			{
				System.out.println("FAIL - RTB Win request for bid_id : " + bidid + " provide unexpected result. Please check manually");
				result = "FAIL - RTB Win request for bid_id : " + bidid + " provide unexpected result. Please check manually";
			}



		}

		con.close();

		return result;

	}
	
	/*
	 * This validate whether adplatform.rtb_bid_log0 or adplatform.rtb_bid_log1 table contains the bidlog information 
	 * 
	 */
	public static String  ValidateRTBBidlogDB(String request_id, String tstamp) throws ClassNotFoundException, SQLException
	{
		String result = "";

		String sqlQuery = "select sum(Exist) as Exist from (Select count(*) as Exist from adplatform.rtb_bid_log1 " +
				" where request_obj like '%\"id\":\"" + request_id + "\"%' and tstamp >= '" + tstamp + "' " +
						"union Select count(*) as Exist from adplatform.rtb_bid_log0 " +
						"where request_obj like '%\"id\":\"" + request_id + "\"%' and tstamp >= '" + tstamp + "') as Query ;";
		
		System.out.println("Running Query in DB : " + sqlQuery);
		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();

		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		

				
		while(rs.next())
		{
			int exist_count = Integer.parseInt( rs.getString("Exist").toString());
			if( exist_count == 0)
			{
				System.out.println("Bid Log count = " + String.valueOf(exist_count).toString() + ": RTB request with id : " + request_id + " does not exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables");
				result = String.valueOf(exist_count).toString() + ": RTB bid request with bid_id : " + request_id + " does not exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables";
			}
			else if(exist_count == 1)
			{
				System.out.println("Bid Log count = " + String.valueOf(exist_count).toString() + ": RTB request with id : " + request_id + " exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables");
				result = String.valueOf(exist_count).toString() + ":RTB request with id : " + request_id + " exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables";
			}
			else
			{
				System.out.println("Bid Log count = " + String.valueOf(exist_count).toString() + ":RTB request with id : " + request_id + " exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables");
				result = String.valueOf(exist_count).toString() + ":RTB request for id : " + request_id + " exist in adplatform.rtb_bid_log1 OR adplatform.rtb_bid_log0 tables";
			}

		}

		con.close();

		return result;

	}

	/*
	 * 
	 * This Function validate all mandatory  Keys of RTB response
	 */
	public static String ValidateRTBResponse(String RTB_Response)
	{
		String result = "";
		//validate id key RTB_Response
		
		if(ValidateRTBResponse_id(RTB_Response))
		{
			System.out.println("'id' key exist in RTB response. ");
			result = result + "'id' key exist in RTB response. \n ";
		}
		else
		{
			System.out.println(" 'id' key DOES NOT exist in RTB response. ");
			result = result + " 'id' key  DOES NOT exist in RTB response. \n";
		}
		
		if(ValidateRTBResponse_bidid(RTB_Response))
		{
			System.out.println("'bidid' key exist in RTB response.");
			result = result + "'bidid' key exist in RTB response. \n ";
		}
		else
		{
			System.out.println(" 'bidid' key  DOES NOT exist in RTB response.");
			result = result + " 'bidid' key  DOES NOT exist in RTB response. \n";
		}
		

		if(ValidateRTBResponse_seatbid(RTB_Response))
		{
			System.out.println("'seatbid' key exist in RTB response.");
			result = result + "'seatbid' key exist in RTB response. \n ";
		}
		else
		{
			System.out.println(" 'seatbid' key  DOES NOT exist in RTB response.");
			result = result + " 'seatbid' key  DOES NOT exist in RTB response. \n";
		}
		

		if(ValidateRTBResponse_bid_in_seatbid(RTB_Response))
		{
			System.out.println("'bid' key in seatbid exist in RTB response.");
			result = result + "'bid' key in seatbid exist in RTB response. \n ";
		}
		else
		{
			System.out.println(" 'bid' key in seatbid  DOES NOT exist in RTB response.");
			result = result + " 'bid' key in seatbid  DOES NOT exist in RTB response. \n";
		}		
		

		String [] fields = {"iurl", "adomain", "crid", "impid", "price", "adid", "nurl","adm", "id", "cid"};
		
		for(String field : fields )
		{

			if(ValidateRTBResponse_key_in_bid(RTB_Response, field))
			{
				System.out.println(field + " key in bid exist in RTB response.");
				result = result + field + " key in bid exist in RTB response. \n ";
			}
			else
			{
				System.out.println(" " + field + " key in seatbid  DOES NOT exist in RTB response.");
				result = result + " " + field + " key in seatbid  DOES NOT exist in RTB response. \n";
			}
			
		}
		
		
		return result;
	}
	
	/*
	 * This function is to validate whether 'id' key exist in RTB response.
	 * 
	 */
	public static boolean ValidateRTBResponse_id(String RTB_Response)
	{
		boolean exist = false;
		JSONParser parser=new JSONParser();
		try
		{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject MainJsonObject = (JSONObject) obj;
			
			//System.out.println("id key value is " + MainJsonObject.get("id"));
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :MainJsonObject.keySet())
			{
				System.out.println("Response Key value: " + key);
				if(key.toString().equalsIgnoreCase("id"))
				{
					exist = true;
					break;
				}
				
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		catch(Exception e)
		{
			System.out.println("position: " + e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return exist;
	}
	
	/*
	 * This function is to validate whether 'bidid' key exist in RTB response.
	 * 
	 */
	public static boolean ValidateRTBResponse_bidid(String RTB_Response)
	{
		boolean exist = false;
		JSONParser parser=new JSONParser();
		try
		{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject MainJsonObject = (JSONObject) obj;
			
			//System.out.println("id key value is " + MainJsonObject.get("id"));
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :MainJsonObject.keySet())
			{
				System.out.println("Response Key value: " + key);
				if(key.toString().equalsIgnoreCase("bidid"))
				{
					exist = true;
					break;
				}
				
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		catch(Exception e)
		{
			System.out.println("position: " + e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return exist;
	}
	
	/*
	 * This function is to validate whether 'seatbid' key exist in RTB response.
	 * 
	 */
	public static boolean ValidateRTBResponse_seatbid(String RTB_Response)
	{
		boolean exist = false;
		JSONParser parser=new JSONParser();
		try
		{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject MainJsonObject = (JSONObject) obj;
			
			//System.out.println("id key value is " + MainJsonObject.get("id"));
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :MainJsonObject.keySet())
			{
				System.out.println("Response Key value: " + key);
				if(key.toString().equalsIgnoreCase("seatbid"))
				{
					exist = true;
					break;
				}
				
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		catch(Exception e)
		{
			System.out.println("position: " + e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return exist;
	}
	
	/*
	 * This function is to validate whether 'bid' key in seatbid,  exist in RTB response.
	 * 
	 */
	public static boolean ValidateRTBResponse_bid_in_seatbid(String RTB_Response)
	{
		boolean exist = false;
		JSONParser parser=new JSONParser();
		try
		{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject MainJsonObject = (JSONObject) obj;
			
			//System.out.println("id key value is " + MainJsonObject.get("id"));
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :MainJsonObject.keySet())
			{
				if(key.toString().equalsIgnoreCase("seatbid"))
				{
					JSONArray seatbidJSON = (JSONArray) MainJsonObject.get(key);
					//System.out.println("JSON STRING IN seat bid key : " + seatbidJSON.get(0));
					JSONObject seatJSON = (JSONObject) seatbidJSON.get(0);
					for (Object appKey : seatJSON.keySet())
					{
						// If Key is aid / sid, then return the value of app_id 
						if(appKey.toString().equalsIgnoreCase("bid"))
						{
							System.out.println("Response Key value: " + appKey);
							exist = true;
							break;
						}
					}
					break;
				}
				
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		catch(Exception e)
		{
			System.out.println("position: " + e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return exist;
	}
	
	
	/*
	 * This function process the RTB response and validate whether 'bid' key exist in RTB response.
	 * 
	 */
	public static boolean ValidateRTBResponse_key_in_bid(String RTB_Response, String key_exist)
	{
		boolean exist = false;
		JSONParser parser=new JSONParser();
		try
		{
			//  Parse MAIN JSON request for searching key value pairs
			Object obj = parser.parse(RTB_Response);
			JSONObject MainJsonObject = (JSONObject) obj;
			
			//System.out.println("id key value is " + MainJsonObject.get("id"));
			//  Traverse through all the possible keys in Main JSON request
			for (Object key :MainJsonObject.keySet())
			{
				if(key.toString().equalsIgnoreCase("seatbid"))
				{
					JSONArray seatbidJSON = (JSONArray) MainJsonObject.get(key);
					//System.out.println("JSON STRING IN seat bid key : " + seatbidJSON.get(0));
					JSONObject seatJSON = (JSONObject) seatbidJSON.get(0);
					for (Object appKey : seatJSON.keySet())
					{
						// If Key is aid / sid, then return the value of app_id 
						if(appKey.toString().equalsIgnoreCase("bid"))
						{
							JSONArray bidJSON = (JSONArray) seatJSON.get(appKey);
							//System.out.println("JSON STRING IN bid key : " + bidJSON.get(0));

							JSONObject admJSON = (JSONObject) bidJSON.get(0);
							for (Object admKey : admJSON.keySet())
							{
								// If Key is aid / sid, then return the value of app_id 
								
								if(admKey.toString().equalsIgnoreCase(key_exist))
								{
									System.out.println("Response Key value: " + admKey);
									exist = true;
									break;
								}
							}
							
							
							break;
						}
					}
					break;
				}
				
			}
		}
		catch(ParseException pe)
		{
			System.out.println("position: " + pe.getPosition());
			System.out.println(pe);
		}
		catch(Exception e)
		{
			System.out.println("position: " + e.getMessage());
			System.out.println(e.getStackTrace());
		}
		return exist;
	}
	
	/*
	 * This Function open the browser and play the local html file in browser. 
	 * Once the ads is completly played, then trackers are validated. 
	 * 
	 * 
	 */
	public static String VerifyTrackers(String browserForCampaignCreation, String htmlFilePath, String cid, String channelID) throws MalformedURLException, InterruptedException, ClassNotFoundException, SQLException
	{

		//int checkFlag = Integer.parseInt(campaignName);

		//For Debugging Use Campaign Name - Automation_Script_Preroll_03182014_010555
		String sqlQuery = " SELECT ad.ad_format, cam.id, IFNULL(ad.duration, 30) AS Ad_Duration FROM campaign cam " +
				" INNER JOIN campaign_members camb ON cam.id = camb.cid INNER JOIN ads ad ON camb.ad_id = ad.id " +
				" WHERE cam.id = '"+ cid +"' ;";

		//if(!(checkFlag==0))
		//{
		//	sqlQuery = sqlQuery + " WHERE cam.id = '"+campaignName+"' ;";
		//}
		//else
		//{
		//	sqlQuery = sqlQuery + " WHERE cam.name = '"+campaignName+"' ;";
		//}

		System.out.println("Query to be used to get Campaign ID, Channel ID, Ad Type and Ad Duration: "+sqlQuery);

		//Get The Campaign Data From DataBase.
		Connection con = MobileTestClass_Methods.CreateServeSQLConnection();
		String [][] campaignData = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArray(con, sqlQuery);
		con.close();

		//Initializing variables with the values from DB 
		String adFormat = campaignData[0][0];
		String campaignID = campaignData[0][1];
		
		String adDuration = campaignData[0][2].toString();

		//htmlFilePath = "file://" + htmlFilePath;
		
		System.out.println("Browsing URL: " +htmlFilePath + ", adformat: " + adFormat + ", campaignID: " + campaignID +  "channelID: " +channelID + ", adDuration: " + adDuration);

		WebDriver driver = MobileTestClass_Methods.WebDriverSetUp(browserForCampaignCreation, null);

		//Get The Start Time For Tracker Calculation
		String trackerStartTime = MobileTestClass_Methods.GetCurrentDBTime();
		System.out.println("Start Time For Tracker Calculation: " +trackerStartTime);

		//Browse HTML File
		driver.get(htmlFilePath);

		//Sleeping thread for ad duration
		try
		{
			Integer sleepDuration = Integer.parseInt(adDuration)*1000;
			Thread.sleep(sleepDuration + 10000);
		}
		catch(Exception e)
		{
			System.out.println("AdDuration is can not be identified because of adDuration Value " + adDuration);
			Thread.sleep(45000);
		}

		//Tracker Validation 
		//String result = MobileTestClass_Methods.MobileAdsTrackerValidation(adFormat, campaignID, channelID, trackerStartTime);

		String result = MobileTestClass_Methods.MobileAds_VdopiaTrackerValidationForCampaignTestPage(adFormat, campaignID, channelID, trackerStartTime);

		driver.quit();

		return result;
	}

	/*
	 * This Function can remove the entries of this campaign from memcamp table.
	 * 
	 */
	public static boolean DeleteEntryFromMemcamp(String campaignID) throws ClassNotFoundException, SQLException
	{
		boolean flag = false;
		try
		{
			MobileTestClass_Methods.InitializeConfiguration();
			String NewSqlQuery = "delete from adplatform.memcamp where cid = " + campaignID + ";";
			System.out.println("Running Query in DB : " + NewSqlQuery);

			//Connection NewCon = MobileTestClass_Methods.CreateSQLConnection();
			Connection NewCon = MobileTestClass_Methods.CreateServeSQLConnection();
			Statement NewStmt = (Statement) NewCon.createStatement();
			NewStmt.executeUpdate(NewSqlQuery);

			NewCon.close();
			flag = true;
		} 
		catch(Exception e)
		{
			System.out.println("Exception handled while Deleting Entry From Memcamp. " +e.getMessage());
			flag = false;
		}
		return flag;
	}


}
