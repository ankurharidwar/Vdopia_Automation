/**
 * Last Changes Done on 5 Mar, 2015 12:07:49 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


public class LoginLib 
{
	public static WebDriver driver;
	public LoginLib(WebDriver driver)
	{
		LoginLib.driver = driver;
	}

	public static void LogIn() throws BiffException, SecurityException, IllegalArgumentException, IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException  
	{
		WebElement login = null;

		try
		{
			login = WebElementsLib.FindWebElementByFieldName("NewLogin", "Button_Login_VadminLogin");
			login.click();
		}
		catch (Exception e) 
		{
			System.out.println("Login is unsuccessful");
			Assert.fail("Exception Handled By Method: LoginLib.LogIn: Login was unsuccessful, Check Element: "+login.toString()+ " In Screen: Login, In Object Repository Sheet.");
		}	

	}

	public static void SignIn(String gmailUserNameForPortal, String gmailPasswordForPortal) throws BiffException, SecurityException, IllegalArgumentException, IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InterruptedException 
	{
		try
		{
			List<WebElement> listSignIn = WebElementsLib.FindPageWebElements("Sign in");

			WebElement userName = listSignIn.get(0);
			userName.click();
			Thread.sleep(1000);
			userName.sendKeys(gmailUserNameForPortal);					//("qa-scripting@vdopia.com");

			Thread.sleep(1000);

			WebElement password = listSignIn.get(1);
			password.click();

			Thread.sleep(1000);
			password.sendKeys(gmailPasswordForPortal);											//("Sunshine7");

			Thread.sleep(1000);

			WebElement submit = listSignIn.get(2);
			submit.click();
			// =====================================================================================================================
			// Niket Commented as Google Allow access button has been removed
			//=====================================================================================================================
			/*
			WebElement loginAccept = WebElementsLib.FindWebElementByFieldName("Sign in Accept", "Button_Accept");

			WebDriverWait wait =  new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.elementToBeClickable(loginAccept));

			Thread.sleep(1000);
			loginAccept.click();
			 */
			System.out.println("User: " +gmailUserNameForPortal + " has loggedin successfully.");
		}

		catch (NoSuchElementException e) 
		{
			System.out.println("Sign in is unsuccessful");
			Assert.fail("NoSuchElementException Handled By Method: LoginLib.SignIn: Sign in was unsuccessful, Check Elements Present In Screen: Sign in, In Object Repository Sheet.");
		}
		catch (NullPointerException e) 
		{
			System.out.println("Sign is unsuccessful");
			Assert.fail("NullPointerException Handled By Method: LoginLib.SignIn: Sign in was unsuccessful, Check Elements Present In Screen: Sign in, In Object Repository Sheet.");
		}
		catch (InvocationTargetException e) 
		{
			System.out.println("Sign is unsuccessful");
			Assert.fail("InvocationTargetException Handled By Method: LoginLib.SignIn: Sign in was unsuccessful, Check Elements Present In Screen: Sign in, In Object Repository Sheet.");	
		}
	}

	public static boolean SignInAndVerify(String gmailUserNameForPortal, String gmailPasswordForPortal) 
	{
		boolean isDisplay = false;
		try
		{
			SignIn(gmailUserNameForPortal, gmailPasswordForPortal);
			//			WebElement textBox_Email = WebElementsLib.FindWebElementByFieldName("Sign in", "TextBox_GoogleSignIn_Email");
			//			textBox_Email.sendKeys(gmailUserNameForPortal);
			//
			//			WebElement textBox_Password = WebElementsLib.FindWebElementByFieldName("Sign in", "TextBox_GoogleSignIn_Password");
			//			textBox_Password.sendKeys(gmailPasswordForPortal);
			//
			//
			//
			//			WebElement submit =WebElementsLib.FindWebElementByFieldName("Sign in", "Button_GoogleSignIn_SignIn");
			//			submit.click();
			//
			//			Thread.sleep(10000);
			//			WebElement loginAccept = WebElementsLib.FindWebElementByFieldName("Sign in Accept", "Button_Accept");
			//			loginAccept.click();

			WebElement link_Logout = WebElementsLib.FindWebElementByFieldName("Home", "Link_Logout");
			isDisplay = link_Logout.isDisplayed();
			if(isDisplay)
			{
				System.out.println("User: " +gmailUserNameForPortal + " has loggedin successfully.");
			}
			else
			{
				System.out.println("User: " +gmailUserNameForPortal + " has not been able to loggedin successfully.");
			}
		}
		catch(Exception e)
		{
			System.out.println("Sign in is unsuccessful");
			Assert.fail("Exception Handled By Method: SignInAndVerify: Sign in was unsuccessful, Check Elements Present In Screen: Sign in, In Object Repository Sheet.");
		}
		return isDisplay;
	}


	public static void ChannelCampaignLogout() throws BiffException, SecurityException, IllegalArgumentException, IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException 
	{
		List<WebElement> logoutList = new ArrayList<WebElement>();

		try
		{
			logoutList = WebElementsLib.FindPageWebElements("Logout");

			WebElement logout = logoutList.get(0);
			logout.click();
		}
		catch (NoSuchElementException e) 
		{
			System.out.println("NoSuchElementException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");
			Assert.fail("NoSuchElementException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");
		}
		catch (NullPointerException e) 
		{
			System.out.println("NullPointerException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");
			Assert.fail("NullPointerException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");
		}
		catch (InvocationTargetException e) 
		{
			System.out.println("InvocationTargetException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");
			Assert.fail("InvocationTargetException Handled By Method: LoginLib.ChannelCampaignLogout: Log Out was unsuccessful, Check Element: "+ logoutList.get(0)+" Present In Screen: Logout, In Object Repository Sheet.");	
		}

	}


	@SuppressWarnings("unused")
	public static void PortalLogout(WebDriver driver) throws BiffException, SecurityException, IllegalArgumentException, IOException, ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException 
	{
		try
		{
			List<WebElement> listPortalLogout = driver.findElements(By.tagName("a"));

			//System.out.println("List Size: " +listPortalLogout.size());
			for (int i=0; i<listPortalLogout.size(); i++)
			{
				//System.out.println("Elements: " +listPortalLogout.get(i).getText());
				if(listPortalLogout.get(i).getText().toLowerCase().contains("Logout"));
				{
					//System.out.println("Logout Button Is: " +listPortalLogout.get(i).getText());
					listPortalLogout.get(i).click();
					break;
				}
			}
		}
		catch (NoSuchElementException e) 
		{
			System.out.println("NoSuchElementException Handled By Method: LoginLib.PortalLogout: Portal Log Out was unsuccessful, Check Logout Element Present In Portal Home Screen.");
			Assert.fail("NoSuchElementException Handled By Method: LoginLib.PortalLogout: Portal Log Out was unsuccessful, Check Logout Element Present In Portal Home Screen.");
		}
		catch (NullPointerException e) 
		{
			System.out.println("NullPointerException Handled By Method: LoginLib.PortalLogout: Portal Log Out was unsuccessful, Check Logout Element Present In Portal Home Screen.");
			Assert.fail("NullPointerException Handled By Method: LoginLib.PortalLogout: Portal Log Out was unsuccessful, Check Logout Element Present In Portal Home Screen.");
		}
	}

}
