/**
 * Last Changes Done on Feb 5, 2015 12:40:04 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: implemented logger
 */
package vlib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




import com.google.api.services.bigquery.Bigquery;

public class UIOperations_BrowserScreenLib 
{

	static Logger logger = Logger.getLogger(UIOperations_BrowserScreenLib.class.getName());

	static String adFormat;
	static int bannerDelay;
	static int nonBannerDelay;
	static int adWait;
	static String campaignID;
	static String channelID;
	static String trackerStartTime; 
	static int testDuration;
	static String adsByText = "";
	static String learnMoreText;


	/*=======================================================================================================
	// Constructor to be initialized to provide variable value across class
	=======================================================================================================*/
	public UIOperations_BrowserScreenLib(String adFormat, int adWait, String campaignID, String channelID, String trackerStartTime)
	{
		UIOperations_BrowserScreenLib.adFormat = adFormat;
		UIOperations_BrowserScreenLib.adWait = adWait;
		UIOperations_BrowserScreenLib.campaignID = campaignID;
		UIOperations_BrowserScreenLib.channelID = channelID;
		UIOperations_BrowserScreenLib.trackerStartTime = trackerStartTime;
		testDuration = 30;
		//initializing configuration to get the variables from Config File
		MobileTestClass_Methods.InitializeConfiguration();
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
	}

	/*=======================================================================================================
	// Constructor to be initialized to provide variable value across class
	=======================================================================================================*/
	public UIOperations_BrowserScreenLib(String adFormat, int adWait, String campaignID, String channelID, String trackerStartTime, String adsByText, String learnMoreText)
	{
		UIOperations_BrowserScreenLib.adsByText = adsByText;
		UIOperations_BrowserScreenLib.learnMoreText = learnMoreText;
		UIOperations_BrowserScreenLib.adFormat = adFormat;
		UIOperations_BrowserScreenLib.adWait = adWait;
		UIOperations_BrowserScreenLib.campaignID = campaignID;
		UIOperations_BrowserScreenLib.channelID = channelID;
		UIOperations_BrowserScreenLib.trackerStartTime = trackerStartTime;
		testDuration = 30;
		//initializing configuration to get the variables from Config File
		MobileTestClass_Methods.InitializeConfiguration();
		bannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("bannerDelay").toString());
		nonBannerDelay = Integer.parseInt(MobileTestClass_Methods.propertyConfigFile.getProperty("nonBannerDelay").toString());
	}

	/*=======================================================================================================
	//Function to Click on Browser Video screen for 'cl' tracker and to get destination url 
	=======================================================================================================*/
	public static void ClickOnBrowserVideoScreen(WebDriver driver) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation will be performed on video screen played on browser.");

		//Initializing local variable to be used within method
		String winHandleBefore;
		String initialUrl = null;

		try
		{
			WebElement vdoRunning = driver.findElement(By.id("vdoPreloaded"));
			winHandleBefore = driver.getWindowHandle();		//Store the current window handle as to be used in method
			initialUrl = driver.getCurrentUrl();			// initial browser url before clicking on video screen
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);
			vdoRunning.click();								//Perform the click operation that opens new window
			Thread.sleep(2000);								// hard code delay for synchronisation
			for(String winHandle : driver.getWindowHandles())
			{
				if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
				{
					driver.switchTo().window(winHandle);	// Switch to new tab
					Thread.sleep(2000);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
					driver.close();							// Close new tab
					driver.switchTo().window(winHandleBefore);// Switch back to main content page

					//Play Video again
					WebElement playVdo = driver.findElement(By.id("vdoPreloaded"));
					playVdo.click();
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Clicked to play video again.. ");

					/** commenting this java script as it doesn't work any more */
					//JavascriptExecutor executor = (JavascriptExecutor)driver;
					//executor.executeScript("document.getElementsByTagName('video')[0].play()");
					break;
				}
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation on video is unsuccessful.", e);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation on video is unsuccessful.", e);
		}
	}

	/*=======================================================================================================
	//Function for mute and unmute video on browser screen
	=======================================================================================================*/
	public static void MuteUnmuteVideoOnBrowserScreen(WebDriver driver) throws InterruptedException
	{
		try
		{
			WebElement btnMute = driver.findElement(By.id("soundimg"));
			boolean stat = btnMute.isDisplayed();
			if	(stat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Ad Mute / Unmute button is displayed");
				JavascriptExecutor js = (JavascriptExecutor)driver;
				String strLeft = (String) js.executeScript("var a = document.getElementById('soundimg').style.left; return a;");
				//Checking if Video is Mute or Unmute
				if(strLeft.equalsIgnoreCase("0px"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video is mute, Now clicking to unmute the video");
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video is not mute, Now clicking to mute the video");
				}
				//Clicking Mute/Unmute Button
				btnMute.click();
				Thread.sleep(2500);
				strLeft = (String) js.executeScript("var a = document.getElementById('soundimg').style.left; return a;");
				//Checking the state of Mute/Unmute button after clicking
				if(strLeft.equalsIgnoreCase("0px"))
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now video is mute, clicking to unmute the video");
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now video is unmute, clicking to mute the video");
				}
				//Clicking Mute/Unmute Button
				btnMute.click();
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Video Ad Mute/Unmute is not Displayed");
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteVideoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (NullPointerException e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method MuteUnmuteVideoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ");
		}
		catch (Exception e) {
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method MuteUnmuteVideoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ");
		}
	}

	/* =======================================================================================================
	Function to Verify Text 'Ads By ...' On the Browser Screen
	=======================================================================================================*/
	public static String VerifyAdsByTextOnBrowserScreen(WebDriver driver)
	{
		String parseText = adsByText;
		boolean state;
		String result = "";
		try
		{
			if(parseText.isEmpty() || parseText == null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : received expected adsByText is empty, therefore will not be validated. ");
			}
			else
			{
				WebElement adsByVdopiaText = driver.findElement(By.id("vdoAdText"));
				state = VerifyTextOnBrowserScreen(adsByVdopiaText, parseText);
				if(state)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is displayed on the screen.");
					result = "PASS:" + " Expected Text '" + parseText + "' is displayed on the screen.\n";
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is not displayed on the screen.");
					result = "FAIL:" + " Expected Text '" + parseText + "' is not displayed on the screen.\n";
				}
			}
		}
		catch(NullPointerException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received expected adsByText value is null; ", e);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method VerifyAdsByTextOnBrowserScreen.Text '" + parseText + "' is not displayed on the screen.", e);
			state = false;
			result = "FAIL: Exception Handled by method VerifyAdsByTextOnBrowserScreen. Expected Text " + parseText + " is not displayed on the screen.\n";
		}
		return result;
	}

	/* =======================================================================================================
	Function to Verify Text 'Learn More' On the Browser Screen
	=======================================================================================================*/
	public static String VerifyLearnMoreTextOnBrowserScreen(WebDriver driver)
	{
		String parseText = learnMoreText;
		boolean state;
		String result = "";
		try
		{
			if(parseText.isEmpty() || parseText == null)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : received expected learnMoreText is empty, therefore will not be validated. ");
			}
			else
			{
				WebElement learnMoreText = driver.findElement(By.linkText(parseText.trim()));
				state = VerifyTextOnBrowserScreen(learnMoreText, parseText);
				if(state)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is displayed on the screen.");
					result = "PASS:" + " Expected Text '" + parseText + "' is displayed on the screen.\n";
				}
				else
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Text '" + parseText + "' is not displayed on the screen.");
					result = "FAIL:" + " Expected Text '" + parseText + "' is not displayed on the screen.\n";
				}
			}
		}
		catch(NullPointerException n)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Received expected learnMoreText value is null; ", n);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method VerifyLearnMoreTextOnBrowserScreen.Text '" + parseText + "' is not displayed on the screen.", e);
			state = false;
			result = "FAIL: Expected Text " + parseText + " is not displayed on the screen.\n";
		}
		return result;
	}

	/* =======================================================================================================
	Function to click on close button on browser screen
	=======================================================================================================*/
	public static boolean CloseVideoOnBrowserScreen(WebDriver driver)
	{
		boolean flag = false;
		try
		{
			WebElement closeButton = driver.findElement(By.id("closeBut"));
			new WebDriverWait(driver, 45).until(ExpectedConditions.visibilityOf(closeButton));
			boolean state = closeButton.isDisplayed();
			if (state)
			{
				closeButton.click();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed, Now closing video.");
				flag = true;
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is not displayed");
				flag = false;
			}
		}
		catch(WebDriverException e)
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method CloseVideoOnBrowserScreen. Video wasn't closed successfully. ", e);
		}
		catch (NullPointerException e) 
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method CloseVideoOnBrowserScreen. Video wasn't closed successfully.", e);
		}
		catch (Exception e) 
		{
			flag = false;
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method CloseVideoOnBrowserScreen. Video wasn't closed successfully.", e);
		}
		return flag;
	}

	/* =======================================================================================================
	Function to Verify Text On the Browser Screen as given in parameter
	=======================================================================================================*/
	public static boolean VerifyTextOnBrowserScreen(WebElement webelement, String text)
	{
		boolean flag = false;

		try
		{
			if	(webelement.isDisplayed())
			{
				if(webelement.getText().toLowerCase().contains(text.toLowerCase()))
				{
					logger.info(text + " is displayed");
					flag = true;	
				}
				else
				{
					logger.info(text + " is not Displayed");
					flag = false;
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Unable to verify text on screen. " + webelement.toString() + " :Element is not displayed ");
				flag = true;
			}

		}
		catch(WebDriverException e)
		{
			logger.error(text + " is not displayed. Error is: " ,e);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception handled by method: VerifyTextOnBrowserScreen", e);
		}
		return flag;
	}

	/*=======================================================================================================
	//Function for mute and unmute vdoBanner Ad on browser screen
	=======================================================================================================*/
	public static void MuteUnmuteVdoBannerOnBrowserScreen(WebDriver driver) 
	{
		try
		{
			//			String cssSelectorMute = "div[style=\"position: absolute; left: 103px; top: 10px; background-image: url(http://cdn.vdopia.com/files/images/html5/sound.png); width: 18px; height: 18px; background-position: -18px 50%; \"]";
			//			String cssSelectorUnMute = "div[style=\"position: absolute; left: 103px; top: 10px; background-image: url(http://cdn.vdopia.com/files/images/html5/sound.png); width: 18px; height: 18px; background-position: 0px 50%; \"]";

			String muteXpath = "//div[contains(@style, 'sound.png')][contains(@style,'-18px 50%')]";
			String unmuteXpath = "//div[contains(@style, 'sound.png')][contains(@style,'0px 50%')]";

			WebElement btnMute = driver.findElement(By.xpath(muteXpath));
			boolean stat = btnMute.isDisplayed();
			if	(stat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute / Unmute button is displayed");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner is not mute, Now clicking to mute the VdoBanner");
				
				/** Clicking Mute/Unmute Button, TouchActions can be used only in case iphpne driver when iphone is connected
				 * else webdriver is sent here to perform click, thats why catching exception: ClassCastException
				 */
				try{
					new TouchActions(driver).flick(btnMute, -100, 0, 0).perform();
				}catch(ClassCastException c)
				{
					btnMute.click();
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute/Unmute is not Displayed");
			}
			Thread.sleep(2000);

			WebElement btnUnMute = driver.findElement(By.xpath(unmuteXpath));
			boolean unmutestat = btnUnMute.isDisplayed();
			if	(unmutestat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now VdoBanner is mute, clicking to unmute the VdoBanner");

				/** Clicking Mute/Unmute Button, TouchActions can be used only in case iphpne driver when iphone is connected
				 * else webdriver is sent here to perform click, thats why catching exception: ClassCastException
				 */
				try{
					new TouchActions(driver).flick(btnUnMute, -100, 0, 0).perform();
				}catch(ClassCastException c)
				{
					btnUnMute.click();
				}
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : VdoBanner Ad Mute/Unmute is not Displayed after mute.");
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteVdoBannerOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (NullPointerException e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method MuteUnmuteVdoBannerOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method MuteUnmuteVdoBannerOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ", e);
		}
	}

	/*=======================================================================================================
	//Function for mute and unmute Leadervdo Ad on browser screen
	=======================================================================================================*/
	public static void MuteUnmuteLeadervdoOnBrowserScreen(WebDriver driver) throws InterruptedException
	{
		try
		{
			String xpathString ="//div[@id='mini']/div[4]";
			WebElement btnMute = driver.findElement(By.xpath(xpathString));
			boolean stat = btnMute.isDisplayed();
			if	(stat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Mute / Unmute button is displayed");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo is not mute, Now clicking to mute the LeaderVdo");

				btnMute.click();
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Mute/Unmute is not Displayed");
			}
			Thread.sleep(2000);

			WebElement btnUnMute = driver.findElement(By.xpath(xpathString));
			boolean unmutestat = btnUnMute.isDisplayed();
			if	(unmutestat)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Now LeaderVdo is mute, clicking to unmute the LeaderVdo");
				btnUnMute.click();
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : LeaderVdo Ad Mute/Unmute is not Displayed after mute.");
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method MuteUnmuteLeadervdoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ");
		}
		catch (NullPointerException e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : NullPointerException Handled by method MuteUnmuteLeadervdoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ");
		}
		catch (Exception e) 
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method MuteUnmuteLeadervdoOnBrowserScreen. Mute / Unmute operation on video is unsuccessful. ");

		}
	}

	/*=======================================================================================================
	//Function to Click on Interestial Ad on Browser screen for 'cl' tracker and to get destination url
	=======================================================================================================*/
	public static void ClickInterstitialOnBrowserScreen(WebDriver driver) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation will be performed for Interstitial ad on Browser screen.");
		String winHandleBefore;
		String initialUrl = null;

		//Click on running Interstitial to get Landing page url..
		try
		{
			WebElement intRunning = driver.findElement(By.id("vdoModalContent"));

			//Store the current window handle
			winHandleBefore = driver.getWindowHandle();

			initialUrl = driver.getCurrentUrl();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);
			intRunning.click();		//Perform the click operation that opens new window
			Thread.sleep(2000);

			for(String winHandle : driver.getWindowHandles())
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Going to Window handle: " + winHandle);
				if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
				{
					driver.switchTo().window(winHandle);
					Thread.sleep(2000);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
					driver.close();
					driver.switchTo().window(winHandleBefore);
					break;
				}
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method ClickInterstitialOnBrowserScreen. Click operation on Interstitial is unsuccessful. Error message is: ", e);		
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation on Interstitial is unsuccessful.", e);	
		}
	}

	/*=======================================================================================================
	//Function to Click on close button on Interestial Ad on Browser screen.
	=======================================================================================================*/
	public static String CloseInterstitialOnBrowserScreen(WebDriver driver)
	{
		String result = "";

		// For Close Button
		try
		{
			WebElement closeButton = driver.findElement(By.id("closeBut"));
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(closeButton));
			boolean state = closeButton.isDisplayed();

			if (state)
			{
				closeButton.click();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed, Now closing Interstitial.");
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is displayed. ");
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close Button is not displayed");
			}
		}
		catch(NoSuchElementException | TimeoutException e)
		{
			result = "Close button wasn't displayed. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Close button wasn't displayed. ");
		}
		catch (Exception e) 
		{
			result = "Interstitial wasn't closed successfully. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Interstitial ad wasn't closed successfully.", e);
		}
		return result;
	}

	/*=======================================================================================================
	//Function to Click on banner type Ad on Browser screen for 'cl' tracker and to get destination url
	=======================================================================================================*/
	public static String ClickOnBrowserBannerScreen(WebDriver driver, String adFormat) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operaton will be performed on browser banner screen.");

		String winHandleBefore;
		String initialUrl = null;
		String result = "";

		try
		{
			WebElement bannerImage = null;

			if(adFormat.equalsIgnoreCase("banner"))
			{
				bannerImage = driver.findElement(By.xpath("//img[@id='companionImage']"));
			}else if(adFormat.equalsIgnoreCase("jsbanner"))
			{
				driver.switchTo().frame(driver.findElement(By.className("MEDIALETS_FRAME")));
				bannerImage = driver.findElement(By.xpath("//img[@id='click']"));
			}

			if(bannerImage !=null)
			{
				//Store the current window handle
				winHandleBefore = driver.getWindowHandle();

				initialUrl = driver.getCurrentUrl();
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);
				bannerImage.click();		//Perform the click operation that opens new window
				Thread.sleep(2000);

				for(String winHandle : driver.getWindowHandles())
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Going to Window handle: " + winHandle);
					if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
					{
						driver.switchTo().window(winHandle);
						Thread.sleep(2000);
						logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
						driver.close();
						driver.switchTo().window(winHandleBefore);
						break;
					}
				}
			}
			else
			{
				result = "Couldn't click on banner. ";
			}
		}
		catch(Exception e)
		{
			result = "Couldn't click on banner. ";
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickOnBrowserBannerScreen.", e);
		}
		return result;
	}

	/*=======================================================================================================
	//Function to Click on Animated banner type Ad on Browser screen for 'cl' tracker and to get destination url
	=======================================================================================================*/
	public static void ClickOnBrowserAnimatedBannerScreen(WebDriver driver) throws InterruptedException
	{
		logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation will be performed on Aniamted banner screen.");

		String winHandleBefore;
		String initialUrl = null;

		//Click on running video to pause it.
		try
		{
			WebElement aniamtedBanner = driver.findElement(By.className("vdoCompanionDiv"));

			//Store the current window handle
			winHandleBefore = driver.getWindowHandle();

			initialUrl = driver.getCurrentUrl();
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Initial page url: " + initialUrl);
			aniamtedBanner.click();		//Perform the click operation that opens new window
			Thread.sleep(2000);

			for(String winHandle : driver.getWindowHandles())
			{
				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Going to Window handle: " + winHandle);
				if(!(winHandle.equalsIgnoreCase(winHandleBefore)))
				{
					driver.switchTo().window(winHandle);
					Thread.sleep(2000);
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Destination url is: " + driver.getCurrentUrl());
					driver.close();
					driver.switchTo().window(winHandleBefore);
					break;
				}
			}
		}
		catch(WebDriverException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : WebDriverException Handled by method ClickOnBrowserAnimatedBannerScreen. Click operation on Animated banner is unsuccessful. Error message is: ", e);		
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception Handled by method ClickOnBrowserAnimatedBannerScreen.");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Click operation on Animated banner is unsuccessful.", e);
		}
	}

	/*=======================================================================================================
	// Main Function to perform all UI operation on browser screen according to adformat.
	=======================================================================================================*/
	public static String UITestsOnBrowserScreen(WebDriver driver, String strUrl, boolean flagForCloseButtonTest, Bigquery bqConnection, String bqProjectID) 
	{
		String result = "";

		try{
			if (adFormat.equalsIgnoreCase("banner") || adFormat.equalsIgnoreCase("jsbanner"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");

				//Click on screen.
				result = result + "  " + UIOperations_BrowserScreenLib.ClickOnBrowserBannerScreen(driver, adFormat);
			}
			else if(adFormat.equalsIgnoreCase("html"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");

				//Click on screen.
				UIOperations_BrowserScreenLib.ClickOnBrowserAnimatedBannerScreen(driver);
			}
			else if(adFormat.equalsIgnoreCase("vdobanner"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + ", Mute / Unmute operation will be performed now.");

				/** Mute/Unmute operation will be performed on vdoBanner, click will not be performed.
				 */
				UIOperations_BrowserScreenLib.MuteUnmuteVdoBannerOnBrowserScreen(driver);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of this ad...");
			}
			else if(adFormat.equalsIgnoreCase("leadervdo"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Mute / Unmute operation will be performed now.");

				//Mute/Unmute on leader vdo
				UIOperations_BrowserScreenLib.MuteUnmuteLeadervdoOnBrowserScreen(driver);

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Waiting for completion of this ad...");
			}
			else if(adFormat.equalsIgnoreCase("appinterstitial") || adFormat.equalsIgnoreCase("htmlinter"))
			{
				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");

				//Click on screen.
				//UIOperations_BrowserScreenLib.ClickInterstitialOnBrowserScreen(driver);

				//Check Close Button on InterstitialScreen
				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Close button operation will be performed now.");
				result = result + "  " + UIOperations_BrowserScreenLib.CloseInterstitialOnBrowserScreen(driver);			
			}
			else if(adFormat.equalsIgnoreCase("video") || adFormat.equalsIgnoreCase("vastfeed"))
			{
				// Verify Text 'Ads by Vdopia' on the mobile screen
				result = result + UIOperations_BrowserScreenLib.VerifyAdsByTextOnBrowserScreen(driver) + "\n";

				// Verify Text 'Learn More' on the mobile screen
				result = result + UIOperations_BrowserScreenLib.VerifyLearnMoreTextOnBrowserScreen(driver) + "\n";

				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");
				//Click on screen.
				UIOperations_BrowserScreenLib.ClickOnBrowserVideoScreen(driver);

				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Mute /Unmute operation will be performed now.");
				//Mute/Unmute on video
				//UIOperations_BrowserScreenLib.MuteUnmuteVideoOnBrowserScreen(driver);

				//Check Close Button on Video
				if(flagForCloseButtonTest)
				{
					logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " X button is being tried to click now.");
					UIOperations_BrowserScreenLib.CloseVideoOnBrowserScreen(driver);
				}
			}
			else if(adFormat.equalsIgnoreCase("inview"))
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For ad: " +adFormat + " Click operation will be performed now.");

				//Click on screen.
				UIOperations_BrowserScreenLib.ClickOnBrowserVideoScreen(driver);
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ******** Ad format : " +adFormat +" is not supported yet. *****************");
			}

			/** Sleeping thread for mobile ad completion
			 */
			int sleepDurationMS = adWait*1000;
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sleeping thread for duration = "+sleepDurationMS+ " mili seconds. ");

			Thread.sleep(sleepDurationMS);
		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occurred while performing test on browser. ", e);
		}

		return result;
	}
}

