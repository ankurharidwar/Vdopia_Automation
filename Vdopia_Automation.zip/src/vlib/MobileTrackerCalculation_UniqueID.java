/**
 * Last Changes Done on 5 Mar, 2015 12:07:48 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;


public class MobileTrackerCalculation_UniqueID 
{

	//******************** This method will check the appearance of ae tracker *************************************************//
	@SuppressWarnings("finally")
	public static boolean waitForAeTrackerAfterCheckingUiAndVi(String uniqueRequestParam, String channelID, String trackerStartTime, int testDuration) throws SQLException, ClassNotFoundException, InterruptedException, InvocationTargetException
	{
		boolean campaignflag = false;
		boolean channelFlag = false;
		boolean aeFlag = false;

		System.out.println("Wait For Ad Completion Started At: "+MobileTestClass_Methods.DateTimeStamp("yyMMdd_hhmmss"));
		System.out.println();

		try
		{
			MobileTestClass_Methods.InitializeConfiguration();

			//for first 5 seconds check if either of vi / ui is fired
			for(int i=0; i<5; i++)
			{
				System.out.println("Checking if ui or vi tracker is fired yet... attempt# "+i);

				if(checkChannelTracker("ui", uniqueRequestParam, channelID, trackerStartTime))
				{	
					channelFlag = true;
					System.out.println("ui Tracker is fired, ae tracker will not be checked now. ");
					break;
				}
				else if(checkCampaignTracker("vi", uniqueRequestParam, channelID, trackerStartTime))
				{
					campaignflag = true;
					System.out.println("vi Tracker is fired, ae tracker will be checked now. ");
					break;
				}

				Thread.sleep(1000);	
			}

			//Check ae tracker only if vi is fired.
			if(campaignflag)
			{
				for(int i=0; i<testDuration; i++)
				{
					System.out.println("Waiting for completion of ad... by checking if ae tracker is fired yet... attempt# "+i);

					if(checkCampaignTracker("ae", uniqueRequestParam, channelID, trackerStartTime))
					{
						aeFlag = true;
						System.out.println("ae Tracker is fired. ");
						break;
					}
					Thread.sleep(1000);	
				}
			}
			else
			{
				if(channelFlag)
				{
					System.out.println("ui Tracker is fired, will not wait any more... ");
				}
				else
				{
					//In case neither ui or vi is fired then sleep till duration passed in definition
					System.out.println("Neither of ui and vi tracker is fired... waiting for completion for: "+testDuration + " seconds. ");
					Thread.sleep(testDuration*1000);
				}

			}
		}
		catch(Exception e)
		{
			aeFlag = false;
			System.out.println("Exception handled by method: WaitForAdEndTracker, while checking ae tracker. ");
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println();
			System.out.println("Wait For Ad Completion Ended At: "+MobileTestClass_Methods.DateTimeStamp("yyMMdd_hhmmss"));
			System.out.println();

			return aeFlag;
		}
	}


	//******************** This method will execute query to get a channel side tracker *************************************************//
	@SuppressWarnings("finally")
	public static boolean checkChannelTracker(String channelTracker, String uniqueRequestParam, String channelID, String trackerStartTime) throws SQLException, ClassNotFoundException, InterruptedException, InvocationTargetException
	{
		boolean flag = false;

		try
		{
			MobileTestClass_Methods.InitializeConfiguration();

			String sqlQueryForChannelTracker = " SELECT measure AS Tracker_Name, Campaign_ID  " +
					" FROM " +" (SELECT measure, IFNULL(campaign_id, 'NoCampaign') AS Campaign_ID FROM ad_log0 " +
					" WHERE channel_id = '"+ channelID +"' AND  uniq_id = '" + uniqueRequestParam + "'" + 
					" AND measure = '"+ channelTracker +"' AND tstamp >= '" + trackerStartTime + "'" +
					" GROUP BY measure " +
					" UNION ALL " +
					" SELECT measure, IFNULL(campaign_id, 'NoCampaign') AS Campaign_ID FROM ad_log1 " +
					" WHERE channel_id = '"+ channelID +"' AND  uniq_id = '" + uniqueRequestParam + "'" +
					" AND measure = '"+ channelTracker +"' AND tstamp >= '" + trackerStartTime + "'" +
					" GROUP BY measure " +
					") AS tmp GROUP BY measure LIMIT 1; ";

			System.out.println("Print query for checking channel tracker: " +sqlQueryForChannelTracker);


			Connection con = MobileTestClass_Methods.CreateServeSQLConnection();
			String [][] channelTrackerData = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArray(con, sqlQueryForChannelTracker);
			con.close();

			if(channelTrackerData.length<1)
			{
				flag = false;
				System.out.println("Channel Tracker: "+ channelTracker +" is not fired yet." );
			}
			else
			{
				if(channelTrackerData[0][0].equalsIgnoreCase(channelTracker))
				{
					flag = true;
					System.out.println("Found Channel Tracker: " +channelTrackerData[0][0] );
				}
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exception handled by method: GetChannelTracker, while checking channel side tracker: "+channelTracker);
			System.out.println(e.getMessage());
			flag = false;
		}
		finally
		{
			return flag;
		}
	}	


	//******************** This method will execute query to get a campaign side tracker *************************************************//
	@SuppressWarnings("finally")
	public static boolean checkCampaignTracker(String campaignTracker, String uniqueRequestParam, String channelID, String trackerStartTime) throws SQLException, ClassNotFoundException, InterruptedException, InvocationTargetException
	{
		boolean flag = false;

		try
		{
			MobileTestClass_Methods.InitializeConfiguration();

			String sqlQueryForCampaignTracker = " SELECT measure AS Tracker_Name, Campaign_ID  " +
					" FROM " +" (SELECT measure, IFNULL(campaign_id, 'NoCampaign') AS Campaign_ID FROM ad_log0 " +					
					" WHERE channel_id = '"+ channelID +"' " +
					" AND uniq_id = '"+ uniqueRequestParam +"' " +

					//" AND tstamp >= (SELECT tstamp FROM ad_log0 WHERE uniq_id = '"+ uniqueRequestParam + "' ORDER  BY tstamp DESC LIMIT 1) " +
					//" AND cookie_val = (SELECT cookie_val FROM ad_log0 WHERE uniq_id = '"+ uniqueRequestParam +"' ORDER  BY tstamp DESC LIMIT 1) " +

					" AND measure = '" + campaignTracker + "' AND tstamp >= '" + trackerStartTime + "'" +
					" GROUP BY measure " +
					" UNION ALL " +
					" SELECT measure, IFNULL(campaign_id, 'NoCampaign') AS Campaign_ID FROM ad_log1 " +
					" WHERE channel_id = '"+ channelID +"' " +
					" AND uniq_id = '"+ uniqueRequestParam +"' " +

					//" AND tstamp >= (SELECT tstamp FROM ad_log1 WHERE uniq_id = '"+ uniqueRequestParam + "' ORDER  BY tstamp DESC LIMIT 1) " +
					//" AND cookie_val = (SELECT cookie_val FROM ad_log1 WHERE uniq_id = '"+ uniqueRequestParam +"' ORDER  BY tstamp DESC LIMIT 1) " +

					" AND measure = '"+ campaignTracker +"' AND tstamp >= '" + trackerStartTime + "'" +
					" GROUP BY measure " +
					") AS tmp GROUP BY measure LIMIT 1; ";

			System.out.println("Print query for checking campaign side tracker: " +sqlQueryForCampaignTracker);

			Connection con = MobileTestClass_Methods.CreateServeSQLConnection();
			String [][] CampaignTrackerData = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArray(con, sqlQueryForCampaignTracker);
			con.close();

			if(CampaignTrackerData.length<1)
			{
				flag = false;
				System.out.println("Campaign Tracker: "+campaignTracker +" is not fired yet. ");
			}
			else
			{
				if(CampaignTrackerData[0][0].equalsIgnoreCase(campaignTracker))
				{
					flag = true;
					System.out.println("Found Campaign Tracker: " +CampaignTrackerData[0][0] );
				}
			}
		}
		catch(Exception e)
		{
			flag = false;
			System.out.println("Exception handled by method: GetCampaignTracker, while checking campaign side tracker: "+campaignTracker);
			System.out.println(e.getMessage());
		}
		finally
		{
			return flag;			
		}

	}


	//This method will return the count supplied campaign tracker
	@SuppressWarnings("finally")
	public static int getSpecificCampaignTrackerWithUniqueParam(String campaignTrackerName, String channelID, String trackerStartTime, String uniqueRequestParam)
	{
		Object trackerCount = null;
		try{
			
			MobileTestClass_Methods.InitializeConfiguration();
			
			String sqlQueryForCampaignTracker = MobileTestClass_Methods.sqlQueryWithUniqueParamForCampaignTracker(channelID, trackerStartTime, uniqueRequestParam);

			//Getting Campaign Trackers In 2 D Array. 
			Connection serveConnectionForChannel = MobileTestClass_Methods.CreateServeSQLConnection();
			String [][] validationDataForChannelTracker = MobileTestClass_Methods.ExecuteMySQLQueryReturnsArray(serveConnectionForChannel, sqlQueryForCampaignTracker);
			serveConnectionForChannel.close();

			//Getting count of desired tracker
			trackerCount = MobileTestClass_Methods.TrackerCalculation(validationDataForChannelTracker, campaignTrackerName);
			System.out.println(campaignTrackerName + " has count = " +trackerCount);

		}catch(Exception e)
		{
			trackerCount = 0;
			System.out.println("Exception occured while checking count of tracker: "+campaignTrackerName);
			System.out.println(e);
		}
		finally
		{
			if(trackerCount != null)
			{
				return Integer.parseInt(trackerCount.toString());
			}
			else
			{
				return 0;
			}
		}

	}

}


