/**
 * Last Changes Done on 27 Jul, 2015 2:21:54 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 





public class EmailLib 
{

	Logger logger = Logger.getLogger(EmailLib.class.getName());

	/** This method sends an email with testing result as attachment.
	 * 
	 * @param toAddress
	 * @param fromAddress
	 * @param attachment
	 * @return
	 */
	public boolean sendEmail(String toAddress, String fromAddress, String attachment)
	{
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Emailing results to: "+toAddress);
			Properties props = new Properties();

			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.socketFactory.port", "465");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", "465");

			Session session = Session.getDefaultInstance(props, new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() 
				{
					return new PasswordAuthentication("qa-scripting@vdopia.com","hg>*aWq2");
				}
			});

			/** Set message */
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromAddress));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress));

			/** Set subject */
			String emailSubject = MobileTestClass_Methods.propertyConfigFile.getProperty("emailSubject").toString();
			String dateTime = MobileTestClass_Methods.DateTimeStamp("MM-dd-yyyy hh:mm:ss a");
			message.setSubject(emailSubject + " Executed At Machine: "+getComputerName() + ", At Time: "+dateTime);

			/** Set message body part */
			BodyPart bodypart = new MimeBodyPart();
			String bodyText = "Chocolate results are stored in mysql table: chocolateResults of database: qaautomation.";
			bodyText = bodyText + "\n\nMobile Ad Serving results are stored in mysql table: mobileAdServingResults of database: qaautomation.";
			bodypart.setText("Daily Automation Execution Result. \n\n"+ bodyText +" \n\nThanks.");

			/** set multipart and add body part into it */
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(bodypart);

			/** Set attachment */
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Attaching file: "+attachment);
			DataSource source = new FileDataSource(new File(attachment));
			bodypart = new MimeBodyPart();
			bodypart.setDataHandler(new DataHandler(source));
			bodypart.setFileName("Automation_Execution_Results.xls");

			/** add attachment */
			multipart.addBodyPart(bodypart);
			message.setContent(multipart);

			Transport.send(message);

			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Email is sent. ");
			return true;
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while sending email. ", e);
			return false;
		}
	}


	public String getComputerName() 
	{
		String hostname = "Unknown";

		try
		{
			InetAddress addr;
			addr = InetAddress.getLocalHost();
			hostname = addr.getHostName();
		}
		catch (UnknownHostException ex)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Hostname can not be resolved");
		}

		return hostname;
	}
}
