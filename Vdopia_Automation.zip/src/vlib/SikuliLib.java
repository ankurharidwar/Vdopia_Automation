/**
 * Last Changes Done on Jan 28, 2015 2:21:29 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import org.apache.log4j.Logger; 
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;

public class SikuliLib 
{

	static Logger logger = Logger.getLogger(SikuliLib.class.getName());

	//This method will be used to click an image using Sikuli 
	public static void ClickObjectUsingSikuli(String imageLocation) throws InterruptedException 
	{
		try
		{
			Screen screen = new Screen();
			Pattern pattern = null;

			try
			{
				pattern = new Pattern(imageLocation);
				screen.wait(pattern,30);
				screen.click(pattern);
				System.out.println("First Attempt To Find Image.");
			}
			catch(FindFailed f)
			{
				System.out.println("Exception In First Attempt: " +f.getMessage());
				System.out.println("FindFailed Exception Handled By Method: ClickObjectUsingSikuli. Please check image being used to identify the webelement. supplied image: " +imageLocation);
				Assert.fail("Image wasn't found. Please use correct image.");
			}

			Thread.sleep(1000);

			//In case image/object wasn't clicked in first attempt and cursor stays in the same screen, then do second atempt.
			if(screen.exists(pattern) != null)
			{
				try
				{
					screen.getLastMatch().click(pattern);
					System.out.println("Second Attempt To Find Image.");
					System.out.println("Object: " +imageLocation + " is clicked successfully.");
				}
				catch(FindFailed f)
				{
					System.out.println("Exception In Second Attempt: " +f.getMessage());
					System.out.println("FindFailed Exception Handled By Method: ClickObjectUsingSikuli. Please check image being used to identify the webelement. supplied image: " +imageLocation);
				}
			}

			Thread.sleep(1000);		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	/*
	//This method checks a particular element's presence in web page.
	public static void ValidateElementUsingSikuli(String imageLocation) throws FindFailed, InterruptedException 
	{
		int wait = 600;

		Screen screen = new Screen();
		try
		{
			Pattern pattern = new Pattern(imageLocation);
			screen.wait(pattern,wait);

			Boolean img_exist = false;

			for(int i=0; i<wait; i++)
			{	
				if(screen.exists(pattern) != null)
				{
					img_exist = true;
					System.out.println("Image: " +imageLocation +" is found on screen successfully: ");
					break;
				}
				Thread.sleep(1000);
			}

			if (!(img_exist))
			{
				Assert.fail("Fail: Unable To Find Element: " +imageLocation);
			}
		}catch(FindFailed f)
		{
			System.out.println("Find Failed Exception Handled By Method: SikuliLib.ValidateElementUsingSikuli. " + f.getMessage());
			Assert.fail("ValidateElementUsingSikuli Fail: Unable To Find Element: " +imageLocation);
		}

	}

	 */


	//This method checks a particular element's presence in web page.
	@SuppressWarnings("finally")
	public static String ValidateElementUsingSikuli(String imageLocation) throws FindFailed, InterruptedException 
	{
		String result = "";
		int wait = 20;

		Screen screen = new Screen();
		try
		{
			Pattern pattern = new Pattern(imageLocation);
			screen.wait(pattern,wait);

			Boolean img_exist = false;

			for(int i=0; i<wait; i++)
			{	
				if(screen.exists(pattern) != null)
				{
					img_exist = true;
					System.out.println("Image: " +imageLocation +" is found on screen successfully: ");

					result = "Image Preview was found on screen.";
					break;
				}
				Thread.sleep(1000);
			}

			if (!(img_exist))
			{
				result = "WARNING: Image Preview wasn't found on screen.";
				System.out.println("WARNING: Unable To Find Image: " +imageLocation);
			}
		}
		catch(FindFailed f)
		{
			System.out.println("Find Failed Exception Handled By Method: SikuliLib.ValidateElementUsingSikuli. ");
			System.out.println("WARNING: Unable To Find Image: " +imageLocation + "\n" + f.getMessage());
			//Assert.fail("ValidateElementUsingSikuli Fail: Unable To Find Element: " +imageLocation);

			result = "WARNING: Image Preview wasn't found on screen.";
		}
		finally
		{
			return result;
		}

	}


	//This method checks a particular element's presence in web page.
	@SuppressWarnings("finally")
	public static String ValidateElementUsingSikuli(String imageLocation, int waitDurationInSeconds) throws FindFailed, InterruptedException 
	{
		String result = "";
		int wait = waitDurationInSeconds;

		Screen screen = new Screen();
		try
		{
			Pattern pattern = new Pattern(imageLocation);
			screen.wait(pattern,wait);

			Boolean img_exist = false;

			for(int i=0; i<wait; i++)
			{	
				if(screen.exists(pattern) != null)
				{
					img_exist = true;
					System.out.println("Image: " +imageLocation +" is found on screen successfully: ");

					result = "Pass: Image Preview was found on screen.";
					break;
				}
				Thread.sleep(1000);
			}

			if (!(img_exist))
			{
				result = "Fail: Image Preview wasn't found on screen.";
				System.out.println("Fail: Unable To Find Image: " +imageLocation);
			}
		}
		catch(FindFailed f)
		{
			System.out.println("Find Failed Exception Handled By Method: SikuliLib.ValidateElementUsingSikuli. ");
			System.out.println("Fail: Unable To Find Image: " +imageLocation + "\n" + f.getMessage());
			//Assert.fail("ValidateElementUsingSikuli Fail: Unable To Find Element: " +imageLocation);

			result = "Fail: Image Preview wasn't found on screen because of sikuli exception.";
		}
		finally
		{
			return result;
		}

	}


}
