/**
 * Last Changes Done on 5 Mar, 2015 12:07:50 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTimeLib 
{


	public static void day(String[] args) 
	{  

		Date now = new Date();  

		SimpleDateFormat simpleDateformat = new SimpleDateFormat("E"); // the day of the week abbreviated  
		//System.out.println(simpleDateformat.format(now));  

		simpleDateformat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely  
		System.out.println(simpleDateformat.format(now));  

		Calendar calendar = Calendar.getInstance();  
		calendar.setTime(now);  
		System.out.println(calendar.get(Calendar.DAY_OF_WEEK)); // the day of the week in numerical format  

	}  

}
