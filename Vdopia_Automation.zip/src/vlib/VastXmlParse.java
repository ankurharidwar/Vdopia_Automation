/**
 * Last Changes Done on Feb 9, 2015 1:14:09 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;





public class VastXmlParse 
{

	static Logger logger = Logger.getLogger(VastXmlParse.class.getName());


	public static String getVastSourceXML_URL(String campaign_id, Connection con) 
	{
		String vastXMLURL = "";
		try
		{
			String vastXMLSetting = null;

			String NewSqlQuery = "select additional_settings as Vast_Settings from ad_network where campaign_id = " + campaign_id + ";";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running Query in DB : " + NewSqlQuery);

			Statement NewStmt = (Statement) con.createStatement();
			ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

			while(NewRs.next())
			{
				vastXMLSetting =  NewRs.getString("Vast_Settings").toString();
			}
			vastXMLURL = processJSON.getValueStr(vastXMLSetting, "adfeed");
		}
		catch(Exception e)
		{
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting vast source xml. ", e);
		}

		return vastXMLURL;
	}

	
	public static String getVastSourceXML_URL(String campaign_id) 
	{
		String vastXMLURL = "";
		try
		{
			String vastXMLSetting = null;

			String NewSqlQuery = "select additional_settings as Vast_Settings from ad_network where campaign_id = " + campaign_id + ";";
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Running Query in DB : " + NewSqlQuery);

			Connection con = MobileTestClass_Methods.CreateSQLConnection();
			Statement NewStmt = (Statement) con.createStatement();
			ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

			while(NewRs.next())
			{
				vastXMLSetting =  NewRs.getString("Vast_Settings").toString();
			}

			con.close();

			vastXMLURL = processJSON.getValueStr(vastXMLSetting, "adfeed");
		}
		catch(Exception e)
		{
			logger.debug(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Error occurred while getting vast source xml. ", e);
		}

		return vastXMLURL;
	}

	public static String GetVastXML(String vast_url)
	{

		String Request_Result = "";

		try 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Sending Request To URL: " + vast_url);
			Request_Result = httpClientWrap.sendGetRequest(vast_url);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ###############  XML START   #####################");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Data Received from URL : " + Request_Result);
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ###############  XML END   #######################");

		}
		catch (Exception e) 
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception while downloading XML from URL :" + vast_url.toString());
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception detail : ", e);
		}

		return Request_Result;
	}


	public static List<String> RenderXML(String XMLData, String XMLTag) throws ParserConfigurationException, SAXException, IOException
	{

		List<String> TagList = new ArrayList<String>();

		InputStream stream = new ByteArrayInputStream(XMLData.getBytes("UTF-8"));

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		Document doc = null;

		try{
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(stream);
		}catch(SAXParseException e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception while parsing the vast");
		}

		if(doc != null)
		{
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();

			//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Root element :" + doc.getDocumentElement().getNodeName());

			NodeList IList = doc.getElementsByTagName(XMLTag);

			//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ----------------------------");

			for (int temp = 0; temp < IList.getLength(); temp++) 
			{
				Node INode = IList.item(temp);

				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : \nCurrent Element :" + INode.getNodeName());

				if (INode.getNodeType() == Node.ELEMENT_NODE) 
				{

					Element eElement = (Element) INode;

					TagList.add(eElement.getTextContent().toString());

					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Data in Vast XML for Tag = " + XMLTag + " is : "+ eElement.getTextContent());
				}
			}
		}
		return TagList;

	}


	//Analyze xml and get attribute value of supplied tag
	@SuppressWarnings("finally")
	public static List<String> RenderXML_GetElementAttribute(String xmlData, String xmlTag, String attribute) throws ParserConfigurationException, SAXException, IOException
	{
		List<String> attributeValue = new ArrayList<String>();

		//IN case xml data is sent as blank or empty then return empty list 
		if(xmlData.isEmpty() || xmlData.equalsIgnoreCase(""))
		{
			return attributeValue;
		}
		else
		{
			try
			{
				InputStream stream = new ByteArrayInputStream(xmlData.getBytes("UTF-8"));

				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(stream);

				//optional, but recommended
				//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
				doc.getDocumentElement().normalize();

				//get node list
				NodeList IList = doc.getElementsByTagName(xmlTag);

				//Converting node to element and get the corresponding attribute
				for(int i=0; i<IList.getLength(); i++)
				{
					Element e = (Element) IList.item(i);
					String value = e.getAttribute(attribute).toString();

					//Add all value to a list
					attributeValue.add(value);

					//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Element Value: " + value + " For Attribute: "+attribute);
				}
			}
			catch (Exception e) 
			{
				attributeValue = null;

				logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Exception occured while getting attribute: "+attribute, e);
			}
			finally
			{
				return attributeValue;
			}
		}
	}


	//Analyze xml and get attribute value of supplied tag
	public static List<String> VastDataParser_GetElementAttribute(String vast_url, String XMLTag, String attribute) throws ParserConfigurationException, SAXException, IOException
	{
		String VastXML_Data = GetVastXML(vast_url);
		List<String> TagData = RenderXML_GetElementAttribute(VastXML_Data, XMLTag, attribute);

		return TagData;
	}


	public static TreeMap<String, ArrayList<String>> RenderXML(String XMLData, String XMLTag, String id) throws ParserConfigurationException, SAXException, IOException

	{

		//List<> TagList = new ArrayList<String>();
		TreeMap <String, ArrayList<String> > TagMap = new TreeMap<String, ArrayList <String>>();

		List<String> TagIds = new ArrayList<String>();


		InputStream stream = new ByteArrayInputStream(XMLData.getBytes("UTF-8"));

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		//dbFactory.setValidating(true);
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(stream);

		//optional, but recommended
		//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
		doc.getDocumentElement().normalize();

		//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Root element :" + doc.getDocumentElement().getNodeName());

		NodeList IList = doc.getElementsByTagName(XMLTag);

		//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : ----------------------------");


		for (int temp = 0; temp < IList.getLength(); temp++) 
		{

			Node INode = IList.item(temp);

			//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : \nCurrent Element :" + INode.getNodeName());

			if (INode.getNodeType() == Node.ELEMENT_NODE) 
			{

				Element eElement = (Element) INode;

				TagIds.add(eElement.getAttribute(id));

			}
		}

		Set<String> Tagset = new HashSet<String>(TagIds);

		for(String TagId : Tagset)
		{

			ArrayList<String> TagData = new ArrayList<String>();

			for (int temp = 0; temp < IList.getLength(); temp++) 
			{

				Node INode = IList.item(temp);

				//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : \nCurrent Element :" + INode.getNodeName());

				if (INode.getNodeType() == Node.ELEMENT_NODE) 
				{

					Element eElement = (Element) INode;
					if(eElement.getAttribute(id).equalsIgnoreCase(TagId))
					{
						TagData.add(eElement.getTextContent().toString());
						//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : For Key = '" + eElement.getAttribute(id) + "' in Tag = '" + XMLTag + "' Value is '" + eElement.getAttribute(id) +"'");
						//logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Data in Vast XML for Tag = '" + XMLTag + "' is : "+ eElement.getTextContent());

					}

				}


			}

			TagMap.put(TagId.toString(),TagData);
		}

		return TagMap;
	}


	public static List<String> VastDataParser(String vast_url, String XMLTag) throws ParserConfigurationException, SAXException, IOException
	{

		String VastXML_Data = GetVastXML(vast_url);
		List<String> TagData = RenderXML(VastXML_Data, XMLTag);

		return TagData;
	}

	public static TreeMap<String, ArrayList<String>> VastDataParser(String vast_url, String XMLTag, String id) throws ParserConfigurationException, SAXException, IOException
	{

		String VastXML_Data = GetVastXML(vast_url);


		TreeMap<String, ArrayList<String>> TagData = RenderXML(VastXML_Data, XMLTag, id);

		return TagData;

	}


}
