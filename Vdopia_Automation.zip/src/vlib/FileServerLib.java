/**
 * Last Changes Done on Jan 22, 2015 3:09:08 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: Introduced Logger 
 */

package vlib;

import projects.TestSuiteClass;import org.apache.log4j.Logger; 
import org.eclipse.jetty.server.Server;

import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.handler.DefaultHandler;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;





public class FileServerLib 
{
	Server server;
	Logger logger = Logger.getLogger(FileServerLib.class.getName());

	public void FTPStart(int portnumber) 
	{
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Starting file server at port: "+portnumber);
			
			this.server = new Server(portnumber);

			ResourceHandler resource_handler = new ResourceHandler();
			resource_handler.setDirectoriesListed(true);

			resource_handler.setWelcomeFiles(new String[]{ "index.html" });

			resource_handler.setResourceBase(".");
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : serving " + resource_handler.getBaseResource());

			HandlerList handlers = new HandlerList();
			handlers.setHandlers(new Handler[] { resource_handler, new DefaultHandler() });
			this.server.setHandler(handlers);

			boolean flag = this.server.isRunning();

			if(flag)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Server is already running: ");

			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Starting FTP Server : ");
				this.server.start();
			}
		}
		catch(Exception e)
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Automation Script is not able to start FTP Server at port :" + portnumber, e);
		}

	}

	public void FTPStop()
	{
		try
		{
			logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Stopping file server. ");
			
			boolean flag = this.server.isRunning();

			if(flag)
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Stopping Server: ");
				this.server.stop();
			}
			else
			{
				logger.info(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Server is not running: ");
			}

		}
		catch(Exception e)
		{
			logger.error(TestSuiteClass.UNIQ_EXECUTION_ID.get()+" : Automation Script is not able to stop FTP Server.", e);
		}

	}


}
