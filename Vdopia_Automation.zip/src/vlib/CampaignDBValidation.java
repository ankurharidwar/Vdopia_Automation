/**
 * Last Changes Done on 5 Mar, 2015 12:07:51 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class CampaignDBValidation 
{
	
	
	public static boolean isadvertiserExist(String adv_email) throws ClassNotFoundException, SQLException
	{
		String sqlQuery = "Select count(*) as Exist FROM advertiser where email = '" + adv_email + "';";
		System.out.println("Running Query in DB : " + sqlQuery);
		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("Advertiser with email = " + adv_email + " does not exist in adplatform.advertiser table");

			}
			else
			{
				System.out.println("Advertiser with email = " + adv_email + " exist in adplatform.advertiser table");
				exist = true;
			}

		}

		con.close();

		return exist;

	}
	
	
	
	public static boolean isCampaignExist(String campaign_name, String adv_email) throws ClassNotFoundException, SQLException
	{
		String sqlQuery = "Select count(*) as Exist from campaign c inner join advertiser a  on c.advertiser_id = a.id where c.name like '" + 
							campaign_name + "' and a.email  = '"+ adv_email + "';";
		
		System.out.println("Running Query in DB : " + sqlQuery);
		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("Camapign with name = " + campaign_name + " does not exist advertiser (" + adv_email + ") in adplatform.rtb_channels table");
			}
			else
			{
				System.out.println("Camapign with name = " + campaign_name + " exist advertiser (" + adv_email + ") in adplatform.rtb_channels table");

				exist = true;
			}

		}

		con.close();

		return exist;

	}
	
	public static String getTargetedChannelForCampaign(String campaign_name, String adv_email) throws ClassNotFoundException, SQLException
	{
		
		String rtbAppId = null;
		String sqlQuery = "select count(*) as Exist from campaign c inner join advertiser a  on c.advertiser_id = a.id where c.name like '" + 
							campaign_name + "' and a.email  = '"+ adv_email + "';";
		
		System.out.println("Running Query in DB : " + sqlQuery);

		//Connection con =  MobileTestClass_Methods.CreateSQLConnection();
		Connection con =  MobileTestClass_Methods.CreateServeSQLConnection();
		Statement stmt = (Statement) con.createStatement();
		ResultSet rs = (ResultSet) stmt.executeQuery(sqlQuery);
		boolean exist = false;
		
		
		while(rs.next())
		{
			if( Integer.parseInt( rs.getString("Exist").toString()) == 0)
			{
				System.out.println("Camapign with name = " + campaign_name + " does not exist advertiser (" + adv_email + ") in adplatform.rtb_channels table");

			}
			else if(Integer.parseInt( rs.getString("Exist").toString()) >= 1)
			{
				System.out.println("Camapign with name = " + campaign_name + " does not exist advertiser (" + adv_email + ") in adplatform.rtb_channels table");
				exist = true;
			}
		}

		
		
		con.close();

		if(exist)
		{
			String NewSqlQuery = "select channel_choice as channel_choice from campaign c inner join advertiser a  on c.advertiser_id = a.id where c.name like '" + 
							campaign_name + "' and a.email  = '"+ adv_email + "';";
			
			System.out.println("Running Query in DB : " + NewSqlQuery);

			//Connection NewCon =  MobileTestClass_Methods.CreateSQLConnection();
			Connection NewCon =  MobileTestClass_Methods.CreateServeSQLConnection();
			Statement NewStmt = (Statement) NewCon.createStatement();
			ResultSet NewRs = (ResultSet) NewStmt.executeQuery(NewSqlQuery);

			while(NewRs.next())
			{
				String channelID = NewRs.getString("channel_choice").toString();
				
				rtbAppId = RTBLib.getRTBAppFromChannelID(channelID);

			}

			NewCon.close();

		}

		return rtbAppId;

	}
	
	

}
