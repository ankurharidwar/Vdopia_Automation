/**
 * Last Changes Done on 5 Mar, 2015 12:07:44 PM
 * Last Changes Done by Pankaj Katiyar
 * Change made in Vdopia_Automation
 * Purpose of change: 
 */
package vlib;

import java.io.File;
import java.io.IOException;
import java.util.TreeMap;


import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class GetReportLabelsLib 
{
	static String expectedTestDataLocation;

	public GetReportLabelsLib(String expectedTestDataLocation)
	{
		GetReportLabelsLib.expectedTestDataLocation = expectedTestDataLocation;
	}


	//This Method Identifies All The Web Elements Present In The Supplied Screen (From Object Repository) And Returns Them In A <WebElement>List.
	public TreeMap<Integer, String> GetReportsLabel (String reportType, String timePeriod, String resultType) throws BiffException, IOException
	{
		//Object Repository Sheet Location Will be set by calling the WebElementsLib constructor.
		Workbook wb = Workbook.getWorkbook(new File(expectedTestDataLocation));
		Sheet sheet = wb.getSheet(0);
		TreeMap<Integer, String> reportData = new TreeMap<Integer, String>();

		//**** This Code Will Read The First And Last Line Line Containing String - Report_Type And Constructor will be called to set this

		int reportTypeColumn = sheet.findCell("Report_Type").getColumn();
		int reportStartRow = sheet.findCell(reportType).getRow();
		int reportEndRow = sheet.findCell(reportType, reportTypeColumn, reportStartRow+1, reportTypeColumn, sheet.getRows(), false).getRow();

		int timePeriodColumn = sheet.findCell("Time_Period").getColumn(); 

		//********************************************************************************

		int timePeriodStartRow = 0;
		int timePeriodEndRow = 0;

		try
		{
			//************** This Code Will Read The First And Last Line Line Containing Time_Period ****************

			timePeriodStartRow = sheet.findCell(timePeriod, timePeriodColumn, reportStartRow, timePeriodColumn, reportEndRow, false).getRow();
			timePeriodEndRow = sheet.findCell(timePeriod, timePeriodColumn, timePeriodStartRow+1, timePeriodColumn, reportEndRow, false).getRow();

			int resultTypeStartRow = 0;
			int resultTypeEndRow = 0;

			int resultTypeColumn = sheet.findCell("Result_Type").getColumn();

			resultTypeStartRow = sheet.findCell(resultType, resultTypeColumn, timePeriodStartRow, resultTypeColumn, timePeriodEndRow, false).getRow();
			resultTypeEndRow = sheet.findCell(resultType, resultTypeColumn, resultTypeStartRow+1, resultTypeColumn, timePeriodEndRow, false).getRow();

			int labelColumn = sheet.findCell("Label_Name").getColumn();
			int positionColumn = sheet.findCell("Position").getColumn();			

			for(int i=resultTypeStartRow; i<= resultTypeEndRow; i++)
			{
				String key = sheet.getCell(positionColumn, i).getContents().toString().trim();
				String value = sheet.getCell(labelColumn, i).getContents().toString().trim();
				reportData.put(Integer.parseInt(key), value);
			}
		}
		catch(Exception n)
		{
			System.out.println("Exception Handled By Method: GetReportsLabel. " +n.getMessage());
		}

		//Closing The Workbook after reading values.
		wb.close();

		return reportData;
	}


}
