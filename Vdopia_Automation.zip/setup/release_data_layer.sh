#!/bin/bash
set -x
#
# This script use for release tag in Objesct Server Instance
#

tag='v1.0'

while getopts ":t:h" opt; do
    case "$opt" in
        t)
            tag=$OPTARG
            ;;
    esac
done

if [ "${tag}" = "v1.0" ]; then
    echo "No tag provided. Cant release code" >&2
    exit 0
fi

#stopping objectserver service
service hudson stop
sleep 15
rm -rf /root/hudson
rm -rf /mnt/filestore/*
git clone git@bitbucket.org:vdopia/hudson.git /root/hudson

cd /root/hudson
git reset --hard
git clean -f -d
git fetch
git fetch --tags
git checkout  $tag -f
if [ $? -eq 0 ]
then
        echo "Data Layer repo checked out"
else
        echo "Failed while checking out Data Layer repository"
        exit 1
fi

# copy settings.xml file for making connections
cp /root/hudson/settings.xml /root/.m2/
cd /root/hudson_properties/; cp -r wurfl  ~/.m2/repository_live/com/wurfl/
cd /root/hudson
#check dir if not exist
DIR=/mnt/filestore
if [ ! -d "$DIR" ];then
	mkdir -p /mnt/filestore
else
	echo "$DIR Already Exists"
fi
#changes in reference.conf
sed -i 's#/Users/lokeshkohli/filestore#/mnt/filestore#g' netty/reference.conf
sed -i 's/devawss3objectstore/qaautomationawss3objectstore/g' netty/reference.conf
sed -i 's/AKIAILSWR2Z5RMRO6UEQ/AKIAIJR2UQZSAQBV5BFQ/g' netty/reference.conf 
sed -i 's#2u0jiESDYuMY6xk6qxor7+tJz+UkcPD9kzuTFyLY#yFUa6IS67wCc8Utz3nYl9MTWLrhiNA2nRunFBWF2#g' netty/reference.conf 
##Chagnes in DB file
#sed -i 's@\bdev\.vdopia\.com\b@10.0.99.25@g' Objectstore/db-config.xml
#sed -i 's/\<root\>/object_server/g' Objectstore/db-config.xml
#sed -i 's/\<root123\>/2l;wdfup1oi3nr;efyi23/g' Objectstore/db-config.xml


#Checking out the latest hudson_properties repository
rm -rf /root/hudson_properties
git clone git@bitbucket.org:vdopia/hudson_properties.git /root/hudson_properties

cd /root/hudson_properties
git reset --hard
git clean -f -d
git pull origin master
if [ $? -eq 0 ]
then
        echo "Hudson_properties repo checked out"
else
        echo "Failed while checking out Hudson_properties repository"
        exit 1
fi

#Copying all properties files in /root/hudson folder
cp /root/hudson_properties/netty/log4j.properties /root/hudson/netty/
cp redis/redisConfig.properties /root/hudson/redis/src/main/resources/redisConfig.properties
cp bigQuery/fluentdConfig.properties /root/hudson/bigQuery/src/main/resources/fluentdConfig.properties
cp externalcache/pooling.properties /root/hudson/externalcache/src/main/resources/com/vdopia/config/pooling.properties
cp externalcache/memcachedConfig.properties /root/hudson/externalcache/src/main/resources/memcachedConfig.properties
cp externalcache/aerospikeConfig.properties /root/hudson/externalcache/src/main/resources/aerospikeConfig.properties
cp extRequestProcessor/extReqProcessorConfig.properties /root/hudson/netty/extReqProcessorConfig.properties
cp Integrations/cdn.properties /root/hudson/Integrations/src/main/resources/cdn.properties
cp DAL/CMS.properties /root/hudson/DAL/src/main/resources/CMS.properties
cp DAL/log4j.properties /root/hudson/DAL/src/main/resources/log4j.properties
cp ResponseGenerator/cdn.properties /root/hudson/ResponseGenerator/src/main/resources/cdn.properties
cp ResponseGenerator/TrackerConfig.properties /root/hudson/ResponseGenerator/src/main/resources/TrackerConfig.properties
########This is a temporary step. Would be removed later on#############################
#publicIP=`curl http://instance-data/latest/meta-data/public-ipv4`
#cat /root/hudson/ResponseGenerator/src/main/resources/TrackerConfig.properties | sed -e "s/trk2.vdopia.com/$publicIP/" >/root/hudson/ResponseGenerator/src/main/resources/TrackerConfig.properties
#cat ResponseGenerator/TrackerConfig.properties | sed -e "s/trk2.vdopia.com/$publicIP/" >/root/hudson/ResponseGenerator/src/main/resources/TrackerConfig.properties
########################################################################################
cp nettyclient/CMS.properties /root/hudson/nettyclient/src/main/resources/CMS.properties
cp nettyclient/log4j.properties /root/hudson/nettyclient/src/main/resources/log4j.properties
cp utils/CMS.properties /root/hudson/utils/src/main/resources/CMS.properties
cp utils/log4j.properties /root/hudson/utils/src/main/resources/log4j.properties
cp utils/QPSConfig.properties /root/hudson/utils/src/main/resources/QPSConfig.properties
cp cache/CMS.properties /root/hudson/cache/src/main/resources/CMS.properties
cp cache/log4j.properties /root/hudson/cache/src/main/resources/log4j.properties
cp cache/cacheConfig.properties /root/hudson/cache/src/main/resources/cacheConfig.properties
cp RequestHandler/maxmindConfig.properties /root/hudson/RequestHandler/src/main/resources/maxmindConfig.properties
#cp netty/spring.properties /root/hudson/netty/src/main/resources/spring.properties
cp netty/log4j.properties /root/hudson/netty/src/main/resources/log4j.properties
cp netty/Config.properties /root/hudson/netty/src/main/resources/Config.properties
cp netty/nettyConfig.properties /root/hudson/netty/src/main/resources/nettyConfig.properties
#cp netty/spring.properties /root/hudson/netty/src/main/resources/spring.properties
cp vast/vastConfig.properties /root/hudson/vast/src/main/resources/vastConfig.properties

cp settings.xml /root/hudson/

wget "http://liquidtelecom.dl.sourceforge.net/project/wurfl/WURFL%20Java%20API/1.5.1/core/wurfl-1.5.1-release.zip"
unzip wurfl-1.5.1-release.zip
mvn install:install-file -Dfile=wurfl-1.5.1.jar -DgroupId=com.wurfl -DartifactId=wurfl -Dversion=1.5.1 -Dpackaging=jar




#Updating JVM max heap size according to the total available physical memory
maxHeapSize=`cat /proc/meminfo | grep MemTotal | awk '{ print $2 * 0.68 / 1000}'`
intHeapSize=`printf '%.0f\n' $maxHeapSize`
if [ $? -eq 0 ]
then
        substutionString='-Xmx'$intHeapSize'm'
else
        substutionString='-Xmx10000m'
        echo "Substitution of JVM max heap failed due to $@ . Defaulting to 10GB"| /usr/sbin/sendmail pankaj.katiyar@vdopia.com
fi

sed -i  "s/-Xmx20000m/$substutionString/g" /root/hudson/netty/pom.xml

#Making configuration changes

echo "Configuration Changes Started."
export WORKSPACE=/root/hudson

#sed -i "s#/tmp/hudson/logs/hudson.log#/tmp/hudson/logs/hudson_ankur.log#g" $WORKSPACE/netty/log4j.properties

sed -i "s#trk2.vdopia.com#automation.qa.vdopia.com#g" $WORKSPACE/ResponseGenerator/src/main/resources/TrackerConfig.properties
sed -i "s#cs.vdopia.com#automation.qa.vdopia.com#g" $WORKSPACE/ResponseGenerator/src/main/resources/TrackerConfig.properties
sed -i -E "s#hostport = .+#hostport = localhost:11211#g" $WORKSPACE/externalcache/src/main/resources/memcachedConfig.properties
sed -i "s#OFF#TRACE#g" $WORKSPACE/netty/log4j.properties
sed -i "s#internal-Aerospike-persistent-658200165.us-east-1.elb.amazonaws.com#10.0.2.47#g" $WORKSPACE/externalcache/src/main/resources/aerospikeConfig.properties
sed -i "s#cache.aerospike.us-east-1.internal.vdopia.com#10.0.2.47#g" $WORKSPACE/externalcache/src/main/resources/aerospikeConfig.properties
#sed -i -E "s#filestore1path =.+#filestore1path = /mnt/filestore#g" $WORKSPACE/netty/reference.conf
#sed -i -E "s#awsS3bucketName =.+#awsS3bucketName = qaautomationawss3objectstore#g" $WORKSPACE/netty/reference.conf
#sed -i -E "s#awsS3accessKey =.+#awsS3accessKey = AKIAIJR2UQZSAQBV5BFQ#g" $WORKSPACE/netty/reference.conf
#sed -i -E "s#awesS3secretKey =.+#awesS3secretKey: \"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\"#g" $WORKSPACE/netty/reference.conf
echo "########################################################"

echo "Configuration Changes Completed."


#Updating tag in version file
echo "version_number=$tag" > /root/hudson/netty/src/main/resources/version.properties

#Compiling the code
mkdir -p /root/.m2/repository_live
cd /root/hudson
mvn clean package -DskipTests
if [ $? -eq 0 ]
then
        echo "Compiled and packaged code"
else
        echo "Failed while compiling code"
        exit 1
fi

##Restarting Data Layer java process
cp -f /root/hudson/netty/target/Netty.jar /root/hudson/netty/Netty.jar
sleep 5
service hudson stop
sleep 3
killall -9 java
service hudson start
sleep 3
