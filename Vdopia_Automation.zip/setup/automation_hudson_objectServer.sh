#!/bin/bash
set -x
#
# This script use for release tag in Objesct Server Instance
#

tag='v1.0'

while getopts ":t:h" opt; do
    case "$opt" in
        t)
            tag=$OPTARG
            ;;
    esac
done

if [ "${tag}" = "v1.0" ]; then
    echo "No tag provided. Cant release code" >&2
    exit 0
fi

#stopping objectserver service
service objectserver stop
rm -rf /root/enhancement
rm -rf /root/filestore/*
git clone git@bitbucket.org:vdopia/enhancement.git /root/enhancement

cd /root/enhancement
git reset --hard
git clean -f -d
git fetch
git fetch --tags
git checkout  $tag -f
if [ $? -eq 0 ]
then
        echo "ObjectServer repo checked out"
else
        echo "Failed while checking out ObjectServer repository"
        exit 1
fi

#check dir if not exist
DIR=/root/filestore
if [ ! -d "$DIR" ];then
        mkdir -p /root/filestore
else
        echo "$DIR Already Exists"
fi
#changes in reference.conf
cp /root/enhancement/Objectstore/src/main/resources/db-config.xml /root/enhancement/Objectstore/
sed -i 's#/Users/lokeshkohli/objectstore#/root/filestore#g' Objectstore/reference.conf
sed -i 's/devawss3objectstore/qaautomationawss3objectstore/g' Objectstore/reference.conf
sed -i 's/AKIAILSWR2Z5RMRO6UEQ/AKIAIJR2UQZSAQBV5BFQ/g' Objectstore/reference.conf
sed -i 's#2u0jiESDYuMY6xk6qxor7+tJz+UkcPD9kzuTFyLY#yFUa6IS67wCc8Utz3nYl9MTWLrhiNA2nRunFBWF2#g' Objectstore/reference.conf
##Chagnes in DB file
sed -i 's@\bdev\.vdopia\.com\b@serve.qa.vdopia.com@g' Objectstore/db-config.xml
#sed -i 's/\<root\>/object_server/g' Objectstore/db-config.xml
sed -i 's/\<root123\>/QA@1234/g' Objectstore/db-config.xml

#Updating JVM max heap size according to the total available physical memory
maxHeapSize=`cat /proc/meminfo | grep MemTotal | awk '{ print $2 * 0.68 / 1000}'`
intHeapSize=`printf '%.0f\n' $maxHeapSize`
if [ $? -eq 0 ]
then
        substutionString='-Xmx'$intHeapSize'm'
else
        substutionString='-Xmx10000m'
        echo "Substitution of JVM max heap failed due to $@ . Defaulting to 10GB"| /usr/sbin/sendmail ankur.agrawal@vdopia.com
fi

#this is # mark for entry not avialable in pom.xml
#sed -i  "s/-Xmx20000m/$substutionString/g" /root/enhancement/Objectstore/pom.xml



#Updating tag in version file
echo "version_number=$tag" > /root/enhancement/Objectstore/src/main/resources/version.properties

#Compiling the code
mkdir -p /root/.m2/repository_live
cd /root/enhancement/Objectstore
mvn clean package -DskipTests
if [ $? -eq 0 ]
then
        echo "Compiled and packaged code"
else
        echo "Failed while compiling code"
        exit 1
fi

##Restarting object server java process
cp -f /root/enhancement/Objectstore/target/ObjectServer.jar /root/enhancement/Objectstore/ObjectServer.jar
sleep 5
service objectserver stop
sleep 3
killall -9 java
service objectserver start
sleep 3
