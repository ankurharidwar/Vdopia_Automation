<?php
//ini_set('display_errors', 1);

header('Content-Type: text/xml');

function curPageURL() {
  $pageURL = 'http';

  if (array_key_exists('HTTPS', $_SERVER) && $_SERVER["HTTPS"] == "on") {$pageURL .= "s";}

  if (array_key_exists('HTTPS', $_SERVER) && $_SERVER["HTTPS"] == "on") 
  {$pageURL .= "s";}
  $pageURL .= "://";
  if ($_SERVER["SERVER_PORT"] != "80") {
    $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
  } else {
    $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
  }
  return $pageURL;
}

//handle GET Call
if ($_SERVER["REQUEST_METHOD"] == "GET") 
{
  $requesturl = curPageURL();
  $bidderfile = $_GET['filename'];
  $file = '/tmp/'.$bidderfile;
  $array = $_GET;
  //print_r($array);

  $requesturl = $_GET['bidderurl']."?";
  foreach($array as $key => $value)
  {
    if($key != 'filename' && $key != 'bidderurl')
    {
      $requesturl .= "&".$key."=".$value;
    }
  }

  $protocol = 'Test';
  if($_SERVER['SERVER_PORT'] == 443) 
  {
    $protocol = 'https://';
  }
  else
  {
    $protocol = 'http://';
  }

  $actualRequest = $protocol.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
  $curl = curl_init($requesturl);

  curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  $response = curl_exec($curl);

  //echo $response;

  file_put_contents($file.'request',$actualRequest);
  file_put_contents($file.'response',$response);

  //Add qaautomation extension in vast response so that automation code can recognize the bidder
  $xml = simplexml_load_file($file.'response');
  $qaautomation = $xml->Ad->InLine;
  $impression = $qaautomation->addChild('Impression', 'qaautomation_bidder_file_'.$bidderfile); 
  print_r($xml->asXML());
}

//Handle POST CALL
else
{
  header('Content-type: text/plain');

  $bidrequest = $_GET['bidderurl'];
  $bidderfile = $_GET['filename'];
  $file = '/tmp/'.$bidderfile;

  if ($_SERVER['REQUEST_METHOD'] === 'POST')
  {

    $postdata = file_get_contents("php://input");
    $array=json_decode($postdata);


    //$k=($array->site->id);
    //  if (($array->site->id)==$apikey OR ($array->app->id==$apikey))
    //  {
    $curl = curl_init($bidrequest);

    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    $resp = curl_exec($curl);

    //write bid request
    file_put_contents($file.'request', $postdata);

    //write bid response
    file_put_contents($file.'response', $resp);
    
    $resp=str_replace('Ad id=\"', 'Ad id=\"qaautomation_bidder_file_'.$bidderfile.':',$resp);
    echo $resp;
    //  }

    //  else
    //  {
    //    echo "\nAlert!! Different APIKEY: ".$k;
    //  }
  }
}

?>
