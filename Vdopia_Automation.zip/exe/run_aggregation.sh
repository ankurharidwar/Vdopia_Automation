

CURRENTDIR=`pwd`
cd `dirname $0`
EXEDIR=`pwd`
cd $CURRENTDIR

echo "#######   SETTING ENVIRONMENT FOR EXECUTION   ##########"
export AUTOMATION_HOME=`dirname $EXEDIR`

echo "AUTOMATION HOME is $AUTOMATION_HOME"

export ANT_HOME=$AUTOMATION_HOME/tpt/apache-ant-1.9.3_unix

echo "ANT_HOME is $ANT_HOME"

export PATH=$PATH:$ANT_HOME/bin
echo "PATH = $PATH"


LogFileLocation="$AUTOMATION_HOME/logs/"`date +'%Y_%m_%d'`
LogFileName=`date +'%Y_%m_%d_%H_%M_%S'`".txt"


echo '<?xml version="1.0" encoding="UTF-8"?> ' > testng_agg.xml
echo '<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd"> ' >> testng_agg.xml
echo '<suite name="Vdopia_Automation" parallel="none">' >> testng_agg.xml
echo '	<listeners> ' >> testng_agg.xml
echo '		<listener class-name="org.uncommons.reportng.HTMLReporter" /> ' >> testng_agg.xml
echo '		<listener class-name="org.uncommons.reportng.JUnitXMLReporter" /> ' >> testng_agg.xml
echo '	</listeners> ' >> testng_agg.xml
echo ' ' >> testng_agg.xml
echo '	<parameter name="browser" value="Chrome" /> ' >> testng_agg.xml
echo '	<parameter name="logFileLocation" ' >> testng_agg.xml
echo '		value="'$LogFileLocation'" /> ' >> testng_agg.xml
echo ' ' >> testng_agg.xml
echo '	<parameter name="logFileName" ' >> testng_agg.xml
echo '                value="'$LogFileName'" /> ' >> testng_agg.xml
echo '	<parameter name="serveSanityCampaign" value="No" /> ' >> testng_agg.xml
echo '	<parameter name="ReRun" value="No" /> ' >> testng_agg.xml
echo '	<parameter name="smokeTest" value="No" /> ' >> testng_agg.xml
echo '	<test name="AdServe"> ' >> testng_agg.xml
echo '		<classes> ' >> testng_agg.xml
echo '			<class name="projects.TestSuiteClass" /> ' >> testng_agg.xml
echo ' ' >> testng_agg.xml
echo '			<class name="aggregationReports.AggregationValidation" /> ' >> testng_agg.xml
echo ' ' >> testng_agg.xml
echo '		</classes>' >> testng_agg.xml
echo '	</test>' >> testng_agg.xml
echo '</suite>' >> testng_agg.xml
echo ' ' >> testng_agg.xml


cd $AUTOMATION_HOME


echo "###############     RUNNING TESTS ###############"
ant -buildfile $AUTOMATION_HOME/build_agg.xml

cd $CURRENTDIR


