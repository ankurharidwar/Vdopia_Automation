

python automation_gui.py

