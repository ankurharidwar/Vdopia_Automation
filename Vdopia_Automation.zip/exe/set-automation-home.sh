echo 'export AUTOMATION_HOME=$1' > $1/exe/load_env.sh; 
chmod 750 $1/exe/load_env.sh; 
source $1/exe/load_env.sh;
